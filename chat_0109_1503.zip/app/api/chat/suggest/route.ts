import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { decryptIfPossible } from "@/lib/crypto";
import { generateText } from "@/lib/ai";

function safeText(v: any) {
  return String(v ?? "").trim();
}

function sanitizeLastAssistantForSuggest(input: string) {
  const out = String(input || "")
    .replace(/\r\n/g, "\n")
    .split("\n")
    .map((ln) => {
      const t = String(ln || "").trim();
      if (!t) return "";
      // Hide stray separator lines that sometimes appear before images.
      if (/^[=＝]+$/.test(t)) return "";
      // Keep a stable token for images so the prompt is not empty.
      if (/^!\[[^\]]*\]\([^\)]+\)\s*$/.test(t)) return "[이미지]";
      if (/^https?:\/\/\S+\.(?:png|jpe?g|gif|webp)(?:\?\S*)?$/i.test(t)) return "[이미지]";
      return ln;
    })
    .filter(Boolean);
  return out.join("\n").trim();
}

function pickLastAssistantTextForSuggest(items: any[]) {
  for (const it of items) {
    const raw = decryptIfPossible(String(it?.content || "")).trim();
    const cleaned = sanitizeLastAssistantForSuggest(raw);
    // skip if effectively empty (e.g., only images/separators)
    if (cleaned && cleaned.replace(/\s+/g, " ").trim().length >= 10) return cleaned;
  }
  return "";
}

function stripMd(input: string) {
  return String(input || "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/!\[[^\]]*\]\([^\)]+\)/g, "[이미지]")
    .replace(/\[[^\]]*\]\([^\)]+\)/g, " ")
    .replace(/[#>*_`]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function pickKeyword(a: string, b: string) {
  const t = stripMd(a + " " + b);
  const tokens = t.split(" ").map((x) => x.trim()).filter(Boolean);
  const cand = tokens
    .map((x) => x.replace(/[\p{P}\p{S}]+/gu, ""))
    .filter((x) => x.length >= 2 && x.length <= 12);
  // 가장 최근 토큰 우선
  return cand.length ? cand[cand.length - 1] : "";
}

function heuristicSuggestions(lastUserText: string, lastAssistantText: string) {
  const kw = pickKeyword(lastUserText, lastAssistantText);
  const k = kw ? `\"${kw}\"` : "";

  const s1 =
    lastAssistantText.includes("?") || lastAssistantText.includes("？")
      ? `…응, ${k ? k + "에 대해" : "그 질문에"} 내 생각은 이래.`
      : `…알겠어. ${k ? k + "부터" : "바로"} 내가 먼저 해볼게.`;

  const s2 = k
    ? `…근데 ${k}는 정확히 뭘 말하는 거야? 한 번만 더 알려줘.`
    : "…잠깐, 지금 상황을 한 문장으로만 정리해줄래?";

  return [s1, s2];
}

function parseSuggestionsFromText(raw: string): string[] {
  const text = safeText(raw);
  if (!text) return [];

  // 1) JSON best-effort
  try {
    const a = text.indexOf("{");
    const b = text.lastIndexOf("}");
    const jsonText = a >= 0 && b > a ? text.slice(a, b + 1) : text;
    const parsed = JSON.parse(jsonText);
    if (Array.isArray(parsed?.suggestions)) {
      return parsed.suggestions
        .map((s: any) => safeText(s))
        .filter(Boolean)
        .slice(0, 2);
    }
  } catch {
    // ignore
  }

  // 2) line-based
  const cleaned = text.replace(/```[\s\S]*?```/g, "").trim();
  const lines = cleaned
    .split("\n")
    .map((l) => l.trim())
    .map((l) => l.replace(/^[-*\d\.\)\s]+/, "").trim())
    .filter(Boolean);

  const out: string[] = [];
  for (const l of lines) {
    const s = l.replace(/^"|"$/g, "").trim();
    if (!s) continue;
    out.push(s);
    if (out.length >= 2) break;
  }
  return out.slice(0, 2);
}

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const chatId = safeText(body?.chatId);
  if (!chatId) return NextResponse.json({ error: "chatId가 필요합니다." }, { status: 400 });

  // (핵심) 클라이언트가 방금 화면에 표시한 내용을 함께 보내면,
  // DB 저장 타이밍과 무관하게 정확한 추천답변을 만들 수 있다.
  const assistantContentFromClient = safeText(body?.assistantContent);
  const userContentFromClient = safeText(body?.userContent);
  const personaOverride = body?.personaOverride || null;

  // 마지막 assistant 메시지(여러 개) 가져오기
  const rows = (db
    .prepare(
      `SELECT m.content AS content
       FROM messages m
       WHERE m.chatId=? AND m.role='assistant'
       ORDER BY m.createdAt DESC
       LIMIT 8`
    )
    .all(chatId) || []) as any[];

  // 마지막 user 메시지도 함께
  const lastUserRow = db
    .prepare(
      `SELECT m.content AS content
       FROM messages m
       WHERE m.chatId=? AND m.role='user'
       ORDER BY m.createdAt DESC
       LIMIT 1`
    )
    .get(chatId) as any;

  const lastUserTextRaw = safeText(userContentFromClient || decryptIfPossible(String(lastUserRow?.content || "")));

  const lastAssistantFromClient = sanitizeLastAssistantForSuggest(assistantContentFromClient);
  const lastAssistant =
    lastAssistantFromClient && lastAssistantFromClient.replace(/\s+/g, " ").trim().length >= 10
      ? lastAssistantFromClient
      : pickLastAssistantTextForSuggest(rows);

  const system = [
    "너는 소설형 AI 채팅의 '추천 답변' 생성기다.",
    "반드시 한국어로만 답한다.",
    "반드시 '주인공(사용자)' 1인칭 시점의 대사로만 2개를 만든다.",
    "지문(상황 설명) 금지. 대사(말)만.",
    "너무 길게 쓰지 말고, 한 줄씩 자연스럽게.",
    "출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\"]}",
  ].join("\n");

  const personaLine = personaOverride
    ? `주인공 정보(참고): 이름=${safeText(personaOverride?.personaName)}, 나이=${Number(personaOverride?.personaAge || 0)}, 성별=${safeText(personaOverride?.personaGender)}, 설명=${safeText(personaOverride?.personaInfo)}`
    : "";

  const user = [
    personaLine,
    "[직전 사용자 발화]",
    lastUserTextRaw,
    "\n[직전 상대 발화/지문]",
    lastAssistant || "(상대 발화 없음)",
    "\n위 내용에 대해, 주인공(사용자)이 다음에 할 법한 대사 2개를 추천해줘.",
  ]
    .filter(Boolean)
    .join("\n");

  const modelOrder = ["gemini-3-flash-preview", "gemini-2.5-pro", "gemini-3-pro-preview"] as const;

  let rawText = "";
  for (const model of modelOrder) {
    try {
      const r = await generateText({
        system,
        user,
        opts: {
          model,
          maxOutputTokens: 220,
          maxReasoningTokens: 0,
        },
      });
      rawText = safeText((r as any)?.text);
      if (rawText) break;
    } catch {
      // try next model
    }
  }

  let suggestions = parseSuggestionsFromText(rawText);
  if (!suggestions || suggestions.length < 2) {
    suggestions = heuristicSuggestions(lastUserTextRaw, lastAssistant);
  }

  // 보장: 2개 / 중복 제거
  const uniq: string[] = [];
  for (const s of suggestions) {
    const v = safeText(s);
    if (!v) continue;
    if (!uniq.includes(v)) uniq.push(v);
    if (uniq.length >= 2) break;
  }
  while (uniq.length < 2) uniq.push(uniq[0] || "…");

  return NextResponse.json({ suggestions: uniq.slice(0, 2) });
}
