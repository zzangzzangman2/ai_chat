import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// 기본값(턴당 요약 글자수) - 서버/클라이언트 공통
// (공백 포함) / 10~200 범위의 step 10 정책에서 default는 50.
const DEFAULT_SUMMARY_LENGTH = 50;
const DEFAULT_RENDER_MODE: "chat" | "novel" = "novel";

const ALLOWED_MODELS = new Set([
  "gemini-3-pro-preview",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
]);

function clampStepInt(n: any, def: number, min: number, max: number, step: number) {
  const v = Number(n);
  if (!Number.isFinite(v)) return def;
  const i = Math.floor(v);
  const snapped = Math.round((i - min) / step) * step + min;
  return Math.min(max, Math.max(min, snapped));
}

function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const chatId = searchParams.get("chatId") || "";
  if (!chatId) return bad("chatId가 필요합니다.");

  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const chat = db.prepare(`SELECT id FROM chats WHERE id=? AND userEmail=?`).get(chatId, u.email);
  if (!chat) return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });

  const row = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(chatId);
  // 설정이 아직 없으면(새 채팅/마이그레이션) 기본값으로 내려준다.
  if (!row) {
    const defaults = {
      chatId,
      personaName: "",
      personaAge: 0,
      personaGender: "",
      personaInfo: "",
      // 최근 원문(유저 입력) 턴수 (user 메시지 1개 = 1턴)
      // keepUserTurns가 정식 키. memoryFrom은 DB/클라이언트 호환을 위해 유지.
      keepUserTurns: 12,
      memoryFrom: 12,
      memoryTo: 24,
      recentSummaryN: 50,
      // 장기기억(새 규격)
      // summaryEvery: 요약 주기(턴)
      // summaryLength: 턴당 글자수(자/턴)
      summaryEvery: 5,
      // 10~200(10단위)로 운용 (default 50)
      summaryLength: DEFAULT_SUMMARY_LENGTH,
      userNote: "",
      model: "gemini-2.5-pro",
      // 기본 출력 길이(슬라이더 초기값)
      // 출력/추론 기본값(UX 기준)
      // NOTE: 서버(route.ts)는 maxOutputTokens 값을 "목표 글자수"로 해석한다.
      // UI 프리셋(1200/1700/2500) 기준의 기본값은 1700자.
      maxOutputTokens: 1700,
      maxReasoningTokens: 768,
      // 기본 지문 색상 (RGB 204,199,199)
      narrationColor: "#CCC7C7",

      // 기본 모드: 소설
      renderMode: DEFAULT_RENDER_MODE,
      updatedAt: Date.now(),
    };
    return NextResponse.json({ settings: defaults });
  }

  // 기존 DB에 예전 기본값(4턴) 등이 저장되어 있으면, UX를 위해 자동 보정한다.
  const patched: any = { ...row };
  let changed = false;
  // 모델 마이그레이션: gemini-2.5-flash는 제거되었으므로 2.5-pro로 자동 교체
  if (patched.model === "gemini-2.5-flash") {
    patched.model = "gemini-2.5-pro";
    changed = true;
  }

  // renderMode 기본값 보정(마이그레이션/미존재 컬럼 대응)
  if (patched.renderMode !== 'chat' && patched.renderMode !== 'novel') {
    patched.renderMode = DEFAULT_RENDER_MODE;
    changed = true;
  }
  // keepUserTurns가 정식 키. legacy(memoryFrom)와 항상 동기화한다.
  const k0 = Number((patched as any).keepUserTurns ?? patched.memoryFrom ?? 12);
  const k = Number.isFinite(k0) ? Math.max(12, Math.min(20, Math.floor(k0))) : 12;
  if ((patched as any).keepUserTurns !== k) {
    (patched as any).keepUserTurns = k;
    changed = true;
  }
  if (patched.memoryFrom !== k) {
    patched.memoryFrom = k;
    changed = true;
  }
  
  // 장기기억(새 규격) 범위 보정
  // - 요약 주기: 3~12턴 (default 5)
  // - 턴당 글자수: 10~200(10단위) (default 50)
  if (Number(patched.summaryEvery ?? 0) < 3) {
    patched.summaryEvery = 3;
    changed = true;
  }
  if (Number(patched.summaryEvery ?? 0) > 12) {
    patched.summaryEvery = 12;
    changed = true;
  }
  {
    const normalized = clampStepInt(patched.summaryLength, DEFAULT_SUMMARY_LENGTH, 10, 200, 10);
    if (normalized !== Number(patched.summaryLength)) {
      patched.summaryLength = normalized;
      changed = true;
    }
  }
// 출력/추론 범위도 벗어나면 보정
  // 기존 프로젝트의 과거 기본값(2000/1024)을 새 기본값(1700/768)으로 UX 보정
  // (유저가 의도적으로 크게 저장한 경우는 settings 저장을 통해 다시 변경 가능)
  if (Number(patched.maxOutputTokens ?? 0) === 2000 && Number(patched.maxReasoningTokens ?? 0) === 1024) {
    patched.maxOutputTokens = 1700;
    patched.maxReasoningTokens = 768;
    changed = true;
  }
  if (Number(patched.maxOutputTokens ?? 1700) < 800) {
    patched.maxOutputTokens = 800;
    changed = true;
  }
  if (Number(patched.maxReasoningTokens ?? 768) < 256) {
    patched.maxReasoningTokens = 256;
    changed = true;
  }
  if (changed) {
    db.prepare(
      `UPDATE chat_settings
       SET model=?, memoryFrom=?, keepUserTurns=?, summaryEvery=?, summaryLength=?, maxOutputTokens=?, maxReasoningTokens=?, renderMode=?, updatedAt=?
       WHERE chatId=?`
    ).run(
      patched.model,
      patched.memoryFrom,
      (patched as any).keepUserTurns ?? patched.memoryFrom,
      patched.summaryEvery,
      patched.summaryLength,
      patched.maxOutputTokens,
      patched.maxReasoningTokens,
      patched.renderMode,
      Date.now(),
      chatId
    );
  }

  return NextResponse.json({ settings: patched });
}

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const body = await req.json();
  const chatId = (body.chatId || "").trim();
  if (!chatId) return bad("chatId가 필요합니다.");

  const chat = db.prepare(`SELECT id FROM chats WHERE id=? AND userEmail=?`).get(chatId, u.email);
  if (!chat) return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });

  const personaName = String(body.personaName || "").trim();
  const personaAge = Number(body.personaAge || 0);
  const personaGender = String(body.personaGender || "").trim();
  const personaInfo = String(body.personaInfo || "").trim();

  // keepUserTurns: 최근 원문으로 포함할 user턴 수 (12~20)
  // - 정식 키: keepUserTurns
  // - legacy 키: memoryFrom (DB/클라이언트 호환)
  const keepUserTurnsIn = Number(body.keepUserTurns ?? body.memoryFrom ?? 16);
  const keepUserTurns = keepUserTurnsIn;

  // memoryFrom: legacy (DB/클라이언트 호환을 위해 동일 값으로 저장)
  const memoryFrom = keepUserTurns;
  // memoryTo: deprecated (DB 호환)
  const memoryTo = Number(body.memoryTo ?? 24);
  const recentSummaryN = Number(body.recentSummaryN ?? 50); // (deprecated, kept for DB compat)
  const summaryEvery = clampStepInt(body.summaryEvery ?? 5, 5, 3, 12, 1);
  const summaryLength = clampStepInt(body.summaryLength ?? DEFAULT_SUMMARY_LENGTH, DEFAULT_SUMMARY_LENGTH, 10, 200, 10);
  const narrationColor = String(body.narrationColor || '#666666');

  // 기본 모드: 소설
  const renderMode: "chat" | "novel" = (body.renderMode === 'chat' || body.renderMode === 'novel')
    ? body.renderMode
    : DEFAULT_RENDER_MODE;

  const userNote = String(body.userNote || "");

  let model = String(body.model || "gemini-2.5-pro");
  // 과거 저장값/클라이언트 호환: flash는 목록에서 제거되었으므로 pro로 자동 치환
  if (model === "gemini-2.5-flash") model = "gemini-2.5-pro";
  const maxOutputTokens = Number(body.maxOutputTokens ?? 1700);
  const maxReasoningTokens = Number(body.maxReasoningTokens ?? 768);

  // --- Validation (한글 에러) ---
  if (personaAge && (!Number.isFinite(personaAge) || personaAge < 0)) return bad("나이는 숫자로 적어주세요.");
  if (!Number.isFinite(keepUserTurns) || keepUserTurns < 12 || keepUserTurns > 20) return bad("최근 원문 턴수는 12~20 사이에서 설정해 주세요.");
  if (!Number.isFinite(summaryLength) || summaryLength < 10 || summaryLength > 200) return bad("턴당 글자수는 10~200 사이에서 10단위로 설정해 주세요.");
  if (summaryLength % 10 !== 0) return bad("턴당 글자수는 10~200 사이에서 10단위로 설정해 주세요.");
  if (!Number.isFinite(summaryEvery) || summaryEvery < 3 || summaryEvery > 12) return bad("요약 주기는 3~12 사이에서 설정해 주세요.");
  if (!ALLOWED_MODELS.has(model)) return bad('지원하지 않는 모델입니다.');
  if (!/^#[0-9a-fA-F]{6}$/.test(narrationColor)) return bad('지문 색상 값이 올바르지 않습니다.');
  if (renderMode !== 'chat' && renderMode !== 'novel') return bad('renderMode 값이 올바르지 않습니다.');

  // NOTE: UI에서는 "출력길이"를 글자수(자)로 노출한다. (route.ts도 글자수 기반으로 목표를 잡음)
  if (maxOutputTokens < 800 || maxOutputTokens > 5000) return bad("출력길이는 800~5000자 사이로 설정해 주세요.");
  if (maxReasoningTokens < 256 || maxReasoningTokens > 8192) return bad("추론길이는 256~8192 토큰 사이로 설정해 주세요.");

  const now = Date.now();

  db.prepare(
    `INSERT INTO chat_settings (
      chatId, personaName, personaAge, personaGender, personaInfo,
      memoryFrom, memoryTo, keepUserTurns, recentSummaryN, summaryEvery, summaryLength,
      userNote, model, maxOutputTokens, maxReasoningTokens, narrationColor, renderMode, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(chatId) DO UPDATE SET
      personaName=excluded.personaName,
      personaAge=excluded.personaAge,
      personaGender=excluded.personaGender,
      personaInfo=excluded.personaInfo,
      memoryFrom=excluded.memoryFrom,
      memoryTo=excluded.memoryTo,
      keepUserTurns=excluded.keepUserTurns,
      recentSummaryN=excluded.recentSummaryN,
      summaryEvery=excluded.summaryEvery,
      summaryLength=excluded.summaryLength,
      narrationColor=excluded.narrationColor,
      renderMode=excluded.renderMode,
      userNote=excluded.userNote,
      model=excluded.model,
      maxOutputTokens=excluded.maxOutputTokens,
      maxReasoningTokens=excluded.maxReasoningTokens,
      updatedAt=excluded.updatedAt
    `
  ).run(
    chatId,
    personaName,
    personaAge || 0,
    personaGender,
    personaInfo,
    memoryFrom,
    memoryTo,
    keepUserTurns,
    recentSummaryN,
    summaryEvery,
    summaryLength,
    userNote,
    model,
    maxOutputTokens,
    maxReasoningTokens,
    narrationColor,
    renderMode,
    now
  );

  const row = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(chatId);
  return NextResponse.json({ settings: row });
}
