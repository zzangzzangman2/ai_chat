import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";

// 장기기억(턴당 글자수) 기본값: LOW(40)
// (공백 포함) / 30~200(10단위)
const DEFAULT_SUMMARY_LENGTH = 40;
const DEFAULT_RENDER_MODE: "chat" | "novel" = "novel";

const ALLOWED_MODELS = new Set([
  "gemini-3-pro-preview",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
]);

function clampStepInt(n: any, def: number, min: number, max: number, step: number) {
  const v = Number(n);
  if (!Number.isFinite(v)) return def;
  const i = Math.floor(v);
  const snapped = Math.round((i - min) / step) * step + min;
  return Math.min(max, Math.max(min, snapped));
}

function defaultReasoningTokens(model: string): number {
  // UX 기준: 모두 LOW가 기본
  if (model === "gemini-3-pro-preview") return 512;
  if (model === "gemini-3-flash-preview") return 256;
  // gemini-2.5-pro
  return 256;
}

function bad(msg: string, status: number = 400) {
  return NextResponse.json({ error: msg }, { status });
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const chatId = (searchParams.get("chatId") || "").trim();
  if (!chatId) return bad("chatId가 필요합니다.");

  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const chat = db.prepare(`SELECT id FROM chats WHERE id=? AND userEmail=?`).get(chatId, u.email);
  if (!chat) return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });

  const row = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(chatId) as any;

  // 설정이 아직 없으면(새 채팅/마이그레이션) 기본값(LOW)으로 내려준다.
  if (!row) {
    const model = "gemini-2.5-pro";
    const defaults = {
      chatId,
      personaName: "",
      personaAge: 0,
      personaGender: "",
      personaInfo: "",

      // 최근 원문(유저 입력) 고정 7턴
      keepUserTurns: 7,
      memoryFrom: 7,
      memoryTo: 24,
      recentSummaryN: 50,

      // 장기기억(새 규격)
      summaryEvery: 5,
      summaryLength: DEFAULT_SUMMARY_LENGTH,

      userNote: "",
      model,

      // 출력/추론 기본값(LOW)
      maxOutputTokens: 1200,
      maxReasoningTokens: defaultReasoningTokens(model),

      // 기본 지문 색상 (RGB 204,199,199)
      narrationColor: "#CCC7C7",

      renderMode: DEFAULT_RENDER_MODE,
      updatedAt: Date.now(),
    };
    return NextResponse.json({ settings: defaults });
  }

  // 기존 DB 값이 예전 기본값이면 UX 기준(LOW)으로 자동 보정
  const patched: any = { ...row };
  let changed = false;

  // 모델 마이그레이션
  if (patched.model === "gemini-2.5-flash") {
    patched.model = "gemini-2.5-pro";
    changed = true;
  }

  // renderMode 보정 (소설 모드만 지원)
  if (patched.renderMode !== "novel") {
    patched.renderMode = "novel";
    changed = true;
  }

  // keepUserTurns/memoryFrom 고정 7턴
  if (Number(patched.keepUserTurns ?? 0) !== 7) {
    patched.keepUserTurns = 7;
    changed = true;
  }
  if (Number(patched.memoryFrom ?? 0) !== 7) {
    patched.memoryFrom = 7;
    changed = true;
  }

  // 장기기억 고정 5턴 + length 범위/스텝 보정
  if (Number(patched.summaryEvery ?? 0) !== 5) {
    patched.summaryEvery = 5;
    changed = true;
  }
  {
    const normalized = clampStepInt(patched.summaryLength, DEFAULT_SUMMARY_LENGTH, 30, 200, 10);
    if (normalized !== Number(patched.summaryLength)) {
      patched.summaryLength = normalized;
      changed = true;
    }
  }

  // 출력/추론 범위도 벗어나면 보정
  if (Number(patched.maxOutputTokens ?? 0) < 800) {
    patched.maxOutputTokens = 800;
    changed = true;
  }
  if (Number(patched.maxReasoningTokens ?? 0) < 256) {
    patched.maxReasoningTokens = 256;
    changed = true;
  }

  // 예전 기본값 감지 → LOW로 downshift
  const mo = Number(patched.maxOutputTokens ?? 0);
  const mr = Number(patched.maxReasoningTokens ?? 0);
  const sl = Number(patched.summaryLength ?? 0);

  const looksLikeOldDefaults =
    (mo === 1700 && mr === 768 && sl === 80) ||
    (mo === 2000 && mr === 1024) ||
    (mo === 1300 && mr === 768 && sl === 120);

  if (looksLikeOldDefaults) {
    patched.maxOutputTokens = 1200;
    patched.maxReasoningTokens = defaultReasoningTokens(String(patched.model || ""));
    patched.summaryLength = DEFAULT_SUMMARY_LENGTH;
    changed = true;
  }

  if (changed) {
    db.prepare(
      `UPDATE chat_settings
       SET model=?, memoryFrom=?, keepUserTurns=?, summaryEvery=?, summaryLength=?, maxOutputTokens=?, maxReasoningTokens=?, renderMode=?, updatedAt=?
       WHERE chatId=?`
    ).run(
      patched.model,
      patched.memoryFrom,
      patched.keepUserTurns,
      patched.summaryEvery,
      patched.summaryLength,
      patched.maxOutputTokens,
      patched.maxReasoningTokens,
      patched.renderMode,
      Date.now(),
      chatId
    );
  }

  return NextResponse.json({ settings: patched });
}

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const body = await req.json();
  const chatId = String(body.chatId || "").trim();
  if (!chatId) return bad("chatId가 필요합니다.");

  const chat = db.prepare(`SELECT id FROM chats WHERE id=? AND userEmail=?`).get(chatId, u.email);
  if (!chat) return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });

  const personaName = String(body.personaName || "").trim();
  const personaAge = Number(body.personaAge || 0);
  const personaGender = String(body.personaGender || "").trim();
  const personaInfo = String(body.personaInfo || "").trim();

  // 고정 규칙
  const keepUserTurns = 7;
  const memoryFrom = 7;
  const memoryTo = Number(body.memoryTo ?? 24);
  const recentSummaryN = Number(body.recentSummaryN ?? 50);
  const summaryEvery = 5;
  const summaryLength = clampStepInt(body.summaryLength ?? DEFAULT_SUMMARY_LENGTH, DEFAULT_SUMMARY_LENGTH, 30, 200, 10);

  const narrationColor = String(body.narrationColor || "#CCC7C7");
  // 소설 모드만 지원 (클라이언트 입력값은 무시)
  const renderMode: "novel" = "novel";

  const userNote = String(body.userNote || "");

  let model = String(body.model || "gemini-2.5-pro");
  if (model === "gemini-2.5-flash") model = "gemini-2.5-pro";

  const maxOutputTokens = Number(body.maxOutputTokens ?? 1200);
  const maxReasoningTokens = Number(body.maxReasoningTokens ?? defaultReasoningTokens(model));

  // --- Validation ---
  if (personaAge && (!Number.isFinite(personaAge) || personaAge < 0)) return bad("나이는 숫자로 적어주세요.");
  if (!Number.isFinite(summaryLength) || summaryLength < 30 || summaryLength > 200) return bad("턴당 글자수는 30~200 사이에서 10단위로 설정해 주세요.");
  if (summaryLength % 10 !== 0) return bad("턴당 글자수는 30~200 사이에서 10단위로 설정해 주세요.");
  if (!ALLOWED_MODELS.has(model)) return bad("지원하지 않는 모델입니다.");
  if (!/^#[0-9a-fA-F]{6}$/.test(narrationColor)) return bad("지문 색상 값이 올바르지 않습니다.");

  // NOTE: UI에서는 "출력길이"를 글자수(자)로 노출한다.
  if (maxOutputTokens < 800 || maxOutputTokens > 5000) return bad("출력길이는 800~5000자 사이로 설정해 주세요.");
  if (maxReasoningTokens < 256 || maxReasoningTokens > 8192) return bad("추론길이는 256~8192 토큰 사이로 설정해 주세요.");

  const now = Date.now();

  db.prepare(
    `INSERT INTO chat_settings (
      chatId, personaName, personaAge, personaGender, personaInfo,
      memoryFrom, memoryTo, keepUserTurns, recentSummaryN, summaryEvery, summaryLength,
      userNote, model, maxOutputTokens, maxReasoningTokens, narrationColor, renderMode, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(chatId) DO UPDATE SET
      personaName=excluded.personaName,
      personaAge=excluded.personaAge,
      personaGender=excluded.personaGender,
      personaInfo=excluded.personaInfo,
      memoryFrom=excluded.memoryFrom,
      memoryTo=excluded.memoryTo,
      keepUserTurns=excluded.keepUserTurns,
      recentSummaryN=excluded.recentSummaryN,
      summaryEvery=excluded.summaryEvery,
      summaryLength=excluded.summaryLength,
      narrationColor=excluded.narrationColor,
      renderMode=excluded.renderMode,
      userNote=excluded.userNote,
      model=excluded.model,
      maxOutputTokens=excluded.maxOutputTokens,
      maxReasoningTokens=excluded.maxReasoningTokens,
      updatedAt=excluded.updatedAt`
  ).run(
    chatId,
    personaName,
    personaAge || 0,
    personaGender,
    personaInfo,
    memoryFrom,
    memoryTo,
    keepUserTurns,
    recentSummaryN,
    summaryEvery,
    summaryLength,
    userNote,
    model,
    maxOutputTokens,
    maxReasoningTokens,
    narrationColor,
    renderMode,
    now
  );

  const row = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(chatId);
  return NextResponse.json({ settings: row });
}
