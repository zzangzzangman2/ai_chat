// Utilities for working with the stored long-memory summary blocks.
// Pure helpers only (no DB/network), so they can be reused safely.

export type SummaryRangeBlock = { startTurn: number; endTurn: number };

export function strlenSummary(x: any): number {
  return String(x || "").length;
}

// 저장된 장기기억 요약에 과거 설정/버그로 인한 "혼합 블록(1-5 + 1-3 등)"이 섞이면
// 프롬프트 품질/UI 가독성이 깨질 수 있어, 현재 summaryEvery에 맞는 블록만 정규화한다.
export function normalizeStoredMemorySummary(summary: string, every: number): string {
  const src = String(summary || "").trim();
  if (!src) return "";

  const re = /^\s*##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*턴\s*\)\s*$/gm;
  const hits: { start: number; end: number; idx: number }[] = [];
  for (const m of src.matchAll(re)) {
    const a = Number(m[1] || 0);
    const b = Number(m[2] || 0);
    if (!Number.isFinite(a) || !Number.isFinite(b) || a <= 0 || b <= 0) continue;
    const start = Math.min(a, b);
    const end = Math.max(a, b);

    // 길이/정렬 체크
    // - 일반 블록: (start-1)%every==0 AND end==start+every-1
    // - 롤업 블록: 1부터 시작하고, (end-start+1)이 every의 배수인 범위(여러 구간을 1개로 압축)
    const size = end - start + 1;
    const isRollup =
      start === 1 &&
      every > 0 &&
      size >= every &&
      size % every === 0 &&
      end % every === 0;

    if (!isRollup) {
      if (size !== every) continue;
      if ((start - 1) % every !== 0) continue;
      if (end !== start + every - 1) continue;
    }

    hits.push({ start, end, idx: (m.index ?? 0) as number });
  }
  if (!hits.length) return "";

  hits.sort((x, y) => x.idx - y.idx);
  const byKey = new Map<string, { start: number; end: number; body: string }>();

  for (let i = 0; i < hits.length; i++) {
    const h = hits[i];
    const startIdx = h.idx;
    const nextIdx = i + 1 < hits.length ? hits[i + 1].idx : src.length;
    const blockText = src.slice(startIdx, nextIdx).trim();
    const parts = blockText.split(/\r?\n\r?\n/);
    const body = (parts.slice(1).join("\n\n") || "").trim();
    if (body.replace(/\s+/g, "").length < 20) continue;
    // 마지막이 우선
    byKey.set(`${h.start}-${h.end}`, { start: h.start, end: h.end, body });
  }

  const blocks = [...byKey.values()].sort((a, b) => a.start - b.start);
  return blocks
    .map((b) => `## 장기 기억 (${b.start}-${b.end}턴)\n\n${b.body}`.trim())
    .join("\n\n");
}

// (보정) summarizeKorean 결과가 구간 턴 번호를 1부터 다시 매기는 경우가 있어,
// 이번에 요약한 assistantTurn 범위(startTurn..endTurn)에 맞게 헤더의 (N턴)/(A-B턴) 표기를 오프셋 보정한다.
// - 대상: '##'/'###' 헤더 라인의 '(..턴)' 표기만
// - '## 장기 기억 (추가 구간)' 같은 비정상 라벨은 '(start-end턴)'으로 강제
export function fixSummaryTurnLabels(summaryChunk: string, startTurn: number, endTurn: number): string {
  const raw = String(summaryChunk || "").trim();
  if (!raw) return raw;

  const st = Math.max(1, Math.floor(startTurn));
  const ed = Math.max(st, Math.floor(endTurn));

  // 모델이 (1-2턴)처럼 "상대 턴"을 쓰는 경우가 많아서 기본은 st-1 만큼 shift한다.
  // 다만 이미 (6-10턴) 같은 "절대 턴" 라벨이 섞여 있으면 shift하지 않는다.
  const detectOffset = () => {
    const s = String(raw || "");
    const nums: number[] = [];
    const re = /\(\s*(\d+)\s*(?:-\s*(\d+)\s*)?턴\s*\)/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(s))) {
      const a = Number(m[1] || 0);
      const b = m[2] != null ? Number(m[2] || 0) : 0;
      if (Number.isFinite(a) && a > 0) nums.push(a);
      if (Number.isFinite(b) && b > 0) nums.push(b);
    }
    if (!nums.length) return st - 1;
    const min = Math.min(...nums);
    const max = Math.max(...nums);

    // 이미 절대 턴(>=st)이 포함되어 있으면 offset=0
    if (min >= st && max <= ed) return 0;
    if (nums.some((n) => n >= st)) return 0;

    return st - 1;
  };
  const offset = detectOffset();

  const lines = raw.split(/\r?\n/);
  const out: string[] = [];

  const shiftRange = (a: number, b?: number) => {
    const aa = Math.max(1, a + offset);
    const bb = b == null ? undefined : Math.max(1, b + offset);
    return { aa, bb };
  };

  for (let line of lines) {
    const trimmed = line.trimStart();

    // top-level 장기 기억 헤더는 범위를 강제
    if (/^##\s*장기\s*기억\b/.test(trimmed)) {
      // (중요) top-level header는 항상 a-b 형태로 고정한다.
      // - single-turn(4턴) 형태는 다른 parser/validator에서 누락될 수 있어 4-4로 통일
      const forced = `## 장기 기억 (${st}-${ed}턴)`;
      // 기존 헤더의 뒤쪽 텍스트는 유지(있다면)
      const rest = trimmed.replace(/^##\s*장기\s*기억\b\s*(\([^)]*\))?\s*/, "");
      line = forced + (rest ? " " + rest : "");
      out.push(line);
      continue;
    }

    // '##'/'###' 헤더에서만 '(..턴)'을 보정한다.
    if (/^#{2,3}\s+/.test(trimmed) && /\(\s*\d+(?:\s*-\s*\d+)?\s*턴\s*\)/.test(trimmed)) {
      line = line.replace(/\(\s*(\d+)\s*(?:-\s*(\d+)\s*)?턴\s*\)/g, (whole, a, b) => {
        const aa = Number(a || 0);
        const bb = b != null ? Number(b || 0) : undefined;
        if (!Number.isFinite(aa) || aa <= 0) return whole;
        if (bb != null && (!Number.isFinite(bb) || bb <= 0)) return whole;

        const shifted = shiftRange(aa, bb);
        const A = shifted.aa;
        const B = shifted.bb;

        // 범위 밖이 너무 튀면 clamp(안전)
        const clamp = (x: number) => Math.max(st, Math.min(ed, x));
        const Ac = clamp(A);
        const Bc = B == null ? undefined : clamp(B);

        if (Bc == null || Ac === Bc) return `(${Ac}턴)`;
        const lo = Math.min(Ac, Bc);
        const hi = Math.max(Ac, Bc);
        return `(${lo}-${hi}턴)`;
      });
    }

    // '추가 구간' 단어가 남아 있으면 제거(가독성)
    line = line.replace(/\(\s*추가\s*구간\s*\)/g, `(${st}-${ed}턴)`);

    out.push(line);
  }

  return out.join("\n").trim();
}

export function extractSummaryRangeBlocks(summary: string): SummaryRangeBlock[] {
  const text = String(summary || "");
  const re = /^\s*##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*턴\s*\)\s*$/gm;
  const out: SummaryRangeBlock[] = [];
  for (const m of text.matchAll(re)) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    if (!Number.isFinite(a) || !Number.isFinite(b) || a < 1 || b < a) continue;
    out.push({ startTurn: a, endTurn: b });
  }
  return out;
}

export function getSummarizedEndTurn(summary: string): number {
  const blocks = extractSummaryRangeBlocks(String(summary || ""));
  if (!blocks.length) return 0;
  return Math.max(...blocks.map((b) => b.endTurn));
}
