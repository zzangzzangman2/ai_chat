export function normalizeSummaryTail(summaryText: string): string {
  const t = String(summaryText || "").trimEnd();
  if (!t) return t;

  const lines = t.split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i--) {
    const lnRaw = lines[i];
    const ln = String(lnRaw || "").trim();
    if (!ln) continue;

    // 헤더 라인은 그대로 둔다.
    if (/^#{2,4}\s+/.test(ln)) break;

    // 문장부호로 끝나면 OK
    if (/[.!?…。]$/.test(ln)) break;

    // 한국어 종결형(다/요)로 끝나면 마침표를 보강
    if (/[다요]$/.test(ln)) {
      lines[i] = ln + ".";
      break;
    }

    // 그 외는 '끊긴 문장' 가능성이 있지만, UI에서 내용이 사라지며 "빠지는" 현상이 생길 수 있어
    // 가능한 한 완결로 보강한다.
    if (ln.length <= 8) {
      lines.splice(i, 1);
      break;
    }
    if (/[가-힣]/.test(ln)) {
      lines[i] = ln + ".";
      break;
    }
    // 한국어가 거의 없는 경우에는 제거(노이즈)
    lines.splice(i, 1);
    break;
  }

  return lines.join("\n").trimEnd();
}

// (안전) 장기기억 요약에 모델이 프롬프트/메타 텍스트를 그대로 섞어 반환하는 경우가 있어
// UI/DB에 저장하기 전에 제거한다.
// - "start_thought" / 영어 지시문 / Dialogue Context 등
// - 유효한 "## 장기 기억 (a-b턴)" 블록만 남긴다.

export function sanitizeLongMemorySummary(input: string, summaryEvery: number): string {
  const raw = String(input || "").replace(/\r\n/g, "\n");
  const headerRe = /^##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*(?:턴)?\s*\)\s*$/gm;

  type Hit = { start: number; end: number; idx: number; len: number };
  const hits: Hit[] = [];
  for (const m of raw.matchAll(headerRe)) {
    const idx = m.index ?? 0;
    const st = Number(m[1]);
    const ed = Number(m[2]);
    if (!Number.isFinite(st) || !Number.isFinite(ed) || ed < st) continue;
    hits.push({ start: st, end: ed, idx, len: m[0].length });
  }
  if (hits.length === 0) return "";

  // Sort by appearance order (idx) to slice bodies
  hits.sort((a, b) => a.idx - b.idx);

  const byStart = new Map<number, { start: number; end: number; text: string }>();

  const isMetaLine = (t: string) => {
    return (
      /^start_thought\b/i.test(t) ||
      /Long[- ]term Memory Summary Writer/i.test(t) ||
      /Dialogue Context/i.test(t) ||
      /Correction on Turn Indexing/i.test(t) ||
      /^Korean only\./i.test(t) ||
      /^Markdown\./i.test(t) ||
      /^Summary of the provided/i.test(t)
    );
  };

  const sanitizeBody = (body: string, blockStart: number) => {
    let out = String(body || "").replace(/\r\n/g, "\n");

    // remove meta + dialogue echo lines
    const lines = out.split("\n");
    const kept: string[] = [];
    for (const line of lines) {
      const tr = line.trim();
      if (!tr) {
        kept.push(line);
        continue;
      }
      if (isMetaLine(tr)) continue;
      if (/^###\s*\(대화\s*요약\)/.test(tr)) continue;
      if (/(사용자\s*:|어시스턴트\s*:|User\s*:|Assistant\s*:)/i.test(tr)) continue;
      kept.push(line);
    }
    out = kept.join("\n");

	  // Remove legacy KSEP label lines that waste budget and often get cut mid-word.
	  const labelStarts = ["[핵심 사건]", "[정보/설정]", "[감정/태도]", "[합의/약속]"];
	  out = out
	    .split("\n")
	    .filter((ln) => {
	      const t = (ln || "").trim();
	      if (!t) return true;
	      return !labelStarts.some((p) => t.startsWith(p));
	    })
	    .join("\n");
	  for (const lab of labelStarts) out = out.split(lab).join("");

    // repair missing ')' at end-of-line like '(1-2턴'
    out = out.replace(/\((\s*\d+\s*[-–~]\s*\d+\s*(?:턴)?\s*)$/gm, (_m, body) => `(${body})`);
    out = out.replace(/\((\s*\d+\s*(?:턴)?\s*)$/gm, (_m, body) => `(${body})`);

    const offset = blockStart > 1 ? blockStart - 1 : 0;

    const shiftIfRelative = (a: number, b: number) => {
      if (blockStart > 1 && b <= summaryEvery && b < blockStart) return [a + offset, b + offset] as const;
      return [a, b] as const;
    };

    // normalize '(a-b)' / '(a-b턴)' -> '(a-b턴)' and '(a-a)' -> '(a턴)'
    out = out.replace(/\(\s*(\d+)\s*[-–~]\s*(\d+)\s*(?:턴)?\s*\)/g, (m0, aS, bS) => {
      let a = Number(aS);
      let b = Number(bS);
      if (!Number.isFinite(a) || !Number.isFinite(b)) return m0;
      [a, b] = shiftIfRelative(a, b);
      if (a === b) return `(${a}턴)`;
      return `(${a}-${b}턴)`;
    });
    out = out.replace(/\(\s*(\d+)\s*(?:턴)?\s*\)/g, (m0, nS) => {
      let n = Number(nS);
      if (!Number.isFinite(n)) return m0;
      const [nn] = shiftIfRelative(n, n);
      return `(${nn}턴)`;
    });

    // normalize whitespace
    out = out.replace(/\n{3,}/g, "\n\n").trim();

    // ensure ending punctuation for UX
    if (out && !/[\.!?…。…\)\]\"”’》〉]$/.test(out)) out += ".";

    return out;
  };

  for (let i = 0; i < hits.length; i++) {
    const h = hits[i];
    const nextIdx = i + 1 < hits.length ? hits[i + 1].idx : raw.length;
    const bodyStart = h.idx + raw.slice(h.idx).split("\n")[0].length; // end of header line
    const body = raw.slice(bodyStart, nextIdx).replace(/^\n/, "");

    // enforce expected range length
    // - 일반 블록: (end-start+1) == summaryEvery
    // - 롤업 블록: 1부터 시작하며 (end-start+1)이 summaryEvery의 배수(여러 구간을 1개로 압축)
    const size = h.end - h.start + 1;
    const isRollup =
      summaryEvery > 0 && h.start === 1 && size >= summaryEvery && size % summaryEvery === 0 && h.end % summaryEvery === 0;
    if (summaryEvery > 0 && !isRollup && size != summaryEvery) continue;
    if (h.start < 1) continue;
    if (summaryEvery > 0 && !isRollup && (h.start - 1) % summaryEvery != 0) continue;

    const cleanedBody = sanitizeBody(body, h.start);

    // (완화) ### 헤딩이 없다고 요약을 통째로 버리면 빈 요약이 자주 발생한다.
    // - 헤딩은 강제 제거(텍스트만 남김)
    // - 의미 길이(공백 제거 후)가 너무 짧으면 제외
    const bodyNoHeadings = cleanedBody.replace(/^\s*#{1,6}\s+/gm, "");
    const meaningfulLen = bodyNoHeadings.replace(/\s/g, "").length;
    if (meaningfulLen < 20) continue;

    const finalBody = bodyNoHeadings.replace(/\n{3,}/g, "\n\n").trim();
    const fullText = `## 장기 기억 (${h.start}-${h.end}턴)\n\n${finalBody}`.trim();
    const prev = byStart.get(h.start);
    if (!prev || fullText.length >= prev.text.length) {
      byStart.set(h.start, { start: h.start, end: h.end, text: fullText });
    }
  }

  if (byStart.size === 0) return "";

  const blocks = [...byStart.values()].sort((a, b) => a.start - b.start);

  // keep only contiguous blocks from turn 1 onward
  const kept: string[] = [];
  let expectedStart = 1;
  for (const b of blocks) {
    if (b.start != expectedStart) break;
    const size = b.end - b.start + 1;
    const isRollup =
      summaryEvery > 0 && b.start === 1 && size >= summaryEvery && size % summaryEvery === 0 && b.end % summaryEvery === 0;
    if (summaryEvery > 0 && !isRollup && b.end != b.start + summaryEvery - 1) break;
    kept.push(b.text);
    expectedStart = b.end + 1;
  }

  return kept.join("\n\n").trim();
}

export function upsertSummaryRangeBlock(prev: string, block: string, st: number, ed: number): string {
  const p = String(prev || "").trim();
  const b = String(block || "").trim();
  if (!b) return p;

  const header = `## 장기 기억 (${st}-${ed}턴)`;
  // block 자체에 header가 없다면 붙여준다(안전).
  const normalized = b.startsWith("##") ? b : `${header}\n\n${b}`;

  if (!p) return normalized;

  // 동일 구간 block이 있으면 교체, 없으면 append
  const re = new RegExp(
    `(^##\\s*장기\\s*기억\\s*\\(\\s*${st}\\s*-\\s*${ed}\\s*턴\\s*\\)[\\s\\S]*?)(?=^##\\s*장기\\s*기억\\s*\\(|\\s*$)`,
    "m"
  );

  if (re.test(p)) {
    return p.replace(re, normalized + "\n\n");
  }
  return `${p}\n\n${normalized}`.trim();
}



