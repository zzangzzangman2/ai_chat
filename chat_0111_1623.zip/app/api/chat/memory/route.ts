import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { summarizeLongMemoryKorean, type ChatGenOpts } from "@/lib/ai";
import { decryptIfPossible } from "@/lib/crypto";
import { stripUrlsAndMediaMarkdown, postprocessLongMemorySummary, LONG_MEMORY_SUMMARY_RULES } from "@/lib/memory_sanitize";
type Msg = { role: string; content: string; createdAt?: number };

// Back-compat alias: older refactors used ChatMsg naming.
// Keeping this alias avoids touching the rest of the file while satisfying TS.
type ChatMsg = Msg;

function strlen(s: string): number {
  return (s ?? "").length;
}

function bad(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

function normalizeSummaryEvery(v: any): number {
  const n = Number(v);
  return Math.max(3, Math.min(12, Number.isFinite(n) ? Math.floor(n) : 5));
}

function normalizePerTurnChars(v: any): number {
  const n = Number(v);
  const base = Number.isFinite(n) ? n : 120;
  const snapped = Math.round(base / 10) * 10;
  return Math.max(30, Math.min(200, snapped));
}

function isAssistantRole(role: string) {
  return role === "assistant" || role === "model";
}

function stripTopMemoryHeader(text: string): string {
  if (!text) return "";
  const lines = text.split(/\r?\n/);
  // drop leading empty lines
  while (lines.length && !lines[0].trim()) lines.shift();
  if (lines.length && /^##\s*장기\s*기억\s*\(/.test(lines[0].trim())) {
    lines.shift();
    // drop one optional blank line after header
    if (lines.length && !lines[0].trim()) lines.shift();
  }
  return lines.join("\n").trim();
}

type Block = { start: number; end: number; body: string };


function normalizeTurnLabelsInText(text: string, blockStart: number, summaryEvery: number): string {
  let out = String(text || "");
  // repair missing ')'
  out = out.replace(/\((\s*\d+\s*[-–~]\s*\d+\s*(?:턴)?\s*)$/gm, (_m, body) => `(${body})`);
  out = out.replace(/\((\s*\d+\s*(?:턴)?\s*)$/gm, (_m, body) => `(${body})`);

  const offset = blockStart > 1 ? blockStart - 1 : 0;
  const shiftIfRelative = (a: number, b: number) => {
    if (blockStart > 1 && b <= summaryEvery && b < blockStart) return [a + offset, b + offset] as const;
    return [a, b] as const;
  };

  // (a-b) or (a-b턴)
  out = out.replace(/\(\s*(\d+)\s*[-–~]\s*(\d+)\s*(?:턴)?\s*\)/g, (_m, a, b) => {
    let A = Number(a);
    let B = Number(b);
    if (!Number.isFinite(A) || !Number.isFinite(B)) return _m;
    [A, B] = shiftIfRelative(A, B);
    if (A === B) return `(${A}턴)`;
    return `(${A}-${B}턴)`;
  });

  // (n) or (n턴)
  out = out.replace(/\(\s*(\d+)\s*(?:턴)?\s*\)/g, (_m, n) => {
    let N = Number(n);
    if (!Number.isFinite(N)) return _m;
    [N] = shiftIfRelative(N, N);
    return `(${N}턴)`;
  });

  return out;
}


function enforceSummaryCharBudget(text: string, perTurnChars: number): string {
  if (!text) return "";
  const maxPerTurn = Math.max(30, Math.min(200, Math.round(Number(perTurnChars || 120) / 10) * 10));
  const lines = String(text).split(/\r?\n/);
  const out: string[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i] ?? "";
    if (line.startsWith("### ")) {
      const header = normalizeSingleTurnLabel(line);
      // (a-b턴) 파싱
      const m = header.match(/\((\d+)\s*(?:-\s*(\d+))?\s*턴\)/);
      const a = m ? Number(m[1]) : NaN;
      const b = m ? Number(m[2] ?? m[1]) : NaN;
      const spanTurns = Number.isFinite(a) && Number.isFinite(b) ? Math.max(1, b - a + 1) : 1;
      const budget = maxPerTurn * spanTurns;

      out.push(header);
      i++;

      const bodyLines: string[] = [];
      while (i < lines.length) {
        const l = lines[i] ?? "";
        if (l.startsWith("### ") || l.startsWith("## ")) break;
        bodyLines.push(l);
        i++;
      }

      const bodyText = bodyLines.join("\n").trim();
      if (bodyText) {
        const compressed = compressToBudget(bodyText, budget);
        if (compressed) out.push(compressed);
      }
      out.push("");
      continue;
    }

    out.push(line);
    i++;
  }

  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
}

function extractNarrativeSentencesFromMsgs(msgs: Msg[]): string[] {
  const assistantTexts = msgs
    .filter((m) => isAssistantRole(String(m.role || "").toLowerCase()))
    .map((m) => String(m.content ?? ""))
    .join("\n")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const cleaned = assistantTexts
    // drop common dialogue patterns
    .replace(/(?:^|\s)[가-힣A-Za-z0-9_]{1,20}\s*[|:：]\s*["“'‘][^\n"”’']{0,240}["”’']?/g, " ")
    .replace(/["“”‘’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return splitSentences(cleaned).map((s) => s.trim()).filter(Boolean);
}

function enforceOverallBlockBudget(body: string, perTurnChars: number, spanTurns: number, maxChars: number, rangeMsgs: Msg[]): string {
  const per = Math.max(30, Math.min(200, Math.round(Number(perTurnChars || 120) / 10) * 10));
  const span = Math.max(1, spanTurns | 0);
  const targetTotal = Math.max(10, maxChars | 0);

  // If already compact enough, keep it.
  const trimmed = String(body || "").trim();
  if (!trimmed) return "";
  if (trimmed.length <= targetTotal + Math.max(0, span - 1)) return ensureSentenceEnd(trimmed).trim() + "\n";

  // Prefer narration sentences from the model output first.
  const withoutHeadings = trimmed
    .split(/\r?\n/)
    .filter((l) => l.trim() && !l.trim().startsWith("#"))
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();

  let candidates = splitSentences(withoutHeadings).map((s) => s.trim()).filter(Boolean);
  if (candidates.length < span) {
    // Supplement from assistant narrative if the model output is too thin.
    candidates = candidates.concat(extractNarrativeSentencesFromMsgs(rangeMsgs));
  }

  const picked: string[] = [];
  for (const c of candidates) {
    if (picked.length >= span) break;
    const compact = compressToBudget(c, per);
    // Avoid ultra-short fragments.
    if (!compact || compact.trim().length < 12) continue;
    // Avoid dialogue leakage.
    if (containsDialogue(compact)) continue;
    picked.push(compact.trim());
  }

  // If still empty, fall back to a single compressed narrative.
  if (!picked.length) {
    const fb = extractNarrativeSentencesFromMsgs(rangeMsgs).join(" ").trim();
    const one = compressToBudget(fb || trimmed, targetTotal);
    return ensureSentenceEnd(one).trim() + "\n";
  }

  // Join as one sentence per line. Newlines add small overhead but remain readable.
  let out = picked.join("\n").trim();
  // Hard overall cap (in case of weird punctuation spacing)
  if (out.length > targetTotal + Math.max(0, span - 1)) {
    out = compressToBudget(out.replace(/\n+/g, " ").trim(), targetTotal);
  }
  {
    const safe = ensureSentenceEnd(out) || makeNeutralFallbackSentence(rangeMsgs);
    return safe.trim() + "\n";
  }
}

/**
 * Minimum-quality reinforcement.
 *
 * Our budgets (perTurnChars, maxChars) are *upper bounds* to prevent runaway summaries.
 * When the model returns something extremely short (10~20 chars) despite having
 * enough context, the UX feels broken.
 *
 * This helper gently supplements with *non-dialogue* narrative sentences from the
 * assistant-side source messages, without exceeding the overall cap.
 */
function enforceMinimumBlockQuality(
  body: string,
  perTurnChars: number,
  spanTurns: number,
  maxChars: number,
  rangeMsgs: Msg[]
): string {
  const trimmed = String(body || "").trim();
  if (!trimmed) return "";

  const span = Math.max(1, spanTurns | 0);
  const capTotal = Math.max(10, maxChars | 0);
  const per = Math.max(30, Math.min(200, Math.round(Number(perTurnChars || 120) / 10) * 10));

  // Soft minimum: aim for ~85% of the cap, but never exceed the cap.
  // Example: perTurn=50, span=3 => cap=150, min≈90.
  const minTotal = Math.min(capTotal, Math.max(24 * span, Math.floor(capTotal * 0.85)));

  // Count narrative sentences (exclude headings).
  const narrativeOnly = trimmed
    .split(/\r?\n/)
    .filter((l) => l.trim() && !l.trim().startsWith("#"))
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();

  const existingSentences = splitSentences(narrativeOnly).map((s) => s.trim()).filter(Boolean);
  const minSentences = span >= 2 ? 2 : 1;

  const isTooShort = trimmed.length < minTotal || existingSentences.length < minSentences;
  if (!isTooShort) return ensureSentenceEnd(trimmed).trim() + "\n";

  // Candidates: assistant narrative only (dialogue stripped).
  const candidates = extractNarrativeSentencesFromMsgs(rangeMsgs)
    .map((s) => compressToBudget(s, per))
    .map((s) => (s ? s.trim() : ""))
    .filter((s) => s && s.length >= 12 && !containsDialogue(s));

  if (!candidates.length) {
    const safe = ensureSentenceEnd(trimmed) || makeNeutralFallbackSentence(rangeMsgs);
    return safe.trim() + "\n";
  }

  // Append up to a few supplemental sentences until we reach the soft minimum.
  let out = trimmed.replace(/\n{3,}/g, "\n\n").trim();

  // Prefer adding as a new line (keeps readability); avoid adding headings.
  for (const c of candidates) {
    if (out.length >= minTotal) break;
    // Avoid duplicating very similar content.
    const already = out.includes(c);
    if (already) continue;
    const appended = (out + "\n" + c).trim();
    if (appended.length > capTotal + Math.max(0, span - 1)) {
      // If we would exceed the cap, try a tighter compress for the remaining room.
      const remain = Math.max(10, capTotal - out.length - 1);
      const tight = compressToBudget(c, remain);
      if (!tight || tight.trim().length < 12 || containsDialogue(tight)) continue;
      const appended2 = (out + "\n" + tight.trim()).trim();
      if (appended2.length > capTotal + Math.max(0, span - 1)) continue;
      out = appended2;
      break;
    }
    out = appended;
  }

  // Final hard cap safety.
  if (out.length > capTotal + Math.max(0, span - 1)) {
    out = compressToBudget(out.replace(/\n+/g, " ").trim(), capTotal);
  }

  {
    const safe = ensureSentenceEnd(out) || makeNeutralFallbackSentence(rangeMsgs);
    return safe.trim() + "\n";
  }
}

function normalizeSingleTurnLabel(line: string): string {
  // (1-1턴) or (1-1) => (1턴)
  return String(line)
    .replace(/\((\d+)\s*-\s*\1\s*턴?\)/g, "($1턴)")
    .replace(/\((\d+)\s*-\s*(\d+)\s*턴?\)/g, "($1-$2턴)")
    .replace(/\((\d+)\s*-\s*(\d+)\)/g, "($1-$2턴)")
    .replace(/\((\d+)\s*턴\)/g, "($1턴)");
}

function compressToBudget(text: string, budget: number): string {
  const max = Math.max(10, budget | 0);
  const src = String(text).replace(/\s+/g, " ").trim();
  if (!src) return "";
  if (src.length <= max) return ensureNiceSentence(src) || "";

  // Prefer full sentences only (no mid-sentence truncation).
  const sentences = splitSentences(src);
  let acc = "";
  for (const s of sentences) {
    const next = acc ? `${acc} ${s}` : s;
    if (next.length <= max) acc = next;
    else break;
  }
  if (acc) return ensureNiceSentence(acc) || "";

  // If even a single sentence doesn't fit, cut on a safe boundary (space/punctuation) and complete.
  const cut = src.slice(0, max).trim();
  const boundary = Math.max(
    cut.lastIndexOf("."),
    cut.lastIndexOf("!"),
    cut.lastIndexOf("?"),
    cut.lastIndexOf("…"),
    cut.lastIndexOf(" "),
  );
  const base = (boundary >= 8 ? cut.slice(0, boundary).trim() : cut).trim();
  return ensureNiceSentence(base) || "";
}

function splitSentences(s: string): string[] {
  // 문장 구분(한국어): 마침표/물음표/느낌표/… 기준 + 줄바꿈 제거
  const parts: string[] = [];
  let buf = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    buf += ch;
    if (ch === "." || ch === "!" || ch === "?" || ch === "…") {
      const t = buf.trim();
      if (t) parts.push(t);
      buf = "";
    }
  }
  const tail = buf.trim();
  if (tail) parts.push(tail);
  return parts;
}

const GOOD_SENTENCE_END_RE = /(다|요|니다|한다|했다|하였다|된다|됐다|있다|없다|였다|이었다)$/;
const BAD_SENTENCE_TAIL_RE =
  /(과|와|및|그리고|또는|혹은|의|을|를|이|가|은|는|에|에서|에게|로|으로|부터|까지|하며|면서|며|하고|이고|적인|스럽게|다정하게|비상식적인|위협적인|자신의)$/;

/**
 * "문장" 단위로만 사용: 불완전한 꼬리(조사/접속/관형사 등)로 끝나는 조각을 걸러낸다.
 * - 블록 전체(여러 줄/헤딩 포함)에 적용하면 안 된다.
 */
function isLikelyCompleteKoreanSentence(s: string): boolean {
  const t = String(s || "").trim();
  if (!t) return false;
  const noP = t.replace(/[.!?…。]+$/g, "").trim();
  if (!noP) return false;

  // 조사/접속/관형사 꼬리로 끝나면 미완으로 본다.
  if (BAD_SENTENCE_TAIL_RE.test(noP)) return false;
  if (/(?:은|는|이|가|을|를|의|에|에서|에게|으로|로|과|와|및|그리고|또는|혹은|하며|면서|며)$/.test(noP)) return false;

  // 명확한 서술형 종결(다/요/니다/했다 등)이 있으면 OK.
  if (GOOD_SENTENCE_END_RE.test(noP)) return true;

  // 문장부호가 이미 있으면 완결로 간주(단, 위 꼬리 패턴은 제외됨).
  if (/[.!?…。]$/.test(t)) return true;

  return false;
}

function trimToLastSafeBoundary(s: string): string {
  const x = String(s || "").trim();
  if (!x) return "";

  const lastP = Math.max(x.lastIndexOf("."), x.lastIndexOf("!"), x.lastIndexOf("?"), x.lastIndexOf("…"));
  if (lastP >= 8) return x.slice(0, lastP + 1).trim();

  const lastComma = Math.max(x.lastIndexOf(","), x.lastIndexOf("，"));
  if (lastComma >= 8) return x.slice(0, lastComma).trim();

  const lastSpace = x.lastIndexOf(" ");
  if (lastSpace >= 8) return x.slice(0, lastSpace).trim();

  return "";
}

/**
 * (핵심) "문장 조각"을 억지로 마침표로 끝내지 말고,
 * - 완결형처럼 보이는 경우만 유지
 * - 아니면 더 안전한 경계로 줄이거나 버린다.
 */
function ensureNiceSentence(t: string): string {
  let x = String(t || "").replace(/\s+/g, " ").trim();
  if (!x) return "";

  // stage-direction 잔여(*로 시작) 제거
  x = x.replace(/^\*+\s*/g, "");

  // 깨진 구두점 정리
  x = x.replace(/,\.(?=\s|$)/g, ".").replace(/\.\,(?=\s|$)/g, ".");

  // 이미 문장부호가 있으면, 미완 꼬리인지 확인한 뒤 필요 시 안전하게 줄인다.
  if (/[.!?…。]$/.test(x)) {
    if (isLikelyCompleteKoreanSentence(x)) return x;
    const trimmed = trimToLastSafeBoundary(x.replace(/[.!?…。]+$/g, "").trim());
    if (trimmed && isLikelyCompleteKoreanSentence(trimmed)) return ensureNiceSentence(trimmed);
    return "";
  }

  // 문장부호가 없으면, '무조건 .'을 붙이지 않고 "완결형처럼 보일 때만" 붙인다.
  if (isLikelyCompleteKoreanSentence(x)) return x + ".";

  const trimmed = trimToLastSafeBoundary(x);
  if (trimmed && isLikelyCompleteKoreanSentence(trimmed)) return ensureNiceSentence(trimmed);

  const base = x.trim();
  if (GOOD_SENTENCE_END_RE.test(base) && !BAD_SENTENCE_TAIL_RE.test(base)) return base + ".";

  return "";
}

/**
 * 블록(여러 줄) 전체를 마지막에 "문장부호로 끝내기" 위해 쓰는 느슨한 보정.
 * - 불완전 문장 판정/삭제는 하지 않는다.
 */
function ensureSentenceEnd(t: string): string {
  const x = String(t || "").trim();
  if (!x) return "";

  // 1) 우선 "완결형 문장"처럼 보이도록 보정(미완 꼬리 제거/마침표 보정)
  const nice = ensureNiceSentence(x);
  if (nice) return nice;

  // 2) 이미 문장부호로 끝났는데도 어색하면(예: '... 중원.') 마지막 안전 경계로 한 번 더 줄여본다.
  if (/[.!?…。]$/.test(x)) {
    const base = x.replace(/[.!?…。]+$/g, "").trim();
    const trimmed = trimToLastSafeBoundary(base);
    const nice2 = trimmed ? ensureNiceSentence(trimmed) : "";
    if (nice2) return nice2;
    return x;
  }

  // 3) 최후: 표시용 최소 보정
  return x + ".";
}

function containsDialogue(text: string): boolean {
  const s = String(text || "");
  if (!s.trim()) return false;

  const lines = s.split(/\r?\n/).map((l) => l.trim());
  for (const l of lines) {
    if (!l) continue;

    // Typical chat labels
    if (/^(?:[-*]\s*)?(?:User|Assistant|사용자|어시스턴트)\s*[:：]/i.test(l)) return true;

    // Character name + delimiter + quote (e.g., 오지명 | "...")
    if (/^[가-힣A-Za-z0-9_]{1,20}\s*[|:：]\s*["“'‘]/.test(l)) return true;

    // Standalone quoted line that looks like dialogue
    if (/^["“'‘][^\n]{2,120}$/.test(l)) return true;

    // Any short inline quote is suspicious in a summary
    if (/(?:^|\s)["“'‘][^\n"”’']{2,80}["”’']/.test(l)) return true;
  }

  const quoteCount = (s.match(/["“”‘’']/g) || []).length;
  if (quoteCount >= 4) return true;

  return false;
}

function makeNeutralFallbackSentence(rangeMsgs: any[]): string {
  const joined = rangeMsgs.map((m) => String((m as any)?.content ?? "")).join(" ");
  const hasSeowon = /임서원|서원/.test(joined);
  const hasJimeong = /오지명|지명/.test(joined);

  if (hasSeowon && hasJimeong) return "오지명과 임서원의 대립으로 긴장감이 높아진다.";
  if (hasSeowon) return "임서원의 상황이 긴장감 속에서 전개된다.";
  return "상황의 긴장감이 높아진다.";
}


function computeContiguousBlocks(blocks: Block[], summaryEvery: number): { blocks: Block[]; endTurn: number } {
  // sort + de-dup (same range -> keep longer body)
  const byKey = new Map<string, Block>();
  for (const b of [...blocks].sort((a, b) => a.start - b.start)) {
    const key = `${b.start}-${b.end}`;
    const prev = byKey.get(key);
    if (!prev || (prev.body?.length ?? 0) < (b.body?.length ?? 0)) {
      byKey.set(key, b);
    }
  }
  const dedup = [...byKey.values()].sort((a, b) => a.start - b.start);

  // Keep only a contiguous chain starting from turn 1.
  // Unlike the older logic, blocks may be variable-length (adaptive merge).
  const kept: Block[] = [];
  let expectedStart = 1;
  while (true) {
    const candidates = dedup.filter((b) => b.start === expectedStart);
    if (candidates.length === 0) break;

    // Prefer the block that covers the farthest end turn.
    let best = candidates[0];
    for (const c of candidates) {
      if (c.end > best.end) best = c;
    }

    kept.push(best);
    expectedStart = best.end + 1;
  }

  const endTurn = kept.length ? kept[kept.length - 1].end : 0;
  return { blocks: kept, endTurn };
}

function extractValidBlocks(summary: string, summaryEvery: number): Block[] {
  if (!summary) return [];
  const re = /^\s*##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*턴\s*\)\s*$/gm;
  const hits: { start: number; end: number; idx: number }[] = [];
  for (const m of summary.matchAll(re)) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    const idx = m.index ?? 0;
    if (!Number.isFinite(a) || !Number.isFinite(b) || a < 1 || b < a) continue;
    hits.push({ start: a, end: b, idx });
  }
  if (hits.length === 0) return [];
  const blocks: Block[] = [];
  for (let i = 0; i < hits.length; i++) {
    const h = hits[i];
    const nextIdx = i + 1 < hits.length ? hits[i + 1].idx : summary.length;
    const raw = summary.slice(h.idx, nextIdx).trim();
    let body = stripTopMemoryHeader(raw);
    body = sanitizeGeneratedBody(body).cleaned;
    body = normalizeTurnLabelsInText(body, h.start, summaryEvery);
    // 유효 조건:
    // 1) 본문이 실제로 존재 (헤더-only/placeholder 제거)
    // 2) 범위가 정상 (end >= start)
    const len = h.end - h.start + 1;
    if (len < 1) continue;
    if (!body || body.replace(/[#\s\n]/g, "").length < 10) continue;

    // (안전) 저장된 요약이 원문 인용/대화요약 템플릿으로 오염된 경우 제외
    if (/\(\s*대화\s*요약\s*\)/.test(body)) continue;
    if (/(?:\b(User|Assistant)\s*:|(?:사용자|어시스턴트)\s*:)/i.test(body)) continue;
    blocks.push({ start: h.start, end: h.end, body });
  }
  // dedupe by (start-end), keep last
  const map = new Map<string, Block>();
  for (const b of blocks) map.set(`${b.start}-${b.end}`, b);
  return Array.from(map.values()).sort((x, y) => x.start - y.start);
}

function blocksToSummary(blocks: Block[]): string {
  if (!blocks.length) return "";
  return blocks
    .map((b) => {
      const body = String(b.body || "")
        .trim()
        .replace(/\((\d+)\s*[-–~]\s*\1\s*턴\)/g, "($1턴)");
      return `## 장기 기억 (${b.start}-${b.end}턴)\n\n${body}\n`;
    })
    .join("\n")
    .trim();
}

function toUiLongMemory(summary: string, summaryEvery: number): string {
  const raw = String(summary || "").trim();
  if (!raw) return "";

  // Preferred: strip the internal turn-range headers and return only narrative bodies.
  try {
    const blocks = extractValidBlocks(raw, summaryEvery);
    if (blocks.length) {
      return blocks
        .map((b) => String(b.body || "").trim())
        .filter((s) => s && s.replace(/\s+/g, "").length > 0)
        .join("\n\n")
        .trim();
    }
  } catch {
    // ignore and fallback
  }

  // Fallback: aggressively remove any headers that may have leaked.
  return raw
    .replace(/^\s*##\s*장기\s*기억\s*\(.*?\)\s*$/gmi, "")
    .replace(/^\s*###\s+.*$/gmi, "")
    .replace(/^\s*##\s+.*$/gmi, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}


function sliceByAssistantTurns(all: Msg[], startTurn: number, endTurn: number): Msg[] {
  const asstIdx: number[] = [];
  for (let i = 0; i < all.length; i++) {
    if (isAssistantRole(all[i]?.role || "")) asstIdx.push(i);
  }
  if (asstIdx.length === 0) return [];
  const st = Math.max(1, startTurn);
  const ed = Math.max(st, endTurn);
  if (st > asstIdx.length) return [];
  const stPos = st === 1 ? 0 : asstIdx[st - 2] + 1;
  const edPos = asstIdx[Math.min(ed - 1, asstIdx.length - 1)];
  if (!Number.isFinite(stPos) || !Number.isFinite(edPos) || edPos < stPos) return [];
  return all.slice(stPos, edPos + 1);
}

type TurnPair = { turn: number; user: ChatMsg; assistant: ChatMsg };

function buildTurnPairs(messages: ChatMsg[]): TurnPair[] {
  const pairs: TurnPair[] = [];
  let turn = 0;

  for (let i = 0; i < messages.length - 1; i++) {
    const a = messages[i];
    const b = messages[i + 1];
    if (a?.role === "user" && isAssistantRole(b?.role)) {
      const userText = String(a.content ?? "").trim();
      const asstText = String(b.content ?? "").trim();
      if (userText.length >= 1 && asstText.length >= 1) {
        turn += 1;
        pairs.push({ turn, user: a, assistant: b });
        i += 1; // consume assistant too
      }
    }
  }
  return pairs;
}

function sliceByTurnPairs(pairs: TurnPair[], startTurn: number, endTurn: number): ChatMsg[] {
  const s = Math.max(1, startTurn);
  const e = Math.max(s, endTurn);
  const picked = pairs.slice(s - 1, e);

  const out: ChatMsg[] = [];
  for (const p of picked) out.push(p.user, p.assistant);
  return out;
}

function buildFallbackBlockBody(rangeMsgs: ChatMsg[], startTurn: number, endTurn: number, maxChars: number): string {
  // Deterministic, narration-only fallback:
  // - remove direct quotes / speaker labels
  // - keep only plain narrative sentences
  const assistantTexts = rangeMsgs
    .filter((m) => isAssistantRole(m.role))
    .map((m) => String(m.content ?? ""))
    .join("\n")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  let cleaned = assistantTexts
    // drop common dialogue patterns
    .replace(/(?:^|\s)[가-힣A-Za-z0-9_]{1,20}\s*[|:：]\s*["“'‘][^\n"”’']{0,200}["”’']?/g, " ")
    .replace(/["“'‘][^\n"”’']{0,200}["”’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  // Prefer 1~2 full sentences
  const sent = splitSentences(cleaned).filter(Boolean);
  let gist = "";
  if (sent.length >= 2) gist = `${sent[0]} ${sent[1]}`.trim();
  else if (sent.length === 1) gist = sent[0].trim();
  else gist = cleaned;

  // Hard budget
  if (gist.length > maxChars) gist = gist.slice(0, maxChars).trim();
  gist = gist.replace(/…+$/g, "").trim();
  gist = ensureNiceSentence(gist) || "";

  // Final safety: narration only
  if (containsDialogue(gist)) {
    gist = ensureNiceSentence(gist.replace(/["“”‘’']/g, "").replace(/\s+/g, " ").trim()) || "";
  }

  if (!gist) {
    const joined = rangeMsgs.map((m) => String((m as any)?.content ?? "")).join(" ");
    const hasSeowon = /임서원|서원/.test(joined);
    const hasJimeong = /오지명|지명/.test(joined);
    if (hasSeowon && hasJimeong) gist = "오지명과 임서원의 대립으로 긴장감이 높아진다.";
    else if (hasSeowon) gist = "임서원의 상황이 긴장감 속에서 전개된다.";
    else gist = "상황의 긴장감이 높아진다.";
  }

  return gist;
}



function reorderAndStripSectionRanges(text: string, blockStart: number, blockEnd: number): string {
  const src = String(text || "").trim();
  if (!src) return "";

  const lines = src.split(/\r?\n/);

  type Sec = { level: string; heading: string; start?: number; order: number; body: string[] };

  const prefix: string[] = [];
  const sections: Sec[] = [];
  let cur: Sec | null = null;
  let order = 0;

  const headingRe = /^(#{3,6})\s+(.+)$/;

  const flush = () => {
    if (!cur) return;
    cur.body = cur.body.join("\n").trim().split(/\r?\n/);
    sections.push(cur);
    cur = null;
  };

  for (const raw of lines) {
    const line = raw.trimEnd();
    const m = line.match(headingRe);
    if (m) {
      flush();
      const level = m[1];
      let head = m[2].trim();

      // Extract optional turn range suffix like "(3-4턴)" or "(3턴)"
      let startNum: number | undefined = undefined;
      const m2 = head.match(/\(\s*(\d+)\s*[-–~]\s*(\d+)\s*턴\s*\)\s*$/);
      const m3 = !m2 ? head.match(/\(\s*(\d+)\s*턴\s*\)\s*$/) : null;
      if (m2) {
        startNum = Number(m2[1]);
        head = head.replace(m2[0], "").trim();
      } else if (m3) {
        startNum = Number(m3[1]);
        head = head.replace(m3[0], "").trim();
      }

      cur = { level, heading: head, start: Number.isFinite(startNum as any) ? startNum : undefined, order: order++, body: [] };
      continue;
    }

    if (!cur) prefix.push(line);
    else cur.body.push(line);
  }
  flush();

  if (!sections.length) return src;

  const hasAnyStart = sections.some((s) => typeof s.start === "number");
  const sorted = hasAnyStart
    ? [...sections].sort((a, b) => {
        const aa = typeof a.start === "number" ? a.start! : Number.POSITIVE_INFINITY;
        const bb = typeof b.start === "number" ? b.start! : Number.POSITIVE_INFINITY;
        if (aa !== bb) return aa - bb;
        return a.order - b.order;
      })
    : sections;

  const out: string[] = [];
  const pre = prefix.join("\n").trim();
  if (pre) out.push(pre);

  for (const s of sorted) {
    const headLine = `${s.level} ${s.heading}`.trimEnd();
    out.push(headLine);
    const body = s.body.join("\n").trim();
    if (body) out.push(body);
    out.push("");
  }

  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}


function normalizeInlineSectionSyntax(text: string): string {
  let s = String(text || "");
  if (!s.trim()) return "";

  // Remove redundant "(요약)" markers that sometimes appear in headings.
  s = s.replace(/\(\s*요약\s*\)/g, "").replace(/[ \t]{2,}/g, " ");

  // If the model outputs multiple headings on one line (e.g. "(1-4턴) ### ... (5-6턴) ..."),
  // ensure headings start on their own line so the section parser can see them.
  s = s.replace(/(\S)(\s*)(#{3,6}\s+)/g, "$1\n$3");

  // Remove any turn-range markers inside the block body to avoid confusion with the outer block range.
  // Examples: "(1-2턴)", "(4턴)", "(1~3턴)"
  s = s
    .replace(/\(\s*\d+\s*[-–~〜~]\s*\d+\s*턴\s*\)/g, "")
    .replace(/\(\s*\d+\s*턴\s*\)/g, "");

  // Clean up empty parentheses that may remain.
  s = s.replace(/\(\s*\)/g, "");

  // Line-level cleanup
  const lines = s.split(/\r?\n/);
  const out: string[] = [];
  for (let line of lines) {
    line = line.replace(/[ \t]{2,}/g, " ").trimEnd();
    const ts = line.trimStart();
    if (/^#{3,6}\s+/.test(ts)) line = ts;

    // Drop lines that are just leftover punctuation.
    if (/^[\s,.;:：]+$/.test(line.trim())) continue;

    // If a line begins with a removed turn marker space, normalize.
    out.push(line);
  }
  return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}



function formatConversation(msgs: Msg[]): string {
  const lines: string[] = [];
  for (const m of msgs) {
    const role = (m.role || "").toLowerCase();
    const label = role === "user" ? "User" : "Assistant";
    const content = String(m.content || "").trim();
    if (!content) continue;
    lines.push(`${label}: ${content}`);
  }
  return lines.join("\n");
}

function fallbackSummaryFromMsgs(msgs: Msg[], maxChars: number): string {
  // 매우 단순한 안전 요약: 각 User/Assistant의 첫 문장만 뽑아 bullet로 구성
  const bullets: string[] = [];
  for (const m of msgs) {
    const role = (m.role || "").toLowerCase();
    if (role !== "user" && !isAssistantRole(role)) continue;
    const label = role === "user" ? "User" : "Assistant";
    const t = String(m.content || "").trim().replace(/\s+/g, " ");
    if (!t) continue;
    const first = t.split(/(?<=[.!?。！？])\s+/)[0] || t;
    bullets.push(`- ${label}: ${first}`);
    if (bullets.join("\n").length > maxChars) break;
  }
  let out = bullets.join("\n").trim();
  if (out.length > maxChars) out = out.slice(0, maxChars);
  if (!out) out = "- (요약 실패) 이 구간의 대화가 비어있거나 요약할 내용이 부족합니다.";
  return out;
}


function isLikelyKoreanSentenceFragment(tail: string): boolean {
  const s = String(tail || "").trim();
  if (!s) return false;

  // Very short tails are usually fragments.
  if (s.length <= 8) return true;

  // Ends with a lone particle (조사) or connective stub.
  if (/(?:\b[이가은는을를에에서로와과의도만]\b)\.?$/u.test(s)) return true;

  // Starts with common connectives but doesn't complete a clause.
  const connective = /^(?:근데|그런데|하지만|그래서|그리고|또는|또|다만|게다가|그러나)\b/u;
  if (connective.test(s) && s.length <= 20) return true;

  // Trails off with "…", or unfinished quotes/parentheses.
  if (/[…\.]$/.test(s) && /["'\(\[]/.test(s) && !/["'\)\]]/.test(s)) return true;

  // Common incomplete endings.
  if (/(?:인데|지만|어서|니까|다면|하는데|했는데|하던데|해서|하여|하며)$/.test(s)) return true;

  return false;
}

function dropKoreanTailFragment(line: string): { line: string; dropped: boolean } {
  const s = String(line || "");
  // Look for the last sentence boundary.
  const idx = Math.max(s.lastIndexOf("."), s.lastIndexOf("!"), s.lastIndexOf("?"), s.lastIndexOf("…"));
  if (idx < 0) return { line: s, dropped: false };

  const head = s.slice(0, idx + 1);
  const tail = s.slice(idx + 1);

  if (isLikelyKoreanSentenceFragment(tail)) {
    return { line: head.trimEnd(), dropped: true };
  }
  return { line: s, dropped: false };
}

function sanitizeGeneratedBody(body: string): { cleaned: string; flags: string[] } {
  const flags: string[] = [];
  let s = String(body || "");

 
  // Remove leaked URLs / media markdown from model output (some models echo inputs).
  s = s.replace(/!\[[^\]]*\]\([^\)]*\)/g, " ");
  s = s.replace(/\[([^\]]*)\]\([^\)]*\)/g, "$1");
  s = s.replace(/https?:\/\/\S+/gi, " ");
  s = s.replace(/\b\S*itimg\.kr\S*\b/gi, " ");
  s = s.replace(/\b\S+\.(?:webp|png|jpe?g|gif)\b/gi, " ");
 // 모델이 프롬프트/분석을 그대로 토해내는 경우 제거
  const badMarkers = [
    "start_thought",
    "Long-term Memory",
    "Summary Writer",
    "Dialogue Context",
    "Turn ",
    "Correction",
    "Korean only",
  ];
  for (const k of badMarkers) {
    if (s.includes(k)) flags.push(`marker:${k}`);
  }

  // 흔한 프롬프트 에코 라인 제거
  s = s
    .replace(/^[ \t]*start_thought[\s\S]*?\n\s*\n/gi, "")
    .replace(/^[ \t]*(Long-term Memory|Memory Summary Writer)\.[\s\S]*?\n\s*\n/gi, "")
    .replace(/^[ \t]*Korean only\.[\s\S]*?\n\s*\n/gi, "")
    .replace(/^[ \t]*Markdown\.[\s\S]*?\n\s*\n/gi, "");

  const lines = s.split(/\r?\n/);
  const out: string[] = [];
  for (const line of lines) {
    const t = line.trimEnd();
    if (!t.trim()) {
      out.push("");
      continue;
    }

    // (금지) 영문 템플릿/턴 메타가 섞여 들어오는 경우 제거 (예: "Turns 1-2):*", "Turn 3:")
    if (/^\s*Turns?\s*\d+/i.test(t) || /^\s*Turn\s*\d+/i.test(t)) {
      flags.push("english_turn_meta");
      continue;
    }

    // Drop leaked URL/media lines (e.g., "[](https://...)", raw links, itimg, .webp)
    const urlLike = /(https?:\/\/\S+|\bitimg\.kr\b|\.(?:webp|png|jpe?g|gif)\b)/i.test(t);
    const emptyMdLink = /^\s*\[\s*\]\([^\)]*\)\s*$/.test(t);
    if (urlLike || emptyMdLink) {
      flags.push("url_or_media_line");
      continue;
    }
    if (/\bTurns?\s*\d+\s*[-–~]\s*\d+\b/i.test(t)) {
      flags.push("english_turn_meta");
      continue;
    }
    // 의미 없는 잔여 마크다운 토큰(단독 '*', '-', ':') 제거
    if (/^\s*[*-]+\s*$/.test(t) || /^\s*[:：]+\s*$/.test(t)) {
      flags.push("dangling_md_token");
      continue;
    }
    // (금지) 원문 지문처럼 '*'로 시작하는 라인은 요약에 포함하지 않는다.
    // 예: "*남자의 대답은 ..." 같은 원문 문장을 그대로 가져오는 경우
    if (/^\s*\*/.test(t)) {
      flags.push("raw_narration_line");
      continue;
    }

    // (금지) 블록 내부에 또 다른 "장기 기억" 헤더가 들어오면 제거 (순서/중복 혼선 방지)
    if (/^##\s*장기\s*기억\s*\(/.test(t.trim())) {
      flags.push("nested_memory_header");
      continue;
    }
    // (금지) "(대화 요약)" 블록/라인 제거
    if (/\(\s*대화\s*요약\s*\)/.test(t)) {
      flags.push("dialogue_summary_block");
      continue;
    }

    // 대화 원문 인용(또는 fallback bullet) 제거
    if (/^\s*[-*]\s*(User|Assistant)\s*:/i.test(t)) {
      flags.push("quoted_dialogue");
      continue;
    }
    if (/^\s*[-*]\s*\(\s*\d+\s*턴\s*\)\s*(사용자|어시스턴트)\s*:/i.test(t)) {
      flags.push("quoted_dialogue");
      continue;
    }
    if (/\b(User|Assistant)\s*:/i.test(t) && /\(\d+\s*턴\)/.test(t)) {
      flags.push("inline_dialogue");
      continue;
    }
    if (/\b(User|Assistant)\s*:/i.test(t)) {
      flags.push("dialogue_label");
      continue;
    }
    if (/(사용자|어시스턴트)\s*:/i.test(t)) {
      flags.push("dialogue_label");
      continue;
    }
    // 인물명 + 구분자(|/:) + 인용부호로 시작하는 대사 라인 제거 (예: 오지명 | "...")
    if (/^[가-힣A-Za-z0-9_]{1,20}\s*[|:：]\s*["“'‘]/.test(t)) {
      flags.push("name_pipe_quote");
      continue;
    }

    // 템플릿 밖 메타 라인 제거
    if (/Dialogue Context|Correction on Turn|Specific Turn Range|Provided \[Dialogue\]/i.test(t)) {
      flags.push("meta_line");
      continue;
    }
    out.push(t);
  }

  // 연속 공백 정리
  let cleaned = out.join("\n");
  // (표기) (n-n턴) -> (n턴)
  cleaned = cleaned.replace(/\((\d+)\s*[-–~]\s*\1\s*턴\)/g, "($1턴)");
  // (문장 수습) 요약 말미가 '자신에게.'처럼 목적어/부사어로 끊기는 케이스 보정
  // 예: "...모든 사진을 자신에게." -> "...모든 사진을 자신에게 옮기려 한다."
  // (너무 과한 추측을 피하기 위해 '했다'가 아니라 '하려 한다'로 완화)
  cleaned = cleaned
    .replace(/자신에게\.(?=\s*$)/g, "자신에게 옮기려 한다.")
    .replace(/자신에게(?=\s*$)/g, "자신에게 옮기려 한다.")
    // 깨진 문장부호(예: "며,." / ",." ) 정리
    .replace(/,\.(?=\s|$)/g, ".")
    .replace(/\.\,(?=\s|$)/g, ".");
  cleaned = cleaned.replace(/\n{3,}/g, "\n\n").trim();

  // 끝맺음 보정(마지막 텍스트 라인이 너무 짧거나 미완성인 경우 제거)
  const ls = cleaned.split(/\r?\n/);
  while (ls.length) {
    const last = ls[ls.length - 1];
    const tl = last.trim();
    if (!tl) {
      ls.pop();
      continue;
    }
    if (tl.startsWith("#") || tl.startsWith("-") || tl.startsWith("*")) break;
    // Drop a trailing Korean sentence fragment that often appears when the model is cut off mid-generation.
    const dropped = dropKoreanTailFragment(tl);
    if (dropped.dropped) {
      ls[ls.length - 1] = dropped.line;
      flags.push("tail_sentence_fragment_dropped");
      // Re-evaluate the updated tail.
      continue;
    }

    const endsOk = /[.!?。！？]$/.test(tl) || /(다|요|함|됨|임)$/.test(tl);
    if (endsOk) break;
    if (/…$/.test(tl)) {
      ls[ls.length - 1] = tl.replace(/…+$/g, ".").trim();
      flags.push("tail_ellipsis_removed");
      break;
    }
    // 너무 짧은 조각(예: "토로")은 제거
    if (tl.length <= 8) {
      flags.push("tail_fragment_dropped");
      ls.pop();
      continue;
    }
    // 한국어 문장처럼 보이면 마침표를 붙여 완결
    if (/[가-힣]/.test(tl)) {
      ls[ls.length - 1] = tl + ".";
      flags.push("tail_punct_added");
    }
    break;
  }
  cleaned = ls.join("\n").replace(/\n{3,}/g, "\n\n").trim();

  // (표기 보정) (n-n턴) -> (n턴)
  cleaned = cleaned.replace(/\((\d+)\s*[-–~]\s*\1\s*턴\)/g, "($1턴)");

  return { cleaned, flags };
}

function isBadKoreanHeadingTail(t: string): boolean {
  const title = (t || "").trim();
  if (!title) return true;
  // 흔한 끊김/미완 패턴: 조사/접속 표현으로 끝남, 또는 구두점으로 끝남
  if (/[.,:;]$/.test(title)) return true;
  if (/(과|와|및|그리고|또는|혹은)$/.test(title)) return true;
  if (/(의|을|를|이|가|은|는|에|에서|에게|로|으로|부터|까지)$/.test(title)) return true;
  if (/(하며|면서|며)$/.test(title)) return true;
  return false;
}

function stripBadHeadingTail(t: string): string {
  let title = (t || "").trim();
  // 불필요 접두어 제거
  title = title.replace(/^\(\s*요약\s*\)\s*/g, "");
  // 끝의 구두점/공백 제거
  title = title.replace(/[\s\u00A0]+$/g, "").replace(/[.,:;]+$/g, "").trim();
  // 끝이 접속/조사로 끝나면 제거 시도
  const tailTokens = [
    "그리고",
    "또는",
    "혹은",
    "및",
    "과",
    "와",
    "의",
    "을",
    "를",
    "이",
    "가",
    "은",
    "는",
    "에",
    "에서",
    "에게",
    "로",
    "으로",
    "부터",
    "까지",
    "하며",
    "면서",
    "며",
  ];
  for (const tok of tailTokens) {
    if (title.endsWith(tok) && title.length > tok.length + 1) {
      title = title.slice(0, -tok.length).trim();
      title = title.replace(/[.,:;]+$/g, "").trim();
      break;
    }
  }
  return title;
}

function inferHeadingFromFirstSentence(nextText: string, maxLen = 22): string {
  const t = String(nextText || "").trim();
  if (!t) return "장면 요약";
  // 첫 문장 후보만
  const first = t.split(/[.!?。！？\n]/)[0].trim();
  let h = first
    .replace(/^[-*]\s+/g, "")
    .replace(/^\(?요약\)?\s*/g, "")
    .replace(/["“”‘’']/g, "")
    .trim();
  if (!h) return "장면 요약";
  // 너무 길면 자르되, 끝이 조사/접속으로 끊기면 한 번 더 다듬음
  if (h.length > maxLen) h = h.slice(0, maxLen).trim();
  h = stripBadHeadingTail(h);
  if (!h) return "장면 요약";
  return h;
}

function repairMarkdownHeadingsUsingContext(markdown: string): { text: string; flags: string[] } {
  const flags: string[] = [];
  const lines = String(markdown || "").split(/\r?\n/);
  const out: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const m = raw.match(/^(#{3,6})\s+(.*)$/);
    if (!m) {
      out.push(raw);
      continue;
    }
    const hashes = m[1];
    let title = (m[2] || "").trim();

    // 본문에 섞인 턴 범위 표기 제거(혹시 남아있을 때)
    title = title.replace(/\(\s*\d+\s*(?:[-–~]\s*\d+)?\s*턴\s*\)\s*$/g, "").trim();
    title = stripBadHeadingTail(title);

    let repaired = false;
    if (!title || isBadKoreanHeadingTail(title) || title.length < 4) {
      // 다음 내용 라인에서 유추
      let j = i + 1;
      let next = "";
      while (j < lines.length) {
        const tt = (lines[j] || "").trim();
        if (!tt) {
          j++;
          continue;
        }
        if (/^#{2,6}\s+/.test(tt)) break; // 다음 섹션/블록 시작
        next = tt;
        break;
      }
      const inferred = inferHeadingFromFirstSentence(next);
      if (inferred !== "장면 요약") {
        title = inferred;
        repaired = true;
      } else {
        // 그래도 못 만들면, 최소한 제목에서 끊긴 꼬리만 제거한 값 사용
        const stripped = stripBadHeadingTail(m[2] || "");
        title = stripped || "장면 요약";
        repaired = true;
      }
    }

    if (repaired) flags.push("heading_repaired");
    out.push(`${hashes} ${title}`);
  }
  return { text: out.join("\n"), flags };
}

function pruneBrokenSentenceFragments(markdown: string): { text: string; flags: string[] } {
  const flags: string[] = [];
  const lines = String(markdown || "").split(/\r?\n/);
  const out: string[] = [];
  for (const raw of lines) {
    const line = String(raw || "");
    const t = line.trim();
    if (!t) {
      out.push(line);
      continue;
    }
    if (/^#{1,6}\s+/.test(t)) {
      out.push(line);
      continue;
    }
    // 깨진 문장부호 정리
    let x = line.replace(/,\.(?=\s|$)/g, ".").replace(/\.\,(?=\s|$)/g, ".");
    // 라인 끝이 조사/접속/연결어미 + '.' 로 끊기는 경우: 마지막 조각 제거
    const badTail = /(의|을|를|이|가|은|는|과|와|에|에서|에게|로|으로|부터|까지|하며|면서|며)\.$/;
    if (badTail.test(x.trim())) {
      flags.push("line_tail_fragment_removed");
      // 라인 전체가 미완이면 제거 (의미 보강은 enforceMinimumBlockQuality가 담당)
      x = "";
    }
    if (!x.trim()) continue;
    out.push(x);
  }
  return { text: out.join("\n"), flags };
}



function extractNarrativeSentences(text: string): string[] {
  const src = String(text || "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/^#{1,6}\s+.*$/gm, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!src) return [];
  return splitSentences(src)
    .map((s) => s.trim().replace(/^\*+\s*/g, ""))
    .map((s) => ensureNiceSentence(s))
    .map((s) => (s ? s.trim() : ""))
    .filter((s) => Boolean(s));
}

function extractAssistantNarrativeFromMsgs(msgs: ChatMsg[]): string[] {
  const assistantTexts = msgs
    .filter((m) => isAssistantRole(m.role))
    .map((m) => String(m.content ?? ""))
    .join("\n");

  const cleaned = assistantTexts
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    // drop common dialogue patterns / quoted lines
    .replace(/(?:^|\s)[가-힣A-Za-z0-9_]{1,20}\s*[|:：]\s*["“'‘][^\n"”’']{0,220}["”’']?/g, " ")
    .replace(/["“”‘’']/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return extractNarrativeSentences(cleaned);
}

function renderCompactSummary(body: string, rangeMsgs: ChatMsg[], perTurnChars: number, spanTurns: number): string {
  const per = Math.max(30, Math.min(200, Math.round(Number(perTurnChars || 120) / 10) * 10));
  const span = Math.max(1, spanTurns | 0);
  const maxTotal = per * span;

  // 1) Prefer model-produced content
  const candidates = extractNarrativeSentences(body);

  // 2) If too sparse, supplement from assistant narration
  const supplemental = extractAssistantNarrativeFromMsgs(rangeMsgs);
  const pool = [...candidates, ...supplemental];

  // Dedup (rough)
  const seen = new Set<string>();
  const uniq: string[] = [];
  for (const s of pool) {
    const key = s.replace(/\s+/g, " ").trim();
    if (!key) continue;
    if (seen.has(key)) continue;
    seen.add(key);
    uniq.push(key);
  }

  const lines: string[] = [];
  for (const s of uniq) {
    if (lines.length >= span) break;
    const compressed = compressToBudget(s, per);
    const t = String(compressed || "").trim();
    if (t.length < 8) continue;
    // dialogue re-check
    if (containsDialogue(t)) continue;
    lines.push(t);
  }

  let out = lines.join("\n").trim();
  if (!out) out = makeNeutralFallbackSentence(rangeMsgs);

  // Final hard cap on total size (avoid bloated sections)
  if (out.length > maxTotal) {
    const ls = out
      .split(/\n+/)
      .map((x) => x.trim())
      .filter(Boolean);
    while (ls.length > 1 && ls.join("\n").length > maxTotal) ls.pop();
    out = ls.join("\n").trim();
  }

  if (!out) out = makeNeutralFallbackSentence(rangeMsgs);
  out = out.replace(/\n{3,}/g, "\n\n").trim();
  return out + "\n";
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const chatId = String(url.searchParams.get("chatId") || "").trim();
    const debug = url.searchParams.get("debug") === "1";
    if (!chatId) return bad("chatId가 필요합니다.");

    const u = await getSessionUser();
    if (!u?.email) return bad("로그인이 필요합니다.", 401);


    const chat = db.prepare('SELECT id FROM chats WHERE id=? AND userEmail=?').get(chatId, u.email) as any;
    if (!chat) return bad("채팅을 찾지 못했습니다.", 404);

    const settings = db
      .prepare('SELECT summaryEvery, summaryLength, longMemoryGuidance, model, maxOutputTokens, maxReasoningTokens\n         FROM chat_settings WHERE chatId=?')
      .get(chatId) as any;

    const summaryEveryVal = normalizeSummaryEvery(settings?.summaryEvery ?? 5);
    const perTurnCharsVal = normalizePerTurnChars(settings?.summaryLength ?? 120);

    const opts: ChatGenOpts = {
      model: String(settings?.model || "gemini-2.5-pro"),
      maxOutputTokens: Number(settings?.maxOutputTokens ?? 1300),
      maxReasoningTokens: Number(settings?.maxReasoningTokens ?? 768),
    };

    // 1) load cache
    let cache: any = null;
    try {
      cache = db
        .prepare('SELECT chatId, recentSummary, recentSummaryChars, summarizedEndTurn, updatedAt\n           FROM chat_memory_cache WHERE chatId=?')
        .get(chatId) as any;
    } catch {
      cache = db
        .prepare('SELECT chatId, recentSummary, recentSummaryChars, updatedAt FROM chat_memory_cache WHERE chatId=?')
        .get(chatId) as any;
    }

    const existingSummary = String(cache?.recentSummary || "");
    const existingPtr = Number(cache?.summarizedEndTurn ?? 0);

    // 1-1) Ensure block storage exists, and migrate legacy cache summary as a single block (B안: 통째 저장)
    // - We intentionally DO NOT parse headings to avoid "format drift" wiping existing memory.
    let maxBlockEnd = 0;
    try {
      const mx = db.prepare('SELECT COALESCE(MAX(endTurn), 0) AS mx FROM chat_memory_blocks WHERE chatId=?').get(chatId) as any;
      maxBlockEnd = Number(mx?.mx ?? 0) || 0;
    } catch {
      maxBlockEnd = 0;
    }

    let legacyEnd = 0;

    if (maxBlockEnd <= 0 && existingSummary.trim()) {
      const legacyClean = postprocessLongMemorySummary(stripUrlsAndMediaMarkdown(existingSummary));
      legacyEnd = Math.max(Number(existingPtr || 0), legacyClean ? 1 : 0);
      if (legacyClean && legacyEnd > 0) {
        const now = Date.now();
        try {
          db.prepare('INSERT OR IGNORE INTO chat_memory_blocks\n             (chatId, startTurn, endTurn, summary, summaryChars, summaryEvery, summaryLength, model, meta, createdAt, updatedAt)\n             VALUES (?,?,?,?,?,?,?,?,?,?,?)').run(
            chatId,
            1,
            legacyEnd,
            legacyClean,
            legacyClean.length,
            summaryEveryVal,
            perTurnCharsVal,
            String(settings?.model || "gemini-2.5-pro"),
            JSON.stringify({ migratedFromCache: true, legacy: true }),
            now,
            now
          );
        } catch {}
      }
      try {
        const mx2 = db.prepare('SELECT COALESCE(MAX(endTurn), 0) AS mx FROM chat_memory_blocks WHERE chatId=?').get(chatId) as any;
        maxBlockEnd = Number(mx2?.mx ?? 0) || 0;
      } catch {
        maxBlockEnd = legacyEnd;
      }
    }

    // 1-2) Manual override (user-edited memory). When present, return it as-is and skip auto-generation.
    const override = db
      .prepare('SELECT summary, summaryChars, updatedAt FROM chat_memory_override WHERE chatId=?')
      .get(chatId) as any;

    if (String(override?.summary || "").trim()) {
      const s = String(override.summary || "");
      return NextResponse.json({
        memory: {
          chatId,
          recentSummary: s,
          recentSummaryChars: Number(override?.summaryChars ?? s.length) || s.length,
          summarizedEndTurn: maxBlockEnd,
          updatedAt: Number(override?.updatedAt ?? Date.now()),
          override: true,
        },
      });
    }

    // 2) load messages (stable order)
    const rows = db
      .prepare('SELECT rowid as rowid, role, content, createdAt\n         FROM messages WHERE chatId=? ORDER BY createdAt ASC, rowid ASC')
      .all(chatId) as any[];

    const all: Msg[] = rows.map((r) => ({
      role: String(r.role || ""),
      content: decryptIfPossible(String(r.content || "")),
      createdAt: Number(r.createdAt || 0),
    }));

    const turnPairs = buildTurnPairs(all);
    const completedTurnCount = turnPairs.length;
    const boundaryEndTurn = completedTurnCount; // allow adaptive merge beyond fixed multiples

    // 3) Load existing blocks from DB (append-only). No parsing/rewrite of stored memory.
    const blocks = (db
      .prepare(
        'SELECT startTurn as start, endTurn as end, summary as body\n' +
         ' FROM chat_memory_blocks WHERE chatId=? ORDER BY startTurn ASC'
      )
      .all(chatId) as any[]).map((r) => ({
      start: Number(r.start || 0),
      end: Number(r.end || 0),
      body: String(r.body || ""),
    }));

        // pointer 결정: "누적(append-only)" 방식으로 계산한다.
    // - 기존 블록은 절대 재작성/병합하지 않고, 마지막 endTurn 이후만 새 블록을 추가한다.
    // - 설정 변경(예: summaryEvery)이 있어도 기존 블록은 유지한다.
    let summarizedEndTurn = 0;
    for (const b of blocks) summarizedEndTurn = Math.max(summarizedEndTurn, Number(b.end || 0));

    // 4) backfill: summary는 "완전 공백"으로 시작하고, boundary까지 누락분만 채운다.
    //    - 각 블록은 반드시 내용이 있어야 저장한다(헤더-only 금지).
    const steps: any[] = [];
    let changed = false;

    while (boundaryEndTurn > 0 && summarizedEndTurn < boundaryEndTurn) {
      const startTurn = summarizedEndTurn + 1;
      let endTurn = Math.min(startTurn + summaryEveryVal - 1, boundaryEndTurn);

      // We only generate a new long-memory block when we have at least `summaryEveryVal` turns available.
      if (endTurn - startTurn + 1 < summaryEveryVal) break;

      // Append-only: if this exact range already exists, skip forward.
      if (blocks.some((b) => b.start === startTurn && b.end === endTurn && String(b.body || "").trim().length > 0)) {
        summarizedEndTurn = endTurn;
        continue;
      }

            const span = endTurn - startTurn + 1;

      // Budget policy (방식 2):
      // - 설정이 "턴당 30자"이고 요약 주기가 3턴이면, 블록 예산은 90자(=30×3).
      // - 누적 방식에서는 블록 span을 확장/병합하지 않는다(기존 블록 재작성/순서 뒤섞임 방지).
      const budgetTurns = summaryEveryVal;
      const softMaxChars = perTurnCharsVal * budgetTurns;
      // Allow a small overflow so the model can finish the sentence naturally.
      const hardMaxChars = Math.min(2000, Math.max(80, Math.ceil(softMaxChars * 1.15)));

      let rangeMsgs = sliceByTurnPairs(turnPairs, startTurn, endTurn);
      // Prevent URL / media markdown leakage into long-memory summaries.
      let convo = stripUrlsAndMediaMarkdown(formatConversation(rangeMsgs));

      let gen = "";
      let ok = true;
      let reason = "";
      // Used later in meta/debug. Must be defined outside try/catch.
      let useTwoPass = false;

      try {
        const guidanceBase = String(settings?.longMemoryGuidance ?? "").trim();
        const guidanceAll = [LONG_MEMORY_SUMMARY_RULES, guidanceBase].filter(Boolean).join("\n").trim();

        // Two-pass mode (B안): generate a richer draft first, then compress to the final character budget.
        // This prevents "first sentence only" artifacts when the budget is very small (e.g. 30 chars × 3 turns = 90 chars).
        useTwoPass = softMaxChars <= 160;

        if (useTwoPass) {
          const firstTarget = Math.min(900, Math.max(hardMaxChars * 3, 240));
          const draft = await summarizeLongMemoryKorean({
            text: convo,
            targetChars: firstTarget,
            opts,
            guidance: guidanceAll,
          });

          if (draft && draft.trim().length > 0 && strlen(draft) > hardMaxChars) {
            gen = await summarizeLongMemoryKorean({
              text: draft,
              targetChars: hardMaxChars,
              opts,
              guidance: `${guidanceAll}\n- 추가 작업: 아래 내용을 한국어로 최대 ${hardMaxChars}자 이내로 재압축해. 문장 끝은 자연스럽게 마무리해.`,
            });
          } else {
            gen = draft;
          }
        } else {
          gen = await summarizeLongMemoryKorean({
            text: convo,
            targetChars: hardMaxChars,
            opts,
            guidance: guidanceAll,
          });
        }
      } catch (e: any) {
        ok = false;
        reason = `summarize_throw:${String(e?.message ?? e)}`;
      }

      if (!gen || gen.trim().length < 10) {
        ok = false;
        reason = reason || "model_empty";
      }

      let body = "";
      if (ok) {
        const first = sanitizeGeneratedBody(postprocessLongMemorySummary(stripUrlsAndMediaMarkdown(gen)));
        body = first.cleaned;

        // Free-form long memory: keep it as plain narrative sentences and enforce a soft+hard budget.
        body = stripTopMemoryHeader(body);
        body = enforceOverallBlockBudget(body, perTurnCharsVal, budgetTurns, hardMaxChars, rangeMsgs);
        body = enforceMinimumBlockQuality(body, perTurnCharsVal, budgetTurns, hardMaxChars, rangeMsgs);

        // dialog/content safety
        const flags = [...first.flags];
        if (containsDialogue(body)) flags.push("summary_contains_dialogue");

        if (!body || body.trim().length < 10) {
          ok = false;
          reason = "summary_empty_after_sanitize";
        } else if (flags.length) {
          // Some flags are warnings, but dialogue is fatal (we fallback)
          const fatal = flags.includes("summary_contains_dialogue");
          reason = `sanitize_flags:${flags.join(",")}`;
          if (fatal) ok = false;
        }
      }

      if (!ok) {
        const fallback = buildFallbackBlockBody(rangeMsgs, startTurn, endTurn, hardMaxChars);
        body = stripTopMemoryHeader(postprocessLongMemorySummary(stripUrlsAndMediaMarkdown(fallback)));
        body = enforceOverallBlockBudget(body, perTurnCharsVal, budgetTurns, hardMaxChars, rangeMsgs);
        body = enforceMinimumBlockQuality(body, perTurnCharsVal, budgetTurns, hardMaxChars, rangeMsgs);
        ok = true;
        reason = `fallback_used:${reason || "unknown"}`;
      }

      // Persist as a block row (append-only). DB uniqueness prevents races from duplicating blocks.
      const now2 = Date.now();
      let inserted = false;
      let insertErr = "";
      try {
        const r = db
          .prepare(
            'INSERT OR IGNORE INTO chat_memory_blocks\n' +
            ' (chatId, startTurn, endTurn, summary, summaryChars, summaryEvery, summaryLength, model, meta, createdAt, updatedAt)\n' +
            ' VALUES (?,?,?,?,?,?,?,?,?,?,?)'
          )
          .run(
            chatId,
            startTurn,
            endTurn,
            body,
            body.length,
            summaryEveryVal,
            perTurnCharsVal,
            String(settings?.model || "gemini-2.5-pro"),
            JSON.stringify({ span, softMaxChars, hardMaxChars, twoPass: useTwoPass, generatedAt: now2 }),
            now2,
            now2
          ) as any;
        inserted = Number(r?.changes ?? 0) > 0;
      } catch (e: any) {
        insertErr = String(e?.message ?? e);
      }

      if (inserted) {
        blocks.push({ start: startTurn, end: endTurn, body });
        summarizedEndTurn = endTurn;
        changed = true;
      } else {
        // If we failed due to an error, stop to avoid silently "succeeding" with empty blocks.
        if (insertErr) {
          steps.push({ startTurn, endTurn, msgCount: rangeMsgs.length, ok: false, reason: `db_insert_failed:${insertErr}` });
          break;
        }
        // If another request already created this range, advance the pointer to avoid looping.
        summarizedEndTurn = Math.max(summarizedEndTurn, endTurn);
      }

      steps.push({ startTurn, endTurn, msgCount: rangeMsgs.length, ok, ...(reason ? { reason } : {}) });
    }
    // 누적(append-only): 기존 블록을 재정렬/병합하지 않고 start 오름차순으로 저장한다.
    const finalBlocks = [...blocks]
      .filter((b) => Number.isFinite(b.start) && Number.isFinite(b.end) && b.start >= 1 && b.end >= b.start)
      .sort((a, b) => a.start - b.start);

    // summarizedEndTurn는 "마지막 블록의 end"로 둔다.
    // If no blocks were created/loaded, keep the DB pointer (maxBlockEnd) instead of resetting to 0.
    summarizedEndTurn = finalBlocks.length ? finalBlocks[finalBlocks.length - 1].end : maxBlockEnd;
    const finalSummary = blocksToSummary(finalBlocks);
    const now = Date.now();


    // 5) DB 저장: "빈 결과"가 기존 요약을 덮어쓰는 것을 막는다.
    //    - placeholder는 저장하지 않음
    const shouldWrite = changed || (!existingSummary.trim() && finalBlocks.length > 0 && finalSummary.trim().length > 0);

    if (shouldWrite) {
      const chars = finalSummary.length;
      // NOTE: use normal string literals here (not template literals) to avoid parser issues in some builds.
      const exists = db.prepare('SELECT chatId FROM chat_memory_cache WHERE chatId=?').get(chatId) as any;
      if (exists?.chatId) {
        // finalSummary가 빈 문자열인데 기존이 비어있지 않으면 덮어쓰지 않음(플리커 방지)
        const shouldWrite = finalSummary.trim() || !existingSummary.trim();
        if (shouldWrite) {
          db.prepare(
            'UPDATE chat_memory_cache\n' +
              ' SET recentSummary=?, recentSummaryChars=?, summaryEvery=?, summaryLength=?, summarizedEndTurn=?, updatedAt=?\n' +
              ' WHERE chatId=?'
          ).run(finalSummary, chars, summaryEveryVal, perTurnCharsVal, summarizedEndTurn, now, chatId);
        } else {
          // 포인터만 갱신
          try {
            db.prepare(
              'UPDATE chat_memory_cache\n' +
                ' SET summaryEvery=?, summaryLength=?, summarizedEndTurn=?, updatedAt=?\n' +
                ' WHERE chatId=?'
            ).run(summaryEveryVal, perTurnCharsVal, summarizedEndTurn, now, chatId);
          } catch {}
        }
      } else {
        db.prepare(
          'INSERT INTO chat_memory_cache (chatId, recentSummary, recentSummaryChars, summaryEvery, summaryLength, summarizedEndTurn, updatedAt)\n' +
            ' VALUES (?,?,?,?,?,?,?)'
        ).run(chatId, finalSummary, chars, summaryEveryVal, perTurnCharsVal, summarizedEndTurn, now);
      }
    }

    // reload (source of truth: DB blocks)
    const blockRows = db
      .prepare(
        'SELECT startTurn as start, endTurn as end, summary as body\n' +
          ' FROM chat_memory_blocks WHERE chatId=? ORDER BY startTurn ASC'
      )
      .all(chatId) as any[];

    const mergedSummary = blocksToSummary(
      blockRows.map((r) => ({
        start: Number(r.start || 0),
        end: Number(r.end || 0),
        body: String(r.body || ""),
      }))
    );

    const outSummaryUi = toUiLongMemory(mergedSummary, summaryEveryVal);
    const outSummaryUiClean = stripUrlsAndMediaMarkdown(outSummaryUi);

const payload: any = {
      ok: true,
      memory: {
        chatId,
        recentSummary: outSummaryUiClean,
        recentSummaryChars: strlen(outSummaryUiClean),
        summarizedEndTurn,
        updatedAt: Date.now(),
      },
    };
    if (debug) {
      payload.debug = {
        summaryEveryVal,
        perTurnCharsVal,
        completedTurnCount,
        boundaryEndTurn,
        summarizedEndTurn,
        blocks: blocks.map((b) => ({ start: b.start, end: b.end, bodyChars: b.body.length })),
        steps,
        rolesSample: all.slice(0, 25).map((m) => m.role),
      };
      // 서버 로그도 같이
      console.log("[chat/memory]", { chatId, summaryEveryVal, completedTurnCount, boundaryEndTurn, summarizedEndTurn, stepsLen: steps.length });
    }

    return NextResponse.json(payload);
  } catch (e: any) {
    console.error("[chat/memory] GET error", e);
    return NextResponse.json({ error: e?.message || "오류" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = (await req.json().catch(() => null)) as any;
    const chatId = String(body?.chatId || "").trim();
    if (!chatId) return bad("chatId가 필요합니다.");

    const recentSummaryRaw = String(body?.recentSummary ?? "");
    const recentSummary = stripUrlsAndMediaMarkdown(recentSummaryRaw);
    const now = Date.now();

    // 수동 편집은 "override"로 저장한다.
    // - 블록 자동 생성(append-only)과 분리하여, 편집 저장이 기존 블록을 재작성/병합하지 않도록 한다.
    const settings = db
      .prepare('SELECT summaryEvery, summaryLength FROM chat_settings WHERE chatId=?')
      .get(chatId) as any;
    const summaryEveryVal = normalizeSummaryEvery(settings?.summaryEvery ?? 5);
    const perTurnCharsVal = normalizePerTurnChars(settings?.summaryLength ?? 120);

    const cleaned = postprocessLongMemorySummary(recentSummary);

    if (!cleaned.trim()) {
      // 빈 값 저장은 override 해제
      try {
        db.prepare('DELETE FROM chat_memory_override WHERE chatId=?').run(chatId);
      } catch {}
    } else {
      try {
        db.prepare('INSERT INTO chat_memory_override (chatId, summary, summaryChars, updatedAt)\n           VALUES (?,?,?,?)\n           ON CONFLICT(chatId) DO UPDATE SET summary=excluded.summary, summaryChars=excluded.summaryChars, updatedAt=excluded.updatedAt').run(chatId, cleaned, cleaned.length, now);
      } catch {}
    }

    // Back-compat: also store into cache for existing UI fields (not used as source of truth).
    try {
      const exists = db.prepare('SELECT chatId FROM chat_memory_cache WHERE chatId=?').get(chatId) as any;
      if (exists?.chatId) {
        db.prepare('UPDATE chat_memory_cache\n           SET recentSummary=?, recentSummaryChars=?, summaryEvery=?, summaryLength=?, updatedAt=?\n           WHERE chatId=?').run(cleaned, cleaned.length, summaryEveryVal, perTurnCharsVal, now, chatId);
      } else {
        db.prepare('INSERT INTO chat_memory_cache (chatId, recentSummary, recentSummaryChars, summaryEvery, summaryLength, updatedAt)\n           VALUES (?,?,?,?,?,?)').run(chatId, cleaned, cleaned.length, summaryEveryVal, perTurnCharsVal, now);
      }
    } catch {}

    // Report pointer for UI/debug (blocks remain the truth)
    let maxBlockEnd = 0;
    try {
      const mx = db.prepare('SELECT COALESCE(MAX(endTurn), 0) AS mx FROM chat_memory_blocks WHERE chatId=?').get(chatId) as any;
      maxBlockEnd = Number(mx?.mx ?? 0) || 0;
    } catch {}

    const outSummaryUi = cleaned ? toUiLongMemory(cleaned, summaryEveryVal) : "";
    const outSummaryUiClean = stripUrlsAndMediaMarkdown(outSummaryUi);
    const outRow = {
      chatId,
      recentSummary: outSummaryUiClean,
      recentSummaryChars: strlen(outSummaryUiClean),
      summarizedEndTurn: maxBlockEnd,
      updatedAt: now,
      override: cleaned.trim() ? true : false,
    };

    return NextResponse.json({ ok: true, memory: outRow });

  } catch (e: any) {
    console.error("[chat/memory] POST error", e);
    return NextResponse.json({ error: e?.message || "오류" }, { status: 500 });
  }
}
