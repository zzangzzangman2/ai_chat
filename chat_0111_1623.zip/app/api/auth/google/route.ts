import { NextResponse } from "next/server";
import { buildGoogleAuthRedirect, attachOauthCookies } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  const { url, state, codeVerifier } = await buildGoogleAuthRedirect();
  const res = NextResponse.redirect(url);
  await attachOauthCookies(res, state, codeVerifier);
  return res;
}
