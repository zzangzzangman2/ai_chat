'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";

type User = {
  email: string;
  name?: string;
  picture?: string;
  nickname?: string | null;
};

function AvatarLabel({ user }: { user: User }) {
  const label = user.nickname || user.name || user.email;
  return (
    <span
      style={{
        fontSize: 14,
        fontWeight: 700,
        color: "#e9eefc",
        maxWidth: 180,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap",
        display: "inline-block",
        lineHeight: "36px",
      }}
      title={label}
    >
      {label}
    </span>
  );
}

function NicknameModal({
  open,
  defaultNick,
  onClose,
  onSaved,
}: {
  open: boolean;
  defaultNick: string;
  onClose: () => void;
  onSaved: (nickname: string) => void;
}) {
  const [nick, setNick] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      const v = String(defaultNick || '').trim();
      if (v) setNick(v);
    }
    if (!open) {
      setNick("");
      setErr(null);
      setSaving(false);
    }
  }, [open]);

  const save = useCallback(async () => {
    const v = nick.trim();
    if (!v) return setErr("닉네임을 입력해줘.");
    setSaving(true);
    setErr(null);
    try {
      const r = await fetch("/api/profile/nickname", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ nickname: v }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j?.error || "저장 실패");
      onSaved(v);
      onClose();
    } catch (e: any) {
      setErr(e?.message || "저장 실패");
    } finally {
      setSaving(false);
    }
  }, [nick, onClose, onSaved]);

  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.70)",
        display: "grid",
        placeItems: "center",
        zIndex: 200,
      }}
    >
      <div
        style={{
          width: "min(460px, calc(100vw - 32px))",
          borderRadius: 22,
          border: "1px solid rgba(255,255,255,0.14)",
          background: "rgba(14,14,16,0.94)",
          boxShadow: "0 18px 70px rgba(0,0,0,0.68)",
          padding: 18,
          backdropFilter: "blur(10px)",
        }}
      >
        <div style={{ display: "grid", justifyItems: "center", gap: 10, padding: "8px 6px 4px" }}>
          {/* 로고 */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/logo-ribbon.png"
            alt="MATE"
            style={{ width: 86, height: 86, borderRadius: 18, boxShadow: "0 10px 30px rgba(0,0,0,0.55)" }}
          />
          <div style={{ fontWeight: 950, fontSize: 22, letterSpacing: "0.2px", color: "#a855f7" }}>
            메이트
          </div>
          <div style={{ fontSize: 12, opacity: 0.72, textAlign: "center", lineHeight: 1.35 }}>
            시작하려면 고유한 닉네임을 정해주세요. (2~20자)
          </div>
        </div>

        <input
          value={nick}
          onChange={(e) => setNick(e.target.value)}
          placeholder="예) 박성준"
          style={{
            width: "100%",
            height: 44,
            borderRadius: 14,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(255,255,255,0.05)",
            color: "#e9eefc",
            padding: "0 14px",
            outline: "none",
            marginTop: 12,
          }}
        />
        {err ? <div style={{ marginTop: 8, fontSize: 12, color: "#ffb4b4" }}>{err}</div> : null}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 12 }}>
          <button
            type="button"
            onClick={onClose}
            style={{
              height: 38,
              padding: "0 14px",
              borderRadius: 14,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(255,255,255,0.06)",
              color: "#e9eefc",
              cursor: "pointer",
            }}
          >
            나중에
          </button>
          <button
            type="button"
            disabled={saving}
            onClick={save}
            style={{
              height: 38,
              padding: "0 14px",
              borderRadius: 14,
              border: "1px solid rgba(168,85,247,0.35)",
              background: "rgba(168,85,247,0.25)",
              color: "#e9eefc",
              cursor: saving ? "not-allowed" : "pointer",
              opacity: saving ? 0.7 : 1,
              fontWeight: 800,
            }}
          >
            {saving ? "저장 중..." : "저장"}
          </button>
        </div>
      </div>
    </div>
  );
}

function getKSTDateKey(d: Date = new Date()) {
  // Format: YYYY-MM-DD in Asia/Seoul
  try {
    const fmt = new Intl.DateTimeFormat("sv-SE", {
      timeZone: "Asia/Seoul",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
    return fmt.format(d); // sv-SE => 2026-01-04
  } catch {
    // Fallback (local timezone)
    return d.toISOString().slice(0, 10);
  }
}

function addDaysKST(dateKey: string, days: number) {
  // dateKey: YYYY-MM-DD
  const [y, m, d] = dateKey.split("-").map((v) => parseInt(v, 10));
  const base = new Date(Date.UTC(y, (m || 1) - 1, d || 1, 12, 0, 0));
  base.setUTCDate(base.getUTCDate() + days);
  return getKSTDateKey(base);
}

type FriendFeeState = {
  lastCheckin: string; // YYYY-MM-DD
  streak: number;
  total: number;
};

function FriendFeeModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [mounted, setMounted] = useState(false);
  const [state, setState] = useState<FriendFeeState>({ lastCheckin: "", streak: 0, total: 0 });
  const [toast, setToast] = useState("");

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    try {
      const raw = localStorage.getItem("mate_friend_fee_state");
      if (raw) {
        const parsed = JSON.parse(raw) as FriendFeeState;
        if (parsed && typeof parsed === "object") setState(parsed);
      }
    } catch {
      // ignore
    }
  }, [open]);

  const persist = useCallback((next: FriendFeeState) => {
    setState(next);
    try {
      localStorage.setItem("mate_friend_fee_state", JSON.stringify(next));
      window.dispatchEvent(new Event("mate_friend_fee_updated"));
    } catch {
      // ignore
    }
  }, []);

  const today = getKSTDateKey();
  const checkedToday = state.lastCheckin === today;

  const onCheckin = useCallback(() => {
    const todayKey = getKSTDateKey();
    if (state.lastCheckin === todayKey) {
      setToast("오늘은 이미 출석체크 했어요 💜");
      return;
    }
    const yesterday = addDaysKST(todayKey, -1);
    const nextStreak = state.lastCheckin === yesterday ? Math.max(1, (state.streak || 0) + 1) : 1;
    const nextTotal = (state.total || 0) + 10;

    persist({ lastCheckin: todayKey, streak: nextStreak, total: nextTotal });
    setToast("출석체크 완료! 친구비 +10 💕");
  }, [persist, state.lastCheckin, state.streak, state.total]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, open]);

  if (!open || !mounted || typeof document === "undefined") return null;

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 10050,
        background: "rgba(0,0,0,0.58)",
        display: "grid",
        placeItems: "center",
        padding: 16,
      }}
    >
      <div
        style={{
          width: "min(520px, 92vw)",
          borderRadius: 18,
          border: "1px solid rgba(255,255,255,0.14)",
          background: "rgba(18,18,24,0.92)",
          boxShadow: "0 18px 60px rgba(0,0,0,0.6)",
          backdropFilter: "blur(10px)",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "14px 14px 10px 14px",
            borderBottom: "1px solid rgba(255,255,255,0.10)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/logo-ribbon.png" alt="메이트" style={{ width: 34, height: 34, borderRadius: 10 }} />
            <div style={{ display: "grid", gap: 2 }}>
              <div style={{ fontWeight: 950, letterSpacing: "0.2px", fontSize: 16, color: "#e9eefc" }}>
                💕 친구비 입금
              </div>
              <div style={{ fontSize: 12, opacity: 0.72 }}>출석체크로 친구비를 받아요</div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            style={{
              height: 34,
              width: 34,
              borderRadius: 10,
              border: "1px solid rgba(255,255,255,0.12)",
              background: "rgba(255,255,255,0.06)",
              color: "#e9eefc",
              cursor: "pointer",
              fontSize: 18,
              lineHeight: "34px",
            }}
          >
            ×
          </button>
        </div>

        <div style={{ padding: 14, display: "grid", gap: 12 }}>
          <div
            style={{
              borderRadius: 16,
              border: "1px solid rgba(255,255,255,0.12)",
              background: "rgba(255,255,255,0.05)",
              padding: 14,
              display: "grid",
              gap: 10,
            }}
          >
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 12 }}>
              <div style={{ fontWeight: 900, color: "#e9eefc" }}>오늘 출석</div>
              <div style={{ fontSize: 12, opacity: 0.7 }}>{today}</div>
            </div>

            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <div style={{ fontSize: 13, opacity: 0.86 }}>
                상태: <span style={{ fontWeight: 900 }}>{checkedToday ? "출석 완료 ✅" : "미출석"}</span>
              </div>
              <div style={{ fontSize: 13, opacity: 0.86 }}>
                연속: <span style={{ fontWeight: 900 }}>{state.streak || 0}일</span>
              </div>
              <div style={{ fontSize: 13, opacity: 0.86 }}>
                누적 친구비: <span style={{ fontWeight: 900 }}>{state.total || 0}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={onCheckin}
              disabled={checkedToday}
              style={{
                height: 40,
                borderRadius: 14,
                border: "1px solid rgba(255,255,255,0.14)",
                background: checkedToday ? "rgba(255,255,255,0.06)" : "rgba(168,85,247,0.28)",
                color: "#e9eefc",
                cursor: checkedToday ? "not-allowed" : "pointer",
                fontWeight: 950,
              }}
            >
              출석체크
            </button>

            {toast ? (
              <div style={{ fontSize: 12, opacity: 0.85 }}>{toast}</div>
            ) : (
              <div style={{ fontSize: 12, opacity: 0.55 }}>* 출석체크는 하루 1회 가능 (KST 기준)</div>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}


export default function AuthControls(props: { onOpenFriendFeePage?: () => void } = {}) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const [nickModal, setNickModal] = useState(false);
  const [defaultNick, setDefaultNick] = useState<string>("");

  const [menuOpen, setMenuOpen] = useState(false);
  const [menuPos, setMenuPos] = useState<{ top: number; left: number } | null>(null);
  const [friendFeeOpen, setFriendFeeOpen] = useState(false);
  const [friendFeeTotal, setFriendFeeTotal] = useState<number>(0);

  // Friend-fee state fetch can get noisy when streaming/billing triggers many updates.
  // We coalesce requests and throttle re-fetching to keep dev logs readable.
  const friendFeeLastFetchAtRef = useRef<number>(0);
  const friendFeeInFlightRef = useRef<Promise<void> | null>(null);
  const friendFeePendingTimerRef = useRef<number | null>(null);
  const friendFeeDidImportRef = useRef<boolean>(false);

  const FRIEND_FEE_USER_ID_KEY = "mate_friendfee_userid_v1";
  const friendFeeKey = useCallback((base: string, uid: string | null | undefined) => {
    const safe = (uid || "").trim();
    if (!safe) return base; // fallback (should not happen)
    return `${base}__${safe}`;
  }, []);

  const getCurrentFriendFeeUserId = useCallback((): string | null => {
    if (typeof window === "undefined") return null;
    try {
      const raw = window.localStorage.getItem(FRIEND_FEE_USER_ID_KEY);
      return raw && raw.trim() ? raw.trim() : null;
    } catch {
      return null;
    }
  }, []);

  const loadFriendFeeTotal = useCallback(
    async (opts?: { force?: boolean }) => {
      if (typeof window === "undefined") return;

      // Throttle: coalesce bursts into a single fetch so dev logs stay readable.
      const now = Date.now();
      const last = friendFeeLastFetchAtRef.current || 0;
      const minGapMs = 1500;

      if (!opts?.force) {
        if (friendFeeInFlightRef.current) return friendFeeInFlightRef.current;
        const delta = now - last;
        if (delta >= 0 && delta < minGapMs) {
          if (friendFeePendingTimerRef.current == null) {
            friendFeePendingTimerRef.current = window.setTimeout(() => {
              friendFeePendingTimerRef.current = null;
              loadFriendFeeTotal({ force: true }).catch(() => null);
            }, Math.max(0, minGapMs - delta));
          }
          return;
        }
      }

      // Coalesce concurrent calls.
      friendFeeLastFetchAtRef.current = now;
      const task = (async () => {
        // (마이그레이션) 기존 로컬스토리지 잔액을 서버로 1회 이관
        // - 서버 잔액이 0이고 ledger가 비어 있을 때만 적용되므로 안전
        if (!friendFeeDidImportRef.current) {
          friendFeeDidImportRef.current = true;
          try {
            const uid = getCurrentFriendFeeUserId();
            const importedKey = uid ? friendFeeKey("mate_friendfee_imported_v1", uid) : "mate_friendfee_imported_v1";
            const already = window.localStorage.getItem(importedKey);
            if (!already) {
              const raw = uid
                ? window.localStorage.getItem(friendFeeKey("mate_friendfee_balance_v1", uid))
                : window.localStorage.getItem("mate_friendfee_balance_v1");
              const localBal = Number(raw);
              if (Number.isFinite(localBal) && localBal > 0) {
                await fetch("/api/friendfee/import", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ balance: localBal }),
                }).catch(() => null);
              }
              try {
                window.localStorage.setItem(importedKey, "1");
              } catch {}
            }
          } catch {
            // ignore
          }
        }

        // 1) 서버(DB) 잔액이 진실의 원본 (기기/브라우저 무관)
        try {
          const r = await fetch("/api/friendfee/state", { cache: "no-store" });
          if (r.ok) {
            const j = await r.json().catch(() => null);
            if (j?.ok) {
              const balReal = Number(j.balance ?? 0);
              const balUi = Math.round(Number.isFinite(balReal) ? balReal : 0);
              setFriendFeeTotal(balUi);

              // local cache (동일 탭/구형 UI 호환)
              try {
                const uid = getCurrentFriendFeeUserId();
                if (uid) {
                  localStorage.setItem(friendFeeKey("mate_friendfee_balance_v1", uid), String(balReal));
                  localStorage.setItem(
                    friendFeeKey("mate_friend_fee_state", uid),
                    JSON.stringify({ total: balUi, updatedAt: Date.now() })
                  );
                } else {
                  localStorage.setItem("mate_friendfee_balance_v1", String(balReal));
                  localStorage.setItem("mate_friend_fee_state", JSON.stringify({ total: balUi, updatedAt: Date.now() }));
                }
              } catch {
                // ignore
              }
              return;
            }
          }
        } catch {
          // ignore
        }

        // 2) 서버가 안되면 (오프라인 등) 로컬 캐시 폴백
        try {
          const uid = getCurrentFriendFeeUserId();
          if (uid) {
            const balRaw = localStorage.getItem(friendFeeKey("mate_friendfee_balance_v1", uid));
            if (balRaw != null) {
              const n = Number(balRaw);
              setFriendFeeTotal(Math.round(Number.isFinite(n) ? n : 0));
              return;
            }
            const legacyRaw = localStorage.getItem(friendFeeKey("mate_friend_fee_state", uid));
            if (legacyRaw) {
              const j = JSON.parse(legacyRaw);
              const t = Number((j as any)?.total ?? 0);
              setFriendFeeTotal(Number.isFinite(t) ? t : 0);
              return;
            }
            setFriendFeeTotal(0);
            return;
          }
          const raw = localStorage.getItem("mate_friend_fee_state");
          if (raw) {
            const j = JSON.parse(raw);
            const t = Number((j as any)?.total ?? 0);
            setFriendFeeTotal(Number.isFinite(t) ? t : 0);
            return;
          }
        } catch {
          // ignore
        }
        setFriendFeeTotal(0);
      })();

      friendFeeInFlightRef.current = task;
      try {
        await task;
      } finally {
        if (friendFeeInFlightRef.current === task) friendFeeInFlightRef.current = null;
      }
    },
    [friendFeeKey, getCurrentFriendFeeUserId]
  );

  useEffect(() => {
    // 최초 로드
    if (typeof window === "undefined") return;
    loadFriendFeeTotal();

    const onUpdated = (ev?: Event) => {
      // Fast-path: if the event already carries the new balance (from a server response),
      // update UI immediately without triggering another /state fetch.
      try {
        const d = (ev as any)?.detail;
        if (d && typeof d.balanceUi === "number") {
          setFriendFeeTotal(d.balanceUi);
          return;
        }
      } catch {
        // ignore
      }

      // Next best: same-tab cache (avoid spamming /api/friendfee/state).
      try {
        const uid = getCurrentFriendFeeUserId();
        const balRaw = uid
          ? window.localStorage.getItem(friendFeeKey("mate_friendfee_balance_v1", uid))
          : window.localStorage.getItem("mate_friendfee_balance_v1");
        if (balRaw != null) {
          const n = Number(balRaw);
          if (Number.isFinite(n)) {
            setFriendFeeTotal(Math.round(n));
            return;
          }
        }
        const legacyRaw = uid
          ? window.localStorage.getItem(friendFeeKey("mate_friend_fee_state", uid))
          : window.localStorage.getItem("mate_friend_fee_state");
        if (legacyRaw) {
          const j = JSON.parse(legacyRaw);
          const t = Number((j as any)?.total ?? 0);
          if (Number.isFinite(t)) {
            setFriendFeeTotal(t);
            return;
          }
        }
      } catch {
        // ignore
      }

      // Last resort: coalesced fetch
      loadFriendFeeTotal();
    };
    const onStorage = (e: StorageEvent) => {
      const uid = getCurrentFriendFeeUserId();
      const keys = new Set<string>([
        "mate_friend_fee_state",
        "mate_friendfee_balance_v1",
        uid ? friendFeeKey("mate_friend_fee_state", uid) : "",
        uid ? friendFeeKey("mate_friendfee_balance_v1", uid) : "",
        FRIEND_FEE_USER_ID_KEY,
      ]);
      if (e.key && keys.has(e.key)) loadFriendFeeTotal();
    };

    window.addEventListener("mate_friend_fee_updated", onUpdated as any);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener("mate_friend_fee_updated", onUpdated as any);
      window.removeEventListener("storage", onStorage);
    };
  }, [loadFriendFeeTotal]);

  // When the authenticated user changes, switch the friend-fee bucket immediately.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const uid = (user as any)?.email || (user as any)?.id || "";
    try {
      if (uid) window.localStorage.setItem(FRIEND_FEE_USER_ID_KEY, String(uid));
      else window.localStorage.removeItem(FRIEND_FEE_USER_ID_KEY);
    } catch {
      // ignore
    }
    // Force a reload of balance for the new user in the same tab.
    loadFriendFeeTotal();
    try {
      window.dispatchEvent(new Event("mate_friend_fee_updated"));
    } catch {
      // ignore
    }
  }, [user, loadFriendFeeTotal]);

  useEffect(() => {
    // 모달 닫힐 때 최신 값 반영(같은 탭에서는 storage 이벤트가 안 뜸)
    if (typeof window === "undefined") return;
    if (!friendFeeOpen) loadFriendFeeTotal();
  }, [friendFeeOpen, loadFriendFeeTotal]);
  useEffect(() => {
    const onOpen = () => setFriendFeeOpen(true);
    if (typeof window !== "undefined") {
      window.addEventListener("mate:openFriendFee", onOpen as any);
    }
    return () => {
      if (typeof window !== "undefined") {
        window.removeEventListener("mate:openFriendFee", onOpen as any);
      }
    };
  }, []);


  const menuRef = useRef<HTMLDivElement | null>(null);
  const nickBtnRef = useRef<HTMLButtonElement | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch("/api/auth/me", { cache: "no-store" });
      const j = await r.json().catch(() => ({} as any));
      const u = (j?.user ?? null) as User | null;
      setUser(u);

      if (u) {
        const nick = (u.nickname ?? "").toString().trim();
        setDefaultNick(nick);

        // 닉네임이 없으면 전용 페이지로 유도 (기존 정책 유지)
        if (!nick) {
          if (typeof window !== "undefined") {
            const p = window.location?.pathname || "";
            if (p !== "/nickname") window.location.href = "/nickname";
          }
        }
      } else {
        setDefaultNick("");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const onLogin = useCallback(() => {
    window.location.href = "/api/auth/google";
  }, []);

  const onLogout = useCallback(async () => {
    setMenuOpen(false);
    setMenuPos(null);
    setFriendFeeOpen(false);
    
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    setUser(null);

    // Clear current user pointer so next login starts from its own bucket.
    try {
      window.localStorage.removeItem(FRIEND_FEE_USER_ID_KEY);
      window.dispatchEvent(new Event("mate_friend_fee_updated"));
    } catch {
      // ignore
    }

    // Notify the app shell to drop any cached auth state immediately.
    try {
      window.dispatchEvent(new Event("sj:logout"));
    } catch {}

    // Hard refresh to ensure all server/client caches are reset and gated routes close.
    try {
      window.location.replace("/?logged_out=1");
    } catch {
      try {
        window.location.reload();
      } catch {}
    }
  }, []);

  // Close dropdown on outside click / ESC
  useEffect(() => {
    if (!menuOpen) return;

    const onDown = (e: MouseEvent) => {
      const btn = nickBtnRef.current;
      const menu = menuRef.current;
      const t = e.target;
      if (t instanceof Node) {
        if (btn && btn.contains(t)) return;
        if (menu && menu.contains(t)) return;
      }
      setMenuOpen(false);
      setMenuPos(null);
    };

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        setMenuPos(null);
      }
    };

    window.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  // Position dropdown under the nickname button (portal menu)
  useEffect(() => {
    if (!menuOpen) {
      setMenuPos(null);
      return;
    }

    const update = () => {
      const btn = nickBtnRef.current;
      if (!btn) return;

      const r = btn.getBoundingClientRect();
      const minW = 160;
      const left = Math.max(8, Math.min(window.innerWidth - minW - 8, r.right - minW));
      const top = Math.min(window.innerHeight - 8, r.bottom + 8);
      setMenuPos({ top, left });
    };

    update();
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);
    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [menuOpen]);

  const right = useMemo(() => {
    if (loading) {
      return <div style={{ fontSize: 12, opacity: 0.6 }}>…</div>;
    }

    if (!user) {
      return (
        <button
          type="button"
          onClick={onLogin}
          style={{
            height: 36,
            padding: "0 12px",
            borderRadius: 12,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(255,255,255,0.06)",
            color: "#e9eefc",
            cursor: "pointer",
            fontWeight: 800,
          }}
        >
          로그인
        </button>
      );
    }

    return (
      <>
        <div style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
          {/* (RED) 닉네임 버튼: 메뉴 토글 */}
          <button
            ref={nickBtnRef}
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            style={{
              height: 40,
              padding: "0 14px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(255,255,255,0.06)",
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
            }}
            aria-haspopup="menu"
            aria-expanded={menuOpen ? "true" : "false"}
          >
            {/* AvatarLabel 내부 글씨 크기가 작으면 여기서 감싸서 키운다 */}
            <div style={{ fontSize: 18, fontWeight: 950, lineHeight: "20px" }}>
              <AvatarLabel user={user} />
            </div>
          </button>

          {/* (YELLOW) 친구비 버튼: 페이지 이동 (nested button 금지) */}
          <div
            role="button"
            tabIndex={0}
            onClick={(e) => {
              e.stopPropagation();
              if (props.onOpenFriendFeePage) props.onOpenFriendFeePage();
              else setFriendFeeOpen(true);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                if (props.onOpenFriendFeePage) props.onOpenFriendFeePage();
                else setFriendFeeOpen(true);
              }
            }}
            style={{
              height: 40,
              padding: "0 14px",
              borderRadius: 12,
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(255,255,255,0.06)",
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              cursor: "pointer",
              userSelect: "none",
            }}
            aria-label={`친구비 ${friendFeeTotal.toLocaleString()} 보유`}
            title={`친구비 ${friendFeeTotal.toLocaleString()}`}
          >
            <img src="/friendfee-coin.png" alt="친구비" width={26} height={26} style={{ display: "block" }} />
            <span style={{ fontSize: 18, fontWeight: 950, letterSpacing: 0.2 }}>{friendFeeTotal.toLocaleString()}</span>
          </div>
        </div>

        {menuOpen && menuPos && typeof document !== "undefined" &&
          createPortal(
            <div
              ref={menuRef}
              role="menu"
              style={{
                position: "fixed",
                top: menuPos.top,
                left: menuPos.left,
                minWidth: 160,
                borderRadius: 12,
                border: "1px solid rgba(255,255,255,0.14)",
                background: "rgba(10,10,10,0.95)",
                boxShadow: "0 10px 30px rgba(0,0,0,0.45)",
                padding: 6,
                zIndex: 1000,
              }}
            >
              <button
                type="button"
                onClick={onLogout}
                role="menuitem"
                style={{
                  width: "100%",
                  textAlign: "left",
                  height: 36,
                  padding: "0 10px",
                  borderRadius: 10,
                  border: "none",
                  background: "transparent",
                  color: "#e9eefc",
                  cursor: "pointer",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "rgba(255,255,255,0.08)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "transparent";
                }}
              >
                로그아웃
              </button>
            </div>,
            document.body
          )}
      </>
    );
  }, [loading, menuOpen, menuPos, onLogin, onLogout, user, friendFeeTotal, props.onOpenFriendFeePage]);

  return (
    <>
      {right}
      <FriendFeeModal open={friendFeeOpen} onClose={() => setFriendFeeOpen(false)} />
      <NicknameModal
        open={nickModal}
        defaultNick={defaultNick}
        onClose={() => setNickModal(false)}
        onSaved={() => refresh()}
      />
    </>
  );
}