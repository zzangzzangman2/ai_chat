#!/usr/bin/env bash
set -euo pipefail

# Moves editor/backup artifacts (*.bak*, *.backup.*, *~, *.old) out of the Next.js
# app tree so Turbopack/TS doesn't waste time scanning them.
#
# Destination: ./backups/app_bak_YYYYMMDD_HHMMSS/<original-relative-path>

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y%m%d_%H%M%S)"
DEST="$ROOT/backups/app_bak_${STAMP}"

mkdir -p "$DEST"

count=0
while IFS= read -r -d '' f; do
  rel="${f#$ROOT/}"
  mkdir -p "$DEST/$(dirname "$rel")"
  mv "$f" "$DEST/$rel"
  count=$((count+1))
done < <(
  find "$ROOT/app" -type f \( \
    -name "*.bak" -o -name "*.bak.*" -o -name "*.backup.*" -o -name "*.old" -o -name "*~" \
  \) -print0
)

echo "Moved $count backup file(s) to: $DEST"