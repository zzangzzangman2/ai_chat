#!/usr/bin/env node
/**
 * Quick sanity test for Gemini models using the same @google/genai SDK your app uses.
 *
 * Usage:
 *   GEMINI_API_KEY="..." node tools/test_gemini_model.mjs gemini-3-pro-preview
 *   GEMINI_API_KEY="..." node tools/test_gemini_model.mjs gemini-2.5-pro "한 줄만 테스트"
 *
 * It prints:
 *  - model
 *  - first 300 chars of output
 *  - usage metadata (if available)
 *  - detailed error status/message if it fails
 */
import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY || "";
if (!apiKey) {
  console.error("ERROR: GEMINI_API_KEY is missing (export GEMINI_API_KEY=...)");
  process.exit(2);
}

const model = (process.argv[2] || "gemini-3-pro-preview").trim();
const prompt = (process.argv[3] || "짧게: 지금 1문장만 출력해줘.").trim();

function extractHttpStatus(err) {
  const e = err || {};
  return (
    e?.status ||
    e?.code ||
    e?.response?.status ||
    e?.cause?.status ||
    e?.cause?.code ||
    null
  );
}

function extractErrText(err) {
  try {
    if (!err) return "";
    if (typeof err === "string") return err;
    if (err?.message) return String(err.message);
    return JSON.stringify(err);
  } catch {
    return String(err);
  }
}

(async () => {
  const genai = new GoogleGenAI({ apiKey });

  const req = {
    model,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: { maxOutputTokens: 256 },
  };

  try {
    const resp = await genai.models.generateContent(req);
    const text =
      resp?.text ??
      resp?.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") ??
      "";
    console.log("OK");
    console.log("model:", model);
    console.log("prompt:", prompt);
    console.log("text(<=300):", text.slice(0, 300));
    console.log("usage:", resp?.usageMetadata || resp?.usage || null);
  } catch (err) {
    const st = extractHttpStatus(err);
    console.error("FAILED");
    console.error("model:", model);
    console.error("status:", st);
    console.error("error:", extractErrText(err));
    // Some errors include a JSON body:
    try {
      if (err?.response?.data) console.error("response.data:", JSON.stringify(err.response.data));
    } catch {}
    process.exit(1);
  }
})();
