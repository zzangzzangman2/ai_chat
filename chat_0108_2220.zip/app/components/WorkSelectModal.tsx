"use client";

import React, { useEffect, useMemo, useState } from "react";

type Preset = {
  id: string;
  userEmail?: string;
  name: string;
  characterName?: string;
  background?: string;
  desc?: string;
  image?: string;
  gallery?: string;
  tags?: string;
  target?: string;
  // DB presets 테이블
  createdAt?: number;
  character?: string;
};

type PresetMeta = {
  views: number;
  likeCount: number;
  followCount: number;
  chatCount: number;
  likedByMe: boolean;
  followedByMe: boolean;
};

type PresetCreator = {
  email: string | null;
  nickname: string | null;
  name: string | null;
  image: string | null;
};

type PresetComment = {
  id: string;
  presetId: string;
  userEmail: string;
  content: string;
  createdAt: number;
  likeCount: number;
  likedByMe: boolean;
};


function safeString(v: any) {
  return typeof v === "string" ? v : "";
}

const FALLBACK_THUMB =
  "data:image/svg+xml;charset=utf-8," +
  encodeURIComponent(`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450" viewBox="0 0 800 450">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#1b1b24"/>
      <stop offset="1" stop-color="#0b0b0f"/>
    </linearGradient>
  </defs>
  <rect width="800" height="450" fill="url(#g)"/>
  <text x="40" y="410" font-family="system-ui,-apple-system,Segoe UI,Roboto" font-size="20" fill="rgba(255,255,255,0.42)">No Cover</text>
</svg>`);

function pickThumb(p: Preset | null) {
  if (!p) return FALLBACK_THUMB;
  const img = safeString((p as any).image).trim();
  if (img) return img;
  const rawGallery = safeString((p as any).gallery).trim();
  if (rawGallery) {
    try {
      const parsed = JSON.parse(rawGallery);
      if (Array.isArray(parsed)) {
        const first = parsed[0];
        if (typeof first === "string" && first.trim()) return first.trim();
        if (first && typeof first === "object") {
          const u = safeString((first as any).url || (first as any).src || (first as any).image).trim();
          if (u) return u;
        }
      }
    } catch {
      // ignore
    }
  }
  return FALLBACK_THUMB;
}

function pickDesc(p: Preset | null) {
  if (!p) return "";
  const d = safeString((p as any).desc).trim();
  if (d) return d;
  const ch = safeString((p as any).character).trim();
  if (ch) return ch;
  const bg = safeString((p as any).background).trim();
  if (bg) return bg;
  const tags = safeString((p as any).tags).trim();
  if (tags) return tags;
  const target = safeString((p as any).target).trim();
  return target;
}

function formatDate(ts?: number) {
  if (!ts || !Number.isFinite(ts)) return "";
  const d = new Date(ts);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function extractTags(preset: Preset | null): string[] {
  if (!preset) return [];
  const raw = [safeString((preset as any).tags), safeString((preset as any).target)].filter(Boolean).join(" ");
  // 1) 해시태그 #태그
  const hashtags = Array.from(raw.matchAll(/#([\p{L}\p{N}_-]{1,32})/gu)).map((m) => `#${m[1]}`);
  const uniq = Array.from(new Set(hashtags.map((t) => t.trim()).filter(Boolean)));
  return uniq.slice(0, 8);
}

export default function WorkSelectModal(props: {
  open: boolean;
  onClose: () => void;
  preset: Preset | null;
  latestChatLoaded: boolean;
  hasLatestChat: boolean;
  onContinue: () => void;
  onNew: () => void;
}) {
  const { open, onClose, preset, latestChatLoaded, hasLatestChat, onContinue, onNew } = props;

  // IMPORTANT: Hooks must be called unconditionally in the same order.
  // `useMemo` is a hook, so it must be above any early-return like `if (!open) return null;`.
  const tags = useMemo(() => extractTags(preset), [preset]);

  // 1차: 소개/댓글 탭 UI만 먼저 완성(댓글은 준비중)
  const [tab, setTab] = useState<"intro" | "comments">("intro");
  const [chatCount, setChatCount] = useState<number | null>(null);
  const [meta, setMeta] = useState<PresetMeta | null>(null);
  const [creator, setCreator] = useState<PresetCreator | null>(null);
  const [me, setMe] = useState<{ email: string; nickname?: string | null } | null>(null);
  const [comments, setComments] = useState<PresetComment[]>([]);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [commentErr, setCommentErr] = useState<string | null>(null);
  const [commentSending, setCommentSending] = useState(false);


  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) return;
    setTab("intro");
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const pid = preset?.id;
    if (!pid) return;
    let cancelled = false;
    setChatCount(null);
    fetch(`/api/chat/count?presetId=${encodeURIComponent(pid)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (cancelled) return;
        const n = j && typeof j.count === "number" ? j.count : null;
        setChatCount(n);
      })
      .catch(() => {
        if (cancelled) return;
        setChatCount(null);
      });
    return () => {
      cancelled = true;
    };
  }, [open, preset?.id]);

  useEffect(() => {
    if (!open) return;
    // current user (for like/follow/comment UI)
    let cancelled = false;
    fetch("/api/auth/me")
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (cancelled) return;
        const u = j?.user;
        setMe(u && u.email ? { email: String(u.email), nickname: u.nickname ?? null } : null);
      })
      .catch(() => {
        if (cancelled) return;
        setMe(null);
      });
    return () => {
      cancelled = true;
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const pid = preset?.id;
    if (!pid) return;
    let cancelled = false;

    // 1) increment view once per open/preset
    fetch("/api/preset/meta", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ presetId: pid, action: "view" }),
    }).catch(() => {});

    // 2) fetch meta
    setMeta(null);
    setCreator(null);
    fetch(`/api/preset/meta?presetId=${encodeURIComponent(pid)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (cancelled) return;
        const m = j?.meta;
        if (m && typeof m.views === "number") setMeta(m as PresetMeta);
        const c = j?.creator;
        if (c && ("email" in c || "nickname" in c || "name" in c)) setCreator(c as PresetCreator);
      })
      .catch(() => {
        if (cancelled) return;
        setMeta(null);
      });

    return () => {
      cancelled = true;
    };
  }, [open, preset?.id]);

  useEffect(() => {
    if (!open) return;
    if (tab !== "comments") return;
    const pid = preset?.id;
    if (!pid) return;
    let cancelled = false;
    setCommentsLoading(true);
    setCommentErr(null);
    fetch(`/api/preset/comments?presetId=${encodeURIComponent(pid)}&limit=50`)
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (cancelled) return;
        setComments(Array.isArray(j?.comments) ? (j.comments as PresetComment[]) : []);
      })
      .catch(() => {
        if (cancelled) return;
        setComments([]);
      })
      .finally(() => {
        if (cancelled) return;
        setCommentsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [open, preset?.id, tab]);

  if (!open) return null;

  const title = preset?.name?.trim() || "(제목 없음)";
  const desc = pickDesc(preset) || "설명이 없습니다.";
  const thumb = pickThumb(preset);
  const createdAt = formatDate((preset as any)?.createdAt);

  const creatorDisplay =
    (creator?.nickname && String(creator.nickname).trim()) ||
    (creator?.name && String(creator.name).trim()) ||
    (creator?.email && String(creator.email).trim()) ||
    ((preset as any)?.userEmail ? String((preset as any).userEmail).trim() : "") ||
    "익명";

  const continueDisabled = !latestChatLoaded || !hasLatestChat;
  const continueLabel = !latestChatLoaded ? "불러오는 중…" : hasLatestChat ? "이어하기" : "이어하기 (기록 없음)";

  const toggleLike = async () => {
    const pid = preset?.id;
    if (!pid) return;
    setCommentErr(null);
    const r = await fetch("/api/preset/like", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ presetId: pid }),
    });
    if (r.status === 401) {
      setCommentErr("로그인이 필요합니다.");
      return;
    }
    const j = await r.json().catch(() => null);
    if (j?.ok) {
      setMeta((prev) =>
        prev ? { ...prev, likeCount: Number(j.likeCount || 0), likedByMe: !!j.likedByMe } : prev
      );
    }
  };

  const toggleFollow = async () => {
    const pid = preset?.id;
    if (!pid) return;
    setCommentErr(null);
    const r = await fetch("/api/preset/follow", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ presetId: pid }),
    });
    if (r.status === 401) {
      setCommentErr("로그인이 필요합니다.");
      return;
    }
    const j = await r.json().catch(() => null);
    if (j?.ok) {
      setMeta((prev) =>
        prev ? { ...prev, followCount: Number(j.followCount || 0), followedByMe: !!j.followedByMe } : prev
      );
    }
  };

  return (
    <>
      <div
        onClick={onClose}
        style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.55)",
          zIndex: 80,
        }}
      />
      <div
        role="dialog"
        aria-modal="true"
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 90,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 16,
        }}
      >
        <div
          style={{
            width: "min(1120px, 100%)",
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(10,10,12,0.96)",
            backdropFilter: "blur(10px)",
            borderRadius: 20,
            boxShadow: "0 24px 80px rgba(0,0,0,0.6)",
            overflow: "hidden",
          }}
        >
          <div
            className="modalGrid"
            style={{
              display: "grid",
              gridTemplateColumns: "minmax(0, 55%) minmax(0, 45%)",
            }}
          >
            {/* 좌측: 이미지 크게 */}
            <div
              style={{
                position: "relative",
                borderRight: "1px solid rgba(255,255,255,0.10)",
                background: "rgba(255,255,255,0.03)",
                minHeight: 520,
              }}
            >
              <div
                aria-hidden
                style={{
                  position: "absolute",
                  inset: 0,
                  backgroundImage: `url(${thumb})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  filter: "blur(22px)",
                  opacity: 0.28,
                  transform: "scale(1.05)",
                }}
              />
              <div
                aria-hidden
                style={{
                  position: "absolute",
                  inset: 0,
                  background:
                    "linear-gradient(90deg, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.35) 55%, rgba(0,0,0,0.55) 100%)",
                }}
              />
              <div style={{ position: "relative", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", padding: 18 }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={thumb}
                  alt={title}
                  style={{
                    width: "100%",
                    height: "100%",
                    maxHeight: 700,
                    objectFit: "contain",
                    display: "block",
                    borderRadius: 14,
                    boxShadow: "0 18px 60px rgba(0,0,0,0.55)",
                  }}
                />
              </div>
            </div>

            {/* 우측: 정보 패널 */}
            <div style={{ display: "flex", flexDirection: "column", minHeight: 520 }}>
              {/* 상단 탭 + 닫기 */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 10,
                  padding: "14px 14px 10px 14px",
                  borderBottom: "1px solid rgba(255,255,255,0.10)",
                  background: "rgba(255,255,255,0.02)",
                }}
              >
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <button
                    type="button"
                    onClick={() => setTab("intro")}
                    style={{
                      fontWeight: 900,
                      fontSize: 13,
                      padding: "8px 10px",
                      borderRadius: 12,
                      border: tab === "intro" ? "1px solid rgba(255,255,255,0.22)" : "1px solid rgba(255,255,255,0.10)",
                      background: tab === "intro" ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.04)",
                      color: "#e9eefc",
                      cursor: "pointer",
                    }}
                  >
                    소개
                  </button>
                  <button
                    type="button"
                    onClick={() => setTab("comments")}
                    style={{
                      fontWeight: 900,
                      fontSize: 13,
                      padding: "8px 10px",
                      borderRadius: 12,
                      border: tab === "comments" ? "1px solid rgba(255,255,255,0.22)" : "1px solid rgba(255,255,255,0.10)",
                      background: tab === "comments" ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.04)",
                      color: "#e9eefc",
                      cursor: "pointer",
                    }}
                  >
                    댓글
                  </button>
                </div>

                {/* 우측: 좋아요 + 닫기 */}
                <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                  <button
                    type="button"
                    onClick={toggleLike}
                    disabled={!me}
                    title={me ? "좋아요" : "로그인 필요"}
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 8,
                      height: 36,
                      padding: "0 12px",
                      borderRadius: 12,
                      border: meta?.likedByMe ? "1px solid rgba(255,110,140,0.35)" : "1px solid rgba(255,255,255,0.14)",
                      background: meta?.likedByMe ? "rgba(255,110,140,0.18)" : "rgba(255,255,255,0.06)",
                      color: me ? "#e9eefc" : "rgba(233,238,252,0.55)",
                      cursor: me ? "pointer" : "not-allowed",
                      fontWeight: 900,
                      fontSize: 12,
                    }}
                  >
                    <span aria-hidden>{meta?.likedByMe ? "❤️" : "🤍"}</span>
                    <span>{meta?.likeCount?.toLocaleString("ko-KR") ?? "0"}</span>
                  </button>

                <button
                  type="button"
                  onClick={onClose}
                  aria-label="닫기"
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 12,
                    border: "1px solid rgba(255,255,255,0.14)",
                    background: "rgba(255,255,255,0.06)",
                    color: "#e9eefc",
                    cursor: "pointer",
                  }}
                >
                  ✕
                </button>
                </div>
              </div>

              {/* 본문(스크롤) */}
              <div style={{ padding: 14, overflow: "auto", flex: "1 1 auto" }}>
                {tab === "intro" ? (
                  <>
                    <div style={{ fontWeight: 900, fontSize: 20, lineHeight: 1.2 }}>{title}</div>

                    {/* 메타(전체 유저 기준) */}
                    <div style={{ marginTop: 10, display: "flex", gap: 10, alignItems: "center", fontSize: 12, opacity: 0.86 }}>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <span aria-hidden>💬</span>
                        <span>{chatCount === null ? "—" : chatCount.toLocaleString("ko-KR")}</span>
                      </span>
                      <span style={{ opacity: 0.55 }}>|</span>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <span aria-hidden>❤️</span>
                        <span>{meta?.likeCount?.toLocaleString("ko-KR") ?? "0"}</span>
                      </span>
                      <span style={{ opacity: 0.55 }}>|</span>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                        <span aria-hidden>👥</span>
                        <span>{meta?.followCount?.toLocaleString("ko-KR") ?? "0"}</span>
                      </span>
                    </div>

                    {/* 제작자 */}
                    <div style={{ marginTop: 12, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                        <div
                          aria-hidden
                          style={{
                            width: 34,
                            height: 34,
                            borderRadius: 12,
                            background: "rgba(255,255,255,0.10)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            flex: "0 0 auto",
                            overflow: "hidden",
                          }}
                        >
                          {creator?.image ? (
                            <img src={creator.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                          ) : (
                            "👤"
                          )}
                        </div>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontWeight: 900, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                            {creatorDisplay}
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={toggleFollow}
                        disabled={!me}
                        title={me ? "팔로우" : "로그인 필요"}
                        style={{
                          borderRadius: 999,
                          padding: "8px 12px",
                          border: "1px solid rgba(255,255,255,0.12)",
                          background: meta?.followedByMe ? "rgba(120,180,255,0.16)" : "rgba(255,255,255,0.06)",
                          color: me ? "#e9eefc" : "rgba(233,238,252,0.55)",
                          cursor: me ? "pointer" : "not-allowed",
                          fontWeight: 900,
                          fontSize: 12,
                        }}
                      >
                        {meta?.followedByMe ? "팔로잉" : "팔로우"}
                      </button>
                    </div>

                    {/* 태그 */}
                    {tags.length > 0 && (
                      <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
                        {tags.map((t) => (
                          <span
                            key={t}
                            style={{
                              fontSize: 12,
                              padding: "6px 10px",
                              borderRadius: 999,
                              border: "1px solid rgba(255,255,255,0.12)",
                              background: "rgba(255,255,255,0.03)",
                              opacity: 0.92,
                            }}
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* 설명 */}
                    <div style={{ marginTop: 14 }}>
                      <div style={{ fontWeight: 900, fontSize: 13, opacity: 0.92 }}>설명</div>
                      <div
                        style={{
                          marginTop: 8,
                          fontSize: 13,
                          opacity: 0.84,
                          lineHeight: 1.6,
                          whiteSpace: "pre-wrap",
                        }}
                      >
                        {desc}
                      </div>
                      {createdAt && <div style={{ marginTop: 10, fontSize: 12, opacity: 0.68 }}>제작일: {createdAt}</div>}
                    </div>
                  </>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                    {/* 에러 */}
                    {commentErr && (
                      <div
                        style={{
                          padding: "10px 12px",
                          borderRadius: 12,
                          border: "1px solid rgba(255,120,120,0.25)",
                          background: "rgba(255,120,120,0.08)",
                          fontSize: 12,
                          opacity: 0.95,
                        }}
                      >
                        {commentErr}
                      </div>
                    )}

                    {/* 작성 */}
                    <div
                      style={{
                        padding: 12,
                        borderRadius: 14,
                        border: "1px solid rgba(255,255,255,0.10)",
                        background: "rgba(255,255,255,0.03)",
                      }}
                    >
                      <div style={{ fontWeight: 900, fontSize: 13, opacity: 0.92 }}>댓글</div>
                      <textarea
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        placeholder={me ? "댓글을 입력하세요…" : "로그인 후 댓글을 작성할 수 있어요."}
                        disabled={!me || commentSending}
                        maxLength={500}
                        style={{
                          marginTop: 8,
                          width: "100%",
                          minHeight: 80,
                          resize: "vertical",
                          padding: 10,
                          borderRadius: 12,
                          border: "1px solid rgba(255,255,255,0.12)",
                          background: "rgba(0,0,0,0.25)",
                          color: "#e9eefc",
                          outline: "none",
                          fontSize: 13,
                          lineHeight: 1.6,
                        }}
                      />
                      <div style={{ marginTop: 8, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                        <div style={{ fontSize: 12, opacity: 0.7 }}>
                          {commentText.length.toLocaleString("ko-KR")}/500
                        </div>
                        <button
                          type="button"
                          disabled={!me || commentSending || commentText.trim().length === 0}
                          onClick={async () => {
                            const pid = preset?.id;
                            if (!pid) return;
                            const text = commentText.trim();
                            if (!text) return;
                            setCommentSending(true);
                            setCommentErr(null);
                            try {
                              const r = await fetch("/api/preset/comments", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ presetId: pid, content: text }),
                              });
                              if (r.status === 401) {
                                setCommentErr("로그인이 필요합니다.");
                                return;
                              }
                              const j = await r.json().catch(() => null);
                              if (!j?.ok) {
                                setCommentErr(j?.error || "댓글 작성 실패");
                                return;
                              }
                              const c = j.comment as PresetComment;
                              setCommentText("");
                              setComments((prev) => [c, ...prev]);
                            } finally {
                              setCommentSending(false);
                            }
                          }}
                          style={{
                            borderRadius: 12,
                            padding: "10px 14px",
                            border: "1px solid rgba(255,255,255,0.18)",
                            background:
                              !me || commentText.trim().length === 0 ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.10)",
                            color: !me || commentText.trim().length === 0 ? "rgba(233,238,252,0.55)" : "#e9eefc",
                            cursor: !me || commentText.trim().length === 0 ? "not-allowed" : "pointer",
                            fontWeight: 900,
                            fontSize: 13,
                          }}
                          title={me ? "댓글 등록" : "로그인 필요"}
                        >
                          {commentSending ? "등록 중…" : "등록"}
                        </button>
                      </div>
                    </div>

                    {/* 목록 */}
                    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
                        <div style={{ fontWeight: 900, fontSize: 13, opacity: 0.92 }}>
                          댓글 목록{" "}
                          <span style={{ fontWeight: 800, opacity: 0.7 }}>
                            ({comments.length.toLocaleString("ko-KR")})
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            const pid = preset?.id;
                            if (!pid) return;
                            setCommentsLoading(true);
                            setCommentErr(null);
                            try {
                              const r = await fetch(`/api/preset/comments?presetId=${encodeURIComponent(pid)}&limit=50`);
                              const j = await r.json().catch(() => null);
                              setComments(Array.isArray(j?.comments) ? (j.comments as PresetComment[]) : []);
                            } catch {
                              setComments([]);
                            } finally {
                              setCommentsLoading(false);
                            }
                          }}
                          style={{
                            borderRadius: 10,
                            padding: "8px 10px",
                            border: "1px solid rgba(255,255,255,0.12)",
                            background: "rgba(255,255,255,0.04)",
                            color: "#e9eefc",
                            cursor: "pointer",
                            fontWeight: 900,
                            fontSize: 12,
                            opacity: 0.9,
                          }}
                        >
                          새로고침
                        </button>
                      </div>

                      {commentsLoading ? (
                        <div style={{ padding: 12, fontSize: 13, opacity: 0.75 }}>불러오는 중…</div>
                      ) : comments.length === 0 ? (
                        <div style={{ padding: 12, fontSize: 13, opacity: 0.75 }}>아직 댓글이 없습니다.</div>
                      ) : (
                        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                          {comments.map((c) => (
                            <div
                              key={c.id}
                              style={{
                                padding: 12,
                                borderRadius: 14,
                                border: "1px solid rgba(255,255,255,0.10)",
                                background: "rgba(255,255,255,0.02)",
                              }}
                            >
                              <div style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                                <div style={{ minWidth: 0 }}>
                                  <div style={{ fontWeight: 900, fontSize: 12, opacity: 0.9 }}>
                                    {c.userEmail}
                                  </div>
                                  <div style={{ marginTop: 6, fontSize: 13, opacity: 0.86, lineHeight: 1.6, whiteSpace: "pre-wrap" }}>
                                    {c.content}
                                  </div>
                                  <div style={{ marginTop: 8, fontSize: 12, opacity: 0.6 }}>
                                    {new Date(c.createdAt).toLocaleString("ko-KR")}
                                  </div>
                                </div>

                                <button
                                  type="button"
                                  disabled={!me}
                                  onClick={async () => {
                                    if (!me) {
                                      setCommentErr("로그인이 필요합니다.");
                                      return;
                                    }
                                    const r = await fetch("/api/preset/comments/like", {
                                      method: "POST",
                                      headers: { "Content-Type": "application/json" },
                                      body: JSON.stringify({ commentId: c.id }),
                                    });
                                    if (r.status === 401) {
                                      setCommentErr("로그인이 필요합니다.");
                                      return;
                                    }
                                    const j = await r.json().catch(() => null);
                                    if (j?.ok) {
                                      setComments((prev) =>
                                        prev.map((x) =>
                                          x.id === c.id
                                            ? { ...x, likeCount: Number(j.likeCount || 0), likedByMe: !!j.likedByMe }
                                            : x
                                        )
                                      );
                                    }
                                  }}
                                  style={{
                                    flex: "0 0 auto",
                                    borderRadius: 999,
                                    padding: "8px 10px",
                                    border: "1px solid rgba(255,255,255,0.12)",
                                    background: me ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.02)",
                                    color: me ? "#e9eefc" : "rgba(233,238,252,0.55)",
                                    cursor: me ? "pointer" : "not-allowed",
                                    fontWeight: 900,
                                    fontSize: 12,
                                    height: 34,
                                    alignSelf: "flex-start",
                                  }}
                                  title={me ? "댓글 좋아요" : "로그인 필요"}
                                >
                                  {c.likedByMe ? "❤️" : "🤍"} {c.likeCount.toLocaleString("ko-KR")}
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
)}
              </div>

              {/* 하단 CTA 고정 */}
              <div
                style={{
                  padding: 14,
                  borderTop: "1px solid rgba(255,255,255,0.10)",
                  background: "rgba(8,8,10,0.96)",
                }}
              >
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <button
                    type="button"
                    onClick={onContinue}
                    disabled={continueDisabled}
                    style={{
                      flex: "1 1 220px",
                      border: "1px solid rgba(255,255,255,0.18)",
                      background: continueDisabled ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.08)",
                      color: continueDisabled ? "rgba(233,238,252,0.55)" : "#e9eefc",
                      borderRadius: 16,
                      padding: "12px 14px",
                      cursor: continueDisabled ? "not-allowed" : "pointer",
                      fontWeight: 900,
                    }}
                  >
                    {continueLabel}
                  </button>

                  <button
                    type="button"
                    onClick={onNew}
                    style={{
                      flex: "1 1 220px",
                      border: "1px solid rgba(255,255,255,0.18)",
                      background: "rgba(120,180,255,0.12)",
                      color: "#e9eefc",
                      borderRadius: 16,
                      padding: "12px 14px",
                      cursor: "pointer",
                      fontWeight: 900,
                    }}
                  >
                    처음하기
                  </button>
                </div>

                <div style={{ marginTop: 10, fontSize: 12, opacity: 0.62 }}>
                  * "처음하기"는 해당 작품의 기존 대화를 정리하고 새로 시작할 수 있습니다.
                </div>
              </div>
            </div>
          </div>

          <style jsx>{`
            @media (max-width: 760px) {
              .modalGrid {
                grid-template-columns: 1fr;
              }
            }

          `}</style>
        </div>
      </div>
    </>
  );
}
