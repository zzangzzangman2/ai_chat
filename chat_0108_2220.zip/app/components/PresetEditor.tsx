"use client";

import { useEffect, useMemo, useState } from "react";
import type { Preset } from "@/app/page";

export default function PresetEditor(props: {
  presets: Preset[];
  selectedPresetId: string | null;
  onSelectPreset: (id: string) => void;
  onPresetSaved: (p: Preset) => void;
  onPresetCreated: (p: Preset) => void;
  onPresetDeleted: (id: string) => void;
}) {
  const { presets, selectedPresetId, onSelectPreset, onPresetSaved, onPresetCreated, onPresetDeleted } = props;

  const THEME = {
      bg: "var(--background)",
      panel: "var(--panel)",
      panel2: "var(--panel2)",
      border: "var(--border)",
      text: "var(--foreground)",
      muted: "var(--muted)",
    } as const;
  
  const selected = useMemo(() => {
    if (!selectedPresetId) return null;
    return presets.find((p) => p.id === selectedPresetId) || null;
  }, [presets, selectedPresetId]);

  const [id, setId] = useState<string | undefined>(undefined);
  const [name, setName] = useState("");
  const [background, setBackground] = useState("");
  const [characterName, setCharacterName] = useState("");
  const [characterAge, setCharacterAge] = useState<number>(20);
  const [character, setCharacter] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [busy, setBusy] = useState(false);

  // 선택 프리셋 변경 시 폼 채우기
  useEffect(() => {
    if (selected) {
      setId(selected.id);
      setName(selected.name || "");
      setBackground(selected.background || "");
      setCharacterName(selected.characterName || "");
      setCharacterAge(selected.characterAge || 20);
      setCharacter(selected.character || "");
      setSystemPrompt(selected.systemPrompt || "");
    }
  }, [selected]);

  function resetNew() {
    setId(undefined);
    setName("");
    setBackground("");
    setCharacterName("");
    setCharacterAge(20);
    setCharacter("");
    setSystemPrompt("");
  }

  async function save() {
    // 프론트에서도 한글 검증
    if (!name.trim()) return alert("프리셋 이름을 적어주세요.");
    if (!background.trim()) return alert("배경을 적어주세요.");
    if (!characterName.trim()) return alert("상대방 캐릭터 이름을 적어주세요.");
    if (!characterAge || characterAge <= 0) return alert("상대방 나이를 올바르게 적어주세요.");
    if (!character.trim()) return alert("상대방 캐릭터(성격/말투/행동 원칙)를 적어주세요.");

    setBusy(true);
    try {
      const res = await fetch("/api/preset/upsert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          name,
          background,
          characterName,
          characterAge,
          character,
          systemPrompt,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "저장 실패");

      const p = json.preset as Preset;
      if (id) onPresetSaved(p);
      else onPresetCreated(p);

      alert("저장 완료");
    } catch (e: any) {
      alert(e?.message || "오류");
    } finally {
      setBusy(false);
    }
  }

  async function del() {
    if (!id) return alert("삭제할 프리셋을 선택해 주세요.");
    const ok = confirm(
      "이 프리셋을 삭제하면, 연결된 채팅/메시지/설정도 함께 삭제됩니다.\n\n정말 삭제할까요?"
    );
    if (!ok) return;

    setBusy(true);
    try {
      const res = await fetch("/api/preset/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "삭제 실패");

      onPresetDeleted(id);
      resetNew();
      alert("삭제 완료");
    } catch (e: any) {
      alert(e?.message || "오류");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 13, fontWeight: 800 }}>프리셋</div>

      <select
        value={selectedPresetId || ""}
        onChange={(e) => onSelectPreset(e.target.value)}
        style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}` }}
      >
        {presets.map((p) => (
          <option key={p.id} value={p.id}>
            {p.name}
          </option>
        ))}
      </select>

      <button
        onClick={resetNew}
        style={{
          padding: 10,
          borderRadius: 12,
          border: `1px solid ${THEME.border}`,
          background: THEME.panel,
          cursor: "pointer",
        }}
      >
        새 작품 작성
      </button>
      <div style={{ height: 1, background: "#eee" }} />

      <label style={{ fontSize: 12, fontWeight: 700 }}>프리셋 이름</label>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}` }}
        placeholder="예: 성준"
      />

      <label style={{ fontSize: 12, fontWeight: 700 }}>배경</label>
      <textarea
        value={background}
        onChange={(e) => setBackground(e.target.value)}
        style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}`, minHeight: 90 }}
        placeholder="예: 나는 아랩클라우드메이터 회사원이다"
      />

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <div>
          <label style={{ fontSize: 12, fontWeight: 700 }}>상대방 캐릭터 이름</label>
          <input
            value={characterName}
            onChange={(e) => setCharacterName(e.target.value)}
            style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}`, width: "100%" }}
            placeholder="예: 서윤아"
          />
        </div>
        <div>
          <label style={{ fontSize: 12, fontWeight: 700 }}>상대방 나이</label>
          <input
            value={String(characterAge)}
            onChange={(e) => setCharacterAge(Number(e.target.value || 0))}
            style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}`, width: "100%" }}
            placeholder="예: 20"
          />
        </div>
      </div>

      <label style={{ fontSize: 12, fontWeight: 700 }}>상대방 캐릭터(성격/말투/행동 원칙)</label>
      <textarea
        value={character}
        onChange={(e) => setCharacter(e.target.value)}
        style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}`, minHeight: 120 }}
        placeholder="예: 여자 20살 신입사원, 말투는..."
      />

      <label style={{ fontSize: 12, fontWeight: 700 }}>추가지침(금칙/우선순위/형식)</label>
      <textarea
        value={systemPrompt}
        onChange={(e) => setSystemPrompt(e.target.value)}
        style={{ padding: 10, borderRadius: 12, border: `1px solid ${THEME.border}`, minHeight: 90 }}
        placeholder="예: 복종금지..."
      />

      <button
        onClick={save}
        disabled={busy}
        style={{
          padding: 12,
          borderRadius: 12,
          border: "1px solid #000",
          background: "#000",
          color: "#fff",
          cursor: "pointer",
          opacity: busy ? 0.6 : 1,
        }}
      >
        저장
      </button>

    </div>
  );
}


