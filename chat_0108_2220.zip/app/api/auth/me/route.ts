import { NextRequest, NextResponse } from "next/server";
import { verifySession, SESSION_COOKIE } from "@/lib/auth";
import { getUserByEmail } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value ?? "";
  const session = token ? await verifySession(token) : null;

  const user = session
    ? (() => {
        const dbUser = getUserByEmail(session.email);
        return {
          email: session.email,
          name: session.name ?? null,
          picture: session.picture ?? null,
          nickname: dbUser?.nickname ?? session.nickname ?? null,
        };
      })()
    : null;

  const res = NextResponse.json({ ok: true, user });

  res.headers.set("Cache-Control", "no-store, max-age=0");
  res.headers.set("Pragma", "no-cache");
  res.headers.append("Vary", "Cookie");
  return res;
}
