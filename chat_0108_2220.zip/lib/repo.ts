import { db } from "./db";

export type PresetRow = {
  id: string;
  name: string;
  background: string;
  character: string;
  systemPrompt: string;
  createdAt: number;
};

export type ChatRow = {
  id: string;
  presetId: string;
  title: string | null;
  createdAt: number;
};

export type MessageRow = {
  id: string;
  chatId: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
};

export function getPreset(presetId: string): PresetRow | undefined {
  return db
    .prepare(
      `SELECT id, name, background, character, systemPrompt, createdAt
       FROM presets WHERE id=?`
    )
    .get(presetId) as PresetRow | undefined;
}

export function getChat(chatId: string): ChatRow | undefined {
  return db
    .prepare(`SELECT id, presetId, title, createdAt FROM chats WHERE id=?`)
    .get(chatId) as ChatRow | undefined;
}

export function createChat(chat: ChatRow) {
  db.prepare(
    `INSERT INTO chats (id, presetId, title, createdAt) VALUES (?, ?, ?, ?)`
  ).run(chat.id, chat.presetId, chat.title, chat.createdAt);
}

export function listChats(presetId: string): ChatRow[] {
  return db
    .prepare(
      `SELECT id, presetId, title, createdAt
       FROM chats WHERE presetId=?
       ORDER BY createdAt DESC`
    )
    .all(presetId) as ChatRow[];
}

export function listMessages(chatId: string): MessageRow[] {
  return db
    .prepare(
      `SELECT id, chatId, role, content, createdAt
       FROM messages WHERE chatId=?
       ORDER BY createdAt ASC`
    )
    .all(chatId) as MessageRow[];
}

export function addMessage(msg: MessageRow) {
  db.prepare(
    `INSERT INTO messages (id, chatId, role, content, createdAt)
     VALUES (?, ?, ?, ?, ?)`
  ).run(msg.id, msg.chatId, msg.role, msg.content, msg.createdAt);
}

