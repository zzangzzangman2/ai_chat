import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = process.env.GOOGLE_AI_API_KEY;
if (!apiKey) throw new Error("Missing GOOGLE_AI_API_KEY in env");

const genAI = new GoogleGenerativeAI(apiKey);

// 개인용 기본값(원하면 모델/옵션 바꿔도 됨)
const model = genAI.getGenerativeModel({
  model: "gemini-3-flash-preview",
});

export type ChatMessage = { role: "user" | "assistant"; content: string };

export async function generateReply(args: {
  systemPrompt: string;     // 프리셋에서 합쳐 만든 system
  messages: ChatMessage[];  // user/assistant 대화
}) {
  const { systemPrompt, messages } = args;

  // Gemini는 "system" role이 따로 없어서 첫 문장으로 주입하는 방식이 흔함
  const prompt =
    `SYSTEM:\n${systemPrompt}\n\n` +
    messages
      .map((m) => `${m.role.toUpperCase()}:\n${m.content}`)
      .join("\n\n") +
    `\n\nASSISTANT:\n`;

  const result = await model.generateContent(prompt);
  const text = result.response.text();
  return text?.trim() || "";
}
