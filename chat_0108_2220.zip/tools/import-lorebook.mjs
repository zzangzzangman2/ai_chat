#!/usr/bin/env node
import fs from "fs";
import path from "path";
import Database from "better-sqlite3";
import crypto from "crypto";

process.on("uncaughtException", (e) => {
  console.error("[FATAL] uncaughtException:", e);
  process.exit(1);
});
process.on("unhandledRejection", (e) => {
  console.error("[FATAL] unhandledRejection:", e);
  process.exit(1);
});

console.log("[import-lorebook] start", process.argv);

function arg(name, fallback = null) {
  const i = process.argv.indexOf(`--${name}`);
  if (i >= 0 && process.argv[i + 1]) return process.argv[i + 1];
  return fallback;
}

const presetName = arg("preset", "강호말출"); // 프리셋 name 또는 characterName
const loreFile = arg("file", "블아챗_로어북.txt");
const dbPath = arg("db", path.join(process.cwd(), "data", "data.sqlite3"));
const mode = arg("mode", "append"); // append | replace

if (!fs.existsSync(dbPath)) {
  console.error(`[ERR] DB not found: ${dbPath}`);
  process.exit(1);
}
if (!fs.existsSync(loreFile)) {
  console.error(`[ERR] Lore file not found: ${loreFile}`);
  process.exit(1);
}

const raw = fs.readFileSync(loreFile, "utf-8").replace(/\r\n/g, "\n").trim();
if (!raw) {
  console.error("[ERR] Lore file is empty.");
  process.exit(1);
}

/**
 * splitLore:
 * 1) 파일에 --- 구분자가 있으면 그걸로 분할 (제작자기준 70개 파일용)
 * 2) 없으면 fallback으로 # 헤딩 기준 분할
 *
 * NOTE: "내용 변경 금지"를 위해, 각 블록은 원문 그대로 유지한다.
 *       (여기서 하는 건 '경계'만 자르는 것)
 */
function splitLore(text) {
  // 1) --- 구분자 우선
  const sep = /\n\s*---\s*\n/g;
  if (sep.test(text)) {
    const parts = text
      .split(sep)
      .map((s) => s.trim())
      .filter(Boolean);

    return parts.map((body, idx) => ({
      title: `로어북-${String(idx + 1).padStart(2, "0")}`,
      body,
    }));
  }

  // 2) fallback: # 헤딩 기준 (기존 방식)
  const lines = text.split("\n");
  const blocks = [];
  let current = { title: "로어북", body: [] };

  const pushCurrent = () => {
    const body = current.body.join("\n").trim();
    if (body) blocks.push({ title: current.title.trim() || "로어북", body });
  };

  for (const line of lines) {
    const m = line.match(/^\s*#+\s*(.+?)\s*$/);
    if (m) {
      pushCurrent();
      current = { title: m[1], body: [] };
    } else {
      current.body.push(line);
    }
  }
  pushCurrent();

  return blocks.length ? blocks : [{ title: "로어북", body: text }];
}

const blocks = splitLore(raw);
console.log("[dbg] split blocks:", blocks.length);

function makeKeysFromTitle(title) {
  // title이 '로어북-01' 같은 자동 제목일 수 있으니 keys는 빈 배열로 두는 게 안전.
  // (키워드 기반 매칭을 쓰는 프로젝트라면 여기서 커스텀하면 됨)
  // 지금 목표는 "70개로 넣기"이므로 keys는 최소/안전값만 넣는다.
  return [];
}

const loreItems = blocks.map((b, idx) => {
  const keys = makeKeysFromTitle(b.title);
  return {
    id: crypto.randomUUID(),
    name: b.title,
    content: b.body,
    keys,
    activationKeys: keys,
    order: idx,
    enabled: true,
    isOpen: false,
  };
});

console.log("[dbg] loreItems:", loreItems.length);

console.log("[dbg] opening db:", dbPath);
const db = new Database(dbPath);

// DB lock으로 “무한대기”되는 거 방지 (최대 5초 기다리고 에러)
db.pragma("busy_timeout = 5000");
db.pragma("journal_mode = WAL");

const cols = db.prepare(`PRAGMA table_info(presets)`).all().map((r) => r.name);
if (!cols.includes("lorebooks")) {
  console.error(
    "[ERR] presets.lorebooks column not found. 서버를 한번 실행해서 마이그레이션을 먼저 돌리거나, 스키마를 확인하세요."
  );
  process.exit(1);
}

const preset = db
  .prepare(
    `SELECT id, name, characterName, lorebooks
       FROM presets
      WHERE name = ? OR characterName = ?
      ORDER BY createdAt DESC
      LIMIT 1`
  )
  .get(presetName, presetName);

if (!preset) {
  console.error(`[ERR] Preset not found by name/characterName: ${presetName}`);
  console.error("힌트: DB에서 presets.name 또는 presets.characterName 값을 확인해 주세요.");
  process.exit(1);
}

let nextLorebooks = [];
if (mode === "replace") {
  nextLorebooks = loreItems;
} else {
  // append
  try {
    const parsed = JSON.parse(String(preset.lorebooks || "[]"));
    nextLorebooks = Array.isArray(parsed) ? parsed : [];
  } catch {
    nextLorebooks = [];
  }
  nextLorebooks = [...nextLorebooks, ...loreItems];
}

console.log(
  "[dbg] before update lorebooks:",
  "mode=", mode,
  "add=", loreItems.length,
  "total=", nextLorebooks.length,
  "jsonBytes=",
  Buffer.byteLength(JSON.stringify(nextLorebooks))
);

db.prepare(`UPDATE presets SET lorebooks = ? WHERE id = ?`).run(
  JSON.stringify(nextLorebooks),
  preset.id
);

console.log("[OK] Updated lorebooks");
console.log(" presetId:", preset.id);
console.log(" presetName:", preset.name, "/", preset.characterName);
console.log(" added:", loreItems.length, "blocks");
console.log(" total:", nextLorebooks.length);

