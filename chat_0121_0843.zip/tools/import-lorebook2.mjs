#!/usr/bin/env node
/**
 * import-lorebook2.mjs (v2)
 *
 * 괄호 마커 기반 로어북 대량 주입:
 *  - (로어북1) ... (로어북30)
 *
 * ✅ 활성화키 규칙(요청 반영):
 *  - 기본: 마커 "(로어북N)" 바로 "위 줄"에 있는 토큰(대개 이모지/키워드)을 활성화키로 사용
 *  - 예:   👌
 *         (로어북4)
 *         ...
 *     -> keys=["👌"]
 *
 *  - 우선순위:
 *     1) "키워드 : ..." 라인이 있으면 그걸 사용
 *     2) 없으면 "(로어북N)" 라인의 바로 위(직전) 비어있지 않은 한 줄을 keys로 사용
 *     3) 둘 다 없으면 keys=[]
 *
 * ✅ 로어 이름 규칙:
 *  - "(로어북N)제목" 같이 같은 줄에 제목이 붙어있으면 그걸 name
 *  - 없으면 "로어 이름 : ..." 라인 사용
 *  - 둘 다 없으면 로어북-XX
 *
 * 사용:
 *  node tools/import-lorebook2.mjs --preset "에덴 길드전쟁" --file "/path/lore.txt" --mode replace
 *  node tools/import-lorebook2.mjs --preset "에덴 길드전쟁" --file "/path/lore.txt" --preview
 */

import fs from "fs";
import path from "path";
import Database from "better-sqlite3";
import crypto from "crypto";

process.on("uncaughtException", (e) => {
  console.error("[FATAL] uncaughtException:", e);
  process.exit(1);
});
process.on("unhandledRejection", (e) => {
  console.error("[FATAL] unhandledRejection:", e);
  process.exit(1);
});

function arg(name, fallback = null) {
  const i = process.argv.indexOf(`--${name}`);
  if (i >= 0 && process.argv[i + 1]) return process.argv[i + 1];
  return fallback;
}

const presetName = arg("preset", null);
const loreFile = arg("file", null);
const dbPath = arg("db", path.join(process.cwd(), "data", "data.sqlite3"));
const mode = arg("mode", "append"); // append | replace
const preview = (process.argv.includes("--preview") || arg("preview", "false") === "true");

if (!presetName) {
  console.error(`[ERR] Missing --preset "프리셋이름"`);
  process.exit(1);
}
if (!loreFile) {
  console.error(`[ERR] Missing --file "/path/to/lorebook.txt"`);
  process.exit(1);
}

if (!fs.existsSync(dbPath)) {
  console.error(`[ERR] DB not found: ${dbPath}`);
  process.exit(1);
}
if (!fs.existsSync(loreFile)) {
  console.error(`[ERR] Lore file not found: ${loreFile}`);
  process.exit(1);
}

const raw = fs.readFileSync(loreFile, "utf-8");

function parseKeywordsLine(s) {
  // "💬, 📱,🎰,🚗" or "💬 📱 🎰 🚗" or "💬/📱" 등 대충 대응
  const cleaned = String(s).trim();
  if (!cleaned) return [];
  // 쉼표/공백/슬래시/파이프 기준으로 split
  return cleaned
    .split(/[,\s\/\|]+/g)
    .map((x) => x.trim())
    .filter(Boolean);
}

function splitLoreByParenMarkers(text) {
  const lines = text.split(/\r?\n/);

  // (로어북1) or (로어북1)제목
  const markerRe = /^\s*\(로어북\s*(\d+)\)\s*(.*)\s*$/;
  const nameRe = /^\s*로어\s*이름\s*[:：]\s*(.+)\s*$/;
  const contentRe = /^\s*로어\s*내용\s*[:：]\s*$/;
  const keywordRe = /^\s*키워드\s*[:：]\s*(.+)\s*$/;

  const sections = [];
  let current = null;

  function findPrevNonEmptyLine(idx) {
    for (let j = idx - 1; j >= 0; j--) {
      const t = (lines[j] || "").trim();
      if (t.length === 0) continue;
      // 마커/메타 라인 제외는 여기선 하지 않음(요청: "바로 위 줄"이 키)
      return t;
    }
    return "";
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const m = line.match(markerRe);
    if (m) {
      // flush previous
      if (current) {
        current.endLine = i - 1;
        sections.push(current);
      }
      const num = Number(m[1]);
      const inlineTitle = (m[2] || "").trim();
      const prevKeyLine = findPrevNonEmptyLine(i); // ✅ 바로 위 활성화키
      current = { num, inlineTitle, prevKeyLine, startLine: i, endLine: i, bodyLines: [] };
      continue;
    }

    if (current) current.bodyLines.push(line);
  }

  if (current) {
    current.endLine = lines.length - 1;
    sections.push(current);
  }

  if (!sections.length) return [];

  const blocks = sections
    .sort((a, b) => a.num - b.num)
    .map((sec) => {
      const bodyLines = sec.bodyLines.slice();

      // title
      let title = sec.inlineTitle || null;
      if (!title) {
        for (const ln of bodyLines) {
          const mm = ln.match(nameRe);
          if (mm) {
            title = String(mm[1]).trim();
            break;
          }
        }
      }
      if (!title) title = `로어북-${String(sec.num).padStart(2, "0")}`;

      // keys: 1) explicit keyword line 2) prevKeyLine
      let keys = [];
      for (const ln of bodyLines) {
        const km = ln.match(keywordRe);
        if (km) {
          keys = parseKeywordsLine(km[1]);
          break;
        }
      }
      if (!keys.length) {
        // sec.prevKeyLine 그대로 키로 사용(요청)
        // 만약 "키워드 :" 같은 라인이 위에 있을 수도 있으니, 그 경우는 ':' 이후만
        const pk = sec.prevKeyLine;
        const k2 = pk.match(keywordRe);
        keys = k2 ? parseKeywordsLine(k2[1]) : parseKeywordsLine(pk);
      }

      // body: after "로어 내용 :" line, until keyword line (exclude)
      let contentStart = -1;
      for (let i = 0; i < bodyLines.length; i++) {
        if (contentRe.test(bodyLines[i])) {
          contentStart = i + 1;
          break;
        }
      }

      let contentEnd = bodyLines.length;
      for (let i = 0; i < bodyLines.length; i++) {
        if (keywordRe.test(bodyLines[i])) {
          contentEnd = i;
          break;
        }
      }

      let contentLines;
      if (contentStart >= 0) {
        contentLines = bodyLines.slice(contentStart, contentEnd);
      } else {
        // fallback: metadata 라인 제외
        contentLines = bodyLines.filter(
          (ln) => !nameRe.test(ln) && !keywordRe.test(ln) && !contentRe.test(ln)
        );
      }

      const body = contentLines.join("\n").trim();
      return { num: sec.num, title, body, keys };
    })
    .filter((b) => b.body.length > 0 || b.title.length > 0);

  return blocks;
}

const blocks = splitLoreByParenMarkers(raw);
if (!blocks.length) {
  console.error("[ERR] No (로어북N) markers found. (로어북1) 같은 마커가 필요합니다.");
  process.exit(1);
}

console.log("[import-lorebook2] split blocks:", blocks.length);

if (preview) {
  console.log("[preview] num:title => keys");
  for (const b of blocks) {
    console.log(` - (${b.num}) ${b.title} => ${JSON.stringify(b.keys)}`);
  }
  process.exit(0);
}

const loreItems = blocks.map((b, idx) => {
  const keys = Array.isArray(b.keys) ? b.keys : [];
  return {
    id: crypto.randomUUID(),
    name: b.title,
    content: b.body,
    keys,
    activationKeys: keys,
    order: idx,
    enabled: true,
    isOpen: false,
  };
});

const db = new Database(dbPath);
db.pragma("journal_mode = WAL");

// presets 테이블/컬럼 체크
const cols = db.prepare(`PRAGMA table_info(presets)`).all().map((r) => r.name);
if (!cols.includes("lorebooks")) {
  console.error(`[ERR] presets.lorebooks column not found. (DB schema 확인 필요)`);
  process.exit(1);
}

// 프리셋 찾기: name 또는 characterName
const preset = db
  .prepare(
    `SELECT id, name, characterName, lorebooks
       FROM presets
      WHERE name = ? OR characterName = ?
      ORDER BY createdAt DESC
      LIMIT 1`
  )
  .get(presetName, presetName);

if (!preset) {
  console.error(`[ERR] Preset not found by name/characterName: ${presetName}`);
  process.exit(1);
}

// 기존 lorebooks 읽기
let prevLorebooks = [];
try {
  const parsed = JSON.parse(preset.lorebooks || "[]");
  prevLorebooks = Array.isArray(parsed) ? parsed : [];
} catch {
  prevLorebooks = [];
}

const nextLorebooks = mode === "replace" ? loreItems : [...prevLorebooks, ...loreItems];

db.prepare(`UPDATE presets SET lorebooks = ? WHERE id = ?`).run(
  JSON.stringify(nextLorebooks),
  preset.id
);

console.log("[OK] Updated lorebooks");
console.log(" presetId:", preset.id);
console.log(" presetName:", preset.name, "/", preset.characterName);
console.log(" added:", loreItems.length, "blocks");
console.log(" total:", nextLorebooks.length);
