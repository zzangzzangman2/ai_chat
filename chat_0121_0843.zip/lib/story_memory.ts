import { stripUrlsAndMediaMarkdown } from "@/lib/memory_sanitize";

/**
 * Sanitizer for story-memory fields (character cards / scene summaries).
 *
 * Policy notes:
 * - We store plain text only.
 * - We aggressively remove broken markdown tokens that caused "!!" / "! (." artifacts.
 * - We do NOT hard-cut by length here. Length/budget is handled by the generator.
 */
export function sanitizeStoryMemoryText(input: string): string {
  if (!input) return "";
  let s = stripUrlsAndMediaMarkdown(String(input));

  // Remove common broken image-markdown leftovers.
  s = s.replace(/^[ \t]*!\s*\(\s*\.?/gm, ""); // "! (." / "!(" prefix
  s = s.replace(/^[ \t]*!{2,}\s*/gm, ""); // "!!" line prefix
  s = s.replace(/^[ \t]*!\s*$/gm, ""); // lone '!'

  // Remove stray unmatched emphasis markers that leak from streaming.
  s = s.replace(/\*{1,3}(?=\s|$)/g, "");

  // Normalize whitespace.
  s = s.replace(/[ \t]+/g, " ");
  s = s.replace(/[ \t]+\n/g, "\n");
  s = s.replace(/\n{3,}/g, "\n\n");

  return s.trim();
}



/**
 * Compact a character "relationship change" line for storage/UI.
 *
 * Goal: keep it as an action summary (no raw dialogue), short and stable.
 *
 * Notes:
 * - Preserves an optional [Tn] prefix.
 * - If the tail looks like a question/dialogue, we replace it with a concise paraphrase.
 */
export function compactCharacterChangeText(input: string): string {
  let s = sanitizeStoryMemoryText(input);
  if (!s) return "";

  // Preserve optional [Tn] prefix.
  let prefix = "";
  const m = s.match(/^\[T\d+\]\s*/i);
  if (m) {
    prefix = m[0];
    s = s.slice(m[0].length);
  }

  // Remove common dialogue quoting wrappers.
  const stripQuoted = (x: string) =>
    x
      .replace(/"[^"]{0,220}"/g, "")
      .replace(/“[^”]{0,220}”/g, "")
      .replace(/「[^」]{0,220}」/g, "")
      .replace(/『[^』]{0,220}』/g, "");

  s = stripQuoted(s);

  // Remove leaked emphasis / punctuation bursts.
  s = s.replace(/\*{1,3}/g, "");
  s = s.replace(/[!?？!]+/g, "");
  s = s.replace(/[ 	]+/g, " ").trim();

  // Split into "target" + "action" when possible.
  let head = "";
  let rest = s;
  const m2 = s.match(/^(.{1,24}?에게)\s*(.*)$/);
  if (m2) {
    head = m2[1];
    rest = (m2[2] || "").trim();
  }

  const src = rest;

  const askSummary = (t: string) => {
    if (/제정신|정신/.test(t)) return "정신 상태를 지적하며 추궁함";
    if (/민원|상담|창구/.test(t)) return "여기가 무슨 곳이냐며 비꼼";
    if (/(왜|이유)/.test(t) || /왜.*(왔|온)/.test(t)) return "이유를 캐묻고 추궁함";
    if (/(누구|정체|신분|이름)/.test(t)) return "정체를 캐묻고 추궁함";
    if (/(뭐|무슨)/.test(t)) return "무슨 일이냐며 추궁함";
    if (/(어디|여기)/.test(t)) return "여기가 어딘지 따져묻음";
    return "따져묻고 추궁함";
  };

  const warnSummary = (t: string) => {
    if (/나가|떠나|꺼져|퇴거|돌아가/.test(t)) return "나가라고 경고함";
    if (/위험|다치|피|후회|죽/.test(t)) return "위험을 경고함";
    return "경고함";
  };

  // If it still looks like dialogue / question, replace tail with a paraphrase.
  const looksLikeAsk = /\?|？/.test(input) || /(뭐야|무슨|왜|어떻게|누구|어디|따져|추궁|질문|요구)/.test(src);
  const looksLikeWarn = /(경고|조심|위험|꺼져|나가|떠나|죽)/.test(src);

  if (!rest) {
    // nothing to compact
  } else if (looksLikeAsk) {
    rest = askSummary(src);
  } else if (looksLikeWarn) {
    rest = warnSummary(src);
  }

  let out = head ? `${head} ${rest}`.trim() : rest.trim();
  if (!out) out = s.trim();

  // Hard cap for storage/UI safety.
  const CAP = 90;
  if (out.length > CAP) out = out.slice(0, CAP).trimEnd() + "…";

  return (prefix + out).trim();
}
export function safeJsonParse<T>(s: any, fallback: T): T {
  try {
    if (s == null) return fallback;
    if (typeof s !== "string") return fallback;
    return JSON.parse(s) as T;
  } catch {
    return fallback;
  }
}
