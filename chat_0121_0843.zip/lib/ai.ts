import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  throw new Error("GEMINI_API_KEY가 .env.local에 없습니다.");
}

export const genai = new GoogleGenAI({ apiKey });

export type ChatGenOpts = {
  model: string;
  maxOutputTokens: number;
  maxReasoningTokens: number;
  // Optional stop sequences (up to 5). If provided, generation stops when any sequence is encountered.
  // NOTE: The stop sequence itself is not included in the response.
  stopSequences?: string[];
};

function normalizeModelName(model: string) {
  const m = String(model || "").trim();
  if (!m) return "";
  // Some routers/providers prefix models like "google/gemini-3-pro-preview".
  const slash = m.lastIndexOf("/");
  return slash >= 0 ? m.slice(slash + 1) : m;
}

function isGemini3Pro(model: string) {
  const m = normalizeModelName(model);
  return m === "gemini-3-pro" || m.startsWith("gemini-3-pro-");
}

function isGemini3Flash(model: string) {
  const m = normalizeModelName(model);
  return m === "gemini-3-flash" || m.startsWith("gemini-3-flash-");
}

function isGemini3(model: string) {
  const m = normalizeModelName(model).toLowerCase();
  return m.startsWith("gemini-3-");
}

function isGemini25Pro(model: string) {
  const m = normalizeModelName(model).toLowerCase();
  return m === "gemini-2.5-pro" || m.startsWith("gemini-2.5-pro-");
}

type ThinkingConfigAny = { thinkingBudget?: number; thinkingLevel?: string };

function buildThinkingConfig(model: string, maxReasoningTokens: number, maxOutputTokensRequested: number): ThinkingConfigAny | null {
  const tRaw = Number(maxReasoningTokens) || 0;
  const t = Math.max(0, Math.floor(tRaw));
  // Gemini 3 (Pro/Flash): use thinkingLevel (recommended for Gemini 3+).
  // NOTE: Gemini 3는 thinkingBudget(숫자) 대신 thinkingLevel(레벨)을 사용한다.
  // maxReasoningTokens가 0이어도(=UI에서 추론을 꺼둔 듯한 입력) 레벨을 생략하면
  // 내부적으로 thinking이 켜진 채로 토큰을 소비하는 케이스가 있어, 최소 레벨로라도 고정한다.
  if (isGemini3Pro(model)) {
    // Gemini 3 Pro: prefer explicit *budget* to avoid "reasoning-only" runs that starve visible output.
    // - We keep thinkingLevel for coarse control, but also pass thinkingBudget (min 128) when possible.
    // - This dramatically reduces MAX_TOKENS truncation where (reasoningTokens + outputTokens) hits maxOutputTokens.
    const level =
      t >= 896 ? "high" :
      t >= 640 ? "medium" :
      t >= 256 ? "low" :
      "minimal";

    const MIN_BUDGET = 128;
    const budget = Math.min(1024, Math.max(MIN_BUDGET, t || 0));

    return { thinkingLevel: level, thinkingBudget: budget };
  }
  if (isGemini3Flash(model)) {
    const level = t >= 896 ? "high" : t >= 640 ? "medium" : t >= 384 ? "low" : "minimal";
    return { thinkingLevel: level };
  }

  if (!t) return null;

  // Gemini 2.5 Pro: thinkingLevel is not supported (400). Use numeric thinkingBudget instead.
  // Provider requires thinkingBudget in [128, 32768].
  // Also, Gemini 2.5 can spend most of maxOutputTokens on hidden thoughts unless we reserve enough room.
  if (isGemini25Pro(model)) {
    const MIN_BUDGET = 128;
    if (t < MIN_BUDGET) return null;

    const req = Math.max(0, Math.floor(Number(maxOutputTokensRequested) || 0));
    const cap0 = req > 0 ? Math.max(0, Math.floor(req * 0.35)) : t;
    const cap = Math.max(MIN_BUDGET, cap0 || 0);
    const budget = Math.min(t, cap);

    return { thinkingBudget: budget };
  }

  return null;
}

function thinkingLevelHeadroom(level: string): number {
  const l = String(level || "").toLowerCase();
  if (l === "minimal") return 256;
  if (l === "low") return 512;
  if (l === "medium") return 768;
  if (l === "high") return 1024;
  return 0;
}

function estimatePromptTokensFromChars(totalChars: number): number {
  const c = Math.max(0, Math.floor(Number(totalChars) || 0));
  if (!c) return 0;
  // Heuristic: Gemini tokenization for Korean/JP can be denser than English.
  // Empirically ~1 token per 1.4~1.8 chars in our prompts; use 1.6 as a conservative midpoint.
  return Math.max(1, Math.ceil(c / 1.6));
}

function dynamicThinkingHeadroomForGemini3(thinkingLevel: string, estimatedPromptTokens: number): number {
  const level = String(thinkingLevel || "").toLowerCase();
  const pt = Math.max(0, Math.floor(Number(estimatedPromptTokens) || 0));
  if (!level || !pt) return 0;

  // Gemini 3 Pro/Flash는 thinking 토큰이 maxOutputTokens 예산을 잠식하는 경향이 있지만,
  // "헤드룸을 과하게" 잡으면(예: +4k) 한 번의 요청이 매우 느려지거나(>120s) 아예 hang처럼 보이는
  // 문제가 더 자주 발생한다.
  //
  // 목표:
  // - 빈 응답(0 outputTokens) 방지에 충분한 최소 헤드룸은 확보
  // - 대신 "한 방" 호출이 과도하게 커지지 않도록 상한을 낮게 유지

  // Prompt가 커질수록 reasoning spend가 늘어나는 경향이 있어 약하게 비례시키되,
  // 비율/바닥값을 보수적으로 낮춘다.
  const ratio =
    level === "minimal" ? 0.04 :
    level === "low" ? 0.06 :
    level === "medium" ? 0.08 :
    level === "high" ? 0.10 :
    0.06;

  const floor =
    level === "minimal" ? 192 :
    level === "low" ? 320 :
    level === "medium" ? 512 :
    level === "high" ? 768 :
    320;

  const dyn = Math.max(floor, Math.round(pt * ratio));
  return Math.min(1536, dyn);
}

function computeEffectiveMaxOutputTokens(
  model: string,
  requestedMaxOutputTokens: number,
  thinkingConfig: ThinkingConfigAny | null,
  system: string,
  user: string
) {
  const req = Math.max(0, Math.floor(Number(requestedMaxOutputTokens) || 0));

  const tb = thinkingConfig?.thinkingBudget ? Math.max(0, Math.floor(Number(thinkingConfig.thinkingBudget) || 0)) : 0;
  const tl = thinkingConfig?.thinkingLevel ? String(thinkingConfig.thinkingLevel) : "";
  const baseHeadroom = tb > 0 ? tb : tl ? thinkingLevelHeadroom(tl) : 0;
  let headroom = baseHeadroom;

  // Gemini 3: reserve *dynamic* headroom based on prompt size.
  // - Prevents long multi-call "continue:MAX_TOKENS" chains (each call can take 40~60s).
  // - Keeps visible output closer to the requested size, instead of being starved by reasoning.
  if (isGemini3(model) && tl) {
    const totalChars = Math.max(0, (system || "").length + (user || "").length);
    const estPromptTokens = estimatePromptTokensFromChars(totalChars);
    const dyn = dynamicThinkingHeadroomForGemini3(tl, estPromptTokens);
    headroom = Math.max(headroom, dyn);
  }

  if (headroom > 0 && (isGemini3(model) || isGemini25Pro(model))) {
    // 핵심 원칙:
    // - req는 "사용자가 체감하는 글 길이"(슬라이더)로 쓰이므로 그대로 존중
    // - headroom은 빈 응답 방지를 위한 최소분만 더한다
    // - 단, Gemini 3 Pro에서 headroom이 커지면 호출이 매우 느려지는 문제가 있어 상한을 낮게 둔다

    // req가 작을수록(headroom 과다) 체감 지연이 커지므로 req 비례 상한을 둔다.
    const headroomCapByReq = Math.max(256, Math.floor(req * 0.85));
    const headroomHardCap = isGemini3Pro(model) ? 1024 : 1536;
    const cappedHeadroom = Math.min(headroom, headroomCapByReq, headroomHardCap);

    const eff = req + cappedHeadroom + 64;

    // 최종 상한: 한 방 호출이 과도하게 커지지 않도록(=hang/120s+) 보수적 캡을 적용
    const hardMax = isGemini3Pro(model) ? 4096 : 8192;
    return Math.min(hardMax, Math.max(req, eff));
  }
  return req;
}


function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T | null> {
  return await Promise.race([
    p,
    new Promise((res) => setTimeout(() => res(null), Math.max(0, ms))),
  ]) as any;
}

function extractHttpStatus(err: any): number | null {
  const e = err || {};
  const cand = [
    e?.status,
    e?.code,
    e?.response?.status,
    e?.cause?.status,
    e?.cause?.code,
    e?.cause?.response?.status,
  ];
  for (const v of cand) {
    const n = Number(v);
    if (Number.isFinite(n) && n >= 100 && n <= 599) return Math.floor(n);
  }
  const msg = String(e?.message || e || "");
  const m = msg.match(/\b(429|500|502|503|504)\b/);
  if (m) return Number(m[1]);
  return null;
}

function isRetryableGeminiError(err: any) {
  const s = extractHttpStatus(err);
  // Typical transient classes: quota/rate (429), backend (5xx).
  return s === 429 || s === 500 || s === 502 || s === 503 || s === 504;
}

async function withRetry<T>(fn: () => Promise<T>, opts: { maxRetries: number; baseDelayMs: number; label?: string }) {
  let attempt = 0;
  let lastErr: any = null;
  while (attempt <= opts.maxRetries) {
    try {
      const value = await fn();
      return { value, retries: attempt };
    } catch (e: any) {
      lastErr = e;
      if (!isRetryableGeminiError(e) || attempt >= opts.maxRetries) throw e;
      const backoff = opts.baseDelayMs * Math.pow(2, attempt);
      const jitter = Math.floor(Math.random() * Math.max(50, opts.baseDelayMs));
      await sleep(backoff + jitter);
      attempt += 1;
      continue;
    }
  }
  // unreachable
  throw lastErr;
}

function isChatDebug() {
  // 로깅만 추가: 기존 기능/출력에는 영향 없음
  return String(process.env.CHAT_DEBUG || "").trim() === "1";
}

function safeLen(v: any) {
  return Array.from(String(v ?? "")).length;
}

function safePreview(v: any, max = 180) {
  const s = String(v ?? "");
  if (s.length <= max) return s;
  return s.slice(0, max) + "…";
}

export async function generateText(params: {
  system: string;
  user: string;
  opts: ChatGenOpts;
}) {
  const { system, user, opts } = params;

  const t0 = Date.now();

  // 일부 모델/SDK 조합에서 thinkingConfig 또는 stopSequences를 거부하는 케이스가 있어
  // 여러 조합을 순차적으로 시도한다.
  const stopSequences = Array.isArray(opts.stopSequences) ? opts.stopSequences.filter(Boolean) : [];

  const maxOutputTokensRequested = opts.maxOutputTokens;
  const thinkingConfig = buildThinkingConfig(opts.model, opts.maxReasoningTokens, maxOutputTokensRequested);
  const effectiveMaxOutputTokens = computeEffectiveMaxOutputTokens(opts.model, maxOutputTokensRequested, thinkingConfig, system, user);

  const baseReq: any = {
    model: opts.model,
    contents: [{ role: "user", parts: [{ text: user }] }],
    config: {
      systemInstruction: system,
      maxOutputTokens: effectiveMaxOutputTokens,
      ...(stopSequences.length ? { stopSequences } : {}),
    },
  };

  const mkNoStop = (req: any) => {
    const cfg = { ...(req.config || {}) } as any;
    delete cfg.stopSequences;
    return { ...req, config: cfg };
  };

  const withThinking: any = thinkingConfig
    ? {
        ...baseReq,
        config: {
          ...baseReq.config,
          thinkingConfig,
        },
      }
    : null;

  const reqs: Array<{ label: string; req: any }> = withThinking
    ? [
        { label: "withThinking", req: withThinking },
        { label: "base", req: baseReq },
        ...(stopSequences.length ? [{ label: "withThinkingNoStop", req: mkNoStop(withThinking) }] : []),
        ...(stopSequences.length ? [{ label: "baseNoStop", req: mkNoStop(baseReq) }] : []),
      ]
    : [
        { label: "base", req: baseReq },
        ...(stopSequences.length ? [{ label: "baseNoStop", req: mkNoStop(baseReq) }] : []),
      ];

  if (isChatDebug()) {
    console.log(
      JSON.stringify({
        tag: "gemini.req",
        model: opts.model,
        maxOutputTokensRequested,
        maxOutputTokens: effectiveMaxOutputTokens,
        maxReasoningTokens: opts.maxReasoningTokens,
        thinkingBudget: (thinkingConfig as any)?.thinkingBudget ?? null,
        thinkingLevel: (thinkingConfig as any)?.thinkingLevel ?? null,
        stopSequences: stopSequences.length ? stopSequences : null,
        systemChars: system.length,
        userChars: user.length,
        systemPreview: safePreview(system, 240),
        userPreview: safePreview(user, 240),
      })
    );
  }

  let resp: any = null; // accepted response (non-empty)
  let lastResp: any = null; // last response even if empty
  let lastErr: any = null;
  const attempts: Array<{ label: string; ok: boolean; ms: number; err?: string }> = [];

  const extractTextQuick = (r: any): string => {
    const parts0 = (r?.candidates?.[0]?.content?.parts || []) as any[];
    const joined0 = parts0.map((p) => (typeof p?.text === "string" ? p.text : "")).join("");
    return typeof r?.text === "string" ? r.text : joined0;
  };

  const extractOutputTokensQuick = (r: any): number => {
    const u = r?.usageMetadata || r?.usage || {};
    return Number(u?.candidatesTokenCount ?? u?.output_tokens ?? 0) || 0;
  };

  const isLikelyEmptyResponse = (r: any): boolean => {
    const t = String(extractTextQuick(r) || "");
    if (t.trim()) return false;
    const out = extractOutputTokensQuick(r);
    const noCandidates = !Array.isArray(r?.candidates) || r.candidates.length === 0;
    // Gemini 3 Pro can return 200 OK with empty text and 0 output tokens (finishReason sometimes blank).
    return out === 0 || noCandidates;
  };

  const modelIs3Pro = isGemini3Pro(opts.model);
  const modelIs3Flash = isGemini3Flash(opts.model);
  const modelIs25Pro = isGemini25Pro(opts.model);
  const CALL_TIMEOUT_MS = modelIs3Pro ? 45_000 : modelIs3Flash ? 30_000 : modelIs25Pro ? 75_000 : 60_000;

  for (const { label, req } of reqs) {
    const t1 = Date.now();
    try {
      const r0 = await withTimeout(
        withRetry(() => genai.models.generateContent(req), {
          maxRetries: 2,
          baseDelayMs: 650,
          label,
        }),
        CALL_TIMEOUT_MS
      );

      if (!r0) {
        attempts.push({ label, ok: false, ms: Date.now() - t1, err: `timeout>${CALL_TIMEOUT_MS}ms` });
        // Gemini 3 Pro는 non-stream에서 "끝까지 기다리다 멈춘 것처럼 보임"이 자주 발생.
        // 한 번만 빠른 low-thinking 재시도를 하고, 그래도 실패하면 다음 조합으로 넘어가지 않고 종료한다.
        if (modelIs3Pro) break;
        continue;
      }

      const r = (r0 as any)?.value ?? r0;
      lastResp = r;

      if (isLikelyEmptyResponse(r)) {
        attempts.push({ label, ok: false, ms: Date.now() - t1, err: "empty_output" });
        continue;
      }

      resp = r;
      attempts.push({ label, ok: true, ms: Date.now() - t1 } as any);
      break;
    } catch (e: any) {
      lastErr = e;
      attempts.push({ label, ok: false, ms: Date.now() - t1, err: String(e?.message || e) });
    }
  }

  // If Gemini 3 Pro timed out (or kept returning empty), do ONE fast retry with a smaller, safer config.
  if (!resp && modelIs3Pro) {
    const tR = Date.now();
    const safeLevel = "low";
    const safeHeadroom = Math.min(768, Math.max(256, Math.floor(maxOutputTokensRequested * 0.6)));
    const safeMaxOut = Math.min(4096, Math.max(512, (maxOutputTokensRequested || 0) + safeHeadroom + 64));

    const fastReq: any = {
      ...baseReq,
      config: {
        ...baseReq.config,
        maxOutputTokens: safeMaxOut,
        thinkingConfig: { thinkingLevel: safeLevel },
      },
    };

    try {
      const rr0 = await withTimeout(
        withRetry(() => genai.models.generateContent(fastReq), {
          maxRetries: 1,
          baseDelayMs: 650,
          label: "g3proFastRetry",
        }),
        45_000
      );
      if (!rr0) {
        attempts.push({ label: "g3proFastRetry", ok: false, ms: Date.now() - tR, err: `timeout>45000ms` });
      } else {
        const r = (rr0 as any)?.value ?? rr0;
        lastResp = r;
        if (!isLikelyEmptyResponse(r)) {
          resp = r;
          attempts.push({ label: "g3proFastRetry", ok: true, ms: Date.now() - tR } as any);
        } else {
          attempts.push({ label: "g3proFastRetry", ok: false, ms: Date.now() - tR, err: "empty_output" });
        }
      }
    } catch (e: any) {
      attempts.push({ label: "g3proFastRetry", ok: false, ms: Date.now() - tR, err: String(e?.message || e) });
    }
  }

  if (!resp) {
    // If we only got empty responses, keep the last one so the rescue path can run.
    resp = lastResp;
  }

  if (!resp) {
    throw lastErr || new Error("gemini generateContent failed");
  }

  const latencyMs = Date.now() - t0;

  const parts = (resp.candidates?.[0]?.content?.parts || []) as any[];
  const joined = parts.map((p) => (typeof p?.text === "string" ? p.text : "")).join("");
  const text = typeof resp.text === "string" ? resp.text : joined;

  const usage = resp.usageMetadata || resp.usage || {};
  const finishReason = String(resp.candidates?.[0]?.finishReason || resp.finishReason || "");

  const promptTokens = Number(usage?.promptTokenCount ?? usage?.prompt_tokens ?? 0) || 0;
  const outputTokens = Number(usage?.candidatesTokenCount ?? usage?.output_tokens ?? 0) || 0;
  const reasoningTokens = Number(usage?.thoughtsTokenCount ?? usage?.reasoning_tokens ?? 0) || 0;
  const totalTokens = Number(usage?.totalTokenCount ?? usage?.total_tokens ?? 0) || (promptTokens + outputTokens + reasoningTokens);

  let finalText = String(text || "");
  let finalUsage: any = {
    promptTokens,
    outputTokens,
    reasoningTokens,
    totalTokens,
  };
  let finalFinishReason = finishReason;

  // (Gemini 3) Fail-safe:
  // 모델이 thinking에 maxOutputTokens를 전부 써버리면 outputTokens=0이 되며 화면엔 빈 응답이 나타난다.
  // 이 경우 1회만 'output 자리'를 확보해 재시도한다.
  const isG3 = isGemini3(opts.model);
  const fr = String(finalFinishReason || "").toUpperCase();
  const isEmptyG3 = isG3 && !finalText.trim();
  const isEmptyMax =
    isEmptyG3 &&
    (fr.includes("MAX") || Number(finalUsage.outputTokens || 0) === 0 || !Array.isArray(resp?.candidates) || resp.candidates.length === 0);

  if (isEmptyMax) {
    const rescueLevel = isGemini3Flash(opts.model) ? "minimal" : "low";
    const rescueHeadroom = thinkingLevelHeadroom(rescueLevel);

    // Give the model enough room for BOTH thinking + visible text.
    // We keep the user's requested maxOutputTokens as the 'visible-output budget' and add a headroom.
    const rescueMaxOut = Math.min(8192, Math.max(512, (maxOutputTokensRequested || 0) + rescueHeadroom + 512));

    const rescueReq: any = {
      ...baseReq,
      config: {
        ...baseReq.config,
        maxOutputTokens: rescueMaxOut,
        thinkingConfig: { thinkingLevel: rescueLevel },
      },
    };

    const t2 = Date.now();
    try {
      const RESCUE_TIMEOUT_MS = 12000;
      const rr0 = await withTimeout(
        withRetry(() => genai.models.generateContent(rescueReq), {
          maxRetries: 1,
          baseDelayMs: 650,
          label: "rescueEmptyOutput",
        }),
        RESCUE_TIMEOUT_MS
      );

      if (!rr0) {
        attempts.push({
          label: "rescueEmptyOutput",
          ok: false,
          ms: Date.now() - t2,
          err: `timeout>${RESCUE_TIMEOUT_MS}ms`,
        });
        // timeout이면 원본 결과(빈 응답)를 그대로 두고, route.ts의 이어쓰기 로직에 맡긴다.
        return {
          text: finalText,
          usage: {
            ...finalUsage,
            latencyMs,
            model: opts.model,
            finishReason: finalFinishReason,
          },
        };
      }

      const rescueResp: any = (rr0 as any)?.value ?? rr0;
      attempts.push({ label: "rescueEmptyOutput", ok: true, ms: Date.now() - t2 });

      const rParts = (rescueResp.candidates?.[0]?.content?.parts || []) as any[];
      const rJoined = rParts.map((p) => (typeof p?.text === "string" ? p.text : "")).join("");
      const rText = typeof rescueResp.text === "string" ? rescueResp.text : rJoined;

      const rUsage = rescueResp.usageMetadata || rescueResp.usage || {};
      const rFinish = String(rescueResp.candidates?.[0]?.finishReason || rescueResp.finishReason || "");

      const rPrompt = Number(rUsage?.promptTokenCount ?? rUsage?.prompt_tokens ?? 0) || 0;
      const rOut = Number(rUsage?.candidatesTokenCount ?? rUsage?.output_tokens ?? 0) || 0;
      const rReason = Number(rUsage?.thoughtsTokenCount ?? rUsage?.reasoning_tokens ?? 0) || 0;
      const rTotal = Number(rUsage?.totalTokenCount ?? rUsage?.total_tokens ?? 0) || (rPrompt + rOut + rReason);

      if (String(rText || "").trim()) {
        finalText = String(rText || "");
        finalUsage = {
          promptTokens: rPrompt,
          outputTokens: rOut,
          reasoningTokens: rReason,
          totalTokens: rTotal,
        };
        finalFinishReason = rFinish;
      }
    } catch (e: any) {
      attempts.push({ label: "rescueEmptyOutput", ok: false, ms: Date.now() - t2, err: String(e?.message || e) });
    }
  }

  if (isChatDebug()) {
    console.log(
      JSON.stringify({
        tag: "gemini.resp",
        model: opts.model,
        latencyMs,
        attempts,
        finishReason: finalFinishReason,
        usage: { ...finalUsage },
        textPreview: safePreview(finalText, 240),
      })
    );
  }

  return {
    text: finalText,
    usage: {
      ...finalUsage,
      latencyMs,
      model: opts.model,
      finishReason: finalFinishReason,
    },
  };
}


export async function generateTextStream(params: {
  system: string;
  user: string;
  opts: ChatGenOpts;
}): Promise<{ stream: AsyncIterable<string>; final: Promise<{ text: string; usage: any }> }> {
  const { system, user, opts } = params;

  // STREAMING DISABLED: return a single-shot result to reduce formatting/NDJSON issues.
  // This keeps call sites compatible while avoiding incremental deltas.
  const one = await generateText({ system, user, opts });
  async function* once() {
    yield one.text;
  }
  return {
    stream: once(),
    final: Promise.resolve({ text: one.text, usage: one.usage }),
  };
}


export async function summarizeKorean(params: {
  text: string;
  targetChars: number;
  opts: ChatGenOpts;
  turnRangeLabel?: string;
  perTurnChars?: number;
  guidance?: string;
}) {
  const { text, targetChars, opts, turnRangeLabel, perTurnChars, guidance } = params;

  const rangeLabel = String(turnRangeLabel || "이번 구간");

  // ---- Clean dialogue (keep ai.ts self-contained) ----
  let cleanDialogue = String(text || "");
  // remove fenced blocks (INFO 포함), media markdown, links
  cleanDialogue = cleanDialogue.replace(/```[\s\S]*?```/g, "");
  cleanDialogue = cleanDialogue.replace(/!\[[^\]]*\]\([^\)]+\)/g, "");
  cleanDialogue = cleanDialogue.replace(/\[[^\]]*\]\([^\)]+\)/g, "");
  cleanDialogue = cleanDialogue.replace(/https?:\/\/\S+/g, "");
  // trim junk lines
  cleanDialogue = cleanDialogue
    .split("\n")
    .filter((ln) => {
      const t = ln.trim();
      if (!t) return false;
      if (/^[!\-_=~.]+$/.test(t)) return false;
      return true;
    })
    .join("\n")
    .trim();

  const extraGuide = guidance ? `\n- 추가 지침: ${guidance}` : "";
  const perTurnHint =
    typeof perTurnChars === "number" && Number.isFinite(perTurnChars) && perTurnChars > 0
      ? `\n- 참고: 턴당 글자수 목표(perTurnChars) ≈ ${Math.floor(perTurnChars)}자`
      : "";

  const system = `너는 소설/대화 로그의 '장기 기억 요약 작가'다.
주어진 [대화]를 읽고, 이후 대화에 참고할 수 있도록 '라벨링 요약'을 만든다.

반드시 한국어로만 답하고, 아래 출력 형식을 절대 어기지 마라.
- 라벨은 정확히 4개: [핵심 사건], [정보/설정], [감정/태도], [합의/약속]
- 각 라벨은 반드시 1줄 이상 작성한다. 내용이 없으면 '없음'이라고 적어라.
- 라벨 줄을 비워두거나, 라벨을 누락하거나, 다른 라벨을 추가하지 마라.
- 불필요한 마크다운(불릿/헤딩/코드블록) 금지. (단, 첫 줄의 '## 장기 기억 (...)' 헤더만 예외)
- 직접 대사 인용(" ", “ ”) 금지. 요지만 서술한다.`;

  const user = `아래 [대화]를 기반으로 장기 기억 요약을 작성해줘.

[요구사항]
1) 문체는 건조한 서술체("~한다", "~했다") 중심으로.
2) 등장인물을 임의로 추가하지 마라. (대화에 없는 제3자/집단 생성 금지)
3) 라벨마다 핵심만 간결히 적되, 너무 짧게(한두 단어) 끝내지 말라.${extraGuide}${perTurnHint}

[출력 형식(절대 준수)]
## 장기 기억 (${rangeLabel})

[핵심 사건] ...
[정보/설정] ...
[감정/태도] ...
[합의/약속] ...

[분량 목표]
- 최소 ${Math.max(120, Math.floor(targetChars * 0.7))}자 ~ 최대 ${Math.floor(targetChars * 1.3)}자

[대화]
${cleanDialogue}`;

  // 요약은 잘리는 경우가 많아 maxOutputTokens를 넉넉하게 확보한다.
  const summaryOpts: ChatGenOpts = {
    ...opts,
    maxOutputTokens: Math.max(1200, Number((opts as any)?.maxOutputTokens || 0)),
  };

  const r = await generateText({ system, user, opts: summaryOpts });

  // ---- Normalize output to the strict label format ----
  const rawOut = String(r.text || "").replace(/\r\n/g, "\n").trim();
  const wantHeader = `## 장기 기억 (${rangeLabel})`;

  const labels = [
    "핵심 사건",
    "정보/설정",
    "감정/태도",
    "합의/약속",
  ] as const;

  // Prefer robust "segment" parsing so we can handle cases like:
  // "[감정/태도] ... [합의/약속] ..."
  const picked: Record<(typeof labels)[number], string[]> = {
    "핵심 사건": [],
    "정보/설정": [],
    "감정/태도": [],
    "합의/약속": [],
  };

  const segRe = /\[(핵심\s*사건|정보\/설정|감정\/태도|합의\/약속)\]\s*[:：]?\s*/g;
  const matches = [...rawOut.matchAll(segRe)];

  const cleanVal = (v: string) => {
    let t = String(v || "");
    // drop any accidental headings / bullets / code fences
    t = t.replace(/^\s*#{1,6}\s*/gm, "");
    t = t.replace(/```[\s\S]*?```/g, " ");
    t = t.replace(/^[\-\*•]\s+/gm, "");
    // avoid direct quotes
    t = t.replace(/[“”"]/g, "");
    // collapse whitespace
    t = t.replace(/\s+/g, " ").trim();
    return t;
  };

  if (matches.length) {
    for (let i = 0; i < matches.length; i++) {
      const m0 = matches[i];
      const keyRaw = String(m0[1] || "").replace(/\s+/g, " ").trim();
      const key = (keyRaw === "핵심 사건" ? "핵심 사건"
        : keyRaw === "정보/설정" ? "정보/설정"
        : keyRaw === "감정/태도" ? "감정/태도"
        : "합의/약속") as (typeof labels)[number];

      const startIdx = (m0.index ?? 0) + String(m0[0]).length;
      const endIdx = i + 1 < matches.length ? (matches[i + 1].index ?? rawOut.length) : rawOut.length;
      const seg = rawOut.slice(startIdx, endIdx);
      const val = cleanVal(seg);
      if (val) picked[key].push(val);
    }
  } else {
    // Fallback: line-based pick
    const lines = rawOut.split("\n").map((x) => x.trim()).filter((x) => x.length > 0);
    for (const ln of lines) {
      for (const key of labels) {
        const re = new RegExp(`^\\[${key.replace(/[-/\\^$*+?.()|[\\]{}]/g, "\\$&")}\\]\\s*[:：]?\\s*(.*)$`);
        const mm = ln.match(re);
        if (mm) {
          const v = cleanVal(String(mm[1] || ""));
          if (v) picked[key].push(v);
          break;
        }
      }
    }
  }

  // Build normalized output (exactly header + 4 label lines)
  const outLines: string[] = [];
  outLines.push(wantHeader);
  outLines.push("");
  for (const key of labels) {
    // Join multiple mentions but keep it one line.
    let v = picked[key].length ? picked[key].join(" / ") : "없음";
    v = cleanVal(v);
    if (!v) v = "없음";
    outLines.push(`[${key}] ${v}`);
  }

  // Trim helper for label values.
  // - Keeps output within budget without adding ellipsis.
  // - Prefers cutting on whitespace/punctuation boundaries when possible.
  const trimSmart = (input: string, maxLen: number): string => {
    const s = String(input || "").replace(/\s+/g, " ").trim();
    const limit = Math.max(0, Math.floor(Number(maxLen) || 0));
    if (!s || limit <= 0) return "";
    if (s.length <= limit) return s;

    // Hard cut, then try to backtrack to a natural boundary.
    let cut = s.slice(0, limit).trimEnd();

    // Backtrack to last whitespace or common punctuation if it exists reasonably close.
    const tail = cut.slice(Math.max(0, cut.length - 20));
    const m = tail.match(/^(.*?)([\s,.;:!?\)\]\}、。！？…])[^\s]*$/);
    if (m && m[1] && m[1].trim().length >= Math.max(4, Math.floor(limit * 0.5))) {
      cut = m[1].trimEnd();
    }

    // Defensive: remove trailing ellipsis/dots.
    cut = cut.replace(/(\u2026|\.{3,})\s*$/g, "").trimEnd();
    return cut;
  };

// Hard enforce the length budget ("턴당 글자" * N턴)
// NOTE: We try to use as much of the target as possible while keeping the 4-label format.
const maxChars = Math.max(20, Math.floor(Number.isFinite(targetChars) ? targetChars : 200));

const headerBlock = wantHeader + "\n\n"; // header + blank line
const prefixes = labels.map((k) => `[${k}] `);

// fixed: headerBlock + label prefixes + newlines between label lines
const fixed = headerBlock.length + prefixes.reduce((a, b) => a + b.length, 0) + 3; // 3 newlines between 4 lines

const budgetForValues = Math.max(0, maxChars - fixed);

// Distribute value budget across 4 labels.
let perLabelBudget = Math.max(6, Math.floor(budgetForValues / 4));

// Re-balance dynamically to fit as close as possible to maxChars
const build = (budget: number) => {
  const lines: string[] = [];
  lines.push(wantHeader);
  lines.push("");
  for (const key of labels) {
    const val = String(outLines.find((ln) => ln.startsWith(`[${key}]`)) || "").replace(/^\[[^\]]+\]\s*/, "");
    const clipped = trimSmart(val, budget);
    lines.push(`[${key}] ${clipped || "없음"}`);
  }
  return lines.join("\n").trim();
};

// Increase budget a bit if we are too short (rare: parser cleaned too much)
let finalText = build(perLabelBudget);

// If too long, shrink budget until it fits.
while (finalText.length > maxChars && perLabelBudget > 4) {
  perLabelBudget -= 2;
  finalText = build(perLabelBudget);
}

// If still too long (extreme tiny target), accept minimal form.
if (finalText.length > maxChars) {
  finalText = build(4);
}

// Remove any trailing ellipsis characters defensively.
finalText = finalText.replace(/(\u2026|\.{3,})\s*$/g, "").trimEnd();

return finalText;
}

// ---------------------------------------------------------------------------
// Long-memory summary (free-form, no headings/labels)
// - Used by /api/chat/memory (long-term memory blocks)
// - Must NOT change summarizeKorean() behavior because /api/chat/send uses it
// ---------------------------------------------------------------------------
export async function summarizeLongMemoryKorean(params: {
  text: string;
  targetChars: number;
  opts: ChatGenOpts;
  guidance?: string;
}) {
  const { text, targetChars, opts, guidance } = params;

  // ---- Clean dialogue (keep ai.ts self-contained) ----
  let cleanDialogue = String(text || "");
  cleanDialogue = cleanDialogue.replace(/```[\s\S]*?```/g, "");
  cleanDialogue = cleanDialogue.replace(/!\[[^\]]*\]\([^\)]+\)/g, "");
  cleanDialogue = cleanDialogue.replace(/\[([^\]]*?)\]\([^\)]+\)/g, "$1");
  cleanDialogue = cleanDialogue.replace(/https?:\/\/\S+/g, "");
  cleanDialogue = cleanDialogue
    .split("\n")
    .filter((ln) => {
      const t = ln.trim();
      if (!t) return false;
      if (/^[!\-_=~.]+$/.test(t)) return false;
      return true;
    })
    .join("\n")
    .trim();

  const soft = Math.max(60, Math.floor(Number(targetChars) || 240));
  const hard = Math.min(2000, Math.max(80, Math.ceil(soft * 1.15)));
  const extraGuide = guidance ? `\n- 추가 지침: ${guidance}` : "";

  const system = `너는 소설/대화 로그의 장기기억 요약가다.
주어진 내용을 다음 대화에서도 참고할 수 있도록, '핵심만' 자연스러운 한국어 문장으로 압축한다.

출력 규칙(절대 준수):
- 한국어만.
- 마크다운(헤딩/불릿/코드블록) 금지. 평문 문장만.
	- [핵심 사건]/[정보/설정]/[감정/태도]/[합의/약속] 같은 라벨 금지.
- 직접 대사 인용(\"...\") 금지. 요지만 서술.
- 등장인물/사실을 임의로 추가하지 마라.
- 문장을 중간에서 끊지 말고 완결된 문장으로 끝내라.`;

  const user = `아래 [대화]를 읽고 장기기억 요약을 작성해줘.${extraGuide}

[분량]
- 목표: 약 ${soft}자
- 허용 상한: 최대 ${hard}자 (단, 문장 마무리를 위해 약간의 여유는 허용)

[요약 방식]
1) 1~3문장.
2) 사건/관계/상태 중심. 감정/추측은 배제.
3) 문장 끝은 반드시 자연스럽게 마무리.

[대화]
${cleanDialogue}`;

  const summaryOpts: ChatGenOpts = {
    ...opts,
    // 요약은 잘리는 경우가 많아 여유 토큰을 확보
    maxOutputTokens: Math.max(1200, Number((opts as any)?.maxOutputTokens || 0)),
  };

  const r = await generateText({ system, user, opts: summaryOpts });
  let out = String(r.text || "").replace(/\r\n/g, "\n").trim();

  // Strip any accidental markdown/headings/bullets.
  out = out.replace(/^\s*#{1,6}\s*.*$/gm, "");
  out = out.replace(/```[\s\S]*?```/g, " ");
  out = out.replace(/^[\-\*•]\s+/gm, "");
  out = out.replace(/[“”"]/g, "");
	// Strip any accidental legacy labels.
	for (const lab of ["[핵심 사건]", "[정보/설정]", "[감정/태도]", "[합의/약속]"]) {
		out = out.split(lab).join("");
	}
  out = out.replace(/\s+/g, " ").trim();

  const endsNice = (s: string) => {
    const t = String(s || "").trim();
    if (!t) return false;
    if (/[.!?…。]$/.test(t)) return true;
    // Korean declarative endings
    return /(다|요|니다|했다|하였다|된다|됐다|있다|없다|였다|이었다)$/.test(t.replace(/\s+$/g, ""));
  };

  const trimToBoundary = (s: string, limit: number) => {
    const x = String(s || "").trim();
    if (!x) return "";
    if (x.length <= limit) return x;
    const cut = x.slice(0, limit).trimEnd();
    // Prefer sentence punctuation boundary.
    const lastP = Math.max(cut.lastIndexOf("."), cut.lastIndexOf("!"), cut.lastIndexOf("?"), cut.lastIndexOf("…"));
    if (lastP >= Math.floor(limit * 0.45)) return cut.slice(0, lastP + 1).trim();
    // Or whitespace boundary.
    const lastSp = cut.lastIndexOf(" ");
    if (lastSp >= Math.floor(limit * 0.6)) return cut.slice(0, lastSp).trim();
    return cut.trim();
  };

  // Hard cap, but try to preserve a clean sentence ending.
  if (out.length > hard) {
    const clipped = trimToBoundary(out, hard);
    out = clipped;
  }

  // If still not nicely ended and we have a small margin, allow up to +12 chars to finish.
  if (!endsNice(out) && out.length < hard + 12) {
    // If model ended without punctuation, do nothing; server-side post-processor can handle.
    // (We keep ai.ts conservative to avoid hallucinating an ending.)
  }

  return out.trim();
}
// ---------------------------------------------------------------------------
// Long-memory section summary (요약.txt 스타일)
// - Output format (exact):
//   ### <짧은 제목> (<start>-<end>턴)
//   <요약 본문>
// - Body is capped by targetChars and trimmed to a clean sentence/space boundary.
// ---------------------------------------------------------------------------
export async function summarizeLongMemorySectionKorean(params: {
  text: string;
  startTurn: number;
  endTurn: number;
  targetChars: number;
  opts: ChatGenOpts;
  guidance?: string;
  personaName?: string;
}): Promise<string> {
  const { text, startTurn, endTurn, targetChars, opts, guidance, personaName } = params;

  const st = Math.max(1, Math.floor(Number(startTurn) || 1));
  const ed = Math.max(1, Math.floor(Number(endTurn) || 1));
  const turnLabel = `${st}-${ed}턴`;

  // Budget: user 요청(80자/턴 x 3턴) = 240자 목표
  const soft = Math.max(120, Math.floor(Number(targetChars) || 240));
  const hard = Math.min(2000, Math.max(160, Math.ceil(soft * 1.15)));
  const extraGuide = guidance ? `\n- 추가 지침: ${String(guidance).trim()}` : "";

  // ---- Clean dialogue (keep ai.ts self-contained) ----
  let cleanDialogue = String(text || "");
  cleanDialogue = cleanDialogue.replace(/```[\s\S]*?```/g, "");
  cleanDialogue = cleanDialogue.replace(/!\[[^\]]*\]\([^\)]+\)/g, "");
  cleanDialogue = cleanDialogue.replace(/\[([^\]]*?)\]\([^\)]+\)/g, "$1");
  cleanDialogue = cleanDialogue.replace(/https?:\/\/\S+/g, "");
  cleanDialogue = cleanDialogue
    .split("\n")
    .map((ln) => ln.trimEnd())
    .filter((ln) => {
      const t = ln.trim();
      if (!t) return false;
      if (/^[!\-_=~.]+$/.test(t)) return false;
      return true;
    })
    .join("\n")
    .trim();

  const heroName = String(personaName || "").trim();
  const heroGuide = heroName
    ? `- 주인공 이름은 반드시 '${heroName}'로 표기(\{\{USER\}\} 같은 토큰 금지).`
    : "- 주인공 이름이 명시되어 있으면 그 고유명칭을 그대로 쓰고, 불명확하면 '주인공'으로 표기(\{\{USER\}\} 토큰 금지).";

  const system = `너는 '장기 기억(요약.txt)'에 추가될 한 개의 섹션을 작성하는 요약가다.

대상: 대화의 특정 구간(${turnLabel}).

출력 형식은 반드시 아래 2줄(다른 텍스트 금지):
1) ### <짧은 제목> (${turnLabel})
2) <자연스러운 요약 문단 1개 (1~3문장)>

규칙(절대 준수):
- 한국어만
- 라벨(예: 장소/시점:, 등장인물/세력:)로 줄을 나누지 말고, 1개 문단 안에서 자연스럽게 이어서 서술
- 직접 대사 인용 금지(따옴표/대사 복붙 금지)
- 불릿/번호/표/코드블록/링크/경로/URL 금지
- ${heroGuide}
- 등장인물은 이름/별명/호칭이 대화에 1회라도 등장하면, 요약에서는 반드시 그 고유명칭으로 통일해 표기하고(대명사 대신 이름 반복 허용), \"소녀/사내/남자/여자\" 같은 일반명사로 바꿔치기하지 말 것(이름이 정말 불명확할 때만 일반명사 허용).
- 가능한 한: (1)장소/시점(확실할 때만) (2)주요 인물/세력 (3)발단→핵심 행동→결과 (4)미해결/다음 목표 포함
- 사실/등장인물을 임의로 추가하지 말 것
- 본문(2번째 줄)은 약 ${soft}자 이내로 최대한 압축(필요하면 과감히 생략)
${extraGuide}

오직 위 형식만 출력하라.`;

  const user = `아래 [대화]를 읽고, ${turnLabel} 구간 요약 섹션을 작성해줘.

[분량]
- 목표: 헤더 1줄 + 본문 1줄(자연 문단) ≈ ${soft}자
- 허용 상한: 최대 ${hard}자(문장 마무리를 위한 소폭 여유만 허용)

[대화]
${cleanDialogue}`;

  const summaryOpts: ChatGenOpts = {
    ...opts,
    // 헤더+문단 2줄을 안정적으로 뱉도록 여유 토큰
    maxOutputTokens: Math.max(1100, Number((opts as any)?.maxOutputTokens || 0)),
  };

  const r = await generateText({ system, user, opts: summaryOpts });
  let out = String(r.text || "").replace(/\r\n/g, "\n").trim();

  // Remove fenced code blocks and inline code remnants.
  out = out.replace(/```[\s\S]*?```/g, " ");
  out = out.replace(/`+/g, "");

  // Strip URLs aggressively.
  out = out.replace(/https?:\/\/\S+/gi, "");
  out = out.replace(/\b\w+?:\/\/\S+/gi, "");

  // Normalize quotes/asterisks that could look like dialogue or emphasis.
  out = out.replace(/["“”‘’]/g, "");
  out = out.replace(/[\*＊∗﹡⁎]/g, "");

  // Split into non-empty trimmed lines.
  const lines0 = out
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => !!l);

  const isHeadingLine = (l: string) => /^#{1,6}\s+/.test(String(l || "").trim());

  let headingLine = "";
  let bodyLines: string[] = [];

  if (lines0.length > 0 && isHeadingLine(lines0[0])) {
    headingLine = lines0[0];
    bodyLines = lines0.slice(1);
  } else {
    // Sometimes the model omits the heading or places it later.
    const idx = lines0.findIndex((l) => isHeadingLine(l));
    if (idx >= 0) {
      headingLine = lines0[idx];
      bodyLines = [...lines0.slice(0, idx), ...lines0.slice(idx + 1)];
    } else {
      bodyLines = lines0;
    }
  }

  // (핵심) 본문에 섞여 들어오는 헤더(### ...) 제거 → "같은 제목 2번" 중복 방지
  bodyLines = bodyLines.filter((l) => !isHeadingLine(l));

  const ensureRange = (h: string) => {
    const t = String(h || "").trim();
    const has = new RegExp(`\\(\\s*${turnLabel.replace(/[-]/g, "\\-")}\\s*\\)`).test(t);
    if (has) return t;
    const stripped = t.replace(/\([^)]*\)\s*$/g, "").trim();
    return `${stripped} (${turnLabel})`.trim();
  };

  // Normalize heading/title.
  let title = String(headingLine || "").trim();
  title = title.replace(/^#{1,6}\s+/, "");
  title = title.replace(/\([^)]*\)\s*$/g, "").trim();
  title = title.replace(/\s+/g, " ").trim();
  if (!title) title = "요약";
  if (title.length > 28) title = title.slice(0, 28).trim();
  const headerLine = ensureRange(`### ${title}`);

  const stripLabelPrefix = (s: string) =>
    String(s || "")
      .replace(
        /^(장소\s*\/\s*시점|등장인물\s*\/\s*세력|등장인물|발단|핵심\s*행동|결과|미해결\s*(떡밥)?\s*\/\s*(다음\s*)?(목표)?)\s*[:：\-]\s*/,
        ""
      )
      .trim();

  const trimToKoreanBoundary = (s: string, limit: number) => {
    const x = String(s || "").replace(/\s+/g, " ").trim();
    if (!x) return "";
    if (x.length <= limit) return x;
    const cut = x.slice(0, limit).trimEnd();
    const lastP = Math.max(
      cut.lastIndexOf("."),
      cut.lastIndexOf("!"),
      cut.lastIndexOf("?"),
      cut.lastIndexOf("…"),
      cut.lastIndexOf("。")
    );
    if (lastP >= Math.floor(limit * 0.45)) return cut.slice(0, lastP + 1).trim();

    // Prefer Korean sentence endings like "다"/"요".
    const ends = ["다", "요", "함", "됨"];
    let best = -1;
    for (const e of ends) {
      const re = new RegExp(`${e}(?=\\s|$)`, "g");
      let m: RegExpExecArray | null;
      while ((m = re.exec(cut))) {
        best = Math.max(best, m.index + e.length);
      }
    }
    if (best >= Math.floor(limit * 0.45)) {
      const clipped = cut.slice(0, best).trim();
      return /[.!?…。]$/.test(clipped) ? clipped : `${clipped}.`;
    }

    const lastSp = cut.lastIndexOf(" ");
    if (lastSp >= Math.floor(limit * 0.6)) return cut.slice(0, lastSp).trim();
    return cut.trim();
  };

  const hero = heroName || "주인공";

  // Body: collapse to one paragraph (remove any accidental label prefixes).
  let bodyRaw = bodyLines
    .map(stripLabelPrefix)
    .filter(Boolean)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();

  // Safety: remove placeholders even if the model slips.
  bodyRaw = bodyRaw.replace(/\{\{USER\}\}/g, hero);
  if (heroName) bodyRaw = bodyRaw.replace(/\b주인공\b/g, heroName);
  bodyRaw = bodyRaw.replace(/\b사용자\b/g, hero);

  // Cap to overall budget (body only).
  const overallCap = Math.max(120, soft);
  const bodyFinal = trimToKoreanBoundary(bodyRaw, overallCap);
  return `${headerLine}\n${bodyFinal}`.trim();
}
