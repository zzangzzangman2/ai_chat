"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Theme = {
  bg: string;
  panel: string;
  panel2: string;
  border: string;
  borderSoft: string;
  text: string;
  muted: string;
};

type CharacterRow = {
  id: number;
  chatId: string;
  canonicalName: string;
  aliases: string[];
  relation: string;
  status: string;
  lastAction: string;
  affinity: number | null;
  threat: number | null;
  lastSeenTurn: number | null;
  createdAt: number | null;
  updatedAt: number | null;
};

type ChangeRow = {
  id: number;
  turn: number;
  text: string;
  createdAt: number | null;
};

type SceneRow = {
  id: number;
  chatId: string;
  turnFrom: number | null;
  turnTo: number | null;
  location: string;
  summary: string;
  entities: string[];
  tags: string[];
  createdAt: number | null;
  updatedAt: number | null;
};

export default function MemoryPanel(props: { theme: Theme; chatId: string | null | undefined; embed?: boolean; turnKey?: string }) {
  const { theme, chatId, embed, turnKey } = props;

  const [tab, setTab] = useState<"characters" | "scenes">("characters");

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string>("");

  const [characters, setCharacters] = useState<CharacterRow[]>([]);
  const [selectedName, setSelectedName] = useState<string>("");
  const [selected, setSelected] = useState<CharacterRow | null>(null);
  const [changes, setChanges] = useState<ChangeRow[]>([]);


  const [charQuery, setCharQuery] = useState<string>("");
  const [sceneQuery, setSceneQuery] = useState<string>("");
  const [mergeToName, setMergeToName] = useState<string>("");

  const [scenes, setScenes] = useState<SceneRow[]>([]);
  const [selectedSceneId, setSelectedSceneId] = useState<number | null>(null);
  const selectedScene = useMemo(() => scenes.find((s) => s.id === selectedSceneId) || null, [scenes, selectedSceneId]);


  const filteredCharacters = useMemo(() => {
    const q = charQuery.trim().toLowerCase();
    if (!q) return characters;
    return characters.filter((c) => {
      const name = (c.canonicalName || "").toLowerCase();
      const rel = (c.relation || "").toLowerCase();
      const st = (c.status || "").toLowerCase();
      return name.includes(q) || rel.includes(q) || st.includes(q);
    });
  }, [characters, charQuery]);

  const filteredScenes = useMemo(() => {
    const q = sceneQuery.trim().toLowerCase();
    if (!q) return scenes;
    return scenes.filter((s) => {
      const loc = (s.location || "").toLowerCase();
      const sum = (s.summary || "").toLowerCase();
      return (
        loc.includes(q) ||
        sum.includes(q) ||
        String(s.turnFrom).includes(q) ||
        String(s.turnTo).includes(q)
      );
    });
  }, [scenes, sceneQuery]);

  const canLoad = !!chatId && String(chatId).trim().length > 0;

  const fetchJson = useCallback(async (url: string, init?: RequestInit) => {
    const res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
    });
    if (!res.ok) {
      const t = await res.text().catch(() => "");
      throw new Error(t || `HTTP ${res.status}`);
    }
    return res.json();
  }, []);

  const loadAll = useCallback(async () => {
    if (!canLoad) return;
    setLoading(true);
    setErr("");
    try {
      const [c, s] = await Promise.all([
        fetchJson(`/api/memory/characters?chatId=${encodeURIComponent(chatId)}`),
        fetchJson(`/api/memory/scenes?chatId=${encodeURIComponent(chatId)}`),
      ]);
      setCharacters(Array.isArray(c?.characters) ? c.characters : []);
      setScenes(Array.isArray(s?.scenes) ? s.scenes : []);
      // Reset selection if missing
      setSelected((prev) => {
        if (!prev) return prev;
        const still = (Array.isArray(c?.characters) ? c.characters : []).find((x: any) => x?.canonicalName === prev.canonicalName);
        return still || null;
      });
      setSelectedName((prev) => {
        if (!prev) return prev;
        const exists = (Array.isArray(c?.characters) ? c.characters : []).some((x: any) => x?.canonicalName === prev);
        return exists ? prev : "";
      });
      setSelectedSceneId((prev) => {
        if (prev == null) return prev;
        const exists = (Array.isArray(s?.scenes) ? s.scenes : []).some((x: any) => Number(x?.id) === Number(prev));
        return exists ? prev : null;
      });
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }, [canLoad, chatId, fetchJson]);

  // 마지막 요약 구간 이후~현재 구간을 다시 스캔해서(assistant-turn 기준)
  // 인물/장면 기억을 보강한다.
  const refreshFromLastSummary = useCallback(async () => {
    if (!canLoad) return;
    setLoading(true);
    setErr("");
    try {
      await fetchJson("/api/memory/refresh", {
        method: "POST",
        body: JSON.stringify({ chatId }),
      });
      await loadAll();
    } catch (e: any) {
      setErr(String(e?.message || e || "refresh failed"));
    } finally {
      setLoading(false);
    }
  }, [canLoad, chatId, fetchJson, loadAll]);

  const loadCharacterDetail = useCallback(
    async (name: string) => {
      if (!canLoad || !name) return;
      setLoading(true);
      setErr("");
      try {
        const data = await fetchJson(
          `/api/memory/characters/${encodeURIComponent(name)}?chatId=${encodeURIComponent(chatId)}`
        );
        setSelected(data?.character || null);
        setChanges(Array.isArray(data?.changes) ? data.changes : []);
        setSelectedName(name);
      setMergeToName("");
      } catch (e: any) {
        setErr(String(e?.message || e));
      } finally {
        setLoading(false);
      }
    },
    [canLoad, chatId, fetchJson]
  );

  useEffect(() => {
    // When chat changes, reload
    setSelectedName("");
    setSelected(null);
    setChanges([]);
    setSelectedSceneId(null);
    if (canLoad) void loadAll();
  }, [chatId, canLoad, loadAll]);

  useEffect(() => {
    // When a turn completes, re-pull lists (no LLM call).
    if (!canLoad) return;
    if (turnKey == null) return;
    void loadAll();
  }, [turnKey, canLoad, loadAll]);

  const saveCharacter = useCallback(async () => {
    if (!canLoad || !selected) return;
    setLoading(true);
    setErr("");
    try {
      await fetchJson(`/api/memory/characters/${encodeURIComponent(selected.canonicalName)}?chatId=${encodeURIComponent(chatId)}`, {
        method: "PATCH",
        body: JSON.stringify({
          relation: selected.relation,
          status: selected.status,
          lastAction: selected.lastAction,
          aliases: selected.aliases,
          affinity: selected.affinity,
          threat: selected.threat,
          lastSeenTurn: selected.lastSeenTurn,
        }),
      });
      await loadAll();
      await loadCharacterDetail(selected.canonicalName);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }, [canLoad, selected, chatId, fetchJson, loadAll, loadCharacterDetail]);

  const deleteCharacter = useCallback(
    async (name: string) => {
      if (!canLoad || !name) return;
      const ok = confirm(`'${name}' 인물 카드를 완전히 삭제할까요?\n(복구 불가)`);
      if (!ok) return;
      setLoading(true);
      setErr("");
      try {
        await fetchJson(`/api/memory/characters/${encodeURIComponent(name)}?chatId=${encodeURIComponent(chatId)}`, { method: "DELETE" });
        setSelectedName("");
        setSelected(null);
        setChanges([]);
        await loadAll();
      } catch (e: any) {
        setErr(String(e?.message || e));
      } finally {
        setLoading(false);
      }
    },
    [canLoad, chatId, fetchJson, loadAll]
  );


  const mergeCharacter = useCallback(
    async (fromName: string, toName: string) => {
      if (!canLoad || !fromName || !toName) return;
      if (fromName === toName) return;
      const ok = confirm(`'${fromName}' 카드를 '${toName}'에 병합할까요?\n- 변화 로그는 모두 '${toName}'로 이동\n- '${fromName}' 카드는 완전 삭제(복구 불가)`);
      if (!ok) return;
      setLoading(true);
      setErr("");
      try {
        await fetchJson(`/api/memory/characters/merge`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ chatId, fromName, toName }),
        });
        setMergeToName("");
        await loadAll();
        // 병합 후 대상 카드로 이동
        await loadCharacterDetail(toName);
      } catch (e: any) {
        setErr(String(e?.message || e));
      } finally {
        setLoading(false);
      }
    },
    [canLoad, chatId, fetchJson, loadAll, loadCharacterDetail]
  );

  const addChange = useCallback(
    async (name: string, turn: number, text: string) => {
      if (!canLoad || !name) return;
      const t = String(text || "").trim();
      if (!t) return;
      setLoading(true);
      setErr("");
      try {
        await fetchJson(`/api/memory/characters/${encodeURIComponent(name)}/changes?chatId=${encodeURIComponent(chatId)}`, {
          method: "POST",
          body: JSON.stringify({ turn, text: t }),
        });
        await loadCharacterDetail(name);
      } catch (e: any) {
        setErr(String(e?.message || e));
      } finally {
        setLoading(false);
      }
    },
    [canLoad, chatId, fetchJson, loadCharacterDetail]
  );

  const deleteChange = useCallback(
    async (name: string, id: number) => {
      if (!canLoad || !name) return;
      const ok = confirm(`이 변화 로그를 완전히 삭제할까요?\n(복구 불가)`);
      if (!ok) return;
      setLoading(true);
      setErr("");
      try {
        await fetchJson(
          `/api/memory/characters/${encodeURIComponent(name)}/changes/${encodeURIComponent(String(id))}?chatId=${encodeURIComponent(chatId)}`,
          { method: "DELETE" }
        );
        await loadCharacterDetail(name);
      } catch (e: any) {
        setErr(String(e?.message || e));
      } finally {
        setLoading(false);
      }
    },
    [canLoad, chatId, fetchJson, loadCharacterDetail]
  );

  const deleteScene = useCallback(
    async (id: number) => {
      if (!canLoad) return;
      const ok = confirm(`이 저장된 기억(장면)을 완전히 삭제할까요?\n(복구 불가)`);
      if (!ok) return;
      setLoading(true);
      setErr("");
      try {
        await fetchJson(`/api/memory/scenes/${encodeURIComponent(String(id))}?chatId=${encodeURIComponent(chatId)}`, { method: "DELETE" });
        setSelectedSceneId(null);
        await loadAll();
      } catch (e: any) {
        setErr(String(e?.message || e));
      } finally {
        setLoading(false);
      }
    },
    [canLoad, chatId, fetchJson, loadAll]
  );

  const [newChangeTurn, setNewChangeTurn] = useState<number>(0);
  const [newChangeText, setNewChangeText] = useState<string>("");

  useEffect(() => {
    // Default turn for manual log: lastSeenTurn or 0
    if (selected?.lastSeenTurn != null) setNewChangeTurn(selected.lastSeenTurn);
    else setNewChangeTurn(0);
    setNewChangeText("");
  }, [selectedName]);

  const panelStyle: React.CSSProperties = {
    background: theme.panel,
    border: `1px solid ${theme.border}`,
    borderRadius: 14,
    padding: 14,
  };

  // 드로어/모달처럼 폭이 좁은 컨테이너에서 2열 레이아웃이 깨지지 않도록
  // 컨테이너 폭 기준으로 자동 스택 전환.
  const rootRef = useRef<HTMLDivElement | null>(null);
  const [containerWidth, setContainerWidth] = useState<number>(0);
  useEffect(() => {
    const el = rootRef.current;
    if (!el) return;
    // ResizeObserver가 없는 환경은 드물지만, 안전하게 가드
    const RO: any = (globalThis as any).ResizeObserver;
    if (!RO) return;
    const ro = new RO((entries: any[]) => {
      const w = entries?.[0]?.contentRect?.width;
      if (typeof w === "number") setContainerWidth(w);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const isNarrow = containerWidth > 0 ? containerWidth < 720 : false;

  if (!canLoad) {
    return (
      <div style={panelStyle}>
        {!embed ? <div style={{ fontWeight: 800, fontSize: 16, marginBottom: 8 }}>기억</div> : null}
        <div style={{ color: theme.muted, lineHeight: 1.55 }}>
          아직 선택된 채팅이 없어요. <b>채팅 화면</b>에서 대화를 시작하거나 기존 채팅을 선택한 뒤 다시 와주세요.
        </div>
      </div>
    );
  }

  return (
    <div ref={rootRef} style={{ display: "grid", gap: 12 }}>
      {embed ? (
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", rowGap: 8 }}>
          <div style={{ color: theme.muted, fontSize: 12 }}>인물/저장된 기억</div>
          <div style={{ flex: 1 }} />
          <div style={{ color: theme.muted, fontSize: 12, fontWeight: 800 }}>자동 반영</div>
        </div>
      ) : (
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ fontWeight: 900, fontSize: 18 }}>기억</div>
          <div
            style={{ color: theme.muted, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
          >
            chatId: {chatId}
          </div>
          <div style={{ flex: 1 }} />
          <div style={{ color: theme.muted, fontSize: 12, fontWeight: 800 }}>자동 반영</div>
        </div>
      )}

      {err ? (
        <div
          style={{
            ...panelStyle,
            border: "1px solid rgba(255,90,90,0.55)",
            background: "rgba(255,90,90,0.10)",
            color: "#ffd6d6",
            fontWeight: 800,
          }}
        >
          {err}
        </div>
      ) : null}

      <div style={{ display: "flex", gap: 8 }}>
        <button
          type="button"
          onClick={() => setTab("characters")}
          style={{
            padding: "8px 10px",
            borderRadius: 999,
            border: `1px solid ${tab === "characters" ? theme.border : theme.borderSoft}`,
            background: tab === "characters" ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.03)",
            color: theme.text,
            fontWeight: 900,
            cursor: "pointer",
          }}
        >
          인물
        </button>
        <button
          type="button"
          onClick={() => setTab("scenes")}
          style={{
            padding: "8px 10px",
            borderRadius: 999,
            border: `1px solid ${tab === "scenes" ? theme.border : theme.borderSoft}`,
            background: tab === "scenes" ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.03)",
            color: theme.text,
            fontWeight: 900,
            cursor: "pointer",
          }}
        >
          저장된 기억
        </button>
        <div style={{ flex: 1 }} />
        {loading ? <div style={{ color: theme.muted, fontSize: 12, padding: "10px 0" }}>불러오는 중…</div> : null}
      </div>

      {tab === "characters" ? (
        <div style={{ display: "grid", gridTemplateColumns: isNarrow ? "1fr" : "320px 1fr", gap: 12 }}>
          {/* Left list */}
          <div style={panelStyle}>
            <div style={{ fontWeight: 900, marginBottom: 10 }}>인물 ({filteredCharacters.length}/{characters.length})</div>
            <input
              value={charQuery}
              onChange={(e) => setCharQuery(e.target.value)}
              placeholder="검색(이름/관계/상태)…"
              style={{
                width: "100%",
                marginBottom: 10,
                padding: "10px 12px",
                borderRadius: 12,
                border: `1px solid ${theme.borderSoft}`,
                background: theme.panel2,
                color: theme.text,
                outline: "none",
              }}
            />
            <div
              style={{ display: "grid", gap: 8, maxHeight: isNarrow ? "34vh" : "70vh", overflow: "auto", paddingRight: 4 }}
            >
              {filteredCharacters.map((c) => {
                const active = c.canonicalName === selectedName;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => void loadCharacterDetail(c.canonicalName)}
                    style={{
                      textAlign: "left",
                      padding: 10,
                      borderRadius: 12,
                      border: `1px solid ${active ? theme.border : theme.borderSoft}`,
                      background: active ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.03)",
                      color: theme.text,
                      cursor: "pointer",
                    }}
                  >
                    <div style={{ fontWeight: 900, display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ flex: 1 }}>{c.canonicalName}</span>
                      {c.lastSeenTurn != null ? (
                        <span style={{ fontSize: 11, color: theme.muted }}>T{c.lastSeenTurn}</span>
                      ) : null}
                    </div>
                    <div style={{ fontSize: 12, color: theme.muted, marginTop: 4, lineHeight: 1.4 }}>
                      {c.relation ? c.relation : "관계: (비어있음)"}
                    </div>
                  </button>
                );
              })}
              {characters.length === 0 ? (
                <div style={{ color: theme.muted, fontSize: 13, lineHeight: 1.6 }}>
                  아직 저장된 인물 카드가 없어요. (고유명사 인물만 자동 생성됩니다)
                </div>
              ) : null}
            </div>
          </div>

          {/* Right detail */}
          <div style={panelStyle}>
            {!selected ? (
              <div style={{ color: theme.muted, lineHeight: 1.6 }}>
                왼쪽에서 인물을 선택하면 상세/편집/삭제가 가능합니다.
              </div>
            ) : (
              <div style={{ display: "grid", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", rowGap: 8 }}>
                  <div style={{ fontWeight: 950, fontSize: 18 }}>{selected.canonicalName}</div>
                  <div style={{ color: theme.muted, fontSize: 12 }}>
                    {selected.lastSeenTurn != null ? `마지막: T${selected.lastSeenTurn}` : "마지막: (없음)"}
                  </div>
                  <div style={{ flex: 1 }} />
                  <button
                    type="button"
                    onClick={() => void saveCharacter()}
                    style={{
                      padding: "8px 10px",
                      borderRadius: 10,
                      border: `1px solid ${theme.borderSoft}`,
                      background: "rgba(255,255,255,0.05)",
                      color: theme.text,
                      fontWeight: 950,
                      cursor: "pointer",
                    }}
                  >
                    저장
                  </button>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <select
                      value={mergeToName}
                      onChange={(e) => setMergeToName(e.target.value)}
                      style={{
                        padding: "8px 10px",
                        borderRadius: 10,
                        border: `1px solid ${theme.borderSoft}`,
                        background: theme.panel2,
                        color: theme.text,
                        outline: "none",
                      }}
                    >
                      <option value="">병합 대상…</option>
                      {characters
                        .filter((c) => c.canonicalName !== selected.canonicalName)
                        .map((c) => (
                          <option key={c.id} value={c.canonicalName}>
                            {c.canonicalName}
                          </option>
                        ))}
                    </select>
                    <button
                      type="button"
                      disabled={!mergeToName}
                      onClick={() => void mergeCharacter(selected.canonicalName, mergeToName)}
                      style={{
                        padding: "8px 10px",
                        borderRadius: 10,
                        border: `1px solid ${theme.borderSoft}`,
                        background: !mergeToName ? "rgba(255,255,255,0.06)" : theme.panel2,
                        color: theme.text,
                        cursor: !mergeToName ? "not-allowed" : "pointer",
                        opacity: !mergeToName ? 0.6 : 1,
                      }}
                    >
                      병합
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => void deleteCharacter(selected.canonicalName)}
                    style={{
                      padding: "8px 10px",
                      borderRadius: 10,
                      border: "1px solid rgba(255,90,90,0.55)",
                      background: "rgba(255,90,90,0.12)",
                      color: "#ffd6d6",
                      fontWeight: 950,
                      cursor: "pointer",
                    }}
                  >
                    삭제
                  </button>
                </div>

                <Field
                  label="관계"
                  value={selected.relation || ""}
                  theme={theme}
                  onChange={(v) => setSelected((p) => (p ? { ...p, relation: v } : p))}
                />
                <Field
                  label="상태"
                  value={selected.status || ""}
                  theme={theme}
                  onChange={(v) => setSelected((p) => (p ? { ...p, status: v } : p))}
                  multiline
                />
                <Field
                  label="직전 행동"
                  value={selected.lastAction || ""}
                  theme={theme}
                  onChange={(v) => setSelected((p) => (p ? { ...p, lastAction: v } : p))}
                  multiline
                />

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <SmallNumberField
                    label="친밀도(affinity)"
                    theme={theme}
                    value={selected.affinity}
                    onChange={(n) => setSelected((p) => (p ? { ...p, affinity: n } : p))}
                  />
                  <SmallNumberField
                    label="위협도(threat)"
                    theme={theme}
                    value={selected.threat}
                    onChange={(n) => setSelected((p) => (p ? { ...p, threat: n } : p))}
                  />
                </div>

                <SmallNumberField
                  label="마지막 등장 턴(lastSeenTurn)"
                  theme={theme}
                  value={selected.lastSeenTurn}
                  onChange={(n) => setSelected((p) => (p ? { ...p, lastSeenTurn: n } : p))}
                />

                <div style={{ borderTop: `1px solid ${theme.borderSoft}`, paddingTop: 12 }}>
                  <div style={{ fontWeight: 950, marginBottom: 8 }}>관계 변화 로그 ({changes.length})</div>

                  <div style={{ display: "grid", gap: 8 }}>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <input
                        type="number"
                        value={Number.isFinite(newChangeTurn) ? newChangeTurn : 0}
                        onChange={(e) => setNewChangeTurn(parseInt(e.target.value || "0", 10))}
                        style={{
                          width: 120,
                          padding: "10px 10px",
                          borderRadius: 10,
                          border: `1px solid ${theme.borderSoft}`,
                          background: "rgba(0,0,0,0.25)",
                          color: theme.text,
                          outline: "none",
                          fontWeight: 800,
                        }}
                        placeholder="턴"
                      />
                      <input
                        type="text"
                        value={newChangeText}
                        onChange={(e) => setNewChangeText(e.target.value)}
                        style={{
                          flex: 1,
                          padding: "10px 10px",
                          borderRadius: 10,
                          border: `1px solid ${theme.borderSoft}`,
                          background: "rgba(0,0,0,0.25)",
                          color: theme.text,
                          outline: "none",
                        }}
                        placeholder='예: [T12] 경멸 단계로 진입'
                      />
                      <button
                        type="button"
                        onClick={() => void addChange(selected.canonicalName, newChangeTurn, newChangeText)}
                        style={{
                          padding: "10px 12px",
                          borderRadius: 10,
                          border: `1px solid ${theme.borderSoft}`,
                          background: "rgba(255,255,255,0.06)",
                          color: theme.text,
                          fontWeight: 950,
                          cursor: "pointer",
                        }}
                      >
                        추가
                      </button>
                    </div>

                    <div style={{ display: "grid", gap: 8, maxHeight: "46vh", overflow: "auto", paddingRight: 4 }}>
                      {changes.map((ch) => (
                        <div
                          key={ch.id}
                          style={{
                            border: `1px solid ${theme.borderSoft}`,
                            background: "rgba(255,255,255,0.03)",
                            borderRadius: 12,
                            padding: 10,
                            display: "grid",
                            gap: 6,
                          }}
                        >
                          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                            <div style={{ fontWeight: 950 }}>T{ch.turn}</div>
                            <div style={{ color: theme.muted, fontSize: 12 }}>#{ch.id}</div>
                            <div style={{ flex: 1 }} />
                            <button
                              type="button"
                              onClick={() => void deleteChange(selected.canonicalName, ch.id)}
                              style={{
                                padding: "6px 10px",
                                borderRadius: 10,
                                border: "1px solid rgba(255,90,90,0.55)",
                                background: "rgba(255,90,90,0.12)",
                                color: "#ffd6d6",
                                fontWeight: 900,
                                cursor: "pointer",
                              }}
                            >
                              삭제
                            </button>
                          </div>
                          <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.55 }}>{ch.text}</div>
                        </div>
                      ))}
                      {changes.length === 0 ? (
                        <div style={{ color: theme.muted, fontSize: 13, lineHeight: 1.6 }}>
                          변화 로그가 없어요. (필요하면 위에서 수동으로 추가 가능)
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: isNarrow ? "1fr" : "1fr 1fr", gap: 12 }}>
          <div style={panelStyle}>
            <div style={{ fontWeight: 950, marginBottom: 10 }}>저장된 기억 ({filteredScenes.length}/{scenes.length})</div>
            <input
              value={sceneQuery}
              onChange={(e) => setSceneQuery(e.target.value)}
              placeholder="검색(장소/요약/턴)…"
              style={{
                width: "100%",
                marginBottom: 10,
                padding: "10px 12px",
                borderRadius: 12,
                border: `1px solid ${theme.borderSoft}`,
                background: theme.panel2,
                color: theme.text,
                outline: "none",
              }}
            />
            <div style={{ display: "grid", gap: 8, maxHeight: isNarrow ? "34vh" : "70vh", overflow: "auto", paddingRight: 4 }}>
              {filteredScenes.map((s) => {
                const active = s.id === selectedSceneId;
                const title = `${s.turnFrom != null ? `T${s.turnFrom}` : "T?"}${s.turnTo != null ? `~T${s.turnTo}` : ""}${s.location ? ` · ${s.location}` : ""}`;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedSceneId(s.id)}
                    style={{
                      textAlign: "left",
                      padding: 10,
                      borderRadius: 12,
                      border: `1px solid ${active ? theme.border : theme.borderSoft}`,
                      background: active ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.03)",
                      color: theme.text,
                      cursor: "pointer",
                    }}
                  >
                    <div style={{ fontWeight: 950, fontSize: 13 }}>{title}</div>
                    <div style={{ color: theme.muted, fontSize: 12, marginTop: 4, lineHeight: 1.45 }}>
                      {(s.summary || "").slice(0, 120)}
                      {(s.summary || "").length > 120 ? "…" : ""}
                    </div>
                  </button>
                );
              })}
              {scenes.length === 0 ? (
                <div style={{ color: theme.muted, fontSize: 13, lineHeight: 1.6 }}>아직 저장된 기억이 없어요.</div>
              ) : null}
            </div>
          </div>

          <div style={panelStyle}>
            {!selectedScene ? (
              <div style={{ color: theme.muted, lineHeight: 1.6 }}>왼쪽에서 저장된 기억을 선택해주세요.</div>
            ) : (
              <div style={{ display: "grid", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap", rowGap: 8 }}>
                  <div style={{ fontWeight: 950, fontSize: 15 }}>
                    {selectedScene.turnFrom != null ? `T${selectedScene.turnFrom}` : "T?"}
                    {selectedScene.turnTo != null ? `~T${selectedScene.turnTo}` : ""}
                    {selectedScene.location ? ` · ${selectedScene.location}` : ""}
                  </div>
                  <div style={{ flex: 1 }} />
                  <button
                    type="button"
                    onClick={() => void deleteScene(selectedScene.id)}
                    style={{
                      padding: "8px 10px",
                      borderRadius: 10,
                      border: "1px solid rgba(255,90,90,0.55)",
                      background: "rgba(255,90,90,0.12)",
                      color: "#ffd6d6",
                      fontWeight: 950,
                      cursor: "pointer",
                    }}
                  >
                    삭제
                  </button>
                </div>
                <div style={{ whiteSpace: "pre-wrap", lineHeight: 1.65 }}>{selectedScene.summary}</div>

                {selectedScene.entities?.length ? (
                  <div style={{ color: theme.muted, fontSize: 12, lineHeight: 1.6 }}>
                    등장 인물: {selectedScene.entities.join(", ")}
                  </div>
                ) : null}
                {selectedScene.tags?.length ? (
                  <div style={{ color: theme.muted, fontSize: 12, lineHeight: 1.6 }}>
                    태그: {selectedScene.tags.join(", ")}
                  </div>
                ) : null}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Field(props: {
  label: string;
  value: string;
  theme: any;
  onChange: (v: string) => void;
  multiline?: boolean;
}) {
  const { label, value, theme, onChange, multiline } = props;
  return (
    <div style={{ display: "grid", gap: 6 }}>
      <div style={{ fontWeight: 900 }}>{label}</div>
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          style={{
            padding: "10px 10px",
            borderRadius: 12,
            border: `1px solid ${theme.borderSoft}`,
            background: "rgba(0,0,0,0.25)",
            color: theme.text,
            outline: "none",
            resize: "vertical",
            lineHeight: 1.55,
          }}
        />
      ) : (
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          style={{
            padding: "10px 10px",
            borderRadius: 12,
            border: `1px solid ${theme.borderSoft}`,
            background: "rgba(0,0,0,0.25)",
            color: theme.text,
            outline: "none",
          }}
        />
      )}
    </div>
  );
}

function SmallNumberField(props: { label: string; value: number | null; onChange: (v: number | null) => void; theme: any }) {
  const { label, value, onChange, theme } = props;
  return (
    <div style={{ display: "grid", gap: 6 }}>
      <div style={{ fontWeight: 900 }}>{label}</div>
      <input
        type="number"
        value={value == null ? "" : String(value)}
        onChange={(e) => {
          const v = e.target.value;
          if (v === "") return onChange(null);
          const n = parseInt(v, 10);
          onChange(Number.isFinite(n) ? n : null);
        }}
        style={{
          padding: "10px 10px",
          borderRadius: 12,
          border: `1px solid ${theme.borderSoft}`,
          background: "rgba(0,0,0,0.25)",
          color: theme.text,
          outline: "none",
          fontWeight: 800,
        }}
      />
    </div>
  );
}
