"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

type Theme = {
  bg: string;
  panel: string;
  panel2: string;
  border: string;
  borderSoft: string;
  text: string;
  muted: string;
};

type Props = {
  theme: Theme;
  chatId: string;
  embed?: boolean;
  turnKey?: number;
};

type SummaryRes = {
  ok: boolean;
  chatId: string;
  summary: string;
  meta?: {
    summarizedEndTurn?: number;
    rolledUpCount?: number;
    lastSummarizedAt?: number;
    updatedAt?: number;
    recentSummaryChars?: number;
  };
  policy?: {
    mode?: string;
    summaryEvery?: number;
    perTurnChars?: number;
    keepUserTurns?: number;
  };
  error?: string;
};

export default function MemoryPanel({ theme: THEME, chatId, embed, turnKey }: Props) {
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [summary, setSummary] = useState<string>("");
  const [meta, setMeta] = useState<SummaryRes["meta"]>({});
  const [policy, setPolicy] = useState<SummaryRes["policy"]>({});
  const [err, setErr] = useState<string>("");
  const [dirty, setDirty] = useState(false);

  const metaLine = useMemo(() => {
    const end = meta?.summarizedEndTurn || 0;
    const chars = meta?.recentSummaryChars || 0;
    const rolled = meta?.rolledUpCount || 0;
    const last = meta?.updatedAt || meta?.lastSummarizedAt || 0;
    const when = last ? new Date(last).toLocaleString() : "";
    const every = policy?.summaryEvery ?? 3;
    const per = policy?.perTurnChars ?? 80;
    const mode = policy?.mode ?? "B";
    return `mode ${mode} · ${per}자/턴 · ${every}턴/블록 · endTurn ${end} · ${chars} chars · rollup ${rolled}${when ? ` · ${when}` : ""}`;
  }, [meta, policy]);

  const load = useCallback(async () => {
    if (!chatId) return;
    setLoading(true);
    setErr("");
    try {
      const res = await fetch(`/api/chat/memory/summary?chatId=${encodeURIComponent(chatId)}`, { cache: "no-store" });
      const json = (await res.json()) as SummaryRes;
      if (!res.ok || !json.ok) throw new Error(json.error || `HTTP ${res.status}`);
      setSummary(String(json.summary || ""));
      setMeta(json.meta || {});
      setPolicy(json.policy || {});
      setDirty(false);
    } catch (e: any) {
      setErr(e?.message || "요약을 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  }, [chatId]);

  const doRefresh = useCallback(async () => {
    if (!chatId) return;
    if (dirty) {
      const ok = window.confirm("저장되지 않은 변경이 있어요. 저장하지 않고 갱신하면 내용이 덮어써질 수 있습니다. 계속할까요?");
      if (!ok) return;
      setDirty(false);
    }
    setRefreshing(true);
    setErr("");
    try {
      const res = await fetch("/api/chat/memory/refresh", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chatId }),
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(t || `HTTP ${res.status}`);
      }
      await load();
    } catch (e: any) {
      setErr(e?.message || "refresh 실패");
    } finally {
      setRefreshing(false);
    }
  }, [chatId, load]);

  const doSave = useCallback(async () => {
    if (!chatId) return;
    setSaving(true);
    setErr("");
    try {
      const res = await fetch("/api/chat/memory/summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chatId, summary }),
      });
      const json = (await res.json().catch(() => null)) as any;
      if (!res.ok || !json?.ok) throw new Error(json?.error || `HTTP ${res.status}`);
      await load();
    } catch (e: any) {
      setErr(e?.message || "저장 실패");
    } finally {
      setSaving(false);
    }
  }, [chatId, summary, load]);

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chatId]);

  useEffect(() => {
    // 새 턴이 들어올 때마다 메타/요약을 다시 확인
    if (turnKey == null) return;
    load();
  }, [turnKey, load]);

  // 다운로드는 필요해지면 나중에 추가 (지금은 요약.txt 편집/저장에 집중)

  const wrapStyle = {
    border: `1px solid ${THEME.border}`,
    background: THEME.panel2,
    borderRadius: 16,
    padding: 14,
  } as const;

  return (
    <div style={wrapStyle}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
        <div>
          <div style={{ fontWeight: 900 }}>요약.txt</div>
          <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>{metaLine}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            type="button"
            onClick={doRefresh}
            disabled={refreshing}
            style={{
              height: 34,
              padding: "0 12px",
              borderRadius: 12,
              border: "none",
              background: "#4f46e5",
              color: "#fff",
              fontWeight: 900,
              cursor: "pointer",
              opacity: refreshing ? 0.6 : 1,
            }}
            title="요약 블록 생성/갱신"
          >
            {refreshing ? "갱신…" : "갱신"}
          </button>
          <button
            type="button"
            onClick={doSave}
            disabled={saving || loading || refreshing || !dirty}
            style={{
              height: 34,
              padding: "0 12px",
              borderRadius: 12,
              border: `1px solid ${THEME.borderSoft}`,
              background: THEME.panel,
              color: THEME.text,
              fontWeight: 800,
              cursor: "pointer",
              opacity: saving || loading || refreshing || !dirty ? 0.6 : 1,
            }}
            title={dirty ? "서버에 저장" : "변경사항 없음"}
          >
            {saving ? "저장…" : "저장"}
          </button>
        </div>
      </div>

      {err ? (
        <div style={{ marginTop: 10, padding: 10, borderRadius: 12, border: `1px solid ${THEME.borderSoft}`, background: "rgba(239,68,68,0.10)", color: "#fecaca", fontSize: 13 }}>
          {err}
        </div>
      ) : null}

      <textarea
        value={summary}
        onChange={(e) => {
          setSummary(e.target.value);
          setDirty(true);
        }}
        placeholder={loading ? "로딩 중…" : "아직 요약이 없습니다."}
        rows={embed ? 16 : 20}
        style={{
          width: "100%",
          marginTop: 12,
          padding: 12,
          borderRadius: 12,
          border: `1px solid ${THEME.borderSoft}`,
          background: THEME.panel,
          color: THEME.text,
          outline: "none",
          resize: "vertical",
          fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
          lineHeight: 1.55,
          whiteSpace: "pre-wrap",
        }}
      />

      <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, fontSize: 12, opacity: 0.75 }}>
        <div>{summary.length} chars</div>
        <div style={{ opacity: 0.6 }}>
          {embed ? "" : dirty ? "※ 저장 버튼을 눌러야 반영됩니다." : "※ 이 텍스트가 장기기억(요약)으로 프롬프트에 들어갑니다."}
        </div>
      </div>
    </div>
  );
}
