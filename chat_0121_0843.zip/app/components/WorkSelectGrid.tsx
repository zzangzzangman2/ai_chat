"use client";

import React, { useMemo } from "react";
import { BookOpen } from "lucide-react";

type Preset = {
  id: string;
  name: string;
  characterName?: string;
  background?: string;
  desc?: string;
  image?: string;
  gallery?: string;
  tags?: string;
  target?: string;
  // 1이면 성인(NSFW) 콘텐츠
  isNsfw?: 0 | 1;
};

function safeString(v: any) {
  return typeof v === "string" ? v : "";
}

function compactTitle(t: string) {
  return String(t || "").trim();
}

function clampText(t: string, max = 120) {
  const s = String(t || "").replace(/\s+/g, " ").trim();
  if (!s) return "";
  if (s.length <= max) return s;
  return s.slice(0, max - 1) + "…";
}

const FALLBACK_THUMB =
  "data:image/svg+xml;charset=utf-8," +
  encodeURIComponent(`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450" viewBox="0 0 800 450">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#1b1b24"/>
      <stop offset="1" stop-color="#0b0b0f"/>
    </linearGradient>
  </defs>
  <rect width="800" height="450" fill="url(#g)"/>
  <circle cx="640" cy="120" r="110" fill="rgba(255,255,255,0.06)"/>
  <circle cx="160" cy="340" r="160" fill="rgba(255,255,255,0.04)"/>
  <g fill="rgba(255,255,255,0.14)">
    <path d="M370 166c0-16 13-30 30-30h142c16 0 30 14 30 30v118c0 16-14 30-30 30H400c-17 0-30-14-30-30V166zm38 22h126c6 0 10 4 10 10v54l-20-18c-4-3-9-3-13 0l-30 26-24-18c-4-3-10-3-14 1l-35 33v-78c0-6 4-10 10-10z"/>
  </g>
  <text x="40" y="410" font-family="system-ui,-apple-system,Segoe UI,Roboto" font-size="18" fill="rgba(255,255,255,0.38)">No Cover</text>
</svg>`);

function pickThumb(p: Preset) {
  const img = safeString((p as any).image).trim();
  if (img) return img;
  const rawGallery = safeString((p as any).gallery).trim();
  if (rawGallery) {
    try {
      const parsed = JSON.parse(rawGallery);
      if (Array.isArray(parsed)) {
        const first = parsed[0];
        if (typeof first === "string" && first.trim()) return first.trim();
        if (first && typeof first === "object") {
          const u = safeString((first as any).url || (first as any).src || (first as any).image).trim();
          if (u) return u;
        }
      }
    } catch {
      // ignore
    }
  }
  return FALLBACK_THUMB;
}

function pickDesc(p: Preset) {
  const d = safeString((p as any).desc).trim();
  if (d) return d;
  const bg = safeString((p as any).background).trim();
  if (bg) return bg;
  const tags = safeString((p as any).tags).trim();
  if (tags) return tags;
  const target = safeString((p as any).target).trim();
  return target;
}

function WorkSelectLogo() {
  return (
    <div
      aria-hidden
      style={{
        width: 26,
        height: 26,
        borderRadius: 10,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(255,255,255,0.06)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
      }}
    >
      <BookOpen size={16} style={{ opacity: 0.92 }} />
    </div>
  );
}

export default function WorkSelectGrid(props: {
  presets: Preset[];
  selectedPresetId: string | null;
  onSelect: (presetId: string) => void;
}) {
  const items = useMemo(() => props.presets || [], [props.presets]);

  // iOS/모바일에서 hover(가짜 hover)로 카드가 튀는 문제를 피하기 위해
  // 실제 hover 가능한 환경에서만 마우스 hover 애니메이션을 적용.
  const canHover = useMemo(() => {
    if (typeof window === "undefined") return false;
    try {
      return !!window.matchMedia && window.matchMedia("(hover: hover)").matches;
    } catch {
      return false;
    }
  }, []);

  return (
    <div
      style={{
        border: "1px solid rgba(255,255,255,0.10)",
        background: "rgba(255,255,255,0.04)",
        borderRadius: 18,
        padding: 16,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, fontWeight: 900, marginBottom: 12, fontSize: 16 }}><WorkSelectLogo />작품 선택</div>

      {items.length === 0 ? (
        <div style={{ opacity: 0.8 }}>프리셋이 없습니다.</div>
      ) : (
        <>
          <style jsx>{`
            .grid4 {
              display: grid;
              grid-template-columns: repeat(4, minmax(0, 1fr));
              gap: 12px;

              /*
                목표:
                - 썸네일은 "안 잘리고(=contain)" 보이게
                - 하지만 카드 안이 허전하지 않게 "꽉 차 보이게"
                - blur는 쓰지 않기

                그래서:
                - 썸네일 영역은 1:1(정사각)로 고정해 카드 높이를 줄이고
                - 배경은 같은 이미지를 cover로 깔아(blur 없이) 빈 공간을 자연스럽게 채우고
                - 전경은 contain으로 원본 전체를 보여줍니다.
              */
              --thumb-ar: 1 / 1;
              --card-pad: 12px;
            }

            @media (max-width: 1100px) {
              .grid4 {
                grid-template-columns: repeat(2, minmax(0, 1fr));
              }
            }

            /* 모바일 1차: 1열 고정은 너무 길어져서 2열로, 썸네일도 가로형으로 */
            @media (max-width: 640px) {
              .grid4 {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                --thumb-ar: 1 / 1;
                --card-pad: 10px;
              }

              .workTitle {
                font-size: 13px;
              }

              .workDesc {
                font-size: 12px;
              }
            }

            @media (max-width: 420px) {
              .grid4 {
                grid-template-columns: repeat(1, minmax(0, 1fr));
              }
            }
          `}</style>

          <div className="grid4">
            {items.map((p) => {
              const thumb = pickThumb(p);
              const title = compactTitle(p.name);
              const desc = clampText(pickDesc(p) || "", 140);
              const active = props.selectedPresetId === p.id;

              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => props.onSelect(p.id)}
                  style={{
                    textAlign: "left",
                    border: active ? "1px solid rgba(255,255,255,0.22)" : "1px solid rgba(255,255,255,0.10)",
                    background: active ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.03)",
                    color: "#e9eefc",
                    borderRadius: 18,
                    overflow: "hidden",
                    cursor: "pointer",
                    padding: 0,
                    boxShadow: active ? "0 0 0 1px rgba(255,255,255,0.06), 0 10px 24px rgba(0,0,0,0.35)" : "none",
                    transition: "transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease",
                    touchAction: "manipulation",
                  }}
                  onMouseEnter={(e) => {
                    if (!canHover) return;
                    (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-2px)";
                  }}
                  onMouseLeave={(e) => {
                    if (!canHover) return;
                    (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0px)";
                  }}
                >
                  <div
                    style={{
                      width: "100%",
                      /* CSS 변수로 모바일에서 가로형(16:9)으로 바꿔서 전체 길이를 줄임 */
                      aspectRatio: "var(--thumb-ar)",
                      background: "linear-gradient(135deg, rgba(255,255,255,0.05), rgba(0,0,0,0.0))",
                      borderBottom: "1px solid rgba(255,255,255,0.08)",
                      position: "relative",
                    }}
                  >
                    {(p as any).isNsfw ? (
                      <div
                        style={{
                          position: "absolute",
                          right: 10,
                          top: 10,
                          zIndex: 2,
                          fontSize: 12,
                          fontWeight: 900,
                          letterSpacing: "-0.2px",
                          padding: "5px 9px",
                          borderRadius: 999,
                          border: "1px solid rgba(255,255,255,0.14)",
                          background: "rgba(0,0,0,0.55)",
                          // 더 '빨간' 느낌으로 (요청)
                          color: "#ff4d4f",
                          backdropFilter: "blur(6px)",
                        }}
                        title="성인 콘텐츠"
                      >
                        19+
                      </div>
                    ) : null}
                    {/*
                      썸네일이 카드 가로/세로비와 다를 때 cover로 자르면 중요한 영역이 잘리는 경우가 많아서
                      - 배경: 같은 이미지를 cover로 깔아(blur 없이) 빈 공간 채우기
                      - 전경: contain(원본 전체 보이기)
                      로 렌더링합니다.
                    */}
                    <div
                      aria-hidden
                      style={{
                        position: "absolute",
                        inset: 0,
                        // url(...) 안에서 특수문자/괄호/따옴표가 깨지지 않도록 JSON.stringify로 감싸줌
                        backgroundImage: `url(${JSON.stringify(thumb)})`,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        // blur 없이도 빈 공간이 허전하지 않게: 살짝 어둡게/선명하게만 처리
                        filter: "saturate(1.06) contrast(1.06) brightness(0.78)",
                        transform: "scale(1.02)",
                        opacity: 0.72,
                        pointerEvents: "none",
                      }}
                    />
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={thumb}
                      alt={title}
                      loading="lazy"
                      style={{
                        position: "absolute",
                        inset: 0,
                        width: "100%",
                        height: "100%",
                        // 잘리지 않게 원본 전체를 보여주기
                        objectFit: "contain",
                        objectPosition: "center",
                        display: "block",
                        // 밝은 배경(특히 SVG/흰 배경)도 카드에 자연스럽게 붙게
                        background: "rgba(0,0,0,0.18)",
                      }}
                    />
                  </div>

                  <div style={{ padding: "var(--card-pad)" }}>
                    <div className="workTitle" style={{ fontWeight: 900, fontSize: 14, lineHeight: 1.25, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {title || "(제목 없음)"}
                    </div>
                    <div
                      className="workDesc"
                      style={{
                        marginTop: 6,
                        fontSize: 12,
                        opacity: 0.78,
                        lineHeight: 1.35,
                        display: "-webkit-box",
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: "vertical",
                        overflow: "hidden",
                      }}
                    >
                      {desc || "설명이 없습니다."}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
