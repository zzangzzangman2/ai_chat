import type { ChatTheme, RenderInline } from "./renderNovel";

export function renderMarkdownLiteNode(
  text: string,
  ctx: { theme: ChatTheme; renderInline: RenderInline; showImages: boolean }
): React.ReactNode {
  const CHAT_THEME = ctx.theme;
  const renderInline = ctx.renderInline;
  const showImages = !!ctx.showImages;

    const t = String(text || "");
    if (!t) return null;

    // (HTML) 아주 제한적으로 "sim-card" 안내 박스를 지원한다.
    // - 워크스페이스/가이드 문구를 HTML table 형태로 그대로 붙여넣는 경우가 있어,
    //   XSS 위험을 최소화하기 위해 <b>/<br>만 허용하고 나머지 태그/속성은 제거한다.
    const tryExtractSimCard = (html: string) => {
      const raw = String(html || "");
      if (!/(<table[\s>][\s\S]*?<\/table>)/i.test(raw)) return null;
	      if (!/class\s*=\s*["'“”][^"'“”]*\bsim-card\b/i.test(raw)) return null;

      const th = raw.match(/<th[^>]*>([\s\S]*?)<\/th>/i);
      const tds = [...raw.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map((m) => String(m[1] || ""));
      if (!th || tds.length < 2) return null;

      const stripToText = (s: string) =>
        String(s || "")
          .replace(/<br\s*\/?>/gi, "\n")
          .replace(/<[^>]+>/g, "")
          .replace(/\s+$/g, "")
          .trim();

      const sanitizeInlineHtml = (s: string) => {
        // 1) 위험 태그 블록 제거
        let x = String(s || "");
        x = x.replace(/<\s*(script|style|iframe|object|embed)[\s\S]*?<\/\s*\1\s*>/gi, "");
        // 2) 허용 태그 외 제거 (b/strong/br만)
        x = x.replace(/<(?!\/?(?:b|strong|br)\b)[^>]*>/gi, "");
        // 3) 허용 태그의 속성 제거
        x = x.replace(/<\s*(b|strong)(?:\s+[^>]*)?>/gi, "<$1>");
        x = x.replace(/<\s*br(?:\s+[^>]*)?\s*\/?>/gi, "<br>");
        return x.trim();
      };

      const title = stripToText(th[1]);
      const descHtml = sanitizeInlineHtml(tds[0]);
      const recHtml = sanitizeInlineHtml(tds[1]);
      if (!title || !descHtml || !recHtml) return null;
      return { title, descHtml, recHtml };
    };

    type Block =
      | { type: "text"; value: string }
      | { type: "code"; lang: string; value: string }
      | { type: "img"; url: string; alt: string };

    const blocks: Block[] = [];

    // 1) 코드블록 분리 (```lang ... ```)
    const codeRe = /```([^\n`]*)\n([\s\S]*?)```/g;
    let last = 0;
    let m: RegExpExecArray | null;
    while ((m = codeRe.exec(t))) {
      const start = m.index;
      const end = codeRe.lastIndex;
      if (start > last) blocks.push({ type: "text", value: t.slice(last, start) });
	      const lang = String(m[1] || "").trim().toLowerCase();
	      const value = String(m[2] || "").replace(/\r\n/g, "\n").trimEnd();
	      // NOTE: 워크스페이스 안내 박스를 코드펜스로 감싸서 붙여넣는 경우가 있어,
	      //       sim-card HTML이면 코드블록으로 취급하지 않고 텍스트로 내려서 렌더링(=카드 변환)되게 한다.
	      const parsedSim = tryExtractSimCard(value);
	      if (parsedSim) blocks.push({ type: "text", value });
	      else blocks.push({ type: "code", lang, value });
      last = end;
    }
    if (last < t.length) blocks.push({ type: "text", value: t.slice(last) });

    // 1.5) 텍스트 블록 내부에서 <table class="sim-card">...</table> 를 별도 블록으로 분리
    // - 일반 HTML은 렌더하지 않고, sim-card만 "카드" UI로 변환한다.
    type SimCardBlock = { type: "simcard"; title: string; descHtml: string; recHtml: string };
    const blocks2: Array<Block | SimCardBlock> = [];
    const simTableRe = /(<table[\s\S]*?<\/table>)/gi;
    for (const b of blocks) {
      if (b.type !== "text") {
        blocks2.push(b);
        continue;
      }
      const s = String(b.value || "");
      let p = 0;
      let m2: RegExpExecArray | null;
      while ((m2 = simTableRe.exec(s))) {
        const a = m2.index;
        const z = simTableRe.lastIndex;
        if (a > p) blocks2.push({ type: "text", value: s.slice(p, a) });
        const html = String(m2[1] || "");
        const parsed = tryExtractSimCard(html);
        if (parsed) blocks2.push({ type: "simcard", ...parsed });
        else blocks2.push({ type: "text", value: html });
        p = z;
      }
      if (p < s.length) blocks2.push({ type: "text", value: s.slice(p) });
    }

    // 2) 텍스트 블록 내부에서 마크다운 이미지(![](...))만 추가 분리
    const out: Array<Block | SimCardBlock> = [];
    const imgRe = /!\[([^\]]*)\]\(([^)\s]+)\)/g;
    for (const b of blocks2) {
      if (b.type !== "text") {
        out.push(b);
        continue;
      }
      const s = b.value;
      let p = 0;
      let im: RegExpExecArray | null;
      while ((im = imgRe.exec(s))) {
        const a = im.index;
        const z = imgRe.lastIndex;
        if (a > p) out.push({ type: "text", value: s.slice(p, a) });
        const alt = String(im[1] || "");
        const url = String(im[2] || "");
        out.push({ type: "img", url, alt });
        p = z;
      }
      if (p < s.length) out.push({ type: "text", value: s.slice(p) });
    }

    const renderTextBlock = (value: string, key: string) => {
      let lines = String(value || "").replace(/\r\n/g, "\n").split("\n");
      if (!showImages) {
        const imgLineRe = /^\s*"?(?:https?:\/\/|\/\/)[^\s"]+\.(?:png|jpe?g|gif|webp)(?:\?[^\s"]*)?"?\s*$/i;
        lines = lines.filter((ln) => !imgLineRe.test(String(ln || "")));
      }
      return (
        <div key={key} style={{ display: "flex", flexDirection: "column", gap: 6, whiteSpace: "pre-wrap" }}>
	      	  {lines.map((line, idx) => {
	      	    const raw = String(line || "");
	      	    const trimmed = raw.trim();
	      	    if (!trimmed) return <div key={idx} style={{ height: 4 }} />;
	      	    // Hide stray standalone separator lines (often appears right before an image)
	      	    if (/^[=＝]+$/.test(trimmed)) return <div key={idx} style={{ height: 4 }} />;
	      	    const t2 = raw.trimEnd();
	      	    return (
	      	      <div key={idx} style={{ lineHeight: 1.6 }}>
	      	        <span style={{ color: CHAT_THEME.speech }}>{renderInline(t2)}</span>
	      	      </div>
	      	    );
	      	  })}
        </div>
      );
    };

    const renderCodeBlock = (lang: string, value: string, key: string) => {
      // (요구) 가로 스크롤(옆으로 밀림) 대신 줄바꿈으로 보이게
      // - status 블록이 특히 길어지므로 pre-wrap + break-word 강제
      return (
        <pre
          key={key}
          style={{
            margin: 0,
            padding: 14,
            borderRadius: 12,
            background: "rgba(255,255,255,0.06)",
            border: "none",
            color: CHAT_THEME.text,
            fontFamily:
              "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
            fontSize: 13,
            lineHeight: 1.55,
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            overflowX: "hidden",
          }}
        >
          {value}
        </pre>
      );
    };

    const renderImageBlock = (url: string, alt: string, key: string) => {
      if (!showImages) return null;
      const safeUrl = String(url || "");
      return (
        <div key={key} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={safeUrl}
            alt={alt || ""}
            style={{
              maxWidth: "100%",
              height: "auto",
              borderRadius: 14,
              border: "none",
              background: "rgba(255,255,255,0.02)",
            }}
          />
        </div>
      );
    };

    const renderSimCardBlock = (b: SimCardBlock, key: string) => {
      return (
        <div
          key={key}
          style={{
            border: "1px solid rgba(255,255,255,0.18)",
            borderRadius: 12,
            overflow: "hidden",
            background: "rgba(255,255,255,0.04)",
          }}
        >
          <div
            style={{
              padding: "12px 14px",
              textAlign: "center",
              fontWeight: 800,
              borderBottom: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(0,0,0,0.18)",
              color: CHAT_THEME.text,
            }}
          >
            {b.title}
          </div>
          <div
            style={{
              padding: "14px 16px",
              textAlign: "center",
              lineHeight: 1.65,
              color: CHAT_THEME.text,
              whiteSpace: "normal",
            }}
            dangerouslySetInnerHTML={{ __html: b.descHtml }}
          />
          <div
            style={{
              padding: "12px 16px",
              textAlign: "center",
              fontWeight: 800,
              borderTop: "1px solid rgba(255,255,255,0.14)",
              color: CHAT_THEME.text,
              whiteSpace: "normal",
            }}
            dangerouslySetInnerHTML={{ __html: b.recHtml }}
          />
        </div>
      );
    };

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {out.map((b, i) => {
          if (b.type === "code") return renderCodeBlock(b.lang, b.value, `md-code-${i}`);
          if (b.type === "img") return renderImageBlock(b.url, b.alt, `md-img-${i}`);
          if (b.type === "simcard") return renderSimCardBlock(b, `md-sim-${i}`);
          return renderTextBlock(b.value, `md-txt-${i}`);
        })}
      </div>
    );
}
