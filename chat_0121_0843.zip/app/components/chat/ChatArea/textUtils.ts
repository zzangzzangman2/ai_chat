// 스트리밍 중에도 [END]가 UI에 잠깐이라도 노출되지 않게 클라이언트에서도 제거
export function stripEndMarkerClient(t: string): string {
  return String(t || "")
    .replace(/\n?\[END\]\s*$/i, "")
    .replace(/\n?<END>\s*$/i, "")
    .trimEnd();
}

// Server-side postprocessing treats any text after a final meta fence as garbage.
// To avoid "stream showed it, then it vanished" mismatches and to keep UI consistent with DB,
// apply the same rule on the client.
export function stripTrailingTextAfterFinalMetaFenceClient(t: string): string {
  const s = String(t || "");
  const lastClose = s.lastIndexOf("```");
  if (lastClose < 0) return s;

  const before = s.slice(0, lastClose);
  const lastOpen = before.lastIndexOf("```");
  if (lastOpen < 0) return s;

  const lineEnd = s.indexOf("\n", lastOpen + 3);
  const openLine = (lineEnd >= 0 ? s.slice(lastOpen, lineEnd) : s.slice(lastOpen)).trim();
  const label = openLine.slice(3).trim().toUpperCase();
  const isMetaFence = label.startsWith("STATUS") || label.startsWith("INFO");
  if (!isMetaFence) return s;

  const after = s.slice(lastClose + 3);
  if (after.trim().length === 0) return s;
  return s.slice(0, lastClose + 3).trimEnd();
}
