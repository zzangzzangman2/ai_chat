import { NextResponse } from "next/server";

import { db } from "@/lib/db";
import { decryptIfPossible, encryptIfPossible } from "@/lib/crypto";
import { summarizeLongMemorySectionKorean } from "@/lib/ai";
import { LONG_MEMORY_SUMMARY_RULES, stripUrlsAndMediaMarkdown } from "@/lib/memory_sanitize";

import { bad, requireChatAccess } from "@/app/api/memory/_util";

import { selectRecentByUserTurns } from "@/app/api/chat/send/_server/textPolicy";
import {
  selectMessagesForAssistantTurnRange,
  selectMessagesForAssistantTurnRangeCapped,
} from "@/app/api/chat/send/_server/turnRange";
import {
  getSummarizedEndTurn,
  hasRangeBlock,
  normalizeStoredMemorySummary,
  strlenSummary,
} from "@/app/api/chat/send/_server/summaryStored";
import {
  normalizeSummaryTail,
  sanitizeLongMemorySummary,
  upsertSummaryRangeBlock,
} from "@/app/api/chat/send/_server/memory";

function clampInt(v: unknown, min: number, max: number, fallback: number) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.trunc(n)));
}

function countAssistantTurns(all: Array<{ role: string }>) {
  const firstUserPos = all.findIndex((m) => m.role === "user");
  if (firstUserPos < 0) return 0;
  let turns = 0;
  for (let i = firstUserPos; i < all.length; i++) {
    // DB에는 assistant가 "assistant" 또는 "model"로 저장될 수 있다.
    // (turnRange 셀렉터와 일치시키지 않으면 completedTurnCount=0으로 고정되어
    // boundaryEndTurn이 0이 되어 요약이 영원히 생성되지 않는 문제가 생긴다.)
    if (all[i].role === "assistant" || all[i].role === "model") turns++;
  }
  return turns;
}

function formatTurnsLocal(turns: Array<{ role: string; content: string }>) {
  return turns
    .map((m) => {
      const tag = m.role === "user" ? "[사용자]" : "[어시스턴트]";
      return `${tag} ${m.content}`;
    })
    .join("\n\n");
}

// B-mode (요약.txt): fixed policy
const SUMMARY_EVERY_ASSISTANT_TURNS = 3; // 3 assistant turns per window
const SUMMARY_PER_TURN_CHARS = 80; // max 80 chars per assistant turn
const KEEP_USER_TURNS = 7; // exclude last 7 user turns from summarization input

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => null)) as any;
    const chatId = String(body?.chatId || "").trim();
    if (!chatId) return bad("chatId가 필요합니다.");

    const access = await requireChatAccess(chatId);
    if (!access.ok) return access.res;

    // settings (model + token budgets)
    const st = db
      .prepare(
        `SELECT model, maxOutputTokens, maxReasoningTokens, thinkingBudget, personaName
         FROM chat_settings WHERE chatId=?`
      )
      .get(chatId) as any;

    const runtime = (body?.runtime ?? {}) as any;
    const summaryEveryVal = SUMMARY_EVERY_ASSISTANT_TURNS; // must match /api/chat/send shouldRefresh logic
    const keepUserTurnsVal = KEEP_USER_TURNS;
    const perTurnCharsVal = SUMMARY_PER_TURN_CHARS;

    // load & decrypt all messages
    const rawAll = db
      .prepare(
        `SELECT id, chatId, role, content, imagesJson, createdAt, updatedAt
         FROM messages WHERE chatId=? ORDER BY createdAt ASC, id ASC`
      )
      .all(chatId) as any[];

    const all = rawAll.map((m) => ({
      ...m,
      content: decryptIfPossible(m.content),
      imagesJson: decryptIfPossible(m.imagesJson),
    }));

    const completedTurnCount = countAssistantTurns(all);

    // Only summarize complete blocks.
    const boundaryEndTurn = Math.floor(completedTurnCount / summaryEveryVal) * summaryEveryVal;
    if (boundaryEndTurn <= 0) {
      return NextResponse.json({ ok: true, skipped: true, reason: "no_complete_block" });
    }

    // current cached summary
    const cache = db
      .prepare(
        `SELECT recentSummary, summarizedEndTurn, rolledUpCount, lastSummarizedAt
         FROM chat_memory_cache WHERE chatId=?`
      )
      .get(chatId) as any;

    let recentSummary = decryptIfPossible(String(cache?.recentSummary || ""));
    recentSummary = normalizeStoredMemorySummary(recentSummary, summaryEveryVal);

    const summarizedEndTurnDb = Math.max(0, Number(cache?.summarizedEndTurn || 0));
    const summarizedEndTurn = Math.max(summarizedEndTurnDb, getSummarizedEndTurn(recentSummary));

    // If cache already covers this boundary, skip.
    if (summarizedEndTurn >= boundaryEndTurn) {
      return NextResponse.json({
        ok: true,
        skipped: true,
        reason: "uptodate",
        summarizedEndTurn,
        boundaryEndTurn,
      });
    }

    // Next window to summarize (always aligned to summaryEveryVal)
    const windowStartTurn = Math.max(1, summarizedEndTurn + 1);
    const windowEndTurn = Math.min(windowStartTurn + summaryEveryVal - 1, boundaryEndTurn);

    // Guard: do not generate partial windows
    if (windowEndTurn !== windowStartTurn + summaryEveryVal - 1) {
      return NextResponse.json({
        ok: true,
        skipped: true,
        reason: "partial_window_not_allowed",
        windowStartTurn,
        windowEndTurn,
        boundaryEndTurn,
      });
    }

    // If this window already exists, also skip.
    if (hasRangeBlock(recentSummary, windowStartTurn, windowEndTurn)) {
      db.prepare(
        `UPDATE chat_memory_cache
         SET summarizedEndTurn=?, updatedAt=?
         WHERE chatId=?`
      ).run(windowEndTurn, Date.now(), chatId);

      return NextResponse.json({
        ok: true,
        skipped: true,
        reason: "range_block_exists",
        windowStartTurn,
        windowEndTurn,
      });
    }

    // Exclude tail (last K user turns) to reduce overlap with recent raw context.
    const tail = selectRecentByUserTurns(all, keepUserTurnsVal);
    // NOTE: 대화가 짧거나(또는 K가 큰 경우) tail이 전체를 다 먹어 capIndex=0이 되면
    // capped selector가 항상 []가 되어 요약이 '영원히' 생성되지 않는 문제가 있었다.
    // 이런 경우에는 중복을 감수하고 uncapped로 fallback한다.
    let capIndex = Math.max(0, all.length - tail.length);
    if (capIndex <= 0) capIndex = all.length;

    let rangeTurns = selectMessagesForAssistantTurnRangeCapped(all, windowStartTurn, windowEndTurn, capIndex);
    if (!rangeTurns.length) {
      rangeTurns = selectMessagesForAssistantTurnRange(all, windowStartTurn, windowEndTurn);
    }
    if (!rangeTurns.length) {
      return NextResponse.json({
        ok: true,
        skipped: true,
        reason: "empty_range_turns",
        windowStartTurn,
        windowEndTurn,
        capIndex,
      });
    }

    const rawText = formatTurnsLocal(rangeTurns);
    const cleanedText = stripUrlsAndMediaMarkdown(rawText);

    const llmOpts = {
      model: String(runtime?.model || st?.model || "gemini-3-flash-preview"),
      maxOutputTokens: clampInt(runtime?.maxOutputTokens ?? st?.maxOutputTokens, 256, 8192, 2048),
      maxReasoningTokens: clampInt(runtime?.maxReasoningTokens ?? st?.maxReasoningTokens, 0, 8192, 0),
      thinkingBudget: clampInt(runtime?.thinkingBudget ?? st?.thinkingBudget, 0, 8192, 0),
    };

    // Generate a single section: "### <title> (a-b턴)\n<body>"
    const targetChars = Math.min(100000, Math.max(80, perTurnCharsVal * summaryEveryVal));
    const sectionRaw = await summarizeLongMemorySectionKorean({
      text: cleanedText,
      startTurn: windowStartTurn,
      endTurn: windowEndTurn,
      targetChars,
      guidance: LONG_MEMORY_SUMMARY_RULES,
      personaName: String(st?.personaName || "").trim(),
      opts: llmOpts,
    });

    // Clean & upsert
    const sectionClean = normalizeSummaryTail(
      stripUrlsAndMediaMarkdown(String(sectionRaw || ""), { keepHeadings: true })
    );

    let nextSummary = upsertSummaryRangeBlock(recentSummary, sectionClean, windowStartTurn, windowEndTurn);
    nextSummary = sanitizeLongMemorySummary(normalizeSummaryTail(nextSummary), summaryEveryVal);

    const nextEndTurn = Math.max(windowEndTurn, getSummarizedEndTurn(nextSummary));

    // Persist
    const now = Date.now();
    const recentSummaryChars = strlenSummary(nextSummary);

    db.prepare(
      `INSERT INTO chat_memory_cache (chatId, recentSummary, summarizedEndTurn, rolledUpCount, lastSummarizedAt, updatedAt, recentSummaryChars)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(chatId) DO UPDATE SET
         recentSummary=excluded.recentSummary,
         summarizedEndTurn=excluded.summarizedEndTurn,
         rolledUpCount=excluded.rolledUpCount,
         lastSummarizedAt=excluded.lastSummarizedAt,
         updatedAt=excluded.updatedAt,
         recentSummaryChars=excluded.recentSummaryChars`
    ).run(
      chatId,
      encryptIfPossible(nextSummary),
      nextEndTurn,
      Math.max(0, Number(cache?.rolledUpCount || 0)),
      now,
      now,
      recentSummaryChars
    );

    const morePending = nextEndTurn < boundaryEndTurn;

    return NextResponse.json({
      ok: true,
      refreshed: true,
      windowStartTurn,
      windowEndTurn,
      summarizedEndTurn: nextEndTurn,
      boundaryEndTurn,
      morePending,
      policy: {
        summaryEvery: summaryEveryVal,
        perTurnChars: perTurnCharsVal,
        keepUserTurns: keepUserTurnsVal,
        targetChars,
      },
    });
  } catch (e: any) {
    console.error("/api/chat/memory/refresh error", e);
    return bad(e?.message || "refresh_failed", 500);
  }
}
