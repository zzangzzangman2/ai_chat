import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import crypto from "crypto";
import { callOpenRouter } from "@/lib/openrouter";

export async function POST(req: Request) {
  const body = await req.json();
  const presetId = String(body.presetId || "");
  const chatId = String(body.chatId || "");
  const userText = String(body.userText || "");

  if (!presetId) return NextResponse.json({ error: "presetId required" }, { status: 400 });
  if (!userText.trim()) return NextResponse.json({ error: "userText required" }, { status: 400 });

  const preset = db.prepare("SELECT * FROM presets WHERE id=?").get(presetId);
  if (!preset) return NextResponse.json({ error: "preset not found" }, { status: 404 });

  // 채팅방 생성/가져오기
  let finalChatId = chatId;
  if (!finalChatId) {
    finalChatId = crypto.randomUUID();
    db.prepare(`INSERT INTO chats (id, presetId, title, createdAt) VALUES (?, ?, ?, ?)`).
      run(finalChatId, presetId, null, Date.now());
  }

  // 유저 메시지 저장
  db.prepare(
    `INSERT INTO messages (id, chatId, role, content, createdAt) VALUES (?, ?, ?, ?, ?)`
  ).run(crypto.randomUUID(), finalChatId, "user", userText, Date.now());

  // 최근 메시지 몇 개 로드
  const history = db.prepare(
    `SELECT role, content FROM messages WHERE chatId=? ORDER BY createdAt ASC`
  ).all(finalChatId) as { role: "user" | "assistant"; content: string }[];

  // 시스템 프롬프트 구성: (배경 + 캐릭터 + systemPrompt)
  const system = [
    preset.systemPrompt,
    preset.background ? `\n[배경]\n${preset.background}` : "",
    preset.character ? `\n[캐릭터]\n${preset.character}` : "",
  ].filter(Boolean).join("\n")
    + "\n\n[출력 금지]\n"
    + "- 응답 맨앞에 작품 제목/부제/태그(예: \"... : ... |\") 같은 헤더 라인을 출력하지 마.\n"
    + "- 본문은 바로 장면(지문/대사/속마음)부터 시작.\n"
    + "- | 문자를 이용한 헤더/구분선 출력 금지.\n";

  const messages = [
    { role: "system" as const, content: system },
    ...history.map(m => ({ role: m.role, content: m.content })),
  ];

  // 모델 호출
  const assistantText = await callOpenRouter({ messages });

  // 어시스턴트 저장
  db.prepare(
    `INSERT INTO messages (id, chatId, role, content, createdAt) VALUES (?, ?, ?, ?, ?)`
  ).run(crypto.randomUUID(), finalChatId, "assistant", assistantText, Date.now());

  return NextResponse.json({ chatId: finalChatId, assistantText });
}
