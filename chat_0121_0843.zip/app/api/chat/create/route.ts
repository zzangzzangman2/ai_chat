import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, isAdminEmail } from "@/lib/auth";
import { randomUUID } from "crypto";
import { encryptIfPossible } from "@/lib/crypto";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const { presetId, replaceExisting } = await req.json();

  if (!presetId) {
    return NextResponse.json({ error: "프리셋을 먼저 선택해 주세요." }, { status: 400 });
  }

  // 프리셋 접근 권한
  // - 공개(isPublic=1): 누구나 채팅 생성 가능
  // - 비공개(isPublic=0): 소유자(작성자) 또는 관리자만 가능
  const preset = db
    .prepare(
      `SELECT
        id,
        characterName,
        firstMessages,
        COALESCE(isPublic, 1) AS isPublic,
        COALESCE(NULLIF(userEmail, ''), NULLIF(ownerEmail, ''), '') AS ownerEmail
      FROM presets
      WHERE id=?`
    )
    .get(presetId) as any;

  if (!preset) {
    return NextResponse.json({ error: "선택한 프리셋을 찾지 못했습니다." }, { status: 404 });
  }

  const ownerEmail = String(preset?.ownerEmail || "").trim().toLowerCase();
  const viewerEmail = String(u.email || "").trim().toLowerCase();
  const isOwner = !!ownerEmail && ownerEmail === viewerEmail;
  const isAdmin = isAdminEmail(viewerEmail);
  const isPublic = Number(preset?.isPublic ?? 1) === 1;

  if (!isPublic && !isOwner && !isAdmin) {
    return NextResponse.json({ error: "비공개 작품입니다." }, { status: 403 });
  }

  const chatId = randomUUID();
  const now = Date.now();

  const profile = db
    .prepare(`SELECT personaName, personaAge, personaGender, personaInfo FROM user_profile WHERE id=1`)
    .get() as any;

  // 같은 작품에 여러 채팅을 쌓지 않도록: "새 대화 시작" 시 기존 대화를 삭제
  if (replaceExisting) {
    const oldChats = db.prepare(`SELECT id FROM chats WHERE presetId=? AND userEmail=?`).all(presetId, u.email) as any[];
    for (const c of oldChats) {
      const id = String(c.id);
      db.prepare(`DELETE FROM message_usage WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM messages WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM chat_settings WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM chat_memory_cache WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM chats WHERE id=? AND userEmail=?`).run(id, u.email);
    }
  }

  db.prepare(`INSERT INTO chats (id, userEmail, presetId, title, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
    chatId,
    u.email,
    presetId,
    null,
    now
  );

  // (요구사항)
  // 채팅을 시작할 때, 작업실에서 설정한 "첫 메시지"를 자동으로 출력(assistant 첫 메시지로 저장)한다.
  // - firstMessages는 JSON 배열 문자열이며, 첫 번째 항목을 사용한다.
  // - 저장 시에는 가능한 한 "상대 | \"...\"" 형태로 보정한다.
  try {
    const raw = String(preset?.firstMessages || "[]");
    let arr: any[] = [];
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) arr = parsed;
    } catch {
      arr = [];
    }

    // firstMessages는 작업실에서 JSON.stringify([{ text: "..." }]) 형태로 저장된다.
    // 과거/호환을 위해 string 배열(["..."])도 함께 지원한다.
    const firstEntry = arr?.[0];
    const first = (
      typeof firstEntry === "string"
        ? firstEntry
        : (firstEntry && typeof firstEntry === "object")
          ? String((firstEntry as any).text ?? (firstEntry as any).content ?? "")
          : ""
    ).trim();
    if (first) {
      const npc = String(preset?.characterName || "상대").trim() || "상대";
      const hasPrefix = new RegExp(`^${npc.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\s*\|`).test(first);
      const contentOnly = hasPrefix ? first.replace(/^.+?\s*\|\s*/, "").trim() : first;

      // workspace의 "첫 메시지"는 제작자가 입력한 원문을 그대로 저장한다.
      // - 제작자가 쌍따옴표로 묶지 않은 문장은 지문으로 취급되어야 하므로,
      //   과거처럼 자동으로 `NPC | "..."` wrapper를 덧씌우지 않는다.
      // - 제작자가 원하면 직접 따옴표/화자 접두를 넣을 수 있다.
      const finalText = hasPrefix ? first : contentOnly;

db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt, userEmail) VALUES (?, ?, ?, ?, ?, ?)`).run(
        randomUUID(),
        chatId,
        "assistant",
        encryptIfPossible(finalText),
        now,
        u.email
      );
    }
  } catch {
    // ignore
  }

  // 기본 설정 row 생성 (전역 페르소나 기본값을 복사)
  {
    const personaName = profile?.personaName ?? null;
    const personaAge = profile?.personaAge ?? null;
    const personaGender = profile?.personaGender ?? null;
    const personaInfo = profile?.personaInfo ?? null;

    // 모델/출력/추론 기본값 (chat_settings 스키마 컬럼명에 맞춤)
    const defaultModel = "gemini-2.5-pro";
    const defaultMaxOutputTokens = 1200;
    const defaultMaxReasoningTokens = 384;

    // 장기기억(새 시스템) 기본값
    const defaultMemoryFrom = 7;
    const defaultSummaryEvery = 5;
    const defaultPerTurnChars = 40;
    const defaultNarrationColor = "#CCC7C7";

    db.prepare(
      `INSERT OR IGNORE INTO chat_settings (
        chatId,
        personaName, personaAge, personaGender, personaInfo,
        model, maxOutputTokens, maxReasoningTokens,
        memoryFrom, summaryEvery, summaryLength,
        narrationColor,
        updatedAt
      ) VALUES (
        ?,
        ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?,
        ?
      )`
    ).run(
      chatId,
      personaName, personaAge, personaGender, personaInfo,
      defaultModel, defaultMaxOutputTokens, defaultMaxReasoningTokens,
      defaultMemoryFrom, defaultSummaryEvery, defaultPerTurnChars,
      defaultNarrationColor,
      now
    );
  }

  return NextResponse.json({ chatId });
}
