import { postprocessLongMemorySummary, stripUrlsAndMediaMarkdown } from "@/lib/memory_sanitize";
import { normalizeStoredMemorySummary } from "./summaryStored";

/**
 * Normalizes the tail sentence ending to reduce "cut-off" 느낌.
 * - Leaves heading lines (##/###) unchanged
 */
export function normalizeSummaryTail(summaryText: string): string {
  const t = String(summaryText || "").trimEnd();
  if (!t) return t;

  const lines = t.split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i--) {
    const lnRaw = lines[i];
    const ln = String(lnRaw || "").trim();
    if (!ln) continue;

    // 헤더 라인은 그대로 둔다.
    if (/^#{2,4}\s+/.test(ln)) break;

    // 문장부호로 끝나면 OK
    if (/[.!?…。]$/.test(ln)) break;

    // 한국어 종결형(다/요)로 끝나면 마침표를 보강
    if (/[다요]$/.test(ln)) {
      lines[i] = ln + ".";
      break;
    }

    // 그 외는 가능한 한 완결로 보강한다.
    if (ln.length <= 8) {
      lines.splice(i, 1);
      break;
    }
    if (/[가-힣]/.test(ln)) {
      lines[i] = ln + ".";
      break;
    }

    // 한국어가 거의 없는 경우에는 제거(노이즈)
    lines.splice(i, 1);
    break;
  }

  return lines.join("\n").trimEnd();
}

/**
 * Sanitizes and normalizes the stored long-memory summary.
 *
 * Storage format is "요약.txt" style with a single H2 header and H3 sections.
 * We keep headings in storage, and rely on summaryStored.ts for normalization.
 */
export function sanitizeLongMemorySummary(input: string, summaryEvery: number): string {
  if (!input) return "";

  // 1) Strip URLs/media markdown while preserving headings.
  let s = stripUrlsAndMediaMarkdown(String(input), { keepHeadings: true });

  // 2) Remove common meta/boilerplate + light cleanup + mask sensitive tokens.
  s = postprocessLongMemorySummary(s);

  // 3) Enforce canonical ordering/contiguity.
  s = normalizeStoredMemorySummary(s, summaryEvery);

  return s.trim();
}

function normalizeRangeLabel(st: number, ed: number): string {
  if (st === ed) return `${st}턴`;
  return `${st}-${ed}턴`;
}

function toSection(blockOrBody: string, st: number, ed: number): string {
  const raw = String(blockOrBody || "").replace(/\r\n/g, "\n").trim();
  if (!raw) return "";

  // Already a section header
  if (/^###\s+/.test(raw)) return raw;

  // Legacy: "## 장기 기억 (a-b턴)" block -> convert to a section.
  const legacyHeaderRe = /^##\s*장기\s*기억\s*\(.*\)\s*\n+/;
  const body = raw.replace(legacyHeaderRe, "").trim();
  const rangeLabel = normalizeRangeLabel(st, ed);
  return (`### 요약 (${rangeLabel})\n${body}`.trim());
}

function removeExistingRange(summary: string, st: number, ed: number): string {
  const src = String(summary || "").replace(/\r\n/g, "\n");
  if (!src.trim()) return "";

  const range = normalizeRangeLabel(st, ed);
  // Remove new sections: ### ... (a-b턴)
  const reSection = new RegExp(
    String.raw`(^###\s+[^\n]*\(\s*${range.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")}\s*\)\s*\n[\s\S]*?)(?=^###\s|\s*$)`,
    "m"
  );
  let out = src.replace(reSection, "");

  // Remove legacy blocks: ## 장기 기억 (a-b턴)
  const reLegacy = new RegExp(
    String.raw`(^##\s*장기\s*기억\s*\(\s*${st}\s*[-–~]\s*${ed}\s*턴\s*\)[\s\S]*?)(?=^##\s*장기\s*기억\s*\(|\s*$)`,
    "m"
  );
  out = out.replace(reLegacy, "");

  return out.replace(/\n{4,}/g, "\n\n\n").trim();
}

/**
 * Upsert a single window (st-ed) into the stored long-memory summary.
 *
 * Accepts either:
 * - a new-format section (### ... (a-b턴) ...)
 * - a legacy block (## 장기 기억 (a-b턴) ...)
 * - a plain body
 */
export function upsertSummaryRangeBlock(prev: string, block: string, st: number, ed: number): string {
  const p0 = String(prev || "").trim();
  const section = toSection(block, st, ed);
  if (!section) return p0;

  const cleanedPrev = removeExistingRange(p0, st, ed);
  if (!cleanedPrev) return section;
  return `${cleanedPrev}\n\n${section}`.trim();
}
