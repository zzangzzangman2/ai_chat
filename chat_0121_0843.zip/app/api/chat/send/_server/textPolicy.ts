export function formatTurns(messages: any[]) {
  return messages
    .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
    .join("\n");
}
export function selectRecentByUserTurns(messages: any[], keepUserTurns: number) {
  if (keepUserTurns <= 0) return [];
  const totalUserTurns = messages.reduce((acc, m) => acc + (m.role === "user" ? 1 : 0), 0);
  const startTurn = Math.max(1, totalUserTurns - keepUserTurns + 1);

  const picked: any[] = [];
  let u = 0;
  for (const msg of messages) {
    if (msg.role === "user") u += 1;
    if (u >= startTurn) picked.push(msg);
  }
  return picked;
}

// lastN 메시지는 그대로 전달하고, 그 이전은 요약으로 대체하는 용도
export function formatStoryTurns(messages: any[], personaName: string, npcName: string) {
  return messages
    .map((m) => {
      const who = m.role === "user" ? personaName : npcName;
      // 컨텍스트에는 "이름 |"을 최대한 유지하되,
      // 첫 줄이 인물 이름으로 시작하는 서술(예: "서윤아는...")에는 접두를 붙이지 않는다.
      return ensurePrefix(m.content, who, [personaName, npcName]);
    })
    .join("\n\n");
}

export function ensurePrefix(text: string, who: string, noPrefixIfStartsWithNames?: string[]) {
  // (요구사항)
  // 지문은 이름 접두를 붙이지 않는다. ("서윤아 | *...*" 같은 출력이 UI에서 어색해짐)
  // 또한 모델이 이미 "이름 |" 형식을 썼다면 중복 접두를 붙이지 않는다.
  const raw = String(text || "");
  const lines = raw.split("\n");
  const firstIdx = lines.findIndex((l) => l.trim().length > 0);
  if (firstIdx === -1) return raw.trim();

  const first = lines[firstIdx].trimStart();
  // 1) 첫 줄이 지문이면 접두 없음
  if (first.startsWith("*")) return raw.trim();
  // 1.5) fenced 블록은 접두를 붙이면 파싱/종료(fence close) 로직이 깨질 수 있어 그대로 둔다.
  if (first.startsWith("```") || first.startsWith("~~~")) return raw.trim();
  // 2) 이미 "이름 |" 형태면 그대로
  if (/^.+?\s*\|\s*/.test(first)) return raw.trim();
  // 3) 첫 줄이 특정 이름으로 시작하는 서술이면 접두 없음
  //    (예: "서윤아는..." 같은 서술에 "상대 |"가 붙는 문제 방지)
  const avoid = (noPrefixIfStartsWithNames || []).map((s) => String(s || "").trim()).filter(Boolean);
  if (avoid.length) {
    for (const nm of avoid) {
      if (first.startsWith(nm) && !first.slice(nm.length).trimStart().startsWith("|")) {
        return raw.trim();
      }
    }
  }

  const prefix = `${who} | `;
  lines[firstIdx] = prefix + first;
  return lines.join("\n").trim();
}

export function stripEndMarker(text: string) {
  const t = String(text || "");
  return t
	// Gemini 3 Pro 전용 내부 센티넬 - 히스토리에 남으면 계속 재출력될 수 있어 제거
	.replace(/<<<END_OF_OUTPUT>>>/g, "")
    .replace(new RegExp("\\n?\\[END\\]\\s*$", "i"), "")
    .replace(new RegExp("\\n?<END>\\s*$", "i"), "")
    .trim();
}

// (마크다운 안정화)
// 일부 세션/모델에서 ```STATUS 코드펜스를 열고 닫는 ```를 누락하는 경우가 있다.
// - 닫는 펜스가 누락되면 UI/저장된 로그에서 상태창이 깨지거나(일부 렌더러는 통째로 텍스트 처리),
//   이후 본문까지 코드블록으로 흡수되는 현상이 발생한다.
// - STATUS 창은 사용자 요구사항상 “항상 고정 형식”이므로, 누락 시 서버에서 최소 복구를 수행한다.
export function repairUnclosedStatusFence(text: string): { text: string; repaired: boolean; hadStatus: boolean } {
  const s0 = String(text || "");
  const idx = s0.search(/(^|\n)\s*```\s*STATUS\b/i);
  if (idx < 0) return { text: s0, repaired: false, hadStatus: false };

  const after = s0.slice(idx + 1);
  const hasClose = /(^|\n)\s*```\s*(\n|$)/.test(after);
  if (hasClose) return { text: s0, repaired: false, hadStatus: true };

  const needsNewline = !s0.endsWith("\n");
  const fixed = s0 + (needsNewline ? "\n" : "") + "```";
  return { text: fixed, repaired: true, hadStatus: true };
}

// 일부 모델이 opening fence와 첫 줄을 같은 라인에 붙여 출력하는 케이스 정규화
// 예) ```STATUS [일지0/3] ...  ->  ```STATUS\n[일지0/3] ...
export function normalizeStatusFenceOpen(text: string): { text: string; normalized: boolean } {
  const s0 = String(text || "");
  const s1 = s0.replace(/(^|\n)\s*```\s*STATUS\b\s+([^\n]+)/gi, (_m, p1, rest) => `${p1}\n\`\`\`STATUS\n${rest}`);
  return { text: s1, normalized: s1 !== s0 };
}


/**
 * Label-agnostic fenced-block helpers
 * - normalizeAnyFenceOpen: if an opening fence has trailing content on same line, split into two lines
 * - repairUnclosedAnyFence: if a fence is opened but not closed, close it at the end
 * - wrapLooseMetaAsFence: conservatively wrap likely meta blocks (without fences) into a ```META ... ``` fence
 *
 * NOTE: These are intentionally non-destructive and append-only friendly.
 */

export function normalizeAnyFenceOpen(text: string): string {
  const s0 = String(text || "");
  // Convert CRLF/CR to LF to simplify processing
  const s = s0.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  // If a line starts with ```<label> and also has extra content, split it into two lines.
  return s.replace(/(^|\n)(\s*```[^\s`]+)\s+([^\n]+)/g, (_m, p1, fence, rest) => {
    return `${p1}${fence}\n${rest}`;
  });
}

export function repairUnclosedAnyFence(text: string): string {
  const s0 = String(text || "");
  const s = s0.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = s.split("\n");

  let open = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/^\s*```/.test(line)) {
      open = !open;
    }
  }

  if (open) {
    // Close the fence at end (ensure newline before closing)
    const t = s.endsWith("\n") ? s : s + "\n";
    return t + "```";
  }
  return s;
}

export function wrapLooseMetaAsFence(text: string): { text: string; wrapped: boolean } {
  const s0 = String(text || "");
  const s = s0.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  // If there's already any fence, don't try to wrap; just return.
  if (s.includes("```")) return { text: s, wrapped: false };

  const lines = s.split("\n");
  // Find a likely "meta header" line near the end.
  // This is conservative to avoid wrapping normal prose.
  const metaHeader = /^\s*(?:\[?(?:STATUS|INFO|SUMMARY|META|DEBUG)\]?\s*:|\[?(?:상태|요약|메모)\]?\s*:)\s*/i;

  let startIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (metaHeader.test(lines[i])) startIdx = i;
  }
  if (startIdx < 0) return { text: s, wrapped: false };

  // Only wrap if the header appears in the last ~35% of the text (typical "end-of-response meta")
  const threshold = Math.floor(lines.length * 0.65);
  if (startIdx < threshold) return { text: s, wrapped: false };

  const before = lines.slice(0, startIdx).join("\n");
  const meta = lines.slice(startIdx).join("\n");

  const wrappedText = `${before}${before ? "\n" : ""}` + "```META\n" + meta + "\n```";
  return { text: wrappedText, wrapped: true };
}


// 가끔 지문 줄 앞에 `이름 | ...` 접두가 붙는 케이스 제거
// - RHS가 따옴표("/“/')로 시작하면 대사로 보고 유지
// - 그렇지 않으면 지문으로 보고 `이름 | ` 제거

// --- renderMode helpers (chat vs novel) ---
export function stripInfoBlock(text: string): string {
  const t = String(text || "");
  if (!t.trim()) return t;
  const lines = t.split(/\r?\n/);
  let cut = -1;

  // legacy: explicit INFO header
  const idxInfo = lines.findIndex((ln) => ln.trim() === "INFO");
  if (idxInfo >= 0) cut = idxInfo;

  // emoji style INFO block (📆📌💡❤️ ...)
  const idxEmoji = lines.findIndex((ln) => /^\s*[📆📌💡❤️]/.test(String(ln || "").trim()));
  if (idxEmoji >= 0) cut = cut >= 0 ? Math.min(cut, idxEmoji) : idxEmoji;

  if (cut >= 0) return lines.slice(0, cut).join("\n").trimEnd();
  return t;
}

export function stripSpeakerPrefixLine(line: string): string {
  const s = String(line || "");
  const m = s.match(/^\s*[^|]{1,40}\s*\|\s*(.+)$/);
  return m ? String(m[1] || "") : s;
}

export function ensureQuoted(text: string): string {
  let s = String(text || "").trim();
  if (!s) return '""';
  // if already quoted (straight/smart), keep
  if (s.startsWith("\"") || s.startsWith("“")) {
    if (!(s.endsWith("\"") || s.endsWith("”"))) s = s + "\"";
    return s;
  }
  return `"${s}"`;
}

export function normalizeNovelPlain(text: string): string {
  // novel 컨텍스트에서는 지문/대사 마킹(*...*, "..." 등)을 최대한 보존한다.
  // - END 마커만 제거
  // - `이름 | ...` 접두가 붙은 라인은 제거하되, RHS가 따옴표 대사면 유지
  // - fenced 메타 패널( ```ANY_LABEL ...``` )은 그대로 유지
  const t0 = stripEndMarker(String(text || ""));
  if (!t0.trim()) return t0.trim();

  const src = t0.split(/\r?\n/);
  const out: string[] = [];

  let inFence = false;
  for (const ln of src) {
    const raw = String(ln || "");

    // fence toggle (preserve fences verbatim)
    if (/^\s*```/.test(raw)) {
      inFence = !inFence;
      out.push(raw.trimEnd());
      continue;
    }
    if (inFence) {
      out.push(raw.trimEnd());
      continue;
    }

    let s = stripSpeakerPrefixLine(raw);
    s = String(s || "").trimEnd();
    const trimmed = s.trimStart();

    // preserve narration marker
    if (trimmed.startsWith("*") && trimmed.endsWith("*")) {
      out.push(trimmed);
      continue;
    }

    // preserve dialogue quotes (straight/smart)
    if (/^["“]/.test(trimmed)) {
      out.push(ensureQuoted(trimmed));
      continue;
    }

    out.push(s);
  }

  let joined = out.join("\n");
  joined = joined.replace(/[ \t]+\n/g, "\n");
  joined = joined.replace(/\n{3,}/g, "\n\n");
  return joined.trim();
}
export function enforceNoPreDialogueTokenLeakForMode(text: string, mode: "chat" | "novel"): string {
  if (mode === "chat") return enforceNoPreDialogueTokenLeak(text);
  const raw = String(text || "");
  if (!raw.trim()) return raw.trim();
  const lines = raw.split(/\r?\n/);

  const getDialogueContent = (line: string): string | null => {
    const s = String(line || "").trim();
    const m = s.match(/^["“]([\s\S]*?)["”]\s*$/);
    if (!m) return null;
    const inside = String(m[1] || "").trim();
    return inside ? inside : null;
  };

  const firstDialogueIdx = lines.findIndex((l) => !!getDialogueContent(l));
  if (firstDialogueIdx < 0) return raw.trim();

  const dialogueContents: string[] = [];
  for (let i = firstDialogueIdx; i < lines.length; i++) {
    const c = getDialogueContent(lines[i]);
    if (c) dialogueContents.push(c);
  }
  if (!dialogueContents.length) return raw.trim();

  const stop = new Set(
    [
      "그리고","하지만","그런데","그래서","그러나","그냥","그저","정말","진짜","일단","지금","오늘","내일","어제","너","나","우리","그","이","저","것","수","때","좀","더","잘","못","왜","뭐","뭔","뭐야","어떤","이런","그런","저런","여기","거기","저기","같이","아마","벌써","다시","계속","이제","또","너무","조금",
    ].map((s) => s.toLowerCase())
  );

  const tokensSet = new Set<string>();
  for (const t of dialogueContents) {
    const ko = t.match(/[가-힣]{2,}/g) || [];
    const en = t.match(/[A-Za-z]{3,}/g) || [];
    for (const w of [...ko, ...en]) {
      const ww = String(w || "").trim();
      if (!ww) continue;
      const key = ww.toLowerCase();
      if (stop.has(key)) continue;
      tokensSet.add(ww);
    }
  }
  const tokens = Array.from(tokensSet);
  if (!tokens.length) return raw.trim();

  const pre = lines.slice(0, firstDialogueIdx);
  const post = lines.slice(firstDialogueIdx);
  const moved: string[] = [];
  const kept: string[] = [];

  const containsAnyToken = (line: string) => {
    const s = String(line || "");
    if (!s.trim()) return false;
    if (getDialogueContent(s)) return false;
    for (const tok of tokens) {
      if (tok.length < 2) continue;
      if (s.includes(tok)) return true;
      const low = tok.toLowerCase();
      if (/[A-Za-z]/.test(tok) && s.toLowerCase().includes(low)) return true;
    }
    return false;
  };

  for (const line of pre) {
    if (containsAnyToken(line)) moved.push(line);
    else kept.push(line);
  }

  const merged = [...kept, ...post, ...moved].join("\n");
  return merged.replace(/\n{3,}/g, "\n\n").trim();
}

export function formatStoryTurnsForMode(msgs: any[], personaName: string, npcName: string, mode: "chat" | "novel"): string {
  if (mode === "chat") return formatStoryTurns(msgs, personaName, npcName);
  const parts: string[] = [];
  for (const m of msgs || []) {
    const c = String((m as any)?.content || "");
    const cleaned = normalizeNovelPlain(c);
    if (cleaned) parts.push(cleaned);
  }
  return parts.join("\n\n").trim();
}

export function buildUserLineForMode(userText: string, personaName: string, mode: "chat" | "novel"): string {
  if (mode === "chat") {
    // 기존 채팅모드 규칙 유지: 주인공 | "..."
    const userLineRaw = ensurePrefix(userText, personaName);
    const m = userLineRaw.match(/^(.+?)\s*\|\s*(.+)$/);
    if (!m) return userLineRaw;
    const speaker = m[1].trim();
    let content = m[2].trim();
    if (!(content.startsWith("\"") || content.startsWith("“"))) {
      content = `\"${content}\"`;
    }
    return `${speaker} | ${content}`;
  }
  // novel: 기본은 큰따옴표(대사)로 보내되, 사용자가 명시한 형식은 보존한다.
  // - *지문* 은 지문으로 그대로 전달
  // - ```ANY_LABEL ...``` 메타 패널은 그대로 전달
  // - 이미 따옴표로 감싼 대사는 유지(끝따옴표만 보정)
  const stripped = String(stripSpeakerPrefixLine(String(userText || "")) || "").trim();
  if (!stripped) return '""';

  // fenced meta block (any label) - preserve as-is
  if (/^```/.test(stripped)) return stripped;

  // narration explicitly marked
  if (stripped.startsWith("*") && stripped.endsWith("*")) return stripped;

  // default: dialogue
  return ensureQuoted(stripped);
}

export function stripNamePrefixFromNarration(line: string) {
  const s = String(line || "");
  const m = s.match(/^(.+?)\s*\|\s*(.+)$/);
  if (!m) return s;
  const rhs = String(m[2] || "").trimStart();
  if (!rhs) return rhs;
  const first = rhs[0];
  const isQuoted = first === '"' || first === "'" || first === "“" || first === "‘";
  return isQuoted ? s : rhs;
}

// 대사 포맷으로 감싸진 지문을 감지해 지문으로 되돌립니다.
// 예) 이름 | "지은이는 ..."  ->  *지은이는 ...*
export function stripDialogueWrappedNarration(raw: string): string {
  const lines = String(raw || "").split(/\r?\n/);
  const out: string[] = [];
  for (const line of lines) {
    const m = line.match(/^\s*([^|]{1,40})\s*\|\s*["“”]\s*([\s\S]*?)\s*["”]\s*$/);
    if (!m) {
      out.push(line);
      continue;
    }
    const inside = (m[2] || "").trim();
    // 명백한 대사 특징(물음/느낌, 인용, 직접호칭 등)이 없고 서술형 동사가 있으면 지문으로 간주
    const looksDialogue = /[?!！？]/.test(inside) || /"|“|”/.test(inside);
    const looksNarrationVerb = /(했다|있었다|없었다|이었다|였다|느꼈|생각했|바라봤|놀랐|붙잡|속삭|말했|되었|되어|흔들|굳어|달아올)/.test(inside);
    if (!looksDialogue && looksNarrationVerb) {
      out.push(`*${inside}*`);
    } else {
      out.push(line);
    }
  }
  return out.join("\n");
}

export function removeEndMarker(s: string): string {
  return String(s || "")
    .replace(/\r?\n?\[END\]\s*$/i, "")
    .replace(/\[END\]\s*$/i, "")
    .replace(/\r?\n\s*\[END\]\s*\r?\n/g, "\n")
    .trimEnd();
}

// (강화) "대사가 나오기도 전에 지문에서 그 대사(단어/표현)에 반응"하는 미래침범을 최대한 억제한다.
// - 같은 답변 안에서 지문 → 대사 순서일 때,
//   지문(대사 이전 구간)에 곧이어 나올 대사 내용(단어/표현)을 먼저 쓰지 않도록
//   **대사에 등장하는 핵심 토큰이 포함된 지문 라인**을 대사 뒤로 이동한다.
// - 완벽한 의미적 차단은 아니지만, 실제로 자주 나오는 "'사장'이라는 단어에..." 류의
//   노골적인 선행 언급을 강하게 줄인다.
export function enforceNoPreDialogueTokenLeak(text: string): string {
  const raw = String(text || "");
  if (!raw.trim()) return raw.trim();

  const lines = raw.split(/\r?\n/);

  const getDialogueContent = (line: string): string | null => {
    // 이름 | "..." (큰따옴표/스마트따옴표 지원)
    const m = String(line || "").match(/^\s*[^|]{1,40}\s*\|\s*["“]([\s\S]*?)["”]\s*$/);
    if (!m) return null;
    const inside = String(m[1] || "").trim();
    return inside ? inside : null;
  };

  const firstDialogueIdx = lines.findIndex((l) => !!getDialogueContent(l));
  if (firstDialogueIdx < 0) return raw.trim();

  const dialogueContents: string[] = [];
  for (let i = firstDialogueIdx; i < lines.length; i++) {
    const c = getDialogueContent(lines[i]);
    if (c) dialogueContents.push(c);
  }
  if (!dialogueContents.length) return raw.trim();

  // 토큰 추출: 한글은 2자 이상, 영문은 3자 이상만.
  const stop = new Set(
    [
      // 아주 흔한 기능어/대명사/접속어(오탐 줄이기)
      "그리고",
      "하지만",
      "그런데",
      "그래서",
      "그러나",
      "그냥",
      "그저",
      "정말",
      "진짜",
      "일단",
      "지금",
      "오늘",
      "내일",
      "어제",
      "너",
      "나",
      "우리",
      "그",
      "이",
      "저",
      "것",
      "수",
      "때",
      "좀",
      "더",
      "잘",
      "못",
      "왜",
      "뭐",
      "뭔",
      "뭐야",
      "어떤",
      "이런",
      "그런",
      "저런",
      "여기",
      "거기",
      "저기",
      "같이",
      "아마",
      "벌써",
      "다시",
      "계속",
      "이제",
      "또",
      "너무",
      "조금",
    ].map((s) => s.toLowerCase())
  );

  const tokensSet = new Set<string>();
  for (const t of dialogueContents) {
    const ko = t.match(/[가-힣]{2,}/g) || [];
    const en = t.match(/[A-Za-z]{3,}/g) || [];
    for (const w of [...ko, ...en]) {
      const ww = String(w || "").trim();
      if (!ww) continue;
      const key = ww.toLowerCase();
      if (stop.has(key)) continue;
      tokensSet.add(ww);
    }
  }
  const tokens = Array.from(tokensSet);
  if (!tokens.length) return raw.trim();

  const pre = lines.slice(0, firstDialogueIdx);
  const post = lines.slice(firstDialogueIdx);

  const moved: string[] = [];
  const kept: string[] = [];

  const containsAnyToken = (line: string) => {
    const s = String(line || "");
    if (!s.trim()) return false;
    // 대사 라인은 건드리지 않는다.
    if (getDialogueContent(s)) return false;
    for (const tok of tokens) {
      if (tok.length < 2) continue;
      if (s.includes(tok)) return true;
      // 영문 토큰은 대소문자 흔들림이 있어 추가로 케이스 인센서티브 검사
      if (/[A-Za-z]/.test(tok) && s.toLowerCase().includes(tok.toLowerCase())) return true;
    }
    return false;
  };

  for (const line of pre) {
    if (containsAnyToken(line)) moved.push(line);
    else kept.push(line);
  }

  if (!moved.length) return raw.trim();

  // 첫 대사 줄 바로 뒤로 이동시켜 "대사 이전 지문"에서의 선행 언급을 제거한다.
  const out = [
    ...kept,
    ...(post.length ? [post[0], ...moved, ...post.slice(1)] : [...moved]),
  ]
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return out;
}



// 모델 출력의 흔한 형태 오류를 최소한으로 정리한다.
// - 지문인데 "이름 | 서윤아는..." 같이 이름 접두가 붙는 케이스
// - 사용자의 최신 대사가 상대(NPC) 쪽으로 잘못 붙는 케이스
export function stripTrailingTextAfterFinalFence(text: string): string {
  const s = String(text || "");

  // We only treat trailing text after a final *meta* fence as garbage.
  // This avoids deleting legitimate text after other fenced blocks.
  // Meta fences we recognize: ```STATUS, ```INFO (case-insensitive).
  const lastClose = s.lastIndexOf("```");
  if (lastClose < 0) return s;

  const before = s.slice(0, lastClose);
  const lastOpen = before.lastIndexOf("```");
  if (lastOpen < 0) return s;

  // Determine the fence label from the opening line.
  const lineEnd = s.indexOf("\n", lastOpen + 3);
  const openLine = (lineEnd >= 0 ? s.slice(lastOpen, lineEnd) : s.slice(lastOpen)).trim();
  const label = openLine.slice(3).trim().toUpperCase();

  const isMetaFence = label.startsWith("STATUS") || label.startsWith("INFO");
  if (!isMetaFence) return s;

  const after = s.slice(lastClose + 3);
  if (after.trim().length === 0) return s;

  return s.slice(0, lastClose + 3).trimEnd();
}


export function stripStandaloneSeparatorLines(s: string): string {
  // Remove noisy standalone separator lines that sometimes appear around images or status blocks.
  // Keeps meaningful content intact.
  return s
    .split(/\r?\n/)
    .filter((line) => {
      const t = line.trim();
      if (!t) return true;
      // '=' or '＝'
      if (/^[=＝]+$/.test(t)) return false;
      // Long dashes/underscores
      if (/^-{3,}$/.test(t)) return false;
      if (/^_{3,}$/.test(t)) return false;
      // Em-dash like separators
      if (/^[—–‐‑‒―━]{3,}$/.test(t)) return false;
      return true;
    })
    .join("\n");
}

export function _charLen(s: string): number {
  return Array.from(String(s || "")).length;
}
export function _sliceChars(s: string, n: number): string {
  return Array.from(String(s || "")).slice(0, n).join("");
}

export function splitTrailingFenceBlockAtEnd(text: string): { body: string; meta: string } {
  const t = String(text || "").trimEnd();
  const re = /```[^\n]*\n[\s\S]*?\n```\s*$/;
  const m = t.match(re);
  if (!m) return { body: t.trim(), meta: "" };
  const meta = String(m[0] || "").trim();
  const body = t.slice(0, t.length - m[0].length).trim();
  return { body, meta };
}

// If a trailing fenced block is too long for the output char budget, truncate its *inside*
// while keeping a valid opening/closing fence.
export function truncateFenceBlockToBudget(fenceBlock: string, budget: number): string {
  const fb = String(fenceBlock || "").trim();
  if (!fb.startsWith("```")) return fb;
  if (_charLen(fb) <= budget) return fb;

  const firstNl = fb.indexOf("\n");
  const lastFence = fb.lastIndexOf("```");
  if (firstNl < 0 || lastFence <= 0) return _sliceChars(fb, budget).trim();

  const open = fb.slice(0, firstNl + 1); // includes newline
  const close = "```";
  const inner = fb.slice(firstNl + 1, lastFence).replace(/\s+$/g, "");
  const reserve = _charLen(open) + _charLen("\n…(생략)\n") + _charLen(close);
  const availInner = Math.max(0, budget - reserve);
  const innerCut = _sliceChars(inner, availInner).trimEnd();
  return `${open}${innerCut}\n…(생략)\n${close}`.trim();
}

// Preserve a trailing fenced meta/status block within the char budget by trimming the body first.
// This prevents cases where the narrative consumes the whole budget and the status window gets dropped or cut.
export function preserveTrailingFenceBlockWithinBudget(text: string, budget: number): string {
  const t0 = String(text || "").trim();
  const { body, meta } = splitTrailingFenceBlockAtEnd(t0);
  if (!meta) return t0;

  // NOTE:
  // Previously we forced the narrative body to end with a placeholder narration line (`*...*`)
  // right before the trailing meta/status fence. That created unwanted trailing "*...*" lines
  // (especially when the scene already felt concluded).
  // Now we keep the body as-is and only trim it to fit the budget, preserving the fence block.
  let b = String(body || "").trimEnd();

  const metaLen = _charLen(meta);
  const total = _charLen(b) + 2 + metaLen;
  if (total <= budget) return `${b}

${meta}`.trim();

  const availBody = budget - metaLen - 2;
  if (availBody < 10) {
    // Body is too small to keep; prefer preserving the meta fence.
    return truncateFenceBlockToBudget(meta, Math.max(60, budget));
  }

  // Trim body to fit, preferring paragraph/line/sentence boundaries
  let bt = b;
  if (_charLen(bt) > availBody) {
    const head = _sliceChars(bt, availBody);
    // Prefer cutting on paragraph, then line, then sentence boundaries.
    const candidates = ["\n\n", "\n", ".", "!", "?", "\"", "'", ")", "]"];
    let cut = -1;
    for (const c of candidates) {
      const idx = head.lastIndexOf(c);
      if (idx > cut) cut = idx;
    }
    bt = (cut >= Math.floor(availBody * 0.55)) ? head.slice(0, cut + 1) : head;
    bt = bt.trimEnd();
  }

  return `${bt}

${meta}`.trim();
}



export function endsWithCompleteFence(text: string): boolean {
  const s = String(text || "").trimEnd();
  if (!s.endsWith("```")) return false;
  // Find the last two fences
  const last = s.lastIndexOf("```");
  const prev = s.lastIndexOf("```", last - 1);
  return prev >= 0;
}

export function findLastStatusFenceCloseEnd(text: string): number {
  const s = String(text || "");
  const re = /(^|\n)\s*```\s*STATUS\b/gi;
  let m: RegExpExecArray | null = null;
  let lastIdx = -1;
  while ((m = re.exec(s))) {
    // m.index points at start of match; find the first backticks in this match
    const mi = m.index;
    const bt = s.indexOf("```", mi);
    if (bt >= 0) lastIdx = bt;
  }
  if (lastIdx < 0) return -1;
  const closeIdx = s.indexOf("```", lastIdx + 3);
  if (closeIdx < 0) return -1;
  return closeIdx + 3;
}

export function normalizeNovelOutput(text: string, personaName: string, npcName: string, latestUserLine?: string) {
  const raw = String(text || "");
  const norm = (s: string) =>
    String(s || "")
      .replace(/[\s\u200b\u200c\u200d]+/g, "")
      .replace(/["'“”‘’\.,!?！？。…]/g, "")
      .trim();
  const latestNorm = latestUserLine ? norm(latestUserLine.replace(new RegExp(`^${personaName}\s*\|\s*`), "")) : "";

  const out: string[] = [];
  for (const line0 of raw.split("\n")) {
    // (1) 지문 앞에 이름 접두가 붙는 경우 제거
    const line = stripNamePrefixFromNarration(line0);
    const m = line.match(/^(.+?)\s*\|\s*(.+)$/);
    if (!m) {
      out.push(line);
      continue;
    }
	    let speaker = String(m[1] || "").trim();
    const rhs = String(m[2] || "").trim();

	    // 모델이 습관적으로 주인공 화자를 "주인공"으로 고정해서 출력하는 경우가 있어,
	    // 실제 설정된 페르소나명이 있으면 강제로 교정한다.
	    if (speaker === "주인공" && personaName && personaName !== "주인공") {
	      speaker = personaName;
	    }

    // 0) (요구사항)
    // 지문(서술) 앞에 "이름 |"가 붙는 형태를 제거한다.
    // - 대사는 반드시 큰따옴표로 감싸야 하므로(규칙), 따옴표가 없으면 지문으로 간주한다.
    // - 예: "서윤아 | 사무실의 공기는..." -> "*사무실의 공기는...*"
    const looksLikeDialogue = rhs.startsWith("\"") || rhs.startsWith("“");
    if (!looksLikeDialogue && !rhs.startsWith("*")) {
      out.push(`*${rhs}*`);
      continue;
    }

    // 1) 지문인데 "이름 | 서윤아는..." 형태로 온 경우: 접두를 제거하고 *...*로 감싼다.
    const looksLikeNarration =
      rhs.startsWith(personaName + "는") ||
      rhs.startsWith(personaName + "은") ||
      rhs.startsWith(personaName + "이") ||
      rhs.startsWith(personaName + "가") ||
      rhs.startsWith(npcName + "는") ||
      rhs.startsWith(npcName + "은") ||
      rhs.startsWith(npcName + "이") ||
      rhs.startsWith(npcName + "가");
    // 1) 지문인데 "이름 | 서윤아는..." 형태로 온 경우: 접두를 제거하고 *...*로 감싼다.
    if (looksLikeNarration && !rhs.startsWith("*") && !looksLikeDialogue) {
      out.push(`*${rhs}*`);
      continue;
    }

    // NOTE: 0)에서 이미 "따옴표 없는 speaker|"는 지문으로 정리되므로,
    // 여기서는 추가 휴리스틱이 필요 없다.

    // 2) 최신 유저 대사가 NPC에 붙는 경우: speaker를 주인공으로 교정
	    if (latestNorm && speaker === npcName && norm(rhs) === latestNorm) {
      out.push(`${personaName} | ${rhs}`);
      continue;
    }

    out.push(line);
  }
  return stripTrailingTextAfterFinalFence(out.join("\n").trim());
}

export function estTokens(text: string) {
  // 아주 러프한 추정(실제 토큰과 다를 수 있음)
  const t = String(text || "").trim();
  if (!t) return 0;
  return Math.ceil(t.length / 4);
}

// 가능한 한 '완결된 문장'에서 잘라 UI에 미완성 문장이 노출되지 않도록 한다.
export function trimToComplete(text: string) {
  const t = String(text || "").trim();
  if (!t) return t;

  // 마지막 종결 후보(. ! ? " ' ) ]) 중 가장 뒤를 기준으로 자른다.
  // 주의: '*'는 지문(*...*)에서 매우 자주 등장하므로 종결 후보에서 제외한다.
  // 또한 "너무 앞에서" 자르면 정상 문단까지 잘려서 오히려 답변이 극단적으로 짧아질 수 있으므로,
  // cut 지점 이후 남는 길이가 충분히 크면(=앞에서 잘리는 케이스) 아예 자르지 않는다.
  // 문자열 리터럴 안에서 따옴표는 반드시 이스케이프한다.
  const candidates = [".", "!", "?", "\"", "'", ")", "]"];
  let cut = -1;
  for (const c of candidates) {
    const idx = t.lastIndexOf(c);
    if (idx > cut) cut = idx;
  }
  if (cut <= 0) return t;

  // cut 이후에 남는 텍스트가 너무 많으면(앞부분만 남기게 되면) 자르지 않는다.
  const tailLen = t.length - (cut + 1);
  if (tailLen >= 120) return t;

  return t.slice(0, cut + 1).trim();
}


// --- Prompt/Output sanitizers (Option A: novel-only) ---
// Avoid feeding markdown-y scaffolding into the model; it tends to leak into output during streaming.
export function sanitizePromptForModel(text: string): string {
  const s = String(text ?? "");
  if (!s) return s;
  const lines = s.split(/\r?\n/);
  const out: string[] = [];
  for (let line of lines) {
    // Strip leading markdown heading/bullet/quote markers that can "infect" generation.
    line = line.replace(/^\s{0,3}(#{1,6}\s+)+/g, "");
    line = line.replace(/^\s{0,3}[-*+]\s+/g, "");
    line = line.replace(/^\s{0,3}>\s+/g, "");
    // Collapse accidental table pipes
    if (/^\s*\|.*\|\s*$/.test(line)) line = line.replace(/\|/g, " ");
    out.push(line);
  }
  return out.join("\n").trim();
}

// Enforce output rules softly without rewriting story content.
// - Remove markdown headings/bullets/links that break the client streaming parser.
// - Keep *...* and "..." as-is.
export function enforceNovelOnlyOutput(text: string): string {
  let s = String(text ?? "");
  if (!s) return s;

  // Remove markdown headings at line starts
  s = s.replace(/^\s{0,3}#{1,6}\s+/gm, "");

  // Remove list bullets at line starts
  s = s.replace(/^\s{0,3}[-*+]\s+/gm, "");

  // Strip markdown link syntax: [text](url) -> text
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1");

  // Strip bold/italic markers that can appear mid-stream
  s = s.replace(/\*\*([^*]+)\*\*/g, "$1");
  s = s.replace(/__([^_]+)__/g, "$1");

  // (repair) INFO/STATUS 펜스가 앞따옴표로 감싸져 대사로 인식되는 경우가 있다: "```Info -> ```INFO
  s = s.replace(/^\s*["“”']+\s*```\s*(INFO|STATUS)\b/gi, "```$1");
  s = s.replace(/^\s*["“”']+\s*(INFO|STATUS)\b/gi, "```$1");

  // (repair) 이미지 다음에 말줄임표로 시작하는 라인에서 앞따옴표가 빠지고 끝따옴표만 남는 경우를 보정: ......린." -> "......린."
  {
    const lines = s.replace(/\r\n/g, "\n").split("\n").map((ln) => {
      const raw = String(ln || "");
      const t = raw.trimStart();
      if (!t) return raw;
      if (t.endsWith('"') && !t.startsWith('"') && !t.startsWith("*") && !t.startsWith("```")) {
        if (/^[.…\.]{2,}/.test(t)) return raw.replace(/^\s*/, (m0) => m0 + '"');
      }
      return raw;
    });
    s = lines.join("\n");
  }

  // (repair) 모델이 맨 위에 작품 제목 같은 한 줄을 찍는 경우 제거(토큰 절감은 프롬프트 단계에서 별도지만, 출력/저장 오염 방지)
  {
    const raw = s.replace(/\r\n/g, "\n");
    const lines = raw.split("\n");
    let firstIdx = -1;
    for (let i = 0; i < lines.length; i++) {
      if (String(lines[i] || "").trim().length > 0) { firstIdx = i; break; }
    }
    if (firstIdx >= 0) {
      const first = String(lines[firstIdx] || "").trim();
      const startsBad = first.startsWith("*") || first.startsWith('"') || first.startsWith("```");
      const titley = first.length <= 45 && !startsBad && (first.includes(":") || first.includes("!") || first.includes("|"));
      if (titley) {
        let second = "";
        for (let j = firstIdx + 1; j < lines.length; j++) {
          const cand = String(lines[j] || "").trim();
          if (cand) { second = cand; break; }
        }
        if (second && second.length > 4) {
          lines.splice(firstIdx, 1);
          s = lines.join("\n").replace(/^\s*\n+/, "");
        }
      }
    }
  }

// Drop leading lines that violate the strict output channels.
// Allowed starts (after whitespace): *...* narration, "..." dialogue, or fenced ```INFO/```STATUS blocks.
// This prevents title echoes like "작품명..." from appearing above the actual story.
{
  const allowedStart = (t: string) => {
    const u = (t || "").trimStart();
    return (
      u.startsWith("*") ||
      u.startsWith('"') ||
      u.startsWith("```INFO") ||
      u.startsWith("```STATUS") ||
      u.startsWith("```")
    );
  };

  if (!allowedStart(s)) {
    const lines = s.split(/\r?\n/);
    let i = 0;
    while (i < lines.length) {
      const rest = lines.slice(i).join("\n");
      if (!rest.trim()) {
        s = "";
        break;
      }
      if (allowedStart(rest)) {
        s = rest.replace(/^\s*\n+/, "");
        break;
      }
      i += 1;
      if (i > 8) break; // safety
    }
  }
}

  return s;

}