import { db as defaultDb } from "@/lib/db";
import { compactCharacterChangeText, sanitizeStoryMemoryText, safeJsonParse } from "@/lib/story_memory";
import { summarizeLongMemoryKorean } from "@/lib/ai";

function safeJsonParseLoose<T>(input: string, fallback: T): T {
  const s = String(input || "").trim();
  const tryParse = (x: string) => {
    try {
      return JSON.parse(x) as T;
    } catch {
      return undefined;
    }
  };

  const direct = tryParse(s);
  if (direct !== undefined) return direct;

  // strip ```json fences
  const unfenced = s
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/```\s*$/i, "")
    .trim();
  const direct2 = tryParse(unfenced);
  if (direct2 !== undefined) return direct2;

  // extract first JSON array/object segment
  const a0 = unfenced.indexOf("[");
  const a1 = unfenced.lastIndexOf("]");
  if (a0 >= 0 && a1 > a0) {
    const seg = unfenced.slice(a0, a1 + 1);
    const d = tryParse(seg);
    if (d !== undefined) return d;
  }
  const o0 = unfenced.indexOf("{");
  const o1 = unfenced.lastIndexOf("}");
  if (o0 >= 0 && o1 > o0) {
    const seg = unfenced.slice(o0, o1 + 1);
    const d = tryParse(seg);
    if (d !== undefined) return d;
  }

  return fallback;
}

function pickLikelyPersonNames(raw: string): string[] {
  const s = String(raw || "");
  const out = new Set<string>();
  // Very conservative: honorific-attached Korean names only (e.g., "미연님", "성준씨")
  const rx = /([가-힣]{2,4})(?:님|씨|양|군)\b/g;
  let m: RegExpExecArray | null;
  while ((m = rx.exec(s))) {
    const n = sanitizeStoryMemoryText(String(m[1] || "")).replace(/\s+/g, " ").trim();
    if (!n) continue;
    out.add(n);
    if (out.size >= 6) break;
  }
  return Array.from(out);
}

type AnyDb = typeof defaultDb;

export type StoryMemoryRangeInput = {
  db?: AnyDb;
  chatId: string;
  startTurn: number;
  endTurn: number;
  // Plain text transcript of the range (already stripped of media URLs if possible)
  rawText: string;
  // Settings-derived per-turn budget (30~200). Used only for soft budgeting.
  perTurnChars: number;
  // Model options passed through from /chat/send route
  opts: any;
};

type ExtractedEntity = {
  name: string;
};

function getUserDisplayName(db: AnyDb, chatId: string): string {
  try {
    const row = db.prepare(`SELECT personaName FROM chat_settings WHERE chatId=?`).get(chatId) as any;
    const n = sanitizeStoryMemoryText(String(row?.personaName || "")).trim();
    // Guard: sometimes a line from dialogue (e.g. "너... 지금... 제정신이냐?")
    // gets mistakenly saved as personaName. Treat such cases as invalid.
    const looksLikeSentence = /[\s\?\!…]/.test(n) || n.includes("...") || n.includes("…") || n.includes("\"");
    const badTokens = /(제정신|웅제정신|지금|너\s*\.|\binfo\b)/i.test(n);
    if (!n || n.length > 16 || looksLikeSentence || badTokens) return "주인공";
    return n;
  } catch {
    return "주인공";
  }
}

function isMetaLine(line: string): boolean {
  const s = String(line || "").trim();
  if (!s) return true;

  // Structured INFO blocks often use KEY: VALUE lines.
  // These may contain proper nouns (e.g., "(헌종 2년)") that should NOT become characters.
  // Keep NPC: lines because they carry the actual speaking character in some presets.
  const mKV = s.match(/^([A-Z][A-Z0-9_]{1,15})\s*:\s*(.*)$/);
  if (mKV) {
    const key = String(mKV[1] || "").trim();
    if (key && key !== "NPC") return true;
  }

  // Fences / headers
  if (/^```/i.test(s)) return true;
  if (/^(info|메타)\b/i.test(s)) return true;

  // Common Info chips
  if (s.includes("📍") || s.includes("🕒") || s.includes("🗓")) return true;
  if (/\b위치\||\b시간\||\b날짜\|/i.test(s)) return true;

  // Separators
  if (/^[-_—]{3,}$/.test(s)) return true;

  // Bracketed stat tags: [이름|💗72|...]
  if (/^\[[^\]]+\]$/.test(s) && s.includes("|")) return true;
  if (s.includes("|💗") || (s.includes("💗") && s.includes("|"))) return true;

  // Symbol/emoji-only lines (approx)
  if (/^[\s\|\[\]\-–—_\u2600-\u27BF\u{1F300}-\u{1FAFF}]+$/u.test(s)) return true;

  return false;
}

function sanitizeActionLine(rawLine: string): string {
  const s = sanitizeStoryMemoryText(String(rawLine || "")).trim();
  if (!s) return "";
  if (isMetaLine(s)) return "";
  return s;
}

function stripRoleTag(line: string): string {
  return String(line || "")
    .replace(/^\[(?:사용자|유저|어시스턴트|assistant|user)\]\s*/i, "")
    .replace(/^(?:User|Assistant):\s*/i, "")
    .trim();
}
function looksLikePipeChips(line: string): boolean {
  const t = sanitizeStoryMemoryText(String(line || "")).trim();
  if (!t) return false;
  if (!(t.includes("|") || t.includes("｜"))) return false;
  const parts = t.split(/[\|｜]/).map((p) => p.trim()).filter(Boolean);
  if (parts.length < 2) return false;
  const shortParts = parts.length <= 6 && t.length <= 80 && parts.every((p) => p.length <= 18);
  const noSentencePunct = !/[\.!\?…]/.test(t);
  const hasSignal = /[0-9]|[💗❤️💕]|호감|불편|평범|경계|친밀|긴장|중립/i.test(t);
  return shortParts && noSentencePunct && hasSignal;
}


function pickRecentLinesAbout(text: string, name: string, maxLines = 3): string[] {
  const n = String(name || "").trim();
  if (!n) return [];
  const lines = String(text || "")
    .split(/\r?\n/)
    .map((l) => stripRoleTag(l))
    .map((l) => String(l || "").trim())
    .filter((l) => !!l && !isMetaLine(l));

  // Prefer assistant lines when possible.
  const assistantLines = String(text || "")
    .split(/\r?\n/)
    .filter((l) => /^\[어시스턴트\]/.test(l) || /^Assistant:/i.test(l))
    .map((l) => stripRoleTag(l))
    .map((l) => String(l || "").trim())
    .filter((l) => !!l && !isMetaLine(l));

  const pool = assistantLines.length ? assistantLines : lines;
  const hits: string[] = [];
  for (let i = pool.length - 1; i >= 0 && hits.length < maxLines; i--) {
    const l = pool[i];
    if (!l) continue;
    if (l.includes(n)) hits.push(l);
  }
  return hits.reverse();
}

function inferStatusFromText(text: string, name: string, userName: string): string {
  const hits = pickRecentLinesAbout(text, name, 2);
  let base = hits.length ? hits[hits.length - 1] : "";
  base = sanitizeStoryMemoryText(base);
  if (!base) {
    // Fallback: generic but non-meta.
    return `${name}은(는) ${userName}와 대화를 이어가고 있다.`;
  }
  // Avoid copying UI chips or bracket tags even if they slipped through.
  if (looksLikePipeChips(base)) {
    return `${name}은(는) ${userName}와 대화를 이어가고 있다.`;
  }
  return ensureSubject(name, base).trim();
}

function stripTurnPrefix(line: string): string {
  return String(line || "").replace(/^\s*\[T\d+\]\s*/i, "").trim();
}

function ensureTurnPrefix(turn: number, line: string): string {
  const body = stripTurnPrefix(line);
  const t = sanitizeStoryMemoryText(body).trim();
  return `[T${Math.max(1, Math.floor(Number(turn || 0)))}] ${t}`.trim();
}

function inferChangeFromText(text: string, name: string, userName: string): string {
  const hits = pickRecentLinesAbout(text, name, 1);
  let base = hits.length ? hits[0] : "";
  base = sanitizeStoryMemoryText(base);
  if (!base) return `${name}은(는) ${userName}와 한 차례 교류했다.`;
  if (looksLikePipeChips(base)) return `${name}은(는) ${userName}와 한 차례 교류했다.`;
  return ensureSubject(name, stripTurnPrefix(base)).trim();
}



// --- Phase3-2 helpers: 2-line status / per-turn change / affinity ---

function extractAffinityFromText(text: string): number | null {
  const t = String(text || "");
  if (!t) return null;

  // Prefer heart emoji patterns: ❤️72 / 💗 72 / ♥72
  const m1 = t.match(/(?:❤️|💗|💕|♥)\s*([0-9]{1,3})/);
  if (m1?.[1]) {
    const v = Math.max(0, Math.min(999, Math.floor(Number(m1[1]))));
    if (Number.isFinite(v)) return v;
  }

  // Fallback: "호감도 72" / "호감:72"
  const m2 = t.match(/호감(?:도)?\s*[:：]?\s*([0-9]{1,3})/);
  if (m2?.[1]) {
    const v = Math.max(0, Math.min(999, Math.floor(Number(m2[1]))));
    if (Number.isFinite(v)) return v;
  }

  return null;
}

function stripLeadingSubject(name: string, sentence: string): string {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  let s = sanitizeStoryMemoryText(String(sentence || "")).trim();
  if (!n || !s) return s;

  // Remove "이름은/는/이/가" or "이름:" prefix.
  s = s.replace(new RegExp(`^${escapeRegExp(n)}\\s*(?:은|는|이|가)\\s*`, "i"), "");
  s = s.replace(new RegExp(`^${escapeRegExp(n)}\\s*[:：]\\s*`, "i"), "");
  return s.trim();
}

function normalizeTwoLineStatus(raw: string, name: string, userName: string): string {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const u = sanitizeStoryMemoryText(String(userName || "")).trim() || "주인공";
  const s0 = String(raw || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = s0
    .split("\n")
    .map((l) => sanitizeStoryMemoryText(String(l || "")).trim())
    .filter(Boolean);

  let cLine = "";
  let uLine = "";

  for (const ln of lines) {
    if (!cLine && (ln.startsWith(`${n}:`) || ln.startsWith(`${n}：`))) cLine = ln;
    else if (!uLine && (ln.startsWith(`${u}:`) || ln.startsWith(`${u}：`))) uLine = ln;
    else if (!cLine) cLine = ln;
    else if (!uLine) uLine = ln;
  }

  let cBody = "";
  if (cLine) {
    cBody = cLine.replace(new RegExp(`^${escapeRegExp(n)}\\s*[:：]\\s*`, "i"), "");
    cBody = stripLeadingSubject(n, cBody);
  }
  if (!cBody) cBody = `${u}와 대화를 이어감`;

  let uBody = "";
  if (uLine) {
    uBody = uLine.replace(new RegExp(`^${escapeRegExp(u)}\\s*[:：]\\s*`, "i"), "");
    uBody = sanitizeStoryMemoryText(uBody).trim();
  }
  if (!uBody) uBody = `${n}에게 반응하며 대화를 이어감`;

  // Keep them short-ish.
  cBody = sanitizeStoryMemoryText(cBody).trim().slice(0, 140);
  uBody = sanitizeStoryMemoryText(uBody).trim().slice(0, 140);

  return `${n}: ${cBody}\n${u}: ${uBody}`.trim();
}

async function summarizeTwoLineStatusForCharacter(raw: string, name: string, userName: string, opts: any): Promise<string> {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const u = sanitizeStoryMemoryText(String(userName || "")).trim() || "주인공";
  if (!n) return "";

  const guidance = [
    `아래는 사용자('${u}')와 인물('${n}')의 대화 일부다.`,
    "현재 상태를 반드시 2줄로만 출력한다.",
    `1줄째는 반드시 '${n}: '로 시작하고, 사용자 행동/말에 대한 '${n}'의 반응(감정/태도/의도)을 1문장으로 쓴다.`,
    `2줄째는 반드시 '${u}: '로 시작하고, '${n}'의 말/행동에 대한 '${u}'의 반응을 1문장으로 쓴다.`,
    "마크다운/불릿/따옴표/이모지 금지. 평문만.",
  ].join(" ");

  const body = await summarizeLongMemoryKorean({
    text: String(raw || "").slice(0, 14000),
    targetChars: 220,
    guidance,
    opts,
  });

  return normalizeTwoLineStatus(String(body || ""), n, u);
}


// --- Phase4-3: 1-line status (캐릭터: 행동 / 감정1, 감정2[, 감정3]) ---

const EMOTION_KEYWORDS = [
  "황당함", "역겨움", "불쾌감", "불쾌함", "짜증", "분노", "경계", "경계심", "불안", "불안감", "공포", "공포심", "긴장", "긴장감", "의아함", "귀찮음", "무관심", "의심", "경멸", "혐오", "중립", "호감", "기대", "안도", "슬픔", "기쁨", "두려움", "경고"
];

function clampOneLine(text: string, maxChars: number): string {
  const t = sanitizeStoryMemoryText(String(text || "")).replace(/\s+/g, " ").trim();
  if (!t) return "";
  if (t.length <= maxChars) return t;
  return t.slice(0, maxChars).trim();
}

function extractDetailAfterPersona(win: string, personaName: string, verbRx: RegExp, maxChars: number): string {
  const w = sanitizeStoryMemoryText(String(win || "")).replace(/\s+/g, " ").trim();
  const p = sanitizeStoryMemoryText(String(personaName || "")).trim();
  if (!w || !p) return "";

  const pEsc = escapeRegExp(p);
  // Grab a short phrase between "<persona>(에게/을/를/한테)" and the action verb.
  const rx = new RegExp(`${pEsc}(?:에게|을|를|한테)?\\s*([^\\n\\.]{0,180}?)\\s*(?:${verbRx.source})`, "i");
  const m = w.match(rx);
  if (!m?.[1]) return "";

  let detail = String(m[1] || "");
  detail = detail.replace(/^\s*(?:에게|을|를|한테)\s*/i, "");
  // Trim common tail fillers
  detail = detail.replace(/\s*(?:했다|하였다|했(?:다)?|함|하며|하면서|하고)\s*$/i, "");
  detail = detail.replace(/[\s,;:!?\.]+$/g, "").trim();
  if (detail.length < 2) return "";

  return clampOneLine(detail, maxChars);
}


function extractQuotedSnippet(text: string, maxChars: number): string {
  const t = sanitizeStoryMemoryText(String(text || "")).replace(/\s+/g, " ").trim();
  if (!t) return "";
  const m = t.match(/[\"“”]([^\"“”\n]{2,120})[\"“”]/) || t.match(/'([^'\n]{2,120})'/);
  if (!m?.[1]) return "";
  let q = String(m[1] || "").replace(/\s+/g, " ").trim();
  q = q.replace(/[。．\.!?！？]+$/g, "").trim();
  if (q.length > maxChars) q = q.slice(0, maxChars).trim();
  return q;
}


function isBadQuoteSnippet(q: string): boolean {
  const s = sanitizeStoryMemoryText(String(q || "")).replace(/\s+/g, " ").trim();
  if (!s) return true;
  if (s.length < 3) return true;
  if (/^[…\.·]+$/.test(s)) return true;

  // 너무 일반적인 단어/표현만 집은 경우(예: '이라는 단어')는 배제
  const semantic = /(용건|목적|정체|신분|이름|증명|왜|뭐|무슨|어디|언제|누구|어떻게|이유)/;
  if (/(이라는|단어|표현)/.test(s) && !semantic.test(s)) return true;

  // 접속사/지시어 수준이면 의미가 없음
  if (/^(그리고|그러고|그런데|그래서|이후|또는|혹은|이것|그것|저것|이런|저런|그게|그건)$/.test(s)) return true;
  return false;
}

function extractQuestionSnippet(text: string, maxChars: number): string {
  const t = sanitizeStoryMemoryText(String(text || "")).replace(/\s+/g, " ").trim();
  if (!t) return "";

  // 물음표가 있는 문장 일부를 뽑는다(최대 80자 범위)
  const m = t.match(/([^\n\r\?？]{3,80}[\?？])/);
  if (!m?.[1]) return "";

  let q = String(m[1] || "").trim();
  q = q.replace(/[\?？]+$/g, "").trim();
  q = q.replace(/[.·…]{2,}/g, "").trim();
  if (q.length > maxChars) q = q.slice(0, maxChars).trim();
  return q;
}

function extractPersonaClause(text: string, personaName: string, maxChars: number): string {
  const w = sanitizeStoryMemoryText(String(text || "")).replace(/\s+/g, " ").trim();
  const p = sanitizeStoryMemoryText(String(personaName || "")).trim();
  if (!w || !p) return "";
  const pEsc = escapeRegExp(p);
  let m = w.match(new RegExp(`${pEsc}\\s*(?:은|는|이|가)\\s*([^\\.\\!\\?\\n]{3,140})`));
  if (!m) m = w.match(new RegExp(`${pEsc}\\s*([^\\.\\!\\?\\n]{3,140})`));
  if (!m?.[1]) return "";
  let clause = String(m[1] || "").trim();
  clause = clause.split(/(?:그리고|이후|그러나|하지만|다만|또한)\s*/)[0].trim();
  clause = clause.replace(/\s*(?:했다가|했지만|했고|하며|하면서|했다|하였다|한다|함|됨)\s*$/g, "").trim();
  clause = clause.replace(/[\s,;:]+$/g, "").trim();
  if (clause.length < 2) return "";
  return clampOneLine(clause, maxChars);
}

function deriveObserveDetailFromWin(win: string, personaName: string): string {
  const clause = extractPersonaClause(win, personaName, 44);
  return clause || "";
}

function deriveWarnDetailFromWin(win: string, personaName: string): string {
  const w = sanitizeStoryMemoryText(win).replace(/\s+/g, " ");
  if (!w) return "";

  // Specific condition warnings (still summarized; never echo raw dialogue).
  if (/(뇌진탕)/.test(w) && /(정신\s*차리)/.test(w)) return "뇌진탕을 걱정하며 정신 차리라 경고함";
  if (/(뇌진탕)/.test(w)) return "뇌진탕을 걱정하며 경고함";
  if (/(정신\s*차리)/.test(w)) return "정신 차리라고 경고함";

  // Never echo raw dialogue; only return concise action summaries.
  if (/(나가|꺼져|돌아가|떠나|퇴거)/.test(w)) return "나가라고 경고함";
  if (/(경고|마지막\s*경고)/.test(w)) return "경고함";
  if (/(침입|불법)/.test(w)) return "침입이라고 경고함";
  if (/조심/.test(w)) return "조심하라고 경고함";
  if (/(해치|다치|피|죽|후회|위험)/.test(w)) return "위험을 경고함";

  const q = extractQuotedSnippet(w, 52);
  if (q) {
    const qq = sanitizeStoryMemoryText(q);
    if (/(나가|꺼져|돌아가|떠나|퇴거)/.test(qq)) return "나가라고 경고함";
    if (/(해치|다치|피|죽|후회|위험)/.test(qq)) return "위험을 경고함";
    if (/(조심|경고|마지막)/.test(qq)) return "경고함";
  }

  return "";
}

function deriveAskDetailFromWin(win: string, personaName: string): string {
  const w = sanitizeStoryMemoryText(win).replace(/\s+/g, " ");
  if (!w) return "";

  const summarizeAsk = (src: string): string => {
    const t = sanitizeStoryMemoryText(src).replace(/\s+/g, " ");
    if (!t) return "따져묻고 추궁함";
    if (/제정신|정신/.test(t)) return "정신 상태를 지적하며 추궁함";
    if (/민원|상담|창구/.test(t)) return "여기가 무슨 곳이냐며 비꼼";
    if (/(용건|목적).*(뭐|뭔|무엇|왜)/.test(t) || /(용건|목적|이유)/.test(t)) return "용건을 캐묻고 추궁함";
    if (/(왜|이유)/.test(t) || /(왜|어째서).*(찾|부르|온)/.test(t) || /왜.*(왔|온)/.test(t)) return "이유를 캐묻고 추궁함";
    if (/(무슨|뭐).*(짓|하)/.test(t)) return "무슨 짓이냐고 따져묻음";
    if (/(누구|정체|신분|이름)/.test(t)) return "정체를 캐묻고 추궁함";
    if (/(뭐|무슨)/.test(t)) return "무슨 일이냐며 추궁함";
    if (/(어디|여기)/.test(t)) return "여기가 어딘지 따져묻음";
    return "따져묻고 추궁함";
  };

  // Prefer question snippet if present, but summarize (do not quote).
  const qs = extractQuestionSnippet(w, 64);
  if (qs) return summarizeAsk(qs);

  // Quoted snippet: classify only.
  const q = extractQuotedSnippet(w, 52);
  if (q) {
    const qq = sanitizeStoryMemoryText(q);
    if (/(명함|정체|신분|누구|이름)/.test(qq)) return "정체를 요구함";
    if (/(말해|대답|답해|설명|밝혀)/.test(qq)) return "설명을 요구함";
    if (/(용건|목적|이유)/.test(qq)) return "용건을 따져묻고 추궁함";
    return summarizeAsk(qq);
  }

  const askRx = /(질문|묻|물었|물어|캐묻|따져|추궁|요구)/i;
  if (askRx.test(w)) return summarizeAsk(w);

  return "";
}

function extractEmotionsFromText(text: string): string[] {
  const t = sanitizeStoryMemoryText(String(text || "")).replace(/\s+/g, " ");
  const out: string[] = [];

  for (const w of EMOTION_KEYWORDS) {
    if (t.includes(w) && !out.includes(w)) out.push(w);
    if (out.length >= 3) break;
  }

  // Ensure 2-3 words
  if (out.length == 0) return ["경계", "중립"];
  if (out.length == 1) return [out[0], "중립"];
  return out.slice(0, 3);
}

function heuristicCharacterActionTowardPersona(cleanText: string, userName: string): string {
  const u = sanitizeStoryMemoryText(String(userName || "")).trim() || "주인공";
  const t = String(cleanText || "");
  if (!t) return `${u}와 대화 이어감`;

  const idx = firstMentionIndex(t, u);
  const w0 = Math.max(0, idx - 220);
  const w1 = Math.min(t.length, idx + 340);
  const win = idx >= 0 ? t.slice(w0, w1) : t;

  // High-signal, persona-targeted actions.
  if (/(저지|막아|막았|막으|가로막)/.test(win)) return `${u}의 행동 저지`;
  if (/방관/.test(win)) return `${u}의 행동 방관`;
  if (/무시/.test(win)) return `${u}를 무시`;
  if (/(노려|노렸|째려)/.test(win)) return `${u}를 노려봄`;
  if (/거절/.test(win)) return `${u}의 제안을 거절`;
  if (/(공격|때리|찌르|쏘|제압)/.test(win)) return `${u}를 공격`;
  if (/(제거\s*대상|제거하|처단|체포)/.test(win)) return `${u}를 제거 대상으로 판단`;

  // Observe with detail when possible.
  if (/(관찰|주시|지켜보)/.test(win)) {
    const obs = deriveObserveDetailFromWin(win, u);
    return obs ? `${u}의 ${obs}을 관찰` : `${u}의 행동을 관찰`;
  }

  // Warn / Ask should include what was said/asked when possible.

  const warnDetail = deriveWarnDetailFromWin(win, u);
  if (warnDetail) {
    const warnShort = warnDetail.replace(/\s*경고함$/g, "경고").trim();
    return `${u}에게 ${warnShort}`.replace(/\s+/g, " ").trim();
  }

  const askDetail = deriveAskDetailFromWin(win, u);
  if (askDetail) {
    let short = clampOneLine(askDetail, 42).trim();
    short = short
      .replace(/\s*추궁함$/g, " 추궁")
      .replace(/\s*요구함$/g, " 요구")
      .replace(/\s*질문함$/g, " 질문");
    return `${u}에게 ${short}`.replace(/\s+/g, " ").trim();
  }

  if (/(대답|답했|답하)/.test(win)) return `${u}에게 대답`;

  // Last resort: if persona action clause exists, use it as a "watch" target.
  const obs2 = deriveObserveDetailFromWin(win, u);
  if (obs2) return `${u}의 ${obs2}을 주시`;

  return `${u}와 대화 이어감`;
}

function formatOneLineStatus(name: string, action: string, emotions: string[]): string {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const a = sanitizeStoryMemoryText(String(action || "")).replace(/\s+/g, " ").trim();
  const emos = (emotions || []).map((x) => sanitizeStoryMemoryText(String(x || "")).trim()).filter(Boolean);
  const e2 = emos.length >= 2 ? emos.slice(0, 3) : extractEmotionsFromText("");
  if (!n) return "";
  return `${n}: ${a || "주인공과 대화 이어감"} / ${e2.join(", ")}`;
}

function normalizeOneLineStatus(raw: string, name: string, fallbackLine: string): string {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  let t = sanitizeStoryMemoryText(String(raw || "")).replace(/\s+/g, " ").trim();
  t = t.replace(/^[-•·•]+\s*/, "");

  if (!n) return sanitizeStoryMemoryText(String(raw || "")).trim();
  if (!t) return fallbackLine;

  // Prefer the first segment that starts with "이름:" if present
  const idx = t.indexOf(`${n}:`);
  if (idx >= 0) t = t.slice(idx);

  // Extract action / emotions
  let action = "";
  let emoPart = "";
  if (t.includes("/")) {
    const parts = t.split("/");
    const left = parts.shift() || "";
    emoPart = parts.join("/");
    action = left.replace(`${n}:`, "").trim();
  } else {
    action = t.replace(`${n}:`, "").trim();
  }
  // sanitize occasional oddities from model output (ellipsis, meta wording)
  action = action.replace(/[.·…]{2,}/g, "").trim();
  action = action.replace(/…/g, "").trim();
  action = action.replace(/(?:이라는|란)\s*단어/g, "").trim();
  action = action.replace(/뭐라고/g, "무슨 말이냐고");
  action = action.replace(/\s+/g, " ").trim();
  if (action.length < 2) return fallbackLine;

  const emos = extractEmotionsFromText(emoPart || t);
  return formatOneLineStatus(n, action, emos) || fallbackLine;
}

function heuristicOneLineStatusFromText(raw: string, name: string, userName: string): string {
  const clean = cleanTurnTextForEncounter(String(raw || ""));
  const action = heuristicCharacterActionTowardPersona(clean, userName);
  const emos = extractEmotionsFromText(clean);
  return formatOneLineStatus(name, action, emos);
}

async function summarizeOneLineStatusForCharacter(raw: string, name: string, userName: string, opts: any): Promise<string> {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const u = sanitizeStoryMemoryText(String(userName || "")).trim() || "주인공";
  if (!n) return "";

  const fallbackLine = heuristicOneLineStatusFromText(raw, n, u);

  const guidance = [
    `아래는 사용자('${u}')와 인물('${n}')의 대화 일부다.`,
    "현재 상태를 반드시 1줄로만 출력한다.",
    `출력 형식은 정확히 '${n}: (사용자에게 한 행동) / (감정단어2~3개)' 이다.`,
    "감정은 한국어 단어만 2~3개로, 쉼표로만 구분한다.",
    "행동은 20~35자 내의 짧은 구문으로 쓴다.",
    "마크다운/불릿/따옴표/이모지 금지. 평문만.",
  ].join(" ");

  const body = await summarizeLongMemoryKorean({
    text: String(raw || "").slice(0, 14000),
    targetChars: 120,
    guidance,
    opts,
  });

  return normalizeOneLineStatus(String(body || ""), n, fallbackLine);
}

function heuristicPersonaChangeFromTurn(cleanText: string, name: string, rosterRx?: RegExp): string {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const t = String(cleanText || "");
  if (!n || !t) return "";

  // If character has an explicit speaker tag, we at least know they spoke.
  if (hasSpeakerTag(t, n)) {
    return `${n}의 말에 반응함`;
  }

  const idx = firstMentionIndex(t, n, rosterRx);
  const w0 = Math.max(0, idx - 180);
  const w1 = Math.min(t.length, idx + 260);
  const win = idx >= 0 ? t.slice(w0, w1) : t;

  if (/경고/.test(win)) return `${n}에게 경고함`;
  if (/(노려|노렸|째려)/.test(win)) return `${n}를 노려봄`;
  if (/무시/.test(win)) return `${n}를 무시함`;
  if (/거절/.test(win)) return `${n}의 제안을 거절함`;
  if (/(제안|부탁|요청)/.test(win)) return `${n}의 제안을 들음`;
  if (/(질문|묻|물었)/.test(win)) return `${n}에게 질문함`;
  if (/(대답|답했)/.test(win)) return `${n}의 말에 대답함`;
  if (/(웃|미소)/.test(win)) return `${n}에게 웃음으로 반응함`;

  return `${n}와 대화를 나눔`;
}


// Change log line must be persona-targeted: "페르소나(=userName)에게 한 행동/변화".
// - MUST include persona name, and we force it to be the FIRST token (예: "이춘복에게 경고함").
// - If no clear persona-targeted action exists, return "" so this turn is skipped for this character.
function heuristicChangeTowardPersonaFromTurn(cleanText: string, name: string, userName: string, rosterRx?: RegExp): string {
  const persona = sanitizeStoryMemoryText(String(userName || "")).trim() || "주인공";
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const t = String(cleanText || "");
  if (!persona || !n || !t) return "";

  // Focus window around where persona + character are close (reduces picking other people's events)
  const idxC = firstMentionIndex(t, n, rosterRx);
  const idxP = t.indexOf(persona);

  let win = t;
  if (idxC >= 0 && idxP >= 0) {
    const center = Math.floor((idxC + idxP) / 2);
    const w0 = Math.max(0, center - 260);
    const w1 = Math.min(t.length, center + 340);
    win = t.slice(w0, w1);
  } else if (idxC >= 0) {
    const w0 = Math.max(0, idxC - 260);
    const w1 = Math.min(t.length, idxC + 340);
    win = t.slice(w0, w1);
  } else if (idxP >= 0) {
    const w0 = Math.max(0, idxP - 260);
    const w1 = Math.min(t.length, idxP + 340);
    win = t.slice(w0, w1);
  }

  // Require some interaction cue. If missing, still return a safe fallback.
  // (This function is only called after encounter validation; we must output 1 line per encounter turn.)
  const hasCue =
    INTERACTION_CUE_RX.test(win) ||
    QUOTE_CUE_RX.test(win) ||
    /[\?？]/.test(win) ||
    hasSpeakerTag(t, n);

  if (!hasCue) {
    // Even when the turn is mostly narration (no obvious quote / ask / interaction verb),
    // try to keep at least one meaningful persona-targeted signal.
    if (/1인\s*파티/.test(win)) return `${persona}와의 관계를 부정하며 1인 파티를 주장함`;
    if (/(구제\s*불능|망상\s*환자)/.test(win)) return `${persona}를 '구제 불능의 망상 환자'로 재분류`;
    if (/(공격|때리|때렸|치|쳤|찌르|찔렀|베어|베었|쏘|쐈|발사|패|폭행)/.test(win)) return `${persona}를 공격함`;
    if (/(비웃|비꼬|조롱|빈정|냉소|코웃음|피식)/.test(win)) return `${persona}에게 비꼬며 조롱함`;
    if (/(노려|노렸|째려)/.test(win)) return `${persona}를 노려봄`;
    if (/무시/.test(win)) return `${persona}를 무시함`;
    if (/거절/.test(win)) return `${persona}의 제안을 거절함`;

    if (/(뇌진탕|정신\s*차리|강제\s*퇴거|퇴거)/.test(win)) {
      const detail = deriveWarnDetailFromWin(win, persona) || "경고함";
      return `${persona}에게 ${detail}`.replace(/\s+/g, " ").trim();
    }

    // Emotion-only fallback (never quotes)
    const emos = extractEmotionsFromText(win);
    const e = (emos || []).find((x) => x && x !== "중립") || (emos || [])[0] || "";
    if (e) {
      if (e === "경계" || e === "경계심") return `${persona}를 경계하며 대치함`;
      if (e === "불안" || e === "불안감") return `${persona}의 상태를 걱정하며 불안해함`;
      if (e === "황당함" || e === "의아함") return `${persona}의 행동에 황당해함`;
      if (e === "무관심") return `${persona}에게 무관심하게 반응함`;
      if (e === "역겨움") return `${persona}에게 역겨움을 드러냄`;
      if (e === "불쾌감" || e === "불쾌함") return `${persona}에게 불쾌감을 드러냄`;
      if (e === "혐오") return `${persona}에게 혐오감을 드러냄`;
      if (e === "경멸") return `${persona}에게 노골적인 경멸을 드러냄`;
      if (e === "분노") return `${persona}에게 분노를 드러냄`;
      if (e === "짜증") return `${persona}에게 짜증을 냄`;
      if (e === "기대") return `${persona}에게 기대감을 보임`;
      if (e === "안도") return `${persona}에게 안도함`;
      if (e === "기쁨") return `${persona}에게 기뻐함`;
      if (e === "슬픔") return `${persona}에게 슬퍼함`;
      if (e === "공포" || e === "공포심" || e === "두려움") return `${persona}를 두려워함`;
    }

    return `${persona}에게 상황을 관찰하며 반응함`;
  }

  // Relationship / emotion stage lines (examples the user wants)
  if (/제거\s*대상/.test(win)) return `${persona}를 제거 대상으로 간주하기 시작함`;
  if (/(살의|죽이|처단)/.test(win)) return `${persona}에 대한 혐오감이 살의로 변화`;
  if (/(경멸\s*단계|관계[^\n]{0,20}경멸)/.test(win)) return `${persona}에 대한 관계가 '경멸' 단계로 진입함`;
  if (/(분노[^\n]{0,20}허탈|허탈함)/.test(win)) return `${persona}에 대한 감정이 분노를 넘어 허탈함으로 변화`;
  if (/(혐오|역겨움)/.test(win) && /(표출|드러내|노골)/.test(win)) return `${persona}에게 극도의 혐오감 표출`;
  if (/F\.U\.C\.K/i.test(win) && /MBTI/i.test(win)) return `${persona}에게 MBTI 'F.U.C.K'이라고 말하며 극도의 혐오감 표출`;
  if (/1인\s*파티/.test(win)) return `${persona}와의 관계를 부정하며 1인 파티를 주장함`;
  if (/(구제\s*불능|망상\s*환자)/.test(win)) return `${persona}를 '구제 불능의 망상 환자'로 재분류`;

  // Action lines (persona-first)
  {
    const warnRx = /(경고|질책|꾸짖|경계)/i;
    if (warnRx.test(win) || /(뇌진탕|정신\s*차리|강제\s*퇴거|퇴거)/.test(win)) {
      const detail = deriveWarnDetailFromWin(win, persona) || "경고함";
      return `${persona}에게 ${detail}`.replace(/\s+/g, " ").trim();
    }
  }
  if (/(공격|때리|때렸|치|쳤|찌르|찔렀|베어|베었|쏘|쐈|발사|패|폭행)/.test(win)) return `${persona}를 공격함`;
  if (/(저지|막아|가로막)/.test(win)) return `${persona}의 행동을 저지함`;
  if (/제압/.test(win)) return `${persona}를 제압하려 함`;
  if (/(노려|노렸|째려)/.test(win)) return `${persona}를 노려봄`;
  if (/무시/.test(win)) return `${persona}를 무시하고 이동함`;
  if (/거절/.test(win)) return `${persona}의 제안을 거절함`;
  {
    const askRx = /(질문|묻|물었|물어|캐묻|따져|추궁|요구)/i;
    if (askRx.test(win)) {
      const detail = deriveAskDetailFromWin(win, persona) || "따져묻고 추궁함";
      return `${persona}에게 ${detail}`.replace(/\s+/g, " ").trim();
    }
  }

  {
    const obsRx = /(관찰|지켜보|주시|살피|응시)/i;
    if (obsRx.test(win)) {
      const clause = deriveObserveDetailFromWin(win, persona);
      if (clause) return `${persona}의 ${clause}을 관찰함`;
      return `${persona}의 행동을 관찰함`;
    }
  }
  if (/(대답|답했)/.test(win)) return `${persona}에게 대답함`;

  // If we got here, we had cues but none mapped cleanly: still keep a minimal but persona-targeted line.
  return `${persona}에게 대화를 이어감`;
}

function normalizeChangeLineForName(name: string, raw: string, fallback: string): string {
  const n = sanitizeStoryMemoryText(String(name || "")).trim();
  const fb = sanitizeStoryMemoryText(String(fallback || "")).replace(/\s+/g, " ").trim() || `${n}와 대화를 나눔`;

  let t = sanitizeStoryMemoryText(String(raw || "")).replace(/\s+/g, " ").trim();
  t = stripTurnPrefix(t);
  t = t.replace(/^[-•·\u2022]+\s*/, "");

  if (!n) return sanitizeStoryMemoryText(String(raw || "")).trim();
  if (!t) return fb;

  // If it starts like "이름은 ..." convert to "이름에게 ..." style if possible.
  const subj = new RegExp(`^${escapeRegExp(n)}\\s*(?:은|는|이|가)\\s+`, "i");
  if (subj.test(t)) {
    const rest = t.replace(subj, "").trim();
    if (rest) t = `${n}에게 ${rest}`;
  }

  return t.startsWith(n) ? t : fb;
}

async function summarizeTurnChangesForNames(
  raw: string,
  names: string[],
  userName: string,
  opts: any
): Promise<Record<string, string>> {
  const u = sanitizeStoryMemoryText(String(userName || "")).trim() || "주인공";
  const list = (names || [])
    .map((n) => sanitizeStoryMemoryText(String(n || "")).trim())
    .filter(Boolean);
  if (!list.length) return {};

  const guidance = [
    "아래는 1턴(짧은 구간)의 대화다.",
    `사용자(주인공)의 이름은 '${u}'이다. 주어는 굳이 쓰지 말고 생략한다.`,
    "아래 인물 목록 각각에 대해, 이 턴에서 사용자와의 관계/태도 변화(또는 핵심 상호작용)를 한 줄로 요약해라.",
    "출력은 반드시 JSON 오브젝트만. 키는 인물명 그대로.",
    "값은 1줄(60자 이내)이며, 반드시 해당 인물명으로 시작한다.",
    "값은 '인물명+조사(을/를/에게/한테/와/과/의...)' 형태로 이어지게 쓰면 더 좋다.",
    "따옴표/마크다운/불릿/이모지 금지.",
    "의미 있는 변화가 없으면 '인물명와 대화를 나눔' 같은 평문으로 써라.",
    "인물 목록: " + list.join(", "),
  ].join(" ");

  const body = await summarizeLongMemoryKorean({
    text: String(raw || "").slice(0, 14000),
    targetChars: Math.max(180, Math.min(520, 80 + list.length * 70)),
    guidance,
    opts,
  });

  const parsed = safeJsonParseLoose<Record<string, any>>(String(body || "").trim(), {});
  const out: Record<string, string> = {};
  if (parsed && typeof parsed == "object") {
    for (const n of list) {
      const v = (parsed as any)[n];
      if (typeof v === "string") out[n] = v;
    }
  }
  return out;
}
// --- Heuristics: proper-noun people only (고유명사 인물) ---

const CROWD_KEYWORDS = [
  "무리",
  "떼",
  "군중",
  "피난민",
  "구경꾼",
  "생존자",
  "여고생",
  "남성",
  "중년",
  "헌터",
  "직원",
  "협회",
  "길드",
  "교사들",
  "사람들",
  "학생들",
];

const MONSTER_KEYWORDS = [
  "고블린",
  "홉고블린",
  "슬라임",
  "악어",
  "박쥐",
  "쥐",
  "마수",
  "괴물",
  "몬스터",
];
// Strong blocklist to avoid registering generic nouns/adjectives as people.
// (We prefer false-negatives over polluted memory cards.)
const NONPERSON_EXACT = new Set<string>([
  "공기",
  "무거운",
  "요구",
  "요청",
  "조건",
  "규칙",
  "상태",
  "장면",
  "상황",
  "분위기",
  "침묵",
  "소리",
  "목소리",
  "마음",
  "기분",
  "생각",
  "느낌",
  "몸",
  "얼굴",
  "눈",
  "입",
  "손",
  "발",
  "가슴",
  "심장",
  "물",
  "불",
  "바람",
  "빛",
  "어둠",
  "시간",
  "장소",
  "오늘",
  "내일",
  "지금",
  "방금",
  "이제",
  "처음",
  "마지막",
  "다음",
  "그때",
  "이것",
  "저것",
  "그것",
  "여기",
  "저기",
  "거기",
  "누구",
  "무엇",
  "왜",
  "어떻게",
  "그리고",
  "하지만",
  "그래서",
  "또는",
  "또한",
  "그러나",
  "즉",
  "만약",
  "아마",
  "혹시",
  "정말",
  "진짜",
  "너무",
  "조금",
  "모두",
  "다시",
  "계속",
  "갑자기",
  "천천히",
  "조용히",
  "빠르게",
  "가만히",
  "자신",
  "상대",
  "대사",
  "지문",
  "INFO",
  "STATUS",
  "시스템",
  "제작자",
  "프리셋",
  "선생",
  "님",
  "씨",
  "형",
  "오빠",
  "누나",
  "언니",
  "아저씨",
  "아줌마",
  "관리",
  "관리국",
  "관리부",
  "관리국장",
  "관리 국장",
  "관리국장님",
  "관리 국장님",
  "국장",
  "국장님",
  "부장",
  "부장님",
  "팀장",
  "팀장님",
  "과장",
  "과장님",
  "대리",
  "대리님",
]);

const NONPERSON_SUFFIX_RX = /(함|기|것|때|중|등|감|성|적|점|값|방|쪽|각|수|말|데|곳|건)$/;

// Korean surname heuristic (성씨 기반) — reduces false positives.
// - 1-syllable surnames: char-class
// - 2-syllable surnames: explicit list
const KO_SURNAME_1 = "김이박최정강조윤장임오한신서권황안송전홍고문양손배백허유남심노하곽성차주우구민진나채원천방공류";
const KO_SURNAME_2 = ["남궁", "제갈", "선우", "서문", "독고", "사공", "동방", "황보", "어금"];

function isLikelyNonPerson(name: string): boolean {
  const t = sanitizeStoryMemoryText(String(name || ""));
  if (!t) return true;
  if (t.length < 2) return true;

  // 동사/형용사 활용 형태(예: "가졌어요")는 인물명이 아닐 확률이 매우 높음
  const verbishEndingRx =
    /(어요|아요|해요|지요|네요|군요|까요|입니다|합니(?:다|까)|했어요|했어|했다|한다|된다|됐(?:어|다)|있어요|없어요)$/;
  if (verbishEndingRx.test(t)) return true;

  // 경칭/직함이 단독으로 나온 경우 (예: "선생님")는 인물명이 아님
  const honorificTokens = new Set([
    "님",
    "씨",
    "선생",
    "선생님",
    "교수",
    "박사",
    "사장",
    "회장",
    "부장",
    "과장",
    "대리",
    "팀장",
    "국장",
    "장군",
    "총장",
    "의원",
  ]);

  if (honorificTokens.has(t)) return true;

  // stopwords: 단, 경칭/직함은 "단독"일 때만 제외하고, "스즈키 선생" 같은 형태는 허용
  if (NONPERSON_EXACT.has(t) && !honorificTokens.has(t)) return true;
  if (NONPERSON_SUFFIX_RX.test(t)) return true;

  const toks = t.split(/\s+/).filter(Boolean);
  if (toks.length > 1) {
    if (toks.some((x) => NONPERSON_EXACT.has(x) && !honorificTokens.has(x))) return true;
  }

  // 숫자 포함은 대부분 비인물(턴, T5 등)
  if (/\d/.test(t)) return true;

  // 명백한 수식어+직함 (거대한 국장 등) 차단
  if (/^(?:거대한|작은|무거운|가벼운|날카로운|차가운|뜨거운)\s+/.test(t)) return true;

  return false;
}

// Allow names that are explicitly listed in the roster, even if they are very short
// (e.g. "린"), while keeping the original conservative filtering for everything else.
function isLikelyNonPersonRespectRoster(name: string, rosterSet: Set<string> | null | undefined): boolean {
  const t = sanitizeStoryMemoryText(String(name || "")).trim();
  if (!t) return true;

  // If it's in the roster, accept it.
  if (rosterSet && rosterSet.size) {
    try {
      const key = normalizeNameKey(t);
      const baseKey = normalizeNameKey(stripTrailingHonorific(t));
      if (key && rosterSet.has(key)) return false;
      if (baseKey && rosterSet.has(baseKey)) return false;
    } catch {
      // ignore
    }
  }

  return isLikelyNonPerson(t);
}

function uniq(arr: string[]): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const x of arr) {
    const t = String(x || "").trim();
    if (!t) continue;
    const k = t.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(t);
  }
  return out;
}

// Rule-based entity guess (fast path).
// Rule-based entity guess (fast path).

const ROSTER_CACHE = new Map<
  string,
  { at: number; names: string[]; set: Set<string>; rx: Map<string, RegExp> }
>();
const ROSTER_TTL_MS = 60_000;

function normalizeNameKey(name: string): string {
  return sanitizeStoryMemoryText(String(name || ""))
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function stripTrailingHonorific(name: string): string {
  const t = sanitizeStoryMemoryText(String(name || "")).replace(/\s+/g, " ").trim();
  const m = t.match(/^(.*?)(?:\s*(?:님|씨|선생님|선생|교수|박사|사장|회장|부장|과장|대리|팀장|국장))$/);
  return m && m[1] ? m[1].trim() : t;
}

function escapeRegExp(s: string): string {
  return String(s || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const HONORIFIC_TAIL = /(님|씨|선생님|선생|교수|박사|사장|회장|부장|과장|대리|팀장|국장)$/;

function buildRosterMentionRegex(name: string): RegExp {
  const raw = sanitizeStoryMemoryText(String(name || "")).replace(/\s+/g, " ").trim();
  const parts = raw.split(/\s+/).map(escapeRegExp).join("\\s+");
  const honorificOpt = HONORIFIC_TAIL.test(raw)
    ? ""
    : "(?:\\s*(?:님|씨|선생님|선생|교수|박사|사장|회장|부장|과장|대리|팀장|국장))?";

  const particle = "(?:은|는|이|가|을|를|와|과|에게|한테|에서|으로|로|의|도|만|부터|까지|랑|하고|께서)";
  // Include '|' because many chats format as "이름|❤️72|...".
  // Also include fullwidth pipe '｜' which can appear in copied text.
  const boundary = `(?=(?:\\s|[\\r\\n]|$|[\\.,!?:;"'”’\\)\\]\\}\|｜])|${particle})`;

  // NOTE: left boundary blocks accidental substring hits ("미연시" vs "미연").
  // right side allows particles / punctuation / whitespace / end.
  return new RegExp(
    `(?<![0-9A-Za-z가-힣\\u3040-\\u30FF\\u4E00-\\u9FFF])(${parts}${honorificOpt})${boundary}`,
    "gi"
  );
}

function getRosterCache(db: any, chatId: string): { names: string[]; set: Set<string>; rx: Map<string, RegExp> } {
  const now = Date.now();
  const cached = ROSTER_CACHE.get(chatId);
  if (cached && now - cached.at < ROSTER_TTL_MS) return { names: cached.names, set: cached.set, rx: cached.rx };

  const names: string[] = [];
  const set = new Set<string>();
  const rx = new Map<string, RegExp>();

  try {
    const chat = db.prepare("SELECT presetId FROM chats WHERE id = ?").get(chatId) as any;
    const presetId = chat?.presetId ? String(chat.presetId) : "";
    if (presetId) {
      const preset = db.prepare("SELECT memoryRoster FROM presets WHERE id = ?").get(presetId) as any;
      const arr = safeJsonParse<any>(preset?.memoryRoster ?? "[]", []);
      if (Array.isArray(arr)) {
        for (const it of arr) {
          const n = sanitizeStoryMemoryText(String(it || "")).replace(/\s+/g, " ").trim();
          if (!n) continue;
          names.push(n);
        }
      }
    }
  } catch {
    // ignore
  }

  const uniqNames = uniq(names).filter((n) => !!sanitizeStoryMemoryText(n));
  for (const n of uniqNames) {
    const key = normalizeNameKey(n);
    if (key) set.add(key);
    const base = stripTrailingHonorific(n);
    if (base && base !== n) set.add(normalizeNameKey(base));
    try {
      rx.set(n, buildRosterMentionRegex(n));
    } catch {
      // ignore
    }
  }

  ROSTER_CACHE.set(chatId, { at: now, names: uniqNames, set, rx });
  return { names: uniqNames, set, rx };
}

function findRosterMentions(raw: string, roster: { names: string[]; rx: Map<string, RegExp> }, max: number): string[] {
  const text = String(raw || "");
  if (!text) return [];
  if (!roster?.names?.length) return [];

  const hits: { name: string; idx: number }[] = [];
  for (const n of roster.names) {
    const r = roster.rx.get(n);
    if (!r) continue;
    try {
      r.lastIndex = 0;
      const m = r.exec(text);
      if (m) hits.push({ name: n, idx: Math.max(0, Number(m.index || 0)) });
    } catch {
      // ignore
    }
  }

  hits.sort((a, b) => a.idx - b.idx);
  const out: string[] = [];
  for (const h of hits) {
    if (out.includes(h.name)) continue;
    out.push(h.name);
    if (out.length >= max) break;
  }
  return out;
}



type RosterCache = { names: string[]; set: Set<string>; rx: Map<string, RegExp> };

type LabeledMsg = { role: "user" | "assistant"; text: string };

type TurnChunk = { turn: number; text: string };

type EncounterInfo = { turns: number[]; lastTurn: number; lastText: string };

function parseLabeledTranscript(raw: string): LabeledMsg[] {
  const s0 = String(raw || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  if (!s0.trim()) return [];

  const lines = s0.split("\n");
  const out: LabeledMsg[] = [];
  let cur: LabeledMsg | null = null;

  const startRx = /^(User|Assistant):\s*(.*)$/i;

  for (const line of lines) {
    const m = String(line || "").match(startRx);
    if (m) {
      if (cur) out.push(cur);
      const tag = String(m[1] || "").toLowerCase();
      const rest = String(m[2] || "");
      cur = { role: tag === "user" ? "user" : "assistant", text: rest };
      continue;
    }

    if (!cur) continue;
    cur.text = cur.text + "\n" + String(line || "");
  }
  if (cur) out.push(cur);

  return out.map((m) => ({ role: m.role, text: String(m.text || "").trimEnd() }));
}

function splitTranscriptIntoAssistantTurns(raw: string, startTurn: number, endTurn: number): TurnChunk[] {
  const st = Math.max(1, Math.floor(Number(startTurn || 1)));
  const ed = Math.max(st, Math.floor(Number(endTurn || st)));

  const msgs = parseLabeledTranscript(raw);
  if (!msgs.length) return [];

  const out: TurnChunk[] = [];
  let turn = st;
  let buf: string[] = [];

  for (const m of msgs) {
    const tag = m.role === "user" ? "User" : "Assistant";
    const line = `${tag}: ${String(m.text || "").trimEnd()}`;
    buf.push(line);

    if (m.role === "assistant") {
      out.push({ turn, text: buf.join("\n") });
      buf = [];
      turn += 1;
      if (turn > ed) break;
    }
  }

  return out;
}

function cleanTurnTextForEncounter(text: string): string {
  const lines = String(text || "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n");

  const out: string[] = [];
  for (const ln of lines) {
    let s = String(ln || "");
    s = s.replace(/^(?:User|Assistant):\s*/i, "");
    s = s.trim();
    if (!s) continue;

    // Handle structured INFO KV lines.
    // - Most KEY: VALUE lines are meta and should not influence entity/encounter detection.
    // - NPC: [이름] ... lines carry the speaking character. Convert into a speaker tag so encounters can be detected.
    const mKV = s.match(/^([A-Z][A-Z0-9_]{1,15})\s*:\s*(.*)$/);
    if (mKV) {
      const key = String(mKV[1] || "").trim();
      const rest0 = String(mKV[2] || "").trim();
      if (key === "NPC") {
        let npcName = "";
        let npcRest = rest0;

        // Prefer bracketed name: NPC: [주모] ...
        const mB = npcRest.match(/^\[([^\]]{1,24})\]\s*(.*)$/);
        if (mB) {
          npcName = String(mB[1] || "");
          npcRest = String(mB[2] || "");
        } else {
          // Fallback: first token (hangul) is treated as name.
          const mT = npcRest.match(/^([가-힣]{1,8})(?:\s+|$)(.*)$/);
          if (mT) {
            npcName = String(mT[1] || "");
            npcRest = String(mT[2] || "");
          }
        }

        npcName = sanitizeStoryMemoryText(npcName).replace(/\s+/g, " ").trim();
        npcRest = String(npcRest || "").trim();

        if (npcName) {
          const merged = `${npcName}: ${npcRest}`.trim();
          if (merged && !isMetaLine(merged) && !looksLikePipeChips(merged)) out.push(merged);
        }
      }
      // For any KEY: VALUE line (including NPC), do not keep the original raw KV line.
      continue;
    }

    if (/^(?:INFO|STATUS|META|SUMMARY)$/i.test(s)) continue;
    if (isMetaLine(s)) continue;
    if (looksLikePipeChips(s)) continue;
    out.push(s);
  }

  return out.join("\n").trim();
}

const INTERACTION_CUE_RX = /(말했|말하|대답|묻|물었|따져|추궁|웃|웃었|미소|끄덕|고개\s*(?:를)?\s*끄덕|노려|노렸|경고|속삭|외치|소리치|대꾸|응답|제안|거절|무시|부르|호칭)/i;
const QUOTE_CUE_RX = /["“”]/;

function hasSpeakerTag(text: string, name: string): boolean {
  const n0 = String(name || "").trim();
  if (!n0) return false;
  const base = stripTrailingHonorific(n0);
  const variants = uniq([n0, base].filter(Boolean));
  for (const v of variants) {
    const rx = new RegExp(`(^|\\n)\\s*${escapeRegExp(String(v || ""))}\\s*(?:[\|｜]|[:：])\\s*`, "i");
    if (rx.test(text)) return true;
  }
  return false;
}

// Extract speaker-tag style names like "주모: ..." or "주모 | ...".
// This lets the memory system track NPCs that are not listed in preset memoryRoster.
function extractSpeakerTagNames(cleanText: string, max: number): string[] {
  const t = String(cleanText || "");
  if (!t) return [];
  const out: string[] = [];
  const lines = t.split("\n");
  for (const ln of lines) {
    const s = String(ln || "").trim();
    if (!s) continue;
    const m = s.match(/^([가-힣]{1,8})\s*(?:[:：]|[\|｜])\s+/);
    if (!m?.[1]) continue;
    const name = sanitizeStoryMemoryText(m[1]).replace(/\s+/g, " ").trim();
    if (!name) continue;
    // Skip generic labels that sometimes appear as pseudo-speakers.
    const lower = name.toLowerCase();
    if (["사용자", "유저", "어시스턴트", "assistant", "user"].includes(lower)) continue;
    if (out.includes(name)) continue;
    out.push(name);
    if (out.length >= Math.max(1, Math.floor(Number(max || 0)))) break;
  }
  return out;
}

function firstMentionIndex(text: string, name: string, rosterRx?: RegExp): number {
  const t = String(text || "");
  if (!t) return -1;
  const n0 = String(name || "").trim();
  if (!n0) return -1;

  if (rosterRx) {
    try {
      rosterRx.lastIndex = 0;
      const m = rosterRx.exec(t);
      if (m) return Math.max(0, Number(m.index || 0));
    } catch {
      // ignore
    }
  }

  const base = stripTrailingHonorific(n0);
  const idx = t.indexOf(n0);
  if (idx >= 0) return idx;
  const idx2 = base && base !== n0 ? t.indexOf(base) : -1;
  return idx2;
}

function isRealEncounterInText(cleanText: string, name: string, rosterRx?: RegExp): boolean {
  const t = String(cleanText || "");
  const n0 = String(name || "").trim();
  if (!t || !n0) return false;

  const idx = firstMentionIndex(t, n0, rosterRx);
  if (idx < 0) return false;

  // Strong evidence: explicit speaker tag ("이름: ..." or "이름 | ...")
  if (hasSpeakerTag(t, n0)) return true;

  const w0 = Math.max(0, idx - 160);
  const w1 = Math.min(t.length, idx + 260);
  const window = t.slice(w0, w1);

  // We require at least one interaction cue near the mention.
  // NOTE: quote-only presence is NOT enough (prevents name-only false positives).
  if (INTERACTION_CUE_RX.test(window)) return true;

  return false;
}

function detectEncountersByTurn(turnChunks: TurnChunk[], roster: RosterCache, userName: string) {
  const byName = new Map<string, EncounterInfo>();
  const ordered: string[] = [];

  for (const chunk of turnChunks) {
    const turn = Math.max(1, Math.floor(Number(chunk.turn || 0)));
    const clean = cleanTurnTextForEncounter(chunk.text);
    if (!clean) continue;

    let candidates: string[] = [];
    if (roster?.names?.length) {
      candidates = findRosterMentions(clean, roster, 12);
    } else {
      candidates = pickLikelyPersonNames(clean);
    }

    // Also allow speaker-tag names (e.g., "주모: ...") to become candidates even when preset roster exists.
    // This prevents missing NPCs that are not listed in preset memoryRoster.
    const sp = extractSpeakerTagNames(clean, 8);
    for (const n of sp) {
      if (!candidates.includes(n)) candidates.push(n);
    }

    candidates = uniq(candidates)
      .filter((n) => !!n && String(n).trim().length > 0)
      .filter((n) => String(n).trim() !== String(userName || "").trim())
      .filter((n) => !isLikelyNonPersonRespectRoster(String(n || ""), roster?.set));

    for (const name of candidates) {
      const r = roster?.rx?.get(name);
      if (!isRealEncounterInText(clean, name, r)) continue;

      const prev = byName.get(name);
      if (!prev) {
        byName.set(name, { turns: [turn], lastTurn: turn, lastText: chunk.text });
        ordered.push(name);
      } else {
        if (!prev.turns.includes(turn)) prev.turns.push(turn);
        if (turn >= prev.lastTurn) {
          prev.lastTurn = turn;
          prev.lastText = chunk.text;
        }
        byName.set(name, prev);
      }
    }
  }

  return { byName, entities: ordered };
}
const CLEANED_CHATS = new Set<string>();

function cleanupObviousGarbageCharacters(db: any, chatId: string) {
  if (CLEANED_CHATS.has(chatId)) return;
  CLEANED_CHATS.add(chatId);

  try {
    const roster = getRosterCache(db, chatId);
    const rows = db
      .prepare("SELECT id, canonicalName FROM character_memory WHERE chatId = ? LIMIT 200")
      .all(chatId) as any[];

    const delChar = db.prepare("DELETE FROM character_memory WHERE chatId = ? AND id = ?");
    const delBlocks = db.prepare("DELETE FROM character_memory_blocks WHERE chatId = ? AND charId = ?");

    for (const r of rows || []) {
      const name = sanitizeStoryMemoryText(String(r?.canonicalName || ""));
      if (!name) continue;

      // 명백히 비인물로 보이고, 프롬프트 로스터에도 없으면 정리
      if (isLikelyNonPerson(name)) {
        const key = normalizeNameKey(name);
        const baseKey = normalizeNameKey(stripTrailingHonorific(name));
        const allowed = roster && roster.set && roster.set.size > 0 ? (roster.set.has(key) || roster.set.has(baseKey)) : false;
        if (!allowed) {
          try {
            delBlocks.run(chatId, r.id);
          } catch {
            // ignore
          }
          try {
            delChar.run(chatId, r.id);
          } catch {
            // ignore
          }
        }
      }
    }
  } catch {
    // ignore
  }
}

function guessEntitiesRuleBased(raw: string): string[] {
  const text = String(raw || "");
  const found: string[] = [];

  // 1) Names + titles (e.g., "스즈키 선생", "김민수 대리")
  const rxTitle = /([가-힣A-Za-z\u3040-\u30FF\u4E00-\u9FFF]{2,20}\s*(?:선생|교감|교장|국장|회장|대리|과장|팀장|사장|교수|박사|경위|경감))/g;
  let m: RegExpExecArray | null;
  while ((m = rxTitle.exec(text))) {
    found.push(m[1]);
  }

  // 2) Korean full names (성씨 기반, 3~4글자)
  const particleOrEnd = "(?:\s*(?:씨|님|선생|선배|후배|대리|과장|팀장|사장|회장))?(?:은|는|이|가|을|를|와|과|에게|한테|에서|으로|로|의|도|만|부터|까지|랑|하고|께서)";
  const boundary = new RegExp(`(?=${particleOrEnd}|[\r\n]|$|[\.,!?:;"'”’\)\]\}\|｜])`);
  const koSurname2 = KO_SURNAME_2.join("|");
  const rxKoFull = new RegExp(
    `(?<![0-9A-Za-z가-힣])((?:${koSurname2})[가-힣]{2}|(?:[${KO_SURNAME_1}])[가-힣]{2})${boundary.source}`,
    "g"
  );

  while ((m = rxKoFull.exec(text))) {
    found.push(m[1]);
  }

  // 3) Spaced names (외국식 공백 이름: "세리자와 아키라")
  // NOTE: 공백 뒤에 '침묵/분위기' 같은 일반명사가 오는 경우(예: "공기 무거운 침묵")를 막기 위해
  //       "조사/호칭/구두점/개행/문장끝"에서만 매칭되도록 제한합니다.
  const rxKoSpaced = new RegExp(
    `(?<![0-9A-Za-z가-힣])([가-힣]{2,8}\s+[가-힣]{2,8})(?=${particleOrEnd}|[\r\n]|$|[\.,!?:;"'”’\)\]\}\|｜])`,
    "g"
  );

  while ((m = rxKoSpaced.exec(text))) {
    found.push(m[1]);
  }

  // 4) Single-token hangul names (2~6) — best-effort with strong stopword filtering.
  const rxKoToken = new RegExp(
    `(?<![0-9A-Za-z가-힣])([가-힣]{2,6})(?=${particleOrEnd}|[\r\n]|$|[\.,!?:;"'”’\)\]\}\|｜])`,
    "g"
  );

  while ((m = rxKoToken.exec(text))) {
    const cand = m[1];
    if (["그", "그녀", "당신", "너", "나", "우리", "저", "너희", "그들"].includes(cand)) continue;
    found.push(cand);
  }

  // 5) Japanese scripts (かな/カナ/漢字)
  const rxJpName = /(?<![0-9A-Za-z\u3040-\u30FF\u4E00-\u9FFF])([\u3040-\u30FF\u4E00-\u9FFF]{2,12})(?=([\r\n]|$|[\.,!?:;"'”’\)\]\}]))/g;
  while ((m = rxJpName.exec(text))) {
    const cand = m[1];
    if (["あなた", "君", "俺", "僕", "私"].includes(cand)) continue;
    found.push(cand);
  }

  // 6) English spaced names (fallback)
  const rxEnSpaced = /(?<![0-9A-Za-z])([A-Z][a-z]{1,20}\s+[A-Z][a-z]{1,20})(?=([\r\n]|$|[\.,!?:;"'”’\)\]\}]))/g;
  while ((m = rxEnSpaced.exec(text))) {
    found.push(m[1]);
  }

  return uniq(found).filter((n) => !isLikelyNonPerson(n));
}

async function extractProperNounPeopleLLM(raw: string, opts: any): Promise<string[]> {
  // LLM-based extraction used as a fallback to improve recall on Japanese names or unusual spacing.
  const guidance = [
    "아래 대화 구간에서 '인물'의 고유명사 이름만 JSON 배열로 출력한다.",
    "지명/기관/직책/몬스터/집단명(무리/떼/피난민/구경꾼 등)은 제외한다.",
    "확실한 이름만 포함한다. 없으면 []만 출력한다.",
    "출력은 JSON 배열만. 설명 금지.",
  ].join(" ");

  const body = await summarizeLongMemoryKorean({
    text: String(raw || "").slice(0, 20000),
    // small budget for extraction
    targetChars: 200,
    guidance,
    opts,
  });

  const trimmed = String(body || "").trim();
  const parsed = safeJsonParseLoose<string[]>(trimmed, []);
  if (!Array.isArray(parsed)) return [];
  return uniq(parsed.map((x) => String(x || "").trim())).filter((n) => !isLikelyNonPerson(n));
}

function guessLocation(raw: string): string {
  const text = String(raw || "");
  // Prefer explicit location markers.
  const m1 = text.match(/📍\s*위치\s*\|\s*([^\n]+)/);
  if (m1?.[1]) return sanitizeStoryMemoryText(m1[1]);

  // Common "T12 · 장소" style
  const m2 = text.match(/T\d+\s*·\s*([^\n]+)/);
  if (m2?.[1]) return sanitizeStoryMemoryText(m2[1]);

  // Fallback: first line with "학교/역/교감실" etc.
  const lines = text.split(/\r?\n/);
  for (const ln of lines) {
    const t = ln.trim();
    if (!t) continue;
    if (/(학교|역|교감실|교무실|사무실|편의점|배수로|던전|승강장|화장실)/.test(t)) {
      // avoid too long lines
      return sanitizeStoryMemoryText(t.slice(0, 60));
    }
  }
  return "";
}

function ensureSubject(name: string, sentence: string): string {
  const s = String(sentence || "").trim();
  if (!s) return "";
  // If sentence already starts with the name, keep.
  if (s.startsWith(name)) return s;
  // If starts with a pronoun, rewrite.
  if (/^(그녀|그가|그는|그|당신|너는|너가)\b/.test(s)) {
    return `${name}은 ${s.replace(/^(그녀|그가|그는|그|당신|너는|너가)\b\s*/, "")}`.trim();
  }
  // Otherwise, prefix with subject.
  return `${name}은 ${s}`.trim();
}

function pickLastMentionSentence(raw: string, name: string): string {
  const text = String(raw || "");
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  let last = "";
  for (const ln of lines) {
    if (!ln.includes(name)) continue;
    const cleaned = sanitizeActionLine(ln);
    if (!cleaned) continue;
    last = cleaned;
  }

  if (!last) return "";
  return sanitizeStoryMemoryText(last).slice(0, 180);
}

async function summarizeScene(raw: string, perTurnChars: number, turns: number, opts: any, userName?: string): Promise<string> {
  const soft = Math.max(280, Math.min(1200, Math.round(perTurnChars * turns * 0.9)));
  const guidance = [
    "대화 구간의 사건을 3~6문장으로 요약한다.",
    "문장은 반드시 주어(인물/기관)를 명시해 '누가 무엇을 했다' 형태로 쓴다.",
    "대명사(그/그녀/당신)로 문장을 시작하지 않는다.",
    "문장 앞에 '!' '*' 같은 기호를 붙이지 않는다.",
    "마크다운 금지. 평문만.",
    userName ? `사용자(주인공)의 이름은 '${userName}'이다. 사용자를 다른 이름/별칭으로 쓰지 말고 반드시 이 이름만 사용한다. 첫 문장은 '${userName}'로 시작한다.` : "",
  ].filter(Boolean).join(" ");

  const body = await summarizeLongMemoryKorean({
    text: String(raw || "").slice(0, 50000),
    targetChars: soft,
    guidance,
    opts,
  });


  let out = sanitizeStoryMemoryText(body);

  // Guard: '제정신' 같은 단어가 사용자 이름으로 오인되는 케이스 방지
  if (userName && userName.trim() && userName.trim() !== "사용자") {
    out = out.replace(/웅제정신/g, userName.trim());
  }

  return out;
}

async function summarizeCharacterStatus(raw: string, name: string, opts: any, userName: string): Promise<{ status: string; relation: string; change?: string }> {
  const guidance = [
    `아래 대화 구간에서 인물 '${name}'에 대해서만 요약한다.`,
    "다음 JSON 오브젝트만 출력한다: {\"relation\": string, \"status\": string, \"change\": string}",
    `relation: '${userName}'(사용자/주인공)와의 관계를 한 줄로(직책/포지션 포함).`,
    "status: 현재 태도/의도/감정 1~2문장.",
    "change: 이번 구간에서 관계/감정/목표가 바뀐 핵심 한 줄(없으면 빈 문자열).",
    "대명사로 문장을 시작하지 않는다. 마크다운 금지.",
  ].join(" ");

  const body = await summarizeLongMemoryKorean({
    text: String(raw || "").slice(0, 20000),
    targetChars: 260,
    guidance,
    opts,
  });


const parsed = safeJsonParseLoose<any>(String(body || "").trim(), null);
if (!parsed || typeof parsed !== "object") {
  // If the model doesn't return valid JSON, do NOT guess from INFO chips.
  return { relation: "", status: "", change: "" };
}

  const relationRaw = sanitizeStoryMemoryText(String(parsed.relation || ""));
  const statusRaw = sanitizeStoryMemoryText(String(parsed.status || ""));
  const change = sanitizeStoryMemoryText(String(parsed.change || ""));

  let relationLine = ensureSubject(name, relationRaw)
    .replace(new RegExp(`^${name}은\\s+`), "")
    .trim();
  if (!relationLine) relationLine = "대화 상대";

  let statusLine = ensureSubject(name, statusRaw).trim();

  return { relation: relationLine, status: statusLine, change };
}

function upsertCharacter(
  db: AnyDb,
  chatId: string,
  name: string,
  patch: { relation?: string; status?: string; lastAction?: string; lastSeenTurn?: number; affinity?: number }
) {
  const now = Date.now();

  // NOTE: relation/lastAction are intentionally unused (UI shows status only).
  // We still keep the columns for compatibility, but we always write empty values.
  const relPatch = "";
  const stPatch = sanitizeStoryMemoryText(String(patch.status ?? "")).trim();
  const actPatch = "";
  const seen = Number(patch.lastSeenTurn || 0);

  const affRaw = (patch as any).affinity;
  const affPatch = Number.isFinite(affRaw) ? Math.max(0, Math.min(999, Math.floor(Number(affRaw)))) : undefined;

  const row = db
    .prepare(`SELECT id, relation, status, lastAction, affinity, lastSeenTurn FROM character_memory WHERE chatId=? AND canonicalName=?`)
    .get(chatId, name) as any;

  if (!row) {
    const relationToInsert = "";
    const statusToInsert = stPatch || "";
    const lastActionToInsert = "";

    db.prepare(
      `INSERT INTO character_memory (chatId, canonicalName, aliases, relation, status, lastAction, affinity, threat, lastSeenTurn, createdAt, updatedAt)
       VALUES (?, ?, '[]', ?, ?, ?, ?, 0, ?, ?, ?)`
    ).run(chatId, name, relationToInsert, statusToInsert, lastActionToInsert, (affPatch ?? 0), seen, now, now);

    return db.prepare(`SELECT id FROM character_memory WHERE chatId=? AND canonicalName=?`).get(chatId, name) as any;
  }

  const nextRelation = "";

  let nextStatus = stPatch ? stPatch : String(row.status ?? "");
  const nextLastAction = "";

  // If existing status looks like meta/INFO, or duplicates lastAction, clear it unless explicitly overwritten.
  if (!stPatch) {
    const st = String(nextStatus || "").trim();
    const la = String(nextLastAction || "").trim();
    if (!st) {
      // keep empty
    } else if (st === la) {
      nextStatus = "";
    } else if (isMetaLine(st) || st.includes("|💗") || (st.startsWith("[") && st.includes("|") && st.endsWith("]"))) {
      nextStatus = "";
    }
  }

  // lastAction is intentionally empty.

  const nextSeen = Math.max(Number(row.lastSeenTurn || 0), seen);

  const nextAffinity = affPatch !== undefined ? affPatch : Math.max(0, Math.min(999, Math.floor(Number(row.affinity || 0))));

  db.prepare(`UPDATE character_memory SET relation=?, status=?, lastAction=?, affinity=?, lastSeenTurn=?, updatedAt=? WHERE id=?`).run(
    nextRelation,
    nextStatus,
    nextLastAction,
    nextAffinity,
    nextSeen,
    now,
    row.id
  );

  return { id: row.id };
}

function insertChange(db: AnyDb, chatId: string, characterId: number, turn: number, text: string) {
  const t = compactCharacterChangeText(text);
  if (!t) return;
  const trn = Math.max(1, Math.floor(Number(turn || 0)));
  const now = Date.now();
  // One line per (character, turn).
  // If refreshed again for the same turn, overwrite the existing line.
  try {
    db.prepare(`DELETE FROM character_change_log WHERE chatId=? AND characterId=? AND turn=?`).run(chatId, characterId, trn);
  } catch {
    // ignore
  }
  db.prepare(
    `INSERT INTO character_change_log (chatId, characterId, turn, text, createdAt) VALUES (?, ?, ?, ?, ?)`
  ).run(chatId, characterId, trn, t, now);
}

function insertScene(db: AnyDb, chatId: string, startTurn: number, endTurn: number, location: string, summary: string, entities: string[]) {
  const now = Date.now();
  const loc = sanitizeStoryMemoryText(location);
  const sum = sanitizeStoryMemoryText(summary);
  if (!sum) return;

  // (중요) 구간이 겹치는 기존 씬 요약은 제거한다.
  // - 예: 이전 버전에서 T1~T1 같은 부분 요약이 먼저 생성되고, 이후 T1~T5가 생성되며 중복/겹침이 발생할 수 있음
  // - 앞으로는 요약 구간(기본 5턴 블록)만 유지하고, 겹치는 구간은 새 구간으로 치환
  try {
    db.prepare(
      `DELETE FROM scene_memory
       WHERE chatId=?
         AND NOT (turnTo < ? OR turnFrom > ?)
         AND NOT (turnFrom=? AND turnTo=?)`
    ).run(chatId, startTurn, endTurn, startTurn, endTurn);
  } catch {
    // ignore
  }

  // 동일 구간(턴 범위)은 1개만 유지 (중복 방지)
  // uniq_scene_memory_chat_turn 인덱스(또는 동등 UNIQUE) 기준으로 UPSERT
  db.prepare(
    `INSERT INTO scene_memory (chatId, turnFrom, turnTo, location, summary, entities, tags, createdAt, updatedAt)
     VALUES (?, ?, ?, ?, ?, ?, '[]', ?, ?)
     ON CONFLICT(chatId, turnFrom, turnTo) DO UPDATE SET
       location=excluded.location,
       summary=excluded.summary,
       entities=excluded.entities,
       updatedAt=excluded.updatedAt`
  ).run(chatId, startTurn, endTurn, loc, sum, JSON.stringify(entities || []), now, now);
}

/**
 * Update story-memory tables for a summarized range.
 *
 * Notes:
 * - Best-effort: never throws to callers.
 * - Proper-noun people only.
 * - Hard-delete policy is implemented via DELETE routes; here we only INSERT/UPDATE.
 */
export async function updateStoryMemoryForRange(input: StoryMemoryRangeInput): Promise<void> {
  const db = input.db || defaultDb;
  const chatId = input.chatId;

  const userName = getUserDisplayName(db, chatId);

  // NOTE: "쓰레기 인물은 그냥 둔다" 정책 — 자동 정리/숨김을 수행하지 않음
  // cleanupObviousGarbageCharacters(db, chatId);
  const startTurn = Math.max(1, Math.floor(input.startTurn));
  const endTurn = Math.max(startTurn, Math.floor(input.endTurn));
  const rawText = String(input.rawText || "");
  const opts = input.opts;
  const turns = Math.max(1, endTurn - startTurn + 1);
  const perTurnChars = Math.max(30, Math.min(200, Math.round(Number(input.perTurnChars || 120) / 10) * 10));

  try {
    const roster = getRosterCache(db, chatId) as RosterCache;

    // 1) Split range transcript into assistant-turn chunks.
    // - rawText usually comes from formatTurns() => "User: ...\nAssistant: ...".
    // - If parsing fails, fall back to treating the whole block as a single chunk at endTurn.
    let chunks = splitTranscriptIntoAssistantTurns(rawText, startTurn, endTurn);
    if (!chunks.length) chunks = [{ turn: endTurn, text: rawText }];

    // 2) Encounter detection (prevents "name mentioned only" from becoming a meeting).
    // - Only entities with real interaction cues are kept.
    const { byName, entities } = detectEncountersByTurn(chunks, roster, userName);

    // 3) Scene memory: always store scene summary, but only keep encountered entities.
    const location = guessLocation(rawText);
    const sceneSummary = await summarizeScene(rawText, perTurnChars, turns, opts, userName);
    insertScene(db, chatId, startTurn, endTurn, location, sceneSummary, entities);

    // 4) Upsert character cards (status=2줄 고정, 최근 만남 기준) + affinity(❤️숫자) 저장
    const charIdByName = new Map<string, number>();
    let statusLlmUsed = 0;
    const STATUS_LLM_LIMIT = 0; // force heuristic: keep status short & deterministic

    for (const name of entities) {
      const info = byName.get(name);
      if (!info) continue;

      const lastTurn = Math.max(startTurn, Math.min(endTurn, Math.floor(Number(info.lastTurn || endTurn))));
      const lastText = String(info.lastText || "");
      const affinity = extractAffinityFromText(lastText);

      const fallbackLine = heuristicOneLineStatusFromText(lastText, name, userName);

      let status1 = "";
      if (statusLlmUsed < STATUS_LLM_LIMIT) {
        try {
          status1 = await summarizeOneLineStatusForCharacter(lastText, name, userName, opts);
          if (status1.trim()) statusLlmUsed += 1;
        } catch {
          // ignore
        }
      }

      if (!status1.trim()) status1 = fallbackLine;
      status1 = sanitizeStoryMemoryText(String(status1 || "")).replace(/\s+/g, " ").trim();

      const row = upsertCharacter(db, chatId, name, {
        relation: "",
        lastAction: "",
        status: sanitizeStoryMemoryText(status1),
        lastSeenTurn: lastTurn,
        affinity: affinity ?? undefined,
      }) as any;

      const cid = Number(row?.id || 0);
      if (cid) charIdByName.set(name, cid);
    }

    // 5) 관계변화(change_log) = 만난 '턴마다' 1줄 누적
    const namesByTurn = new Map<number, string[]>();
    for (const name of entities) {
      const info = byName.get(name);
      if (!info?.turns?.length) continue;
      for (const t of info.turns) {
        const trn = Math.max(startTurn, Math.min(endTurn, Math.floor(Number(t || 0))));
        const arr = namesByTurn.get(trn) || [];
        if (!arr.includes(name)) arr.push(name);
        namesByTurn.set(trn, arr);
      }
    }

    let turnLlmUsed = 0;
    const TURN_LLM_LIMIT = 0; // force heuristic: change lines must be persona-targeted & deterministic

    for (const chunk of chunks) {
      const trn = Math.max(startTurn, Math.min(endTurn, Math.floor(Number(chunk.turn || 0))));
      const names = namesByTurn.get(trn) || [];
      if (!names.length) continue;

      let turnMap: Record<string, string> = {};
      // LLM은 다인물 턴에서만 제한적으로 사용
      if (names.length >= 2 && turnLlmUsed < TURN_LLM_LIMIT) {
        try {
          turnMap = await summarizeTurnChangesForNames(chunk.text, names, userName, opts);
          if (turnMap && Object.keys(turnMap).length) turnLlmUsed += 1;
        } catch {
          // ignore
        }
      }

      const clean = cleanTurnTextForEncounter(chunk.text);

      for (const name of names) {
        const cid = charIdByName.get(name);
        if (!cid) continue;

        const rosterRx = roster?.rx?.get(name);
        const line = heuristicChangeTowardPersonaFromTurn(clean, name, userName, rosterRx);
        if (!line) continue;

        // DB에는 텍스트만 저장 (UI에서 [Txx] 접두사 부착)
        insertChange(db, chatId, cid, trn, line);
      }
    }
  } catch {
    // best effort: ignore
  }
}

/**
 * Lightweight per-turn refresh (NO LLM).
 * - Extract entities from the current turn text only (user+assistant)
 * - Upsert character cards with lastAction/lastSeenTurn
 * - Never touches relation/status unless the record is new
 */
export function upsertCharactersLightweightForTurn(input: {
  db?: AnyDb;
  chatId: string;
  turn: number;
  rawText: string;
  maxNames?: number;
}): void {
  const db = input.db || defaultDb;
  const chatId = String(input.chatId || "");
  const turn = Math.max(1, Math.floor(Number(input.turn || 0)));
  const rawText = String(input.rawText || "");
  const maxNames = Math.max(1, Math.min(12, Math.floor(Number(input.maxNames || 8))));
  try {
    const roster = getRosterCache(db, chatId) as RosterCache;
    if (!roster.names.length) return;

    const userName = getUserDisplayName(db, chatId);

    const clean = cleanTurnTextForEncounter(rawText);
    if (!clean) return;

    let entities = findRosterMentions(clean, roster, maxNames);
    entities = uniq(entities).filter((n) => !!n && !isLikelyNonPersonRespectRoster(n, roster.set));
    entities = entities.filter((n) => String(n).trim() !== String(userName || "").trim());

    for (const name of entities) {
      if (!name || isLikelyNonPersonRespectRoster(name, roster.set)) continue;

      // Prevent "name mentioned only" from becoming a meeting.
      const r = roster.rx.get(name);
      if (!isRealEncounterInText(clean, name, r)) continue;

      // Lightweight path: 1-line status + 턴별 change 1줄 + affinity 저장
      const affinity = extractAffinityFromText(rawText);
      const status1 = heuristicOneLineStatusFromText(rawText, name, userName);

      const rrx = roster.rx.get(name);
      const changeLine = heuristicChangeTowardPersonaFromTurn(clean, name, userName, rrx);
      // no persona-targeted action => do not record a turn in change_log (but still upsert status/affinity)

      const row = upsertCharacter(db, chatId, name, {
        relation: "",
        lastAction: "",
        status: sanitizeStoryMemoryText(status1),
        lastSeenTurn: turn,
        affinity: affinity ?? undefined,
      }) as any;
      if (changeLine) insertChange(db, chatId, Number(row?.id || 0), turn, changeLine);
    }
  } catch {
    // best effort
  }
}
