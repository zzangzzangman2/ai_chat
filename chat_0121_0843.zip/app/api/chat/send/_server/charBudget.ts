// Character-based budgeting helpers.
// Uses Array.from to count unicode codepoints consistently.

export function strlen(s: string): number {
  return Array.from(String(s || "")).length;
}

export function sliceChars(s: string, n: number): string {
  return Array.from(String(s || "")).slice(0, n).join("");
}

export function truncateToCharBudget(text: string, budget: number): string {
  const t = String(text || "").trim();
  if (strlen(t) <= budget) return t;

  // 문장 단위로 최대한 자연스럽게 자르기
  const head = sliceChars(t, budget);
  // Prefer cutting on paragraph boundaries first, then line breaks, then sentence-ending punctuation.
  const candidates = ["\n\n", "\n", ".", "!", "?", "\"", "'", ")", "]", "*"];
  let cut = -1;
  for (const c of candidates) {
    const idx = head.lastIndexOf(c);
    if (idx > cut) cut = idx;
  }
  const out = cut >= Math.floor(budget * 0.55) ? head.slice(0, cut + 1) : head;
  return out.trim();
}
