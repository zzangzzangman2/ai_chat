console.log("[chat/send] module loaded", new Date().toISOString());
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { randomUUID } from "crypto";
import { generateText, generateTextStream, summarizeKorean, summarizeLongMemoryKorean } from "@/lib/ai";
import { decryptIfPossible, encryptIfPossible } from "@/lib/crypto";

import { stripUrlsAndMediaMarkdown, LONG_MEMORY_SUMMARY_RULES } from "@/lib/memory_sanitize";// ---- 비용 추정(간단 버전) ----
import { isChatDebug, dbg } from "./_server/debug";
import { getModelPricing, estimateCost } from "./_server/billing";
import { resolvePersona, persistPersonaIfMissing, type PersonaOverride } from "./_server/persona";
import {
  strlenSummary,
  normalizeStoredMemorySummary,
  extractSummaryRangeBlocks,
  getSummarizedEndTurn,
} from "./_server/summaryStored";
import {
  selectMessagesForAssistantTurnRange,
  selectMessagesForAssistantTurnRangeCapped,
} from "./_server/turnRange";
import { strlen, sliceChars, truncateToCharBudget } from "./_server/charBudget";
import { distribute } from "./_server/distribute";
import {
  formatTurns,
  selectRecentByUserTurns,
  formatStoryTurns,
  formatStoryTurnsForMode,
  buildUserLineForMode,
  ensurePrefix,
  stripNamePrefixFromNarration,
  stripDialogueWrappedNarration,
  normalizeAnyFenceOpen,
  repairUnclosedAnyFence,
  wrapLooseMetaAsFence,
  stripTrailingTextAfterFinalFence,
  splitTrailingFenceBlockAtEnd,
  stripEndMarker,
  normalizeNovelOutput,
  normalizeNovelPlain,
enforceNovelOnlyOutput,
  estTokens,
  trimToComplete,
  preserveTrailingFenceBlockWithinBudget,
} from "./_server/textPolicy";
import { sanitizePromptCached } from "./_server/promptCache";
import { buildFormatGuide } from "./_server/formatGuide";
import { normalizeSummaryTail, sanitizeLongMemorySummary, upsertSummaryRangeBlock } from "./_server/memory";

function stripStandaloneSeparatorLines(s: string): string {
  // Remove noisy standalone separator lines that sometimes appear around images or status/meta blocks.
  // Keeps meaningful content intact.
  return s
    .split(/\r?\n/)
    .filter((line) => {
      const t = line.trim();
      if (t.length === 0) return true;
      // Common separators: ---  ___  ***  ===  ———  ━━━ etc.
      if (/^(?:[-–—=_*]|━){3,}$/.test(t)) return false;
      return true;
    })
    .join("\n");
}

function endsWithCompleteFence(s: string): boolean {
  const t = (s ?? "").trimEnd();
  if (!t.endsWith("```")) return false;

  const close = t.lastIndexOf("```");
  if (close < 0) return false;

  const beforeClose = t.slice(0, close);
  const open = beforeClose.lastIndexOf("```");
  if (open < 0) return false;

  // Ensure there's nothing but whitespace after the closing fence (trimEnd above guarantees this).
  // This is a lightweight guard to avoid auto-continuing when the model already ended with a full fenced block.
  return true;
}


function computeAssistantTurnNowAfterWrite(dbAny: any, chatId: string, assistantMsgId: string): number {
  try {
    const rows = dbAny
      .prepare(`SELECT id FROM messages WHERE chatId=? AND role='assistant' ORDER BY createdAt ASC`)
      .all(chatId) as any[];
    const idx = rows.findIndex((r) => String(r?.id) === String(assistantMsgId));
    if (idx >= 0) return idx + 1;
    return rows.length;
  } catch {
    return 0;
  }
}

// If a ```STATUS ...``` fenced block exists and is closed, remove any extra output after it.
// This prevents the model from "finishing STATUS" and then continuing narrative (wasted tokens / broken UI).
function trimAfterClosedStatusFence(s: string): { text: string; trimmed: boolean } {
  const src = String(s ?? "");
  const openIdx = src.search(/```\s*STATUS\b/i);
  if (openIdx < 0) return { text: src, trimmed: false };
  const closeIdx = src.indexOf("```", openIdx + 3);
  if (closeIdx < 0) return { text: src, trimmed: false };

  const end = closeIdx + 3;
  const after = src.slice(end);
  if (after.trim().length === 0) return { text: src, trimmed: false };
  return { text: src.slice(0, end).trimEnd(), trimmed: true };
}


function normalizeStatusFenceOpen(text: string): { normalized: boolean; text: string } {
  const s0 = String(text || "");
  const out = normalizeAnyFenceOpen(s0);
  return { normalized: out !== s0, text: out };
}

function repairUnclosedStatusFence(text: string): { repaired: boolean; text: string } {
  const s0 = String(text || "");
  const out = repairUnclosedAnyFence(s0);
  return { repaired: out !== s0, text: out };
}

// Return the end offset (index) of the last closed ```STATUS ... ``` block.
// - If no closed STATUS block exists, returns -1.
// - The returned index points to the end of the closing fence line (exclusive).
function findLastStatusFenceCloseEnd(text: string): number {
  const src = String(text ?? "");
  const openIdx = src.search(/```\s*STATUS\b/i);
  if (openIdx < 0) return -1;

  // Find the last line that is exactly ``` after the STATUS open.
  const re = /^```[ \t]*$/gm;
  let m: RegExpExecArray | null;
  let last = -1;
  while ((m = re.exec(src)) !== null) {
    if (m.index > openIdx) last = m.index;
  }
  if (last < 0) return -1;

  const nl = src.indexOf("\n", last);
  return nl >= 0 ? nl : src.length;
}




// Gemini Developer API(유료) 가격표(프롬프트 <= 200k tokens 구간)의 input/output 단가만 사용한다.
// 참고: https://ai.google.dev/gemini-api/docs/pricing
// 환율은 실시간이 아니라 기본값(환경변수로 덮어쓰기 가능)로 처리한다.
const DEFAULT_USD_TO_KRW = Number(process.env.USD_TO_KRW) || 1350;

function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}

export async function POST(req: Request) {
  const _reqId = `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
  const _url = new URL(req.url);
  console.log(`[chat/send][${_reqId}] -> ${req.method} ${_url.pathname}${_url.search}`);
  // 요청 헤더(ua/referer...) 로그는 너무 시끄러워서 기본 비활성.
  // 필요 시 CHAT_DEBUG_HEADERS=1 로만 켠다.
  if (process.env.CHAT_DEBUG_HEADERS === "1") {
    console.log(
      `[chat/send][${_reqId}] ua=${req.headers.get("user-agent") || ""} referer=${req.headers.get("referer") || ""}`
    );
  }
  // try/catch 경계에서 사용할 최소 로그 컨텍스트(블록 스코프 이슈 방지)
  let _cidForLog = "";
  let _reqIdForLog = "";
  let debugReasons: string[] = [];
  let _tEnd: (label: string) => void = () => {};
  let _tSendTotal = "";
  let _tPost = "";
  try {
    const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

	  const body = await req.json();
	  const wantStreamRaw = Boolean((body as any)?.stream);
	  // Respect client streaming flag. (Some models may be force-buffered later.)
	  let wantStream = wantStreamRaw;

    // body.userText 는 프론트에서 보내는 입력 텍스트.
    // 아래에서 동일 변수명을 다시 선언하지 않도록 별칭을 준다.
    const { chatId, message, userText: userTextInput, presetId, personaOverride, regenerate, userMessageId, replaceAssistantId, runtime } = body || {};

    const cid = String(chatId || "").trim();
	    _cidForLog = cid;
    const finalUserText = String((typeof userTextInput === "string" ? userTextInput : message) || "").trim();
    const regen = Boolean(regenerate);
    const replaceAid = String(replaceAssistantId || "").trim();
    const userMid = String(userMessageId || "").trim();

    let effectiveUserText = finalUserText;

    // 재생성 모드면: userMessageId 기준으로 DB에서 읽어와 정확한 원문을 사용
    if (regen && userMid) {
      const row = db.prepare(`SELECT content FROM messages WHERE id=?`).get(userMid) as any;
      const raw = row?.content ? decryptIfPossible(row.content) : "";
      effectiveUserText = String(raw || finalUserText || "").trim();
    }

    const userText = effectiveUserText;
    if (!cid) return bad("채팅이 없습니다. 먼저 '새 채팅 만들기'를 눌러주세요.");
    if (!userText) return bad("메시지를 입력해 주세요.");

	    const reqId = randomUUID();
	    _reqIdForLog = reqId;
    const tSendTotal = `send.total:${cid}:${reqId}`;
    const tPrompt = `send.prompt.build:${cid}:${reqId}`;
    const tGemini = `send.gemini.call:${cid}:${reqId}`;
    const tPost = `send.postprocess:${cid}:${reqId}`;
	    _tSendTotal = tSendTotal;
	    _tPost = tPost;

    // console.time/timeEnd는 dev/서버 환경에서 라벨 중복/예외 미종료로 경고가 자주 뜬다.
    // 대신 Date.now() 기반으로 안정적인 타이밍 로그를 남긴다.
    const _marks = new Map<string, number>();
    function tStart(label: string) {
      _marks.set(label, Date.now());
      return label;
    }
    function tEnd(label: string) {
      const t0 = _marks.get(label);
      if (typeof t0 !== "number") return;
      const ms = Date.now() - t0;
      const s = ms >= 1000 ? `${(ms / 1000).toFixed(3)}s` : `${ms.toFixed(3)}ms`;
      console.log(`${label}: ${s}`);
      _marks.delete(label);
    }
	    _tEnd = tEnd;

	    tStart(tSendTotal);
	    tStart(tPrompt);
	    debugReasons = [];

    const tDbChat = `step.db.채팅:${cid}:${reqId}`;
    tStart(tDbChat);
    const chat = db.prepare(`SELECT id, presetId FROM chats WHERE id=?`).get(cid) as any;
    tEnd(tDbChat);
    if (!chat) return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });

    const tDbPreset = `step.db.프리셋:${cid}:${reqId}`;
    tStart(tDbPreset);
    const preset = db
      .prepare(
        `SELECT id, name, background, characterName, characterAge, character, systemPrompt,
                firstMessages, lorebooks
         FROM presets WHERE id=?`
      )
      .get(chat.presetId) as any;
    tEnd(tDbPreset);

    if (!preset) return NextResponse.json({ error: "프리셋을 찾지 못했습니다." }, { status: 404 });

    // chat_settings가 없는 경우(마이그레이션/생성 중 누락 등)에는 여기서 기본값으로 자동 생성한다.
    // 404로 떨어지면 프론트에서는 "라우트가 없다"로 오해하기 쉬워 디버깅이 매우 어려워진다.
    const tDbSettings = `step.db.설정:${cid}:${reqId}`;
    tStart(tDbSettings);
    let settings = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(cid) as any;
    tEnd(tDbSettings);
    if (!settings) {
      try {
        db.prepare(`INSERT OR IGNORE INTO chat_settings (chatId, updatedAt) VALUES (?, ?)`).run(cid, Date.now());
      } catch {
        // ignore
      }
      settings = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(cid) as any;
    }
    if (!settings) return NextResponse.json({ error: "채팅 설정을 찾지 못했습니다." }, { status: 400 });

    // (중요) 페르소나는 "settings"(DB 저장값) + "personaOverride"(프론트 임시값)을 합쳐서 결정한다.
    // settings에 이름이 비어있으면, override 기반으로 1회 저장해 다음 호출부터 안정적으로 유지한다.
    const persona = resolvePersona(settings, (personaOverride || null) as PersonaOverride);
    persistPersonaIfMissing(db, cid, settings, persona);


    const renderMode: "novel" = "novel";

    const now = Date.now();

    // 1) 유저 메시지 저장(재생성 모드면 저장하지 않음)
    const userMsg = {
      id: regen && userMid ? userMid : randomUUID(),
      chatId: cid,
      role: "user" as const,
      content: userText,
      createdAt: now,
    };

    if (!regen) {
      db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt, userEmail) VALUES (?, ?, ?, ?, ?, ?)`).run(
        userMsg.id,
        userMsg.chatId,
        userMsg.role,
        encryptIfPossible(userMsg.content),
        userMsg.createdAt,
        u.email
      );
    }

    // 2) 전체 메시지 로드
    const tDbMsgs = tStart("db.전체메시지 로드");
    const all = db
      .prepare(`SELECT role, content, createdAt FROM messages WHERE chatId=? ORDER BY createdAt ASC`)
      .all(cid)
      .map((m: any) => ({ ...m, content: decryptIfPossible(m.content) })) as any[];
    tEnd(tDbMsgs);
    // 3) 메모리 구성:
    // - 최근 컨텍스트는 "유저 입력 K턴" 기준으로 포함한다 (user 메시지 1개 = 1턴)
    // - 장기기억(요약)은 '유저 입력 턴' 기준으로 [memoryFrom..memoryTo] 범위의 대화를 요약
    // - 요약은 매 요청마다 다시 만들지 않고, summaryEvery(5~10턴)마다 갱신 + 설정 변경 시 강제 갱신

    // 최근 K턴(= user 메시지 K개) 원문을 그대로 프롬프트에 포함한다.
// - UI에서는 최근 K턴 조절을 제거했으므로, 서버 기본값을 사용한다.
	// - UI에서 조절을 제거했고, 서버도 고정값(7턴)만 사용한다.
	const keepUserTurns = 7;
    const tTail = tStart("유저프롬프트.최근K턴 선별");
    const tail = selectRecentByUserTurns(all, keepUserTurns);
    tEnd(tTail);

    // 유저 입력만 카운트해서 "입력 턴"을 만든다. (user 메시지 1개 = 1턴)
    let userTurnCount = 0;
    for (const m of all) {
      if (m.role === "user") userTurnCount += 1;
    }

        const rtModel = String((runtime && typeof runtime === "object") ? runtime.model : "").trim();
    const rtOut = Number((runtime && typeof runtime === "object") ? runtime.maxOutputTokens : NaN);
    const rtReason = Number((runtime && typeof runtime === "object") ? runtime.maxReasoningTokens : NaN);

    // (중요) 서버 기본값이 UI/DB 기본값과 어긋나면, "LOW로 설정했는데 실제 요청은 HIGH" 같은
    // 혼선이 생길 수 있다. 따라서 모델별 기본값을 /api/chat/settings의 defaultReasoningTokens와 맞춘다.
    function defaultReasoningTokensByModel(model: string): number {
      const m = String(model || "").trim();
      if (m === "gemini-3-pro-preview") return 512;
      if (m === "gemini-3-flash-preview") return 256;
      // gemini-2.5-pro (및 기타)
      return 256;
    }
    function defaultOutputCharsByModel(_model: string): number {
      // UX 기본 출력 길이(글자수)
      return 1200;
    }

    const chosenModel = rtModel || settings.model || "gemini-2.5-pro";

    const sOut = Number(settings?.maxOutputTokens);
    const sReason = Number(settings?.maxReasoningTokens);

    const outRaw = Number.isFinite(rtOut)
      ? rtOut
      : Number.isFinite(sOut)
        ? sOut
        : defaultOutputCharsByModel(chosenModel);

    const reasonRaw = Number.isFinite(rtReason)
      ? rtReason
      : Number.isFinite(sReason)
        ? sReason
        : defaultReasoningTokensByModel(chosenModel);

    const opts = {
      model: chosenModel,
      maxOutputTokens: (() => {
        const v = Number(outRaw);
        return Math.max(800, Math.min(5000, Math.floor(v)));
      })(),
      maxReasoningTokens: (() => {
        const v = Number(reasonRaw);
        // 256단위로 정규화 (Gemini 3 Pro thinkingLevel 매핑, Gemini 2.5/3 Flash thinkingBudget 모두에 안전)
        return Math.max(256, Math.min(8192, Math.floor(v / 256) * 256));
      })(),
    };

    try {
    console.log(JSON.stringify({
      tag: "send.runtime.pick",
      chatId: cid,
      reqId,
      model: opts.model,
      rtOut: Number.isFinite(rtOut) ? rtOut : null,
      rtReason: Number.isFinite(rtReason) ? rtReason : null,
      sOut: Number.isFinite(sOut) ? sOut : null,
      sReason: Number.isFinite(sReason) ? sReason : null,
      pickedOut: opts.maxOutputTokens,
      pickedReason: opts.maxReasoningTokens,
      outSource: Number.isFinite(rtOut) ? "runtime" : Number.isFinite(sOut) ? "settings" : "default",
      reasonSource: Number.isFinite(rtReason) ? "runtime" : Number.isFinite(sReason) ? "settings" : "default",
    }));
  } catch {
    // ignore
  }
// 요약 대상: tail(최근 원문) 제외한 과거 메시지 전체
    // (디버그 로그에서도 참조하므로 먼저 계산한다)
    const olderMsgs = all.slice(0, Math.max(0, all.length - tail.length));

    dbg({
      tag: "send.context",
      chatId: cid,
      reqId,
      model: opts.model,
      maxOutputTokens: opts.maxOutputTokens,
      maxReasoningTokens: opts.maxReasoningTokens,
      keepUserTurns,
      totalMessages: all.length,
      totalUserTurns: userTurnCount,
      tailMessages: tail.length,
      olderMessages: olderMsgs.length,
    });

    // NOTE: 과거 로깅 추가 중 'summaryEvery' 식별자에서 TDZ(Temporal Dead Zone) ReferenceError가
    // 발생한 케이스가 있어, dev 번들(Turbopack)에서도 안전하도록 다른 변수명으로 분리한다.
	// 요약 주기: 고정 3턴 (assistant 응답 3개마다 장기기억 블록 생성)
	const summaryEveryVal = 3;

    // 턴당 글자수: 고정 80자(B 모드). UI/런타임 조절은 일단 무시한다.
    // - 목표: 요약.txt처럼 "짧고 끊김 없이" 누적되는 단일 장기기억 텍스트
    // - 3턴 주기이므로 한 번 갱신 목표는 80*3=240자
    const perTurnCharsVal = 80;

    

    // '턴'은 기본적으로 1개의 assistant 응답(=완료된 대화 1턴)으로 계산한다.
    // - UI에서 '요약 주기 N턴'은 사용자 체감 기준(문답 1회 = 1턴)에 맞추기 위해 assistant 기준으로 맞춘다.
    const isAsstRole = (role: any) => {
      const r = String(role || "").toLowerCase();
      return r === "assistant" || r === "model";
    };
    const countAssistantTurns = (msgs: any[]) => msgs.reduce((acc, m) => acc + (isAsstRole(m?.role) ? 1 : 0), 0);
    const countAssistantTurnsUpTo = (msgs: any[], ts: number) => {
      if (!ts) return 0;
      return msgs.reduce((acc, m) => acc + (isAsstRole(m?.role) && Number(m?.createdAt || 0) <= ts ? 1 : 0), 0);
    };

    const completedTurnCount = countAssistantTurns(all);
    const completedTurnCountNext = completedTurnCount + 1;
// 4) 장기기억 요약 캐시 로드 (UI의 "요약 보기" 및 누적 요약 갱신에 사용)
    const cache = (() => {
      try {
        return db
          .prepare(
            `SELECT recentSummary, updatedAt, lastSummarizedAt, rolledUpCount
             FROM chat_memory_cache
             WHERE chatId=?`
          )
          .get(cid) as any;
      } catch {
        return null;
      }
    })();

    let historySummary = cache?.recentSummary ? String(cache.recentSummary) : "";
    // 현재 설정(summaryEvery)에 맞는 블록만 남겨서 prompt/UI 혼란을 방지
    historySummary = normalizeStoredMemorySummary(historySummary, summaryEveryVal);
    let lastSummarizedAt = Number(cache?.lastSummarizedAt || 0);
    let rolledUpCount = Number(cache?.rolledUpCount || 0);
    const cacheUpdatedAt = Number(cache?.updatedAt || 0);

    // 요약 텍스트는 10,000자 기준으로 제한/롤업한다.
    const summaryMaxChars = 10000;


    async function rollupIfNeeded(summary: string) {
      // 10,000자를 넘기면 기존 요약을 5,000자로 다시 요약(압축)하고 계속 누적
      if (strlenSummary(summary) <= summaryMaxChars) return { summary, rolledUpCount };
      const tLbl = `send.summary.rollup:${cid}:${reqId}`;
      tStart(tLbl);
      dbg({ tag: "send.summary.rollup.start", chatId: cid, reqId, inputChars: strlenSummary(summary) });
	      const endTurn = getSummarizedEndTurn(
	        sanitizeLongMemorySummary(String(summary || ""), summaryEveryVal)
	      );
      const rollupEnd = endTurn > 0 ? endTurn : summaryEveryVal;
      const compact = await summarizeKorean({
        text: summary,
        targetChars: 5000,
        opts,
        turnRangeLabel: `1-${rollupEnd}턴`,
        perTurnChars: perTurnCharsVal,
        guidance: "롤업(압축) 요약: 기존 요약을 더 짧고 조밀하게 유지",
      });
      tEnd(tLbl);
      dbg({ tag: "send.summary.rollup.end", chatId: cid, reqId, outputChars: strlenSummary(compact) });
      rolledUpCount += 1;
      return { summary: compact, rolledUpCount };
    }

// (보정) summarizeKorean 결과의 턴 라벨/구간을 다루는 로직은 _server/summaryStored 로 분리했다.
const summarizedEndTurn = getSummarizedEndTurn(
  sanitizeLongMemorySummary(String(historySummary || ""), summaryEveryVal)
);
const boundaryEndTurn = Math.floor(completedTurnCountNext / summaryEveryVal) * summaryEveryVal;

// 이번 경계(boundaryEndTurn)에서 요약할 고정 구간: [boundary-summaryEvery+1 .. boundary]
const windowStartTurn = Math.max(1, boundaryEndTurn - summaryEveryVal + 1);
const windowEndTurn = Math.max(windowStartTurn, boundaryEndTurn);

const hasRangeBlock = (() => {
  const s = String(historySummary || "");
  if (!s.trim()) return false;
  const re = new RegExp(
    `^##\\s*장기\\s*기억\\s*\\(\\s*${windowStartTurn}\\s*-\\s*${windowEndTurn}\\s*턴\\s*\\)`,
    "m"
  );
  return re.test(s);
})();

const shouldRefresh = (() => {
  if (completedTurnCountNext < summaryEveryVal) return false;
  if (boundaryEndTurn <= 0) return false;

  // 이미 요약된 구간이면 갱신 불필요
  if (boundaryEndTurn <= summarizedEndTurn) return false;

  // 캐시가 없거나 비어 있으면 생성
  if (!cache) return true;
  if (!String(historySummary || "").trim()) return true;

  // 현재 window 블록이 누락/손상되면 재생성
  if (!hasRangeBlock) return true;

  // 그 외는 boundary 진입(=새 window 도달)로 갱신
  return true;
})();

	// 단일 요약 텍스트(요약.txt)만 유지: 캐릭터/씬 스토리메모리 갱신 신호는 제거
	const mode = shouldRefresh ? "all" : null;
	const memoryRefresh = {
	  shouldRefresh,
	  mode,
	  boundaryEndTurn,
	  windowStartTurn,
	  windowEndTurn,
	  runtime: runtime || null,
	  completedTurnCount: completedTurnCountNext,
	};



const refreshLongMemoryNow = async () => {
  // 이번 갱신에서 요약할 턴 구간(항상 summaryEveryVal 크기의 고정 구간)
  const startTurn = windowStartTurn;
  const endTurn = windowEndTurn;
const tailStartIdx = Math.max(0, all.length - tail.length);
const rangeMsgs = selectMessagesForAssistantTurnRangeCapped(all, startTurn, endTurn, tailStartIdx);
let rangeMsgs2 = rangeMsgs;
      // story-memory(인물/씬) 저장용 원문(미디어 제거된 평문)
// 첫 요약 블록(예: 1- )에서 cap 때문에 원문이 비는 경우가 있어 seed 요약은 uncapped로 생성한다.
if (rangeMsgs2.length === 0 && summarizedEndTurn <= 0 && startTurn === 1) {
  rangeMsgs2 = selectMessagesForAssistantTurnRange(all, startTurn, endTurn);
}
      if (rangeMsgs2.length > 0) {
	  const raw = formatTurns(rangeMsgs2);
	  // (중요) 요약 입력이 빈 문자열로 들어가던 버그 방지: 실제 대화 원문(raw)을 사용
	  const rawForSummary = stripUrlsAndMediaMarkdown(raw);
        const tLbl = summarizedEndTurn <= 0 ? `send.summary.full:${cid}:${reqId}` : `send.summary.delta:${cid}:${reqId}`;
        tStart(tLbl);

        const turnCountInRange = Math.max(1, endTurn - startTurn + 1);
        const targetChars = Math.min(100000, Math.max(50, perTurnCharsVal * turnCountInRange));
        const rangeLabel = startTurn === endTurn ? `${startTurn}턴` : `${startTurn}-${endTurn}턴`;

        dbg({
          tag: summarizedEndTurn <= 0 ? "send.summary.full.start" : "send.summary.delta.start",
          chatId: cid,
          reqId,
          startTurn,
          endTurn,
          turns: turnCountInRange,
          inputChars: raw.length,
          targetChars,
          rangeMessages: rangeMsgs.length,
          rangeLabel,
        });

        // 장기기억 요약은 "라벨 요약"(summarizeKorean) 대신, 자연 문장(1~3문장) 기반 요약을 사용한다.
        // - LOW/MID/HIGH는 targetChars(=턴당 글자수 * N턴)로만 조절
        // - 하드컷 대신 문장 마무리를 위해 약간(약 15%)의 여유를 허용
        // - 대명사로 시작하는 주어 생략 문장을 피하고, "누가 무엇을 했다" 형태를 강제
        const extraGuidance = [
          String(settings.longMemoryGuidance || "").trim(),
          "문장은 인물/기관을 주어로 명시해 '누가 무엇을 했다' 형태로 쓴다.",
          "대명사(그/그녀/당신/너)로 문장을 시작하지 않는다.",
          "문장 앞에 '!' '*' 같은 기호를 붙이지 않는다.",
        ].filter(Boolean).join(" / ");

        const body = await summarizeLongMemoryKorean({
          text: rawForSummary,
          targetChars,
          guidance: extraGuidance,
          opts,
        });

        // 범위 헤더를 서버가 직접 강제해 구간 파싱/증분 갱신을 안정화한다.
        const chunkWithHeader = `## 장기 기억 (${rangeLabel})

${body}`.trim();
        const cleanedChunk = sanitizeLongMemorySummary(normalizeSummaryTail(chunkWithHeader), summaryEveryVal);

        tEnd(tLbl);

        dbg({
          tag: summarizedEndTurn <= 0 ? "send.summary.full.end" : "send.summary.delta.end",
          chatId: cid,
          reqId,
          outputChars: strlenSummary(cleanedChunk),
          rangeLabel,
        });

        const combined = sanitizeLongMemorySummary(
          upsertSummaryRangeBlock(historySummary || "", cleanedChunk, startTurn, endTurn).trim(),
          summaryEveryVal
        );

        // 10,000자 제한 + 롤업(5,000자 압축)
        let rolled = await rollupIfNeeded(combined);
        historySummary = sanitizeLongMemorySummary(normalizeSummaryTail(rolled.summary), summaryEveryVal);
        rolledUpCount = rolled.rolledUpCount;

        // 롤업 이후에도 여전히 10,000자 넘는다면 한 번 더 압축(안전장치)
        if (strlenSummary(historySummary) > summaryMaxChars) {
          const rolled2 = await rollupIfNeeded(historySummary);
          historySummary = sanitizeLongMemorySummary(normalizeSummaryTail(rolled2.summary), summaryEveryVal);
          rolledUpCount = rolled2.rolledUpCount;
        }

        // lastSummarizedAt은 "마지막으로 요약에 포함된 메시지 createdAt의 최대값"으로 유지한다.
        const newestAt = rangeMsgs.reduce((mx, m) => Math.max(mx, Number(m?.createdAt || 0)), 0);
        lastSummarizedAt = newestAt || Number(lastSummarizedAt || 0) || Date.now();
      } else {
        // 메시지가 없으면 갱신하지 않음
      }

      // 요약 캐시 저장(조회용) - UI에서 "요약 보기"로 확인
      try {
        // (중요) 저장 시 헤더(## 장기 기억 (a-b턴)) 구조를 유지해야 다음 증분 갱신 파싱이 안정적이다.
        // - postprocessLongMemorySummary()는 ##/### 구조를 지워버려 누적 갱신을 깨뜨릴 수 있으므로 제거
        // Keep headings in storage (## / ###) for "요약.txt" style.
        const historySummaryToStore = stripUrlsAndMediaMarkdown(String(historySummary || ""), { keepHeadings: true });
        const summaryChars = strlenSummary(historySummaryToStore);
        db.prepare(
          `INSERT INTO chat_memory_cache (chatId, recentSummary, recentSummaryChars, updatedAt, lastSummarizedAt, rolledUpCount)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(chatId) DO UPDATE SET
             recentSummary=excluded.recentSummary,
             recentSummaryChars=excluded.recentSummaryChars,
             updatedAt=excluded.updatedAt,
             lastSummarizedAt=excluded.lastSummarizedAt,
             rolledUpCount=excluded.rolledUpCount`
        ).run(cid, historySummaryToStore, summaryChars, Date.now(), Number(lastSummarizedAt || 0), Number(rolledUpCount || 0));


      } catch {
        // 캐시 실패는 치명적이지 않으므로 무시
      }
    
};

// (중요) 스트리밍 응답을 우선한다.
// - 장기기억/스토리메모리 갱신(LLM 호출)은 /api/chat/send 경로에서 실행하지 않는다.
// - 필요 시 클라이언트가 /api/chat/memory/refresh 를 별도 호출하도록 memoryRefresh 신호만 내려준다.

    // 5) 시스템 프롬프트 구성
    // (병목 분석 로그용) 구성 요소별 시간 측정: 페르소나설정 / 프리셋 / 로어북 / 유저노트 / 장기기억
    const tPersonaBlock = tStart("페르소나설정");
    // NOTE: personaOverride(프론트 임시값) + settings(DB 저장값)을 이미 resolvePersona로 합쳤다.
    // user 입력 1턴 기준(=user 메시지)으로 프롬프트가 흔들리지 않도록 여기서는 persona만 사용한다.
    const personaNameFinal = persona.name || "주인공";
    const personaAgeFinal = persona.age || 0;
    const personaGenderFinal = persona.gender;
    const personaInfoFinal = persona.info;

    const personaBlock = [
      `# (1) 페르소나(주인공 설정)`,
      `- 이름: ${personaNameFinal || "(미입력)"}`,
      `- 나이: ${personaAgeFinal ? String(personaAgeFinal) : "(미입력)"}`,
      `- 성별: ${personaGenderFinal || "(미입력)"}`,
      `- 상세 정보: ${personaInfoFinal || ""}`,
    ].join("\n");
    tEnd(tPersonaBlock);

    const tPresetBlock = tStart("프리셋");

    const presetBlock = [
      `# 프리셋`,
      `- 배경: ${preset.background}`,
      `- 상대방 캐릭터 이름: ${preset.characterName || ""}`,
      `- 상대방 나이: ${preset.characterAge || 0}`,
      `- 상대방 캐릭터(성격/말투/행동 원칙): ${preset.character}`,
      `- 추가지침(금칙/우선순위/형식): ${preset.systemPrompt || ""}`,
    ].join("\n");
    tEnd(tPresetBlock);

    // (요구사항)
    // 작업실(캐릭터 제작)에서 저장한 로어북을 대화 프롬프트에 반영한다.
    // - 로어는 기본적으로 '활성화 키'가 최근 대화/입력에 등장하면 포함한다.
    // - 키가 비어있거나 매칭되는 항목이 없으면, 활성화된 로어 중 앞부분 일부를 포함한다.
    const pickLorebooks = () => {
      const tLore = tStart("로어북");
      try {
      const raw = String(preset?.lorebooks || "[]");
      let arr: any[] = [];
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) arr = parsed;
      } catch {
        arr = [];
      }

      const enabled = arr
        .filter((x) => x && typeof x === "object")
        .filter((x) => x.enabled !== false);

      const haystack = `${historySummary || ""}\n${settings?.userNote || ""}`;
      // context/userText는 아래에서 만들어지지만, 로어 선택은 시스템 블록 단계에서도 쓸 수 있게
      // 유저 입력만 먼저 참조한다.
      const recentText = `${haystack}\n${userText || ""}`;

      const norm = (s: string) => String(s || "").toLowerCase();
      const h = norm(recentText);

      const scored = enabled.map((lb) => {
        const keyRaw = lb.activationKey ?? lb.key ?? lb.keys ?? "";
        const keys = Array.isArray(keyRaw)
          ? keyRaw.map((k: any) => String(k || "").trim()).filter(Boolean)
          : String(keyRaw || "")
              .split(/[,\n]+/)
              .map((k) => String(k || "").trim())
              .filter(Boolean);

        let score = 0;
        for (const k of keys) {
          const kk = norm(k);
          if (kk && h.includes(kk)) score += 10;
        }
        return { lb, score, keys };
      });

      scored.sort((a, b) => b.score - a.score);

      const matched = scored.filter((x) => x.score > 0).slice(0, 12);
      const picked = (matched.length ? matched : scored.slice(0, 6))
        .map((x) => ({
          name: String(x.lb?.name || "").trim(),
          content: String(x.lb?.content || x.lb?.text || "").trim(),
          keys: x.keys,
        }))
        .filter((x) => x.name || x.content);

      if (!picked.length) return "# 로어북\n(없음)";

      const lines: string[] = ["# 로어북(작업실)"];
      for (const lb of picked) {
        const k = lb.keys && lb.keys.length ? ` (키: ${lb.keys.join(", ")})` : "";
        lines.push(`- ${lb.name || "(무제)"}${k}`);
        if (lb.content) lines.push(`  - ${lb.content}`);
      }
      return lines.join("\n");
      } finally {
        tEnd(tLore);
      }
    };

    const loreBlock = pickLorebooks();

    const tUserNote = tStart("유저노트");
    const noteBlock = settings.userNote
      ? `# (3) 유저노트(답변 생성 시 참고)\n${settings.userNote}`
      : `# (3) 유저노트(답변 생성 시 참고)\n(없음)`;
    tEnd(tUserNote);

    const tLongMemoryBlock = tStart("장기기억");
    const memoryBlock = [
      `# (2) 장기기억 요약(최근 원문 ${keepUserTurns}턴 제외, ${summaryEveryVal}턴마다 갱신)`,
      historySummary || "(없음)",
    ].join("\n");
    tEnd(tLongMemoryBlock);

    // NOTE: 출력길이 슬라이더(런타임)가 즉시 반영되도록 opts(maxOutputTokens)를 우선 사용한다.
    // (DB settings.maxOutputTokens는 '저장'된 값이고, 런타임 슬라이더는 body.runtime으로 넘어옴)
    const maxOut = Number(opts.maxOutputTokens ?? settings.maxOutputTokens ?? 1024);
    const modelName = String((opts as any)?.model || "");
    const isGemini3 = modelName.includes("gemini-3");
    const isGemini3Pro = modelName.includes("gemini-3-pro");

	    // gemini-3-pro 계열은 "모델 델타 스트리밍"이 불안정할 수 있다.
	    // 다만 transport 자체를 non-stream(JSON)로 강제하면 120s 프록시 타임아웃에 취약해진다.
	    // 따라서 stream=true로 들어오면 NDJSON(keep-alive ping + done-only)로 처리하고,
	    // stream=false면 기존처럼 JSON 응답으로 처리한다.


	    // 제작자/프리셋이 '상태창(메타/INFO)'을 요구하는지 감지한다.
	    // - formatGuide 자체에 STATUS/INFO 단어가 포함될 수 있으므로, preset/persona/note/userNote/lore 쪽만 본다.
	    // - 실제 제작 프리셋에선 ```INFO, "Info" 헤더, 📍/🕒 같은 표기가 쓰이기도 해서 함께 탐지한다.
	    const authorWantsStatus = /상태\s*창|캐릭터\s*상태|\[\s*시간\s*\/\s*장소\s*\]|\bINFO\b|```\s*(?:STATUS|INFO)\b|Info\s*\n\s*📍|📍\s*위치|🕒\s*시간|위치\s*\|\s*시간/i.test(
	      [presetBlock, personaBlock, noteBlock, String(settings.userNote || ""), loreBlock].filter(Boolean).join("\n")
	    );


    // (요구사항)
    // UI 슬라이더의 값(예: 800/1600)을 사용자는 사실상 "글자수"처럼 체감한다.
    // 하지만 모델의 토큰화(언어/모델별)가 달라서 "max_output_tokens"만으로는
    // 글자수(한글 자수)가 크게 흔들릴 수 있다.
    // → 해결: "목표 글자수"를 슬라이더 값에 맞추고, 결과가 너무 짧/길면 1~2회
    //         재작성하며 max_output_tokens를 **동적으로 보정**한다.
    // 슬라이더 값은 UI에 "토큰"으로 표기되어 있지만, 사용자는 사실상 "원하는 글 길이"(글자수 감각)로 사용한다.
    // 모델별/언어별 토큰화 비율이 달라 max_output_tokens만으로는 길이가 크게 흔들린다.
    // 그래서 **결과 텍스트는 글자수 기준으로 고정**하고,
    // 생성 단계에서는 충분히 쓸 수 있도록 max_output_tokens를 더 크게 잡아(후술) 짧게 끊기는 현상을 줄인다.
    const HARD_CAP_CHARS = 200000; // absolute safety cap to prevent runaway DB growth
    const NO_TRUNCATE_OUTPUT = true; // 원칙: 서버 절단 금지(슬라이더는 '권장' 길이)

    const targetChars = Math.max(200, Math.min(20000, Math.floor(maxOut))); // 슬라이더 값 = 권장 글자수

    // 1) 프롬프트 지시용(강제): 목표의 90% 이상 쓰도록 강하게 요구
    const promptMinChars = Math.max(200, Math.floor(targetChars * 0.90));
    const promptMaxMul = isGemini3Pro ? 1.10 : 1.15;
    const promptMaxChars = Math.max(promptMinChars + 80, Math.floor(targetChars * promptMaxMul));

    // 2) 로직 판단용(안전장치): "너무 짧다" 판단 기준(목표의 60%)
    const logicMinChars = Math.max(120, Math.floor(targetChars * 0.60));

    // 3) 폭주 방지용 상한(완화 절단)
    //    - NO_TRUNCATE_OUTPUT=true라도, 이어쓰기/토큰 예산 상향 등으로 과출력이 발생할 수 있다.
    //    - 다만 Gemini 3 Pro는 "상대적으로 짧은 목표"에서도 실제 출력이 1.4~1.6배로 나오는 경우가 많아
    //      기존 상한(1.18x)이 너무 자주 걸리며 문장/따옴표가 중간에서 끊겼다(cap:RUNAWAY).
    //    - 따라서 작은 목표에서는 상한을 더 넉넉히 주고, 목표가 커질수록 점진적으로 낮춘다.
    const runawayMaxMul = (() => {
      if (!isGemini3Pro) return 1.30;
      if (targetChars <= 1200) return 1.80;
      if (targetChars <= 2000) return 1.60;
      if (targetChars <= 3200) return 1.45;
      return 1.35;
    })();
    const runawayPad = isGemini3Pro ? 240 : 120;
    const runawayMaxChars = Math.max(promptMaxChars + runawayPad, Math.floor(targetChars * runawayMaxMul));

    // 절단 금지 모드에서는 "재작성/길이 보정" 트리거(minChars)를 0으로 두되,
    // '너무 짧다' 판단에는 logicMinChars/promptMinChars를 사용한다.
    const minChars = NO_TRUNCATE_OUTPUT ? 0 : logicMinChars;
    const maxChars = NO_TRUNCATE_OUTPUT ? runawayMaxChars : Math.max(minChars + 40, targetChars);
    const charBudget = Math.min(HARD_CAP_CHARS, maxChars);

    // 생성 단계에서만 사용할 "여유 토큰" 상한.
    // - max_output_tokens가 너무 낮으면(특히 1000 이하) 짧게 끊기거나 형식이 무너지는 케이스가 많다.
    // - 대신 최종 결과는 아래에서 글자수로 강제 절단하므로, 여기서는 넉넉히 준다.
    // Token budget: keep the existing heuristic, but relax the cap for Gemini 3 models.
    // - Gemini 3 Pro can produce larger single responses; too-low caps force auto-continue,
    //   which creates long "silent" gaps and increases ALB/UX risk.

    // cap(최대치) 자체를 올려도, 현재 로직은 targetChars(=슬라이더) 기반으로
    // floor(targetChars * 2.2)에서 먼저 제한되는 경우가 많다.
    // 특히 Gemini 3 Pro는 "한 덩어리로" 출력하다 MAX_TOKENS로 끊기는 케이스가 있어,
    // 작은 슬라이더 값에서도 최소 토큰 여유를 보장해 준다(서사/메타 블록 완결 목적).
    const cap = isGemini3 ? 8192 : 6000;

    // 생성 단계 토큰 예산(폭주 방지 + 끊김 완화)
    // - 과거: Gemini 3에 minBoost=4096을 강제하면서 작은 target에서도 과출력이 발생(예: 1200 -> 2800+).
    // - 개선: targetChars에 따라 부드럽게 스케일링한다.
    const boostMul = isGemini3
      ? (isGemini3Pro
          ? (targetChars <= 2000 ? 1.30 : targetChars <= 2600 ? 1.45 : 2.0)
          : (targetChars <= 1600 ? 1.35 : targetChars <= 2600 ? 1.55 : 2.0))
      : 2.2;

    const rawBoost = Math.floor(targetChars * boostMul);

    // 작은 목표에서는 최소치를 낮추고(폭주 방지), 큰 목표에서는 끊김을 막기 위해 올린다.
    // (진단) Gemini 3 Pro가 "reasoning만" 소비하고 output을 0으로 끝내는(MAX_TOKENS) 케이스가 있어,
    // 생성 단계 max_output_tokens 하한을 올려 실제 출력 여지를 확보한다.
    const minBoost = isGemini3
      ? (
          // Gemini 3 Pro는 작은 목표에서도 MAX_TOKENS로 잘리는/빈 출력(outputTokens=0) 케이스가 있어,
          // 최소 토큰 하한을 과하지 않게 올리되(폭주 방지), 슬라이더(글자 수)를 토큰 상한으로 환산해 존중한다.
          isGemini3Pro
            ? (targetChars >= 3200 ? 4096 : targetChars >= 2000 ? 3072 : 1536)
            : targetChars >= 3200 ? 3072 : 1536
        )
      : 512;

	    let boostedMaxOutputTokens = Math.max(minBoost, Math.min(cap, rawBoost));

	    // (중요) output 슬라이더는 '글자 수' 개념이다.
	    // gemini-3-pro 계열에서 이를 그대로 토큰 상한으로 쓰면(예: 800자 -> 800 tokens)
	    // MAX_TOKENS/빈 출력이 발생해 재시도/이어쓰기 때문에 총 지연이 커진다.
	    // → 글자 수를 토큰으로 완만히 환산한 상한을 적용한다.
	    const proTokenCapFromChars = isGemini3Pro ? Math.max(1024, Math.min(cap, Math.floor(targetChars * 2.2))) : 0;
	    const maxOutputTokensForCall = isGemini3Pro
	      ? Math.max(64, Math.min(cap, Math.min(proTokenCapFromChars, boostedMaxOutputTokens)))
	      : Math.max(64, Math.min(cap, boostedMaxOutputTokens));

    // "중간 끊김"이 계속 발생해서, 형식을 단순화하고(LLM이 놓치기 쉬운 규칙 제거)
    // 반드시 짧게라도 완결되도록 강제한다.
    const minParagraphs = maxOut >= 3000 ? 8 : maxOut >= 2000 ? 6 : 3;

	    // 모델이 '상태창 요구'를 추측으로 오판하는 케이스가 있어, 명시적으로 YES/NO를 박아준다.
    const statusRequired = authorWantsStatus ? "YES" : "NO";

	    const formatGuide = buildFormatGuide({ statusRequired, targetChars, promptMinChars, promptMaxChars });

const system = [
      `너는 아래 설정을 따르는 '상대방 캐릭터'로서 반응한다.`,
      ``,
      sanitizePromptCached(presetBlock),
      ``,
      sanitizePromptCached(personaBlock),
      ``,
      sanitizePromptCached(noteBlock),
      ``,
      sanitizePromptCached(memoryBlock),
      ``,
      sanitizePromptCached(loreBlock),
      ``,
      sanitizePromptCached(formatGuide),
    ].join("\n");

		    // (변경) 상태창을 포함한 응답을 '한 번의 호출'로 생성한다.
	    // - Gemini 3 Pro는 streaming 중간에 fenced(STATUS/INFO)가 반쪽으로 보이는 문제가 컸지만,
	    //   Pro에서는 "done-only"(delta 미전송) 방식을 적용하여 UI 깨짐을 줄인다.
	    // - 그래도 MAX_TOKENS로 끊겨 닫힘 펜스가 누락될 수 있어, 아래의 textPolicy 복구(repairUnclosedAnyFence)로 최소 보정한다.
		    // 추가 안전장치(비용 절감): Gemini 3 Pro에서 STATUS를 "마지막"에 출력한 뒤, 즉시 종료되도록 stop sequence를 사용한다.
		    // - 모델이 STATUS를 닫고도 계속 출력(불필요 토큰 낭비)하는 케이스를 줄인다.
		    // - stopSequences는 해당 문자열을 응답에 포함하지 않고 중단한다.
		    const STATUS_SEPARATE_MODE_ENV = process.env.AI_STATUS_SEPARATE_MODE === "1";
		    const STATUS_STOP_MARK = "<<<END_OF_OUTPUT>>>";
		    const useStatusStopMark = Boolean(authorWantsStatus && isGemini3Pro && !STATUS_SEPARATE_MODE_ENV);
		    const systemMain = useStatusStopMark
		      ? [
		          system,
		          "",
		          "※ (중요) 2단계(STATUS) fenced 코드블록을 닫은 직후, 마지막 줄에 <<<END_OF_OUTPUT>>> 를 정확히 출력한 뒤 즉시 종료하라. (이 문자열 이후에는 어떤 텍스트도 출력하지 마라.)",
		        ].join("\n")
		      : system;
	
	    // 이어쓰기/보강용 시스템 프롬프트
	    // - 이어쓰기에서는 "상태창/메타"를 다시 출력하지 않도록 금지한다(상태창은 첫 호출의 맨 끝 1회만).
	    // - Gemini 3 Pro는 프롬프트가 길수록(특히 memory/lore) 지연이 커져, 이어쓰기에서만 경량 시스템을 사용한다.
	    //   (직전 출력 tail을 user 메시지로 제공하므로, 이어쓰기에는 format+persona 중심으로 충분)
	    const systemForContinuation = isGemini3Pro
	      ? [
	          `너는 아래 설정을 따르는 '상대방 캐릭터'로서 반응한다.`,
	          ``,
	          sanitizePromptCached(personaBlock),
	          ``,
	          sanitizePromptCached(noteBlock),
	          ``,
	          sanitizePromptCached(formatGuide),
	          ``,
	          "※ (중요) 이 이어쓰기 호출에서는 fenced 코드블록(```...```) 출력 금지. STATUS/INFO/메타 블록도 출력하지 마라.",
	        ].join("\n")
	      : [
	          systemMain,
	          "",
	          "※ (중요) 이 이어쓰기 호출에서는 fenced 코드블록(```...```) 출력 금지. STATUS/INFO/메타 블록도 출력하지 마라.",
	        ].join("\n");

	    // (Gemini 3 Pro) 상태창/메타가 "반드시" 필요하지만 본문이 먼저 잘려(또는 모델이 누락해) 상태창이 빠지는 케이스가 있다.
	    // 그 경우에만 아주 짧은 2차 호출로 STATUS 블록만 생성해 덧붙인다.
	    // - 프롬프트를 경량화해 지연을 최소화한다.
	    const systemForStatus = isGemini3Pro
	      ? [
	          `너는 아래 설정을 따르는 '상대방 캐릭터'로서 반응한다.`,
	          ``,
	          sanitizePromptCached(personaBlock),
	          ``,
	          sanitizePromptCached(noteBlock),
	          ``,
	          // 상태창만 출력하도록 강제
	          `지금부터는 '2단계 메타/상태'만 작성한다.`,
	          `출력은 반드시 하나의 fenced 코드블록으로만 구성한다.`,
	          `코드블록은 첫 줄이 정확히 \`\`\`STATUS 여야 하며, 마지막 줄은 \`\`\` 로 닫는다.`,
	          `코드블록 밖에는 어떤 텍스트도 출력하지 마라.`,
	          ``,
	          // 형식 힌트(중요한 부분만)
	          `STATUS 블록 내부는 '짧고 구조화된' 항목들로 채운다. (예: TARGET/TYPE/DATA/LIVE 등)`,
	        ].join("\n")
	      : system;

	    const systemStatus = system; // (레거시) 별도 상태창 호출용 - 현재는 기본 비활성

    // 6) 모델 호출
    // - 최근 컨텍스트는 "유저 입력 K턴" 기준으로 tail에 포함
    // - 그 이전은 historySummary(요약)로 대체
    const personaName = personaNameFinal;
    const npcName = preset.characterName || "상대";

    // 최근 대화 컨텍스트는 유지하되, URL/이미지 마크다운(![](), !!https://...)은 모델 입력에서 제거한다.
    // - 토큰 낭비/유출(긴 URL) 방지
    // - 모델이 URL 문자열을 "참고"해서 출력 형식을 깨는 현상 방지
    const contextRaw = formatStoryTurnsForMode(tail, personaName, npcName, renderMode);
    const context = stripUrlsAndMediaMarkdown(contextRaw);
    // 사용자 입력을 모드에 맞춰 전달한다.
    const userLine = buildUserLineForMode(userText, personaName, renderMode);

    const user = [      context ? `[최근 대화]\n${context}` : "",
      ``,
      `다음은 사용자의 최신 입력이다. 이 입력(주인공 발화)은 이미 화면에 표시되어 있으므로, 이를 다시 "..." 대사로 출력하지 말고 그 다음 장면(지문 + 상대의 반응)만 이어서 출력하라. 사용자의 문장을 교정/재작성하지 말고, 상대가 이를 들었다는 전제 하에 반응만 진행하라. (이름 | ... 같은 화자표기는 쓰지 말고 큰따옴표만 사용)`,
      `사용자 최신 입력(참고용, 재출력 금지): ${userLine}`,
      ``,
      `출력은 곧바로 시작하라.`,
    ]
      .filter(Boolean)
      .join("\n");

    
tEnd(tPrompt);



// ---- Streaming (NDJSON) ----
if (wantStream) {
const encoder = new TextEncoder();

  // Stream debug logging (set STREAM_DEBUG=1 to enable)
  const STREAM_DEBUG = process.env.STREAM_DEBUG === "1";
  const streamDbgId = `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
  const streamTag = `[api][chat.send][stream][${streamDbgId}][chat:${String(chatId)}]`;

  // (UX/네트워크 안정화)
  // 모델이 델타를 한동안 안 줄 때도 연결이 살아있음을 알리고,
  // 일부 프록시/버퍼가 응답을 뭉쳐 보내는 현상을 완화하기 위해 heartbeat를 흘려보낸다.
  // - 클라이언트는 type:"ping"을 텍스트에 반영하지 않음(무시)
  // - 하지만 수신 시각 갱신에는 사용 가능
  const HEARTBEAT_MS = 700;

  const rs = new ReadableStream({
    start(controller) {
      (async () => {
        let streamClosed = false;
        let lastPingAt = 0;
        let lastDeltaAt = 0;

        const safeEnqueue = (obj: any) => {
          if (streamClosed) return false;
          try {
            const now = Date.now();
            if (obj?.type === "ping") {
              const sincePing = lastPingAt ? now - lastPingAt : -1;
              const sinceDelta = lastDeltaAt ? now - lastDeltaAt : -1;
              lastPingAt = now;
              if (STREAM_DEBUG) {
                console.debug(`${streamTag} ping sent (sincePing=${sincePing}ms sinceDelta=${sinceDelta}ms)`, obj);
              }
            }
            controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
            return true;
          } catch (e: any) {
            streamClosed = true;
            if (STREAM_DEBUG) console.warn(`${streamTag} enqueue ignored (closed)`, e?.message || e);
            return false;
          }
        };

        const safeClose = () => {
          if (streamClosed) return;
          streamClosed = true;
          try {
            controller.close();
          } catch {}
        };

        // First-byte flush (keep-alive before Gemini starts producing)
        safeEnqueue({ type: "ping", phase: "start", t: Date.now() });

        try {
          const tGeminiStream = tStart(`send.gemini.stream`);

          // ===== Generation (append-only) + optional auto-continue (max 2) =====
          // Goal: if the model ends with MAX_TOKENS, automatically request a continuation
          // (append-only) up to 2 times, preserving the user's reasoning/UI settings.

          const mergeUsage = (base: any, add: any) => {
            if (!add) return base;
            if (!base) return { ...add };
            const out: any = { ...base };
            for (const k of ["promptTokens", "outputTokens", "reasoningTokens", "totalTokens", "latencyMs"]) {
              out[k] = Number(out[k] || 0) + Number(add[k] || 0);
            }
            // keep the last model / finishReason for observability
            if (add.model) out.model = add.model;
            if (add.finishReason) out.finishReason = add.finishReason;
            if (add.tokenBreakdown) out.tokenBreakdown = add.tokenBreakdown;
            return out;
          };

          const makeContinueUser = (combined: string) => {
            const tailLen = 800;
            const tail = combined.slice(Math.max(0, combined.length - tailLen));
            return [
              context ? `[최근 대화]\n${context}` : "",
              "",
              "[CONTINUE] 직전 출력이 MAX_TOKENS로 중단되었다.",
              "- 이미 출력한 내용은 절대 반복/요약/재진술하지 말고, 바로 다음 문장부터 그대로 이어서만 써라.",
              "- 형식은 헌법을 그대로 유지한다: 지문=*...*, 대사=\"...\".",
	              "- (중요) 이어쓰기에서도 fenced 코드블록(```...```) 출력은 절대 금지한다. 상태/INFO/STATUS 같은 메타 블록도 다시 출력하지 마라(상태창은 첫 호출의 맨 끝 1회만).",
              "- 마지막 문장이 미완이면 자연스럽게 이어서 완결까지 마무리하라.",
              "",
              "[직전 출력의 마지막 부분(참고, 반복 금지)]",
              tail,
              "",
              "출력은 곧바로 이어서 시작하라.",
            ]
              .filter(Boolean)
              .join("\n");
          };

          const awaitFinalFast = async (p: Promise<any>, ms: number) => {
            try {
              return await Promise.race([p, new Promise((res) => setTimeout(() => res(null), Math.max(0, ms)))]);
            } catch {
              return null;
            }
          };

          // Gemini 3 Pro 계열은 "추론(thinking) + 텍스트"가 maxOutputTokens 예산을 공유하는 듯한 동작을 보이며,
          // 스트리밍 중간에 fenced(STATUS/INFO) 같은 "닫힘이 필요한" 형식이 MAX_TOKENS로 쉽게 반쪽이 난다.
          // 따라서 Gemini 3 Pro에서는 delta를 보내지 않고(done에 최종 완성본만) "한 방에" 내려보낸다.
          const PRO_DONE_ONLY = modelName.includes("gemini-3-pro");

          const stripStandaloneSeparatorLines = (s: string) => s.replace(/^\s*---+\s*$/gm, "");

          const runOneBuffered = async (userPrompt: string, tag: string) => {
            if (STREAM_DEBUG) console.debug(`${streamTag} gen.start (${tag}) [buffered]`);

            // Keep-alive pings while waiting for non-stream response
            let lastEmitAt = Date.now();
            const hb = setInterval(() => {
              try {
                const now = Date.now();
                if (now - lastEmitAt < HEARTBEAT_MS) return;
                lastEmitAt = now;
                safeEnqueue({ type: "ping", t: now });
              } catch {
                // ignore
              }
            }, Math.max(200, Math.floor(HEARTBEAT_MS / 2)));

            try {
              const p0 = generateText({
                system: systemMain,
                user: userPrompt,
                opts: {
                  ...opts,
                  maxOutputTokens: maxOutputTokensForCall,
                  ...(useStatusStopMark ? { stopSequences: [STATUS_STOP_MARK] } : {}),
                },
              });

              // DONE-ONLY: 모델은 non-stream 호출로 생성하고, transport는 NDJSON로 keep-alive ping을 보낸다.
              // (요구사항) UI는 "한 번에" 최종 결과만 보여주되, 120s 프록시 타임아웃을 피하고
              //            사용자가 "멈춘 것"처럼 느끼지 않도록 연결을 살아 있게 유지한다.
              let r: any = await p0;
              let raw = stripStandaloneSeparatorLines(String(r?.text || ""));

              if (!raw.trim()) debugReasons.push(`empty:${tag}`);

              const usage: any = (r as any)?.usage ?? null;
              const finishReason = String(
                (usage && (usage.finishReason || usage.native_finish_reason || (usage as any).nativeFinishReason)) || ""
              ).toUpperCase();
              if (STREAM_DEBUG) console.debug(`${streamTag} gen.done (${tag}) [buffered] finishReason=${finishReason}`);
              return { raw, usage, finishReason };
            } finally {
              clearInterval(hb);
            }
          };

          const runOneStream = async (userPrompt: string, tag: string) => {
            if (STREAM_DEBUG) console.debug(`${streamTag} gen.start (${tag})`);

            const gen = await generateTextStream({
              system: systemMain,
              user: userPrompt,
		              opts: {
		                ...opts,
		                maxOutputTokens: maxOutputTokensForCall,
		                ...(useStatusStopMark ? { stopSequences: [STATUS_STOP_MARK] } : {}),
		              },
            });

            let raw = "";
            let lastEmitAt = Date.now();
            const hb = setInterval(() => {
              try {
                const now = Date.now();
                if (now - lastEmitAt < HEARTBEAT_MS) return;
                lastEmitAt = now;
                safeEnqueue({ type: "ping", t: now });
              } catch {
                // ignore
              }
            }, Math.max(200, Math.floor(HEARTBEAT_MS / 2)));

            let hadDelta = false;
            let stoppedEarly = false;
            try {
              for await (const delta of gen.stream) {
                hadDelta = true;
                const combined = raw + delta;

                // NOTE: 이전 버전은 STATUS fenced block이 닫히는 순간 스트리밍을 중단(EARLY STOP)했지만,
                // gemini-3-pro 계열에서 본문이 짧게 끊기는 원인이 되었다.
                // STATUS/meta 출력은 후처리(맨 마지막 정리) 단계에서 처리하므로 여기서는 중단하지 않는다.

                // Normal path: append-only, but still sanitize noisy separators
                raw = stripStandaloneSeparatorLines(combined);
                lastEmitAt = Date.now();
                const nowD = Date.now();
                const gap = lastDeltaAt ? nowD - lastDeltaAt : -1;
                lastDeltaAt = nowD;

                if (STREAM_DEBUG)
                  console.debug(`${streamTag} delta recv (${tag}) (gap=${gap}ms len=${String(delta || "").length})`);
                safeEnqueue({ type: "delta", text: delta });
              }
            } finally {
              // keep hb alive until we emit done (final usage may arrive slightly later)
            }
            try {
            let final: any = null;
            let usage: any = null;

            // gen.final can resolve much later than the last visible delta (esp. gemini-3-pro*).
            // We must avoid the ping-only/0-char failure mode where no delta arrives but final is late.
            const isGemini25 = modelName.includes("gemini-2.5");
            const isGemini3Pro = modelName.includes("gemini-3-pro");
            const baseFinalWait = isGemini3Pro ? 9000 : (isGemini3 ? 4200 : (isGemini25 ? 2600 : 1800));
            // NOTE: If we stopped early AND received no deltas, final often arrives late—do not use tiny waits.
            const FINAL_WAIT_MS = (!hadDelta && stoppedEarly) ? (isGemini3Pro ? 20000 : 12000) : baseFinalWait;
            final = await awaitFinalFast(gen.final, FINAL_WAIT_MS);
            usage = (final as any)?.usage ?? null;

            // Some models (esp. gemini-3-pro-preview) attach usage late. Wait a bit more if needed.
            if (!usage) {
              const extraWaitMs = isGemini3Pro ? 7000 : isGemini3 ? 3000 : isGemini25 ? 1800 : 1200;
              if (STREAM_DEBUG) console.debug(`${streamTag} final.wait.extra (${tag}) ms=${extraWaitMs}`);
              const f2 = await awaitFinalFast(gen.final, extraWaitMs);
              if (f2) final = f2;
              usage = (final as any)?.usage ?? usage;
            }

            // If we still got nothing AND no deltas ever arrived (ping-only), do one non-stream retry to avoid 0-char output.
            if (!final && !hadDelta) {
              try {
                if (STREAM_DEBUG) console.debug(`${streamTag} final.fallback.nonstream (${tag})`);
		                const fb = await generateText({
                  system: systemMain,
                  user: userPrompt,
		                  opts: { ...opts, maxOutputTokens: maxOutputTokensForCall },
                });
                const ft = String(fb?.text || "");
                if (ft) {
                  final = { text: ft, usage: (fb as any)?.usage ?? null };
                  usage = (final as any)?.usage ?? usage;
                }
              } catch {
                // ignore
              }
            }


            // Append any remaining tail only (never rewrite)
            if (hadDelta && final?.text) {
              const ft = String(final.text || "");
              if (ft.startsWith(raw) && ft.length > raw.length) {
                const tail = ft.slice(raw.length);
                raw += tail;
                try {
                  safeEnqueue({ type: "delta", text: tail });
                } catch {
                  // ignore
                }
              }
            }
            if (!hadDelta && final?.text) {
              const ft = String(final.text || "");
              raw += ft;
              try {
                safeEnqueue({ type: "delta", text: ft });
              } catch {
                // ignore
              }
            }

            // Finish reason should be sourced from usage metadata; in this stream handler `final`
            // only includes { text, usage } (no finishReason field).
            const finishReason = String(
              (usage && (usage.finishReason || usage.native_finish_reason || (usage as any).nativeFinishReason)) || ""
            ).toUpperCase();
            if (STREAM_DEBUG) console.debug(`${streamTag} gen.done (${tag}) finishReason=${finishReason}`);
            return { raw, usage, finishReason };
            } finally {
              clearInterval(hb);
            }
          };

          const runOne = PRO_DONE_ONLY ? runOneBuffered : runOneStream;


          let combinedRaw = "";
          let combinedUsage: any = null;
          let finishReason = "";

          // 1) initial generation
          {
            const r0 = await runOne(user, "main");
            combinedRaw += r0.raw;
            combinedUsage = mergeUsage(combinedUsage, r0.usage);
            finishReason = r0.finishReason;
          }

          // 2) auto-continue up to N times if MAX_TOKENS
          // NOTE: gemini-3-pro-preview can be slow and is more likely to hit ALB/edge idle timeouts.
          // Disable auto-continue for gemini-3-pro* (user wants single-shot output). If needed, raise the token budget instead.
          const isGemini3Pro = typeof opts.model === "string" && opts.model.includes("gemini-3-pro");
          const MAX_CONTINUES = isGemini3Pro ? 0 : 2;
          for (let i = 0; i < MAX_CONTINUES; i++) {
                        if (finishReason !== "MAX_TOKENS") break;
            // If the model already produced a complete fenced meta block at the end, do not auto-continue.
            // Continuing from here often causes "text after status/info fence" artifacts.
            if (endsWithCompleteFence(combinedRaw)) {
              finishReason = "STOP";
              break;
            }
            const contUser = makeContinueUser(combinedRaw);
            const r = await runOne(contUser, `cont${i + 1}`);
            combinedRaw += r.raw;
            combinedUsage = mergeUsage(combinedUsage, r.usage);
            finishReason = r.finishReason;
          }

          // Preserve final finishReason in usage for logging/UI.
          try {
            if (combinedUsage) combinedUsage.finishReason = finishReason || combinedUsage.finishReason;
          } catch {
            // ignore
          }

          const latestUsage: any = combinedUsage;
          const raw = combinedRaw;

          tEnd(tGeminiStream);

          // (기존 후처리 핵심만 적용: 이름/지문 오류 정리 + 완결 보정 + 예산 컷)
          let assistantText = raw;
          assistantText = stripNamePrefixFromNarration(assistantText);
          assistantText = stripDialogueWrappedNarration(assistantText);
          assistantText = stripEndMarker(assistantText);
	          // Safety: if stopSequences failed and the marker leaked, drop it.
	          try {
	            assistantText = assistantText.split(STATUS_STOP_MARK).join("");
	          } catch {
	            // ignore
	          }
          // In novel mode, avoid aggressive trimming that can drop early scene setup.
// (chat mode only) keep trimToComplete; in novel mode we keep append-only content.
          // Always enforce novel-only output markers (removes accidental markdown markers, keeps *...* / "..." / fenced).
          assistantText = enforceNovelOnlyOutput(assistantText);

          // Label-agnostic fence stabilization (opening line split + unclosed fence repair + conservative loose-meta wrapping)
          assistantText = normalizeAnyFenceOpen(assistantText);
          assistantText = repairUnclosedAnyFence(assistantText);
	          assistantText = wrapLooseMetaAsFence(assistantText).text;
		          // If a STATUS fenced block is closed and then the model keeps writing, trim after STATUS close.
		          assistantText = trimAfterClosedStatusFence(assistantText).text;
		          // Label-agnostic fallback: treat everything after the final closing fence as garbage.
		          assistantText = stripTrailingTextAfterFinalFence(assistantText);

	          // (기본) 상태창은 본문과 함께 "한 번의 호출"로 생성한다.
	          // 다만 필요 시(디버그/실험) 별도 호출 모드를 켤 수 있도록 토글을 남긴다.
	          const STATUS_SEPARATE_MODE_ENV = process.env.AI_STATUS_SEPARATE_MODE === "1";
	          const STATUS_SEPARATE_MODE = false; // forced OFF: always generate STATUS in the main call (single LLM request).
	          if (STATUS_SEPARATE_MODE && authorWantsStatus) {
            try {
              // 본문에 섞인 fenced 블록/미닫힘 잔해를 제거(상태창은 아래에서 새로 생성)
              let bodyOnly = String(assistantText || "");
              bodyOnly = bodyOnly.replace(/```[\s\S]*?```/g, "");
              bodyOnly = bodyOnly.replace(/```[\s\S]*$/g, "");
              assistantText = bodyOnly.trimEnd();

              const sceneTail = String(assistantText || "").slice(-900);
              const statusUser = [
                "너는 방금 답변의 장면을 기반으로, 서사/대사 없이 '상태창'만 출력하라.",
                "- 반드시 fenced 코드블록 1개로만 출력한다: ```STATUS ...```",
                "- 제작자/프리셋이 요구한 상태창 포맷을 최대한 따른다. (가능하면 [시간/장소], [캐릭터 상태] 포함)",
                "- 불필요한 설명/해설/지시문 금지.",
                "",
                "[최근 장면(참고)]",
                sceneTail,
              ].join("\n");

	              const st = await generateText({
	                system: systemStatus,
	                user: statusUser,
	                opts: { ...opts, maxReasoningTokens: 0, maxOutputTokens: 1024 },
	              });

              // 상태창 호출의 usage도 합산(가능한 경우)
              if ((st as any)?.usage && latestUsage) {
                const add = (st as any).usage;
                for (const k of ["promptTokens", "outputTokens", "reasoningTokens", "totalTokens", "latencyMs"]) {
                  (latestUsage as any)[k] = Number((latestUsage as any)[k] || 0) + Number((add as any)[k] || 0);
                }
                if ((add as any).model) (latestUsage as any).model = (add as any).model;
                if ((add as any).finishReason) (latestUsage as any).finishReason = (add as any).finishReason;
              }

                            let metaRaw = String(st?.text || "").trim();
              // Gemini 3 Pro는 MAX_TOKENS로 fenced 블록이 '닫힘 없이' 잘리는 케이스가 많다.
              // 따라서 모델이 fence를 완결하지 못해도 서버에서 안전하게 감싸서 UI 파싱을 지킨다.
              let metaBody = metaRaw;
              if (metaBody.startsWith("```")) {
                const nl = metaBody.indexOf("\n");
                metaBody = nl >= 0 ? metaBody.slice(nl + 1) : "";
              }
              const close = metaBody.lastIndexOf("```");
              if (close >= 0) metaBody = metaBody.slice(0, close);
              metaBody = metaBody.trimEnd();
              if (metaBody) {
                if (metaBody.length > 6000) metaBody = metaBody.slice(0, 6000).trimEnd();
                const meta = "```STATUS\n" + metaBody + "\n```";
                assistantText = preserveTrailingFenceBlockWithinBudget(
                  `${String(assistantText || "").trimEnd()}\n\n${meta}`.trim(),
                  maxChars
                );
              }

            } catch {
              // ignore (fallback: no status block)
            }
          }

          // Keep trailing meta/status fenced block intact by trimming the body first.
          assistantText = preserveTrailingFenceBlockWithinBudget(assistantText, maxChars);

          // NOTE: do not override maxChars here; use the value computed from UI/output settings above.
          if (!NO_TRUNCATE_OUTPUT) {
            if (!NO_TRUNCATE_OUTPUT) assistantText = truncateToCharBudget(assistantText, maxChars);
          }
          // messages 저장
          const createdAt = Date.now();
          const assistantId = randomUUID();

          db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt, userEmail) VALUES (?, ?, ?, ?, ?, ?)`).run(
            assistantId,
            String(chatId),
            "assistant",
            assistantText,
            createdAt,
            u.email
          );
          // (스토리/캐릭터 메모리) 기능 제거: 장기기억 요약만 운용


          // usage 저장(가능하면 실측, 없으면 추정치로라도 저장)
// - 유저가 "토큰 사용량"을 눌렀을 때 항상 값이 보이게 한다.
// - 특히 gemini-3-pro 계열은 usage 메타데이터가 늦거나 누락되는 케이스가 있어 fallback이 필요하다.
          const usageForStore: any = latestUsage && typeof latestUsage === "object" ? { ...latestUsage } : null;

          const promptTokens =
            (usageForStore ? Number(usageForStore.promptTokens || 0) || 0 : 0) || estTokens(`${system}\n\n${user}`);
          const outputTokens =
            (usageForStore ? Number(usageForStore.outputTokens || 0) || 0 : 0) || estTokens(assistantText);
          const reasoningTokens = (usageForStore ? Number(usageForStore.reasoningTokens || 0) || 0 : 0) || 0;

          const totalTokens =
            (usageForStore ? Number(usageForStore.totalTokens || 0) || 0 : 0) || promptTokens + outputTokens + reasoningTokens;

          const latencyMs = (usageForStore ? Number(usageForStore.latencyMs || 0) || 0 : 0) || 0;

          const modelForCost = String((usageForStore && (usageForStore.model || "")) || opts.model || "").trim() || String(opts.model || "");

          const cost = estimateCost(modelForCost, promptTokens, outputTokens);

          // prompt token breakdown (promptTokens를 구성요소별로 배분; 합계는 항상 promptTokens)
          // - 정확한 토크나이저가 없으므로 각 블록의 "추정 토큰" 비율로 promptTokens를 배분한다.
          // - 단, 값이 존재하는 항목은 최소 1토큰을 보장해(표시 0 방지) 사용자에게 어디서 소비되는지 보이게 한다.
          const w = (s: string) => {
            const t = estTokens(s || "");
            return s && s.trim().length > 0 ? Math.max(1, t) : 0;
          };

          const presetPromptW = w(presetBlock);
          const lorebookW = w(typeof loreBlock === "string" ? loreBlock : "");
          const personaW = w(personaBlock);
          const userNoteW = w(noteBlock);
          const longMemoryW = w(historySummary);
          const recentTurnsW = w(context);
          const userInputW = w(userLine);

          // system 전체에는 위 블록들이 포함되어 있으므로, 남는 부분을 "시스템/규칙"으로 분리한다.
          const systemW = estTokens(systemMain);
          const systemAndRulesW = Math.max(0, systemW - (presetPromptW + lorebookW + personaW + userNoteW + longMemoryW));

          const weights = {
            presetPrompt: presetPromptW,
            lorebookPrompt: lorebookW,
            persona: personaW,
            userNote: userNoteW,
            longMemorySummary: longMemoryW,
            recentTurns: recentTurnsW,
            userInput: userInputW,
            systemAndRules: systemAndRulesW,
          };

          const tokenBreakdown = distribute(promptTokens, weights);
          const estPromptTotal = promptTokens;

          const enrichedUsage: any = usageForStore || {};
          enrichedUsage.model = modelForCost;
          enrichedUsage.promptTokens = promptTokens;
          enrichedUsage.outputTokens = outputTokens;
          enrichedUsage.reasoningTokens = reasoningTokens;
          enrichedUsage.totalTokens = totalTokens;
          enrichedUsage.latencyMs = latencyMs;

          enrichedUsage.tokenBreakdown = tokenBreakdown;
          enrichedUsage.estPromptTotal = estPromptTotal;
          enrichedUsage.estimatedCostUsd = cost.costUsd;
          enrichedUsage.estimatedCostKrw = cost.costKrw;
          enrichedUsage.usdToKrw = cost.usdToKrw;

          db.prepare(
            `INSERT OR REPLACE INTO message_usage (messageId, chatId, model, promptTokens, outputTokens, reasoningTokens, totalTokens, latencyMs, estPromptTotal, tokenBreakdown, costUsd, costKrw, usdToKrw, createdAt)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          ).run(
            assistantId,
            String(chatId),
            String(enrichedUsage.model || opts.model),
            promptTokens,
            outputTokens,
            reasoningTokens,
            totalTokens,
            latencyMs,
            estPromptTotal,
            JSON.stringify(tokenBreakdown),
            cost.costUsd,
            cost.costKrw,
            cost.usdToKrw,
            createdAt
          );

          safeEnqueue({
                type: "done",
                user: userMsg,
                assistant: {
                  id: assistantId,
                  chatId: String(chatId),
                  role: "assistant",
                  content: assistantText,
                  createdAt,
                },
                usage: enrichedUsage || null,
                memoryRefresh,
              });
          if (STREAM_DEBUG) console.debug(`${streamTag} done sent (len=${assistantText.length})`, { usage: enrichedUsage || null });
          safeClose();
          // Long-memory refresh (summary/storyMemory) is handled out-of-band.
          // We do NOT run any LLM-based refresh work from /api/chat/send (even deferred).
          // The client may trigger /api/chat/memory/refresh after send/stream using memoryRefresh.
        } catch (e: any) {
          if (STREAM_DEBUG) console.error(`${streamTag} stream error`, e);
          safeEnqueue({ type: "error", error: String(e?.message || e || "error") });
          safeClose();
        }
      })();
    },
  });

  return new Response(rs, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

let latestUsage: any = null;

    tStart(tGemini);
	    const first = await generateText({
      system: systemMain,
      user,
	      opts: { ...opts, maxOutputTokens: maxOutputTokensForCall },
    });
    let assistantText = first.text;
    latestUsage = first.usage;
    {
      const fr = String(first?.usage?.finishReason || "").toUpperCase();
      if (fr && fr !== "STOP" && fr !== "FINISH_REASON_UNSPECIFIED") {
        debugReasons.push(`finishReason:${fr}`);
      }
    }


    // 1) 토큰 상한으로 끊긴 경우: 같은 시스템/컨텍스트를 유지한 채 이어쓰기 요청을 몇 번 자동 수행
//    (재작성보다 이어쓰기가 자연스럽고, 사용자가 겪는 "중간 끊김"을 직접 해결)
//
//    ⚠️ 중요한 안정화:
//    - 상태/INFO/STATUS 같은 fenced 메타 블록이 중간에 나오면, 이어쓰기에서 그 뒤에 본문이 붙어 "상태창 뒤에 또 본문"이 생긴다.
//    - 그래서 이어쓰기 전에 마지막 fenced 블록(있다면)을 떼어두고(메타), 본문만 이어쓴 뒤 마지막에 메타를 1회만 붙인다.
const splitTrailingFenceBlock = (text: string) => {
  const t = String(text || "").trim();
  // 마지막 ```...``` 블록을 잡되, 끝에 있어야만 "메타"로 취급한다.
  const re = /```[^\n]*\n[\s\S]*?\n```\s*$/;
  const m = t.match(re);
  if (!m) return { body: t, meta: "" };
  const meta = m[0].trim();
  const body = t.slice(0, t.length - m[0].length).trim();
  return { body, meta };
};
const stripAllFenceBlocks = (text: string) => {
  const t = String(text || "");
  // 모든 fenced 블록을 제거(이어쓰기에서는 절대 메타/코드블록을 만들지 않도록)
  return t.replace(/```[^\n]*\n[\s\S]*?\n```/g, "").trim();
};

let finish = String((first as any)?.usage?.finishReason || "");

// meta를 분리한 본문 기준으로 이어쓰기를 수행한다.
const _split0 = splitTrailingFenceBlock(assistantText);
let metaTail = _split0.meta;
assistantText = _split0.body;

// Gemini 3 Pro can be very slow per call (40~60s). Avoid long chained auto-continues.
const maxAutoContinue = (typeof opts.model === "string" && opts.model.includes("gemini-3-pro")) ? 1 : 2;
for (let i = 0; i < maxAutoContinue; i++) {
  const cutByMax = /MAX/i.test(finish);
  if (cutByMax) debugReasons.push("continue:MAX_TOKENS");
  if (!cutByMax) break;

  const tail = assistantText.slice(-600);
  const contUser = [
    "너는 방금 출력한 답변의 '서사 본문'을 이어서 계속 써야 한다.",
    "- 절대 앞부분을 반복하지 말고, 바로 이어서 계속한다.",
    "- 형식은 유지한다: 지문은 *...*, 상대(NPC) 대사는 큰따옴표 \"...\".",
    "- (중요) fenced 코드블록(```...```)은 절대 출력하지 마라. 상태/INFO/STATUS 같은 메타 블록 출력 금지.",
    "- (중요) 서사 본문은 따옴표 대사로 끝내지 말고, 반드시 *...* 지문 한 줄로 장면을 닫아라.",
    "",
    "[이전 출력의 끝부분]",
    tail,
    "",
    "이어서 출력하라."
  ].join("\n");

  // 남은 분량만큼만 이어쓰기 예산을 준다(폭주 방지)
  const curLen = Array.from(String((assistantText || "").trim())).length;
  const room = Math.max(0, runawayMaxChars - curLen);
  if (room <= 80) {
    debugReasons.push(`continue:MAX_TOKENS_SKIP(room=${room})`);
    break;
  }
  const extendTokens = Math.max(384, Math.min(2048, Math.floor(room * 2.0)));

  const cont = await generateText({
	    system: systemForContinuation,
    user: contUser,
    opts: { ...opts, maxOutputTokens: extendTokens },
  });

  const moreRaw = stripEndMarker(cont.text);
  const more = stripAllFenceBlocks(moreRaw);

  // 일부 모델은 MAX_TOKENS인데도 빈 문자열을 내는 경우가 있어(특히 3-pro),
  // 이때는 무한 이어쓰기를 피하기 위해 즉시 중단한다.
  if (!more) {
    debugReasons.push("continue:EMPTY_DELTA");
    latestUsage = cont.usage || latestUsage;
    finish = String(cont?.usage?.finishReason || "");
    break;
  }

  assistantText = `${stripEndMarker(assistantText)}\n${more}`.trim();
  latestUsage = cont.usage || latestUsage;
  finish = String(cont?.usage?.finishReason || "");
}

const strlenLocal = (s: string) => Array.from(String(s || "")).length;

// 길이 측정 시에는 "서사 본문"만 본다.
// - STATUS/INFO 같은 fenced 블록(메타)은 길이에서 제외
// - URL/이미지 마크다운(![](), !!https://...)도 제외
const narrativeForLen = (text: string) => {
  let t0 = stripEndMarker(String(text || ""));
  // 완결된 fenced 블록 제거
  t0 = stripAllFenceBlocks(t0);
  // 비완결 fenced(열렸는데 안 닫힌) 블록 제거: ``` 이후 끝까지 제거
  t0 = t0.replace(/```[^\n]*\n[\s\S]*$/g, "");
  // 남은 ``` 잔해 제거
  t0 = t0.replace(/```/g, "");
  return stripUrlsAndMediaMarkdown(t0);
};

// 1-b) 절단 금지 모드에서도 답변이 지나치게 짧게 끝나면(특히 gemini-3-pro* 조기 STOP),
//      재작성 없이 '이어쓰기'를 1회만 수행해 분량을 보강한다.
//      (프롬프트에서 이미 분량을 강하게 요구하지만, 안전망으로 둔다.)
if (NO_TRUNCATE_OUTPUT) {
  const curLenTotal = strlenLocal((assistantText || "").trim());
  const fullForLen = metaTail ? `${assistantText}\n\n${metaTail}` : assistantText;
  const curLenNarr = strlenLocal(narrativeForLen((fullForLen || "").trim()));
  const gap = promptMinChars - curLenNarr;

  // - 목표(90%)보다 부족할 때만 보강
  // - 너무 조금(50자 이하) 부족한 건 그냥 넘어감(과잉 생성 방지)
  // - 이미 폭주 상한(runawayMaxChars)에 근접하면 보강하지 않음
  const room = runawayMaxChars - curLenTotal;

  if (curLenNarr > 0 && gap > 50 && room > 80) {
    debugReasons.push(`continue:SHORT(narr=${curLenNarr}<${promptMinChars}, gap=${gap})`);
    const tail = assistantText.slice(-700);

    // 이어쓰기 예산을 "필요한 만큼만" 부여해 폭주를 막는다.
    // (한글 1자 ≈ 0.6~1 토큰 가정, 넉넉히 3배)
    const extendTokens = Math.max(384, Math.min(2048, gap * 3));

    const contUser = [
      "너는 방금 출력한 서사 본문을 **바로 이어서** 조금만 더 보강해야 한다.",
      "- 절대 앞부분을 반복하지 말고, 직전 문장 다음부터 자연스럽게 이어간다.",
      "- 형식 유지: 지문 *...*, 상대 대사 \"...\"",
      "- 메타/상태창/코드블록 절대 금지.",
      "- 이미지/링크/URL/마크다운(![](), []()) 절대 금지.",
      `- (중요) 약 ${Math.min(gap, 900)}자 정도만 묘사를 더 추가해서 자연스럽게 마무리하라.`,
      "- 마지막은 반드시 *...* 지문 한 줄로 장면을 닫아라.",
      "",
      "[이전 출력의 끝부분]",
      tail,
      "",
      "이어서 출력하라.",
    ].join("\n");

    const cont = await generateText({
	      system: systemForContinuation,
      user: contUser,
      opts: { ...opts, maxOutputTokens: extendTokens },
    });

    const moreRaw = stripEndMarker(cont.text);
    const more = stripAllFenceBlocks(moreRaw);

    if (more) {
      assistantText = `${stripEndMarker(assistantText)}\n${more}`.trim();
      latestUsage = cont.usage || latestUsage;
      finish = String(cont?.usage?.finishReason || finish || "");
    } else {
      debugReasons.push("continue:SHORT_EMPTY");
      latestUsage = cont.usage || latestUsage;
    }
  }
}

// (안전장치) 절단 금지 모드에서도, DB/메모리 폭주만 막기 위한 절대 상한만 둔다.
// NOTE: runawayMaxChars로 자르는 것은 '이미 생성된(과금된) 출력'을 버리게 되므로 비활성화한다.
if (NO_TRUNCATE_OUTPUT) {
  const curLen = strlenLocal((assistantText || "").trim());
  if (curLen > HARD_CAP_CHARS) {
    debugReasons.push(`cap:HARD(${curLen}>${HARD_CAP_CHARS})`);
    assistantText = truncateToCharBudget(assistantText, HARD_CAP_CHARS);
  }
}

// 이어쓰기 후에는 (있다면) 메타 블록을 1회만 맨 끝에 붙인다.
if (metaTail) {
  assistantText = `${assistantText}\n\n${metaTail}`.trim();
}
// (요구사항) 초반 몇 번 답변이 너무 짧거나 중간에서 끊기는 케이스 보정
    // - "중간 끊김"이면: 같은 내용을 "완결" 형태로 재작성(짧아도 됨)
    // - "너무 짧음"이면: 형식 유지 + 조금 더 길게(하지만 끊기지 않게)
    const trimmed = (assistantText || "").trim();

    // 너무 긴 규칙을 주면 모델이 오히려 '*' 같은 잔해만 내보내는 케이스가 있어,
    // 최소 구조(주인공 대사 + 지문 + NPC 대사)만 만족하는지 강하게 검증한다.
    // 추가로 '길이'를 슬라이더 값(=targetChars)에 최대한 맞추기 위해
    // 너무 짧거나/너무 길면 1~2회 재작성하며 max_output_tokens를 동적으로 보정한다.
    const isTooShort = trimmed.length < minChars;
    const isTooLong = trimmed.length > maxChars + 80;
    const looksCut = trimmed.length > 0 && !/[\.!\?"\'\)\]\*]$/.test(trimmed);

    const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const hasNpcLine = new RegExp(`(^|\\n)${esc(npcName)}\\s*\\|\\s*.+`, "m").test(trimmed);
    const hasNarration = /(^|\n)\*[^\n]*\*/m.test(trimmed) || /(^|\n)\*[^\n]+/m.test(trimmed);
    const hasPersonaLine = new RegExp(`(^|\\n)${esc(personaName)}\\s*\\|\\s*.+`, "m").test(trimmed);

    const badShape = trimmed === "*" || trimmed === "" || !hasNpcLine || !hasPersonaLine || !hasNarration;

    // 길이 보정에 사용할 토큰 상한 계산(출력 길이와 사용 토큰/문자 비율 기반)
    const adjustMaxOutputTokens = (desiredChars: number) => {
      // 목표는 "최종 결과를 desiredChars 근처로" 맞추는 것이고, 실제 길이는 아래에서 문자수로 잘라 고정한다.
      // 문제는 max_output_tokens가 너무 낮으면(특히 1000 이하) 모델이 조기 종료/끊김/형식 누락을 내기 쉽다는 점.
      // 그래서 생성 단계에서는 **충분히 크게** 주고, 최종은 문자수로 잘라낸다.
      // 경험적으로(한글 기준) 1토큰당 1~4자까지 흔들릴 수 있으므로 여유를 두어 2.2배를 기본으로 둔다.
      const boosted = Math.floor(desiredChars * 2.2);
      return Math.max(512, Math.min(5000, boosted));
    };
    // NOTE: strlen/sliceChars/truncateToCharBudget are imported from ./_server/charBudget

    if (!NO_TRUNCATE_OUTPUT && (badShape || looksCut || isTooShort || isTooLong)) {
      try {
        const retryUser = [
          user,
          "[추가 지시]",
          badShape
            ? "방금 답변이 형식을 만족하지 못했습니다(대사/지문 누락 또는 '*'만 출력). 아래 규칙대로 전체를 다시 작성하세요."
            : looksCut
              ? "방금 답변이 문장 중간에서 끊겼습니다. 같은 장면을 **짧아도 좋으니 완결**되게 다시 작성하세요."
              : isTooLong
                ? `방금 답변이 너무 깁니다. 같은 장면을 유지하되 군더더기를 줄여 약 ${targetChars}자(±10%) 안으로 더 짧고 밀도 있게 다시 작성하세요.`
                : `방금 답변이 너무 짧습니다. 같은 장면을 유지하되 묘사/상황/심리를 더 추가하여 최소 ${minChars}자 이상으로 충분히 길게 쓰고, 끝까지 완결되게 다시 작성하세요.`,
          "- 반드시 한국어",
          `- 글자수 목표: 약 ${targetChars}자(±10%), 가능하면 ${maxChars}자 이내`,
      `  1) 지문 1~3문장: *...* (행동/표정/상황/심리)`,
      `  2) 주인공 대사 1줄: ${personaNameFinal} | "..." (반드시 큰따옴표로 감싼다)`,
      `  3) 상대 대사 1~3줄: ${preset.characterName || "상대"} | "..." (반드시 큰따옴표로 감싼다)`,
          "- 지문 줄에는 이름 접두를 붙이지 말 것",
          "- 마지막은 마침표/물음표/느낌표/따옴표 중 하나로 문장을 완결하고 종료한다. ([END] 금지)",
          "[주인공 대사(그대로)]",
          userLine,
          "[이전 답변(참고용, 그대로 복붙 금지)]",
          assistantText,
        ].join("\n");

        // 길이/형식 보정 시에는 max_output_tokens를 동적으로 조절한다.
        // - 너무 짧으면 더 쓸 수 있게 상향
        // - 너무 길면 짧게 쓰도록 하향
        const nextMaxOut = adjustMaxOutputTokens(targetChars);
        const rewritten = await generateText({
          system: systemMain,
          user: retryUser,
          opts: { ...opts, maxOutputTokens: nextMaxOut },
        });
        if (rewritten?.text) {
          assistantText = rewritten.text;
          latestUsage = rewritten.usage;
        }
      } catch {
        // ignore
      }
    }

    // (요구사항 #2)
    // "이어쓰기"는 모델이 그대로 지시문을 섞어 출력하거나(예: '이어지는...') 빈 문자열이 나오는 경우가 있어,
    // 2차 재작성 + 최종 문장 단위 절단으로 안정적으로 '완결'을 보장한다.
	    assistantText = stripEndMarker(assistantText || "");
	    // 내부 센티넬이 대화 히스토리에 섞여 들어가면 계속 재출력되는 문제가 있어서
	    // 저장/반환 전에 항상 제거한다.
	    assistantText = assistantText.replace(/<<<END_OF_OUTPUT>>>/g, "").trim();

	    // gemini-3-pro는 길이 지시를 무시하고 과하게 출력하는 경우가 있어
	    // (특히 LOW/MID) promptMaxChars를 크게 초과하면 안전하게 잘라준다.
	    if (isGemini3Pro && assistantText.length > promptMaxChars) {
	      assistantText = trimToComplete(assistantText.slice(0, promptMaxChars));
	    }

    const t1 = (assistantText || "").trim();
    const stillCut = t1.length > 0 && !/[\.\!\?\"\'\)\]\*]$/.test(t1);
    if (!NO_TRUNCATE_OUTPUT && stillCut) {
      try {
        const retryUser2 = [
          user,
          "[추가 지시]",
          "아래 텍스트는 마지막 문장이 미완성입니다. 같은 내용을 **완결된 형태로 전체를 다시 작성**하세요.",
          "- 출력 형식(대사: 이름 | 내용 / 지문: *...*)은 반드시 유지",
          "- 마지막은 완결된 문장/문단으로 끝내기. ([END] 금지)",
          `- 글자수 목표: 약 ${targetChars}자(±10%), 가능하면 ${maxChars}자 이내`,
          "[미완성 텍스트]",
          assistantText,
        ].join("\n");

        const rewritten2 = await generateText({
          system: systemMain,
          user: retryUser2,
          opts: { ...opts, maxOutputTokens: adjustMaxOutputTokens(targetChars) },
        });

        if (rewritten2?.text) {
          assistantText = stripEndMarker(rewritten2.text);
          latestUsage = rewritten2.usage;
        }
      } catch {
        // ignore
      }
    }

    if (!NO_TRUNCATE_OUTPUT) {
      assistantText = trimToComplete(stripEndMarker(assistantText || ""));
    }

    // 마크다운(STATUS 코드펜스) 누락 복구
    {
      const n = normalizeStatusFenceOpen(assistantText);
      if (n.normalized) {
        assistantText = n.text;
        console.warn(`[chat/send] normalized STATUS opening fence (non-stream)`, {
          chatId: String(chatId),
        });
      }
      const r = repairUnclosedStatusFence(assistantText);
      assistantText = r.text;
      if (r.repaired) {
        console.warn(`[chat/send] repaired unclosed STATUS fence (non-stream)`, {
          chatId: String(chatId),
          model: String(opts.model || ""),
        });
      }
    }
    // UI/형식 안정화: 지문 접두/주인공 대사 주체 오류를 최소한으로 교정
    // (핵심) 슬라이더 값(예: 800/1600)에 맞춰 **문자수 기준**으로 최종 길이를 고정한다.
    // - 내부적으로는 max_output_tokens를 넉넉히 줄 수 있지만,
    // - 사용자에게 노출되는 결과는 목표 문자수 범위(±) 안으로 맞춘다.
    if (!NO_TRUNCATE_OUTPUT) {
      const _beforeCharBudget = assistantText;
      assistantText = truncateToCharBudget(assistantText, maxChars);
      if (strlen(_beforeCharBudget) > maxChars) debugReasons.push("trim:CHAR_BUDGET");
    }

    // 여전히 너무 짧으면(특히 1,000 이하 구간) 1회 더 재작성한다.
    if (!NO_TRUNCATE_OUTPUT && (strlen(assistantText) < Math.min(minChars, Math.floor(targetChars * 0.35)) || strlen(assistantText) < 180)) {
      try {
        const retryUser3 = [
          user,
          "[추가 지시]",
          `지금 답변이 너무 짧습니다. 같은 장면을 유지하되 최소 ${minChars}자 이상으로 충분히 서술하고, 끝까지 완결되게 다시 작성하세요.`,
          `- 글자수 목표: 약 ${targetChars}자(±10%), 가능하면 ${maxChars}자 이내`,
          "- 첫 줄은 지문으로 시작(대사로 시작 금지)",
          "- 지문(*...*)에는 이름 접두를 붙이지 말 것",
          "- 마지막은 완결된 문장/문단으로 종료. ([END] 금지)",
          "[주인공 대사(그대로)]",
          userLine,
        ].join("\n");
        const rewritten3 = await generateText({
          system: systemMain,
          user: retryUser3,
          opts: { ...opts, maxOutputTokens: adjustMaxOutputTokens(targetChars) },
        });
        if (rewritten3?.text) {
          assistantText = normalizeNovelPlain(rewritten3.text);
          if (!NO_TRUNCATE_OUTPUT) {
            const _beforeCharBudget2 = assistantText;
            assistantText = truncateToCharBudget(assistantText, maxChars);
            if (strlen(_beforeCharBudget2) > maxChars) debugReasons.push("trim:CHAR_BUDGET");
          }
          latestUsage = rewritten3.usage;
        }
      } catch {
        // ignore
      }
    }

    // Gemini 3 Pro 계열에서 fenced STATUS/INFO가 본문 생성에 섞이면 MAX_TOKENS 때 쉽게 반쪽으로 잘려 UI가 깨진다.
    // 따라서 non-stream에서도 본문은 fenced 메타를 포함하지 않도록 정리하고,
    // 상태창은 항상 별도 짧은 호출로 생성해 맨 끝에 1회만 붙인다.
    const STATUS_SEPARATE_MODE = false;

    // (Fallback) 별도 모드가 OFF여도, "상태창이 반드시 필요한데 누락"되는 케이스는 보강한다.
    // - Gemini 3 Pro는 STOP/MAX_TOKENS/EMPTY_DELTA 혼재로 STATUS 블록이 빠지거나, 본문만 출력되고 끝나는 경우가 있다.
    // - 이 경우는 짧은 2차 호출(가능하면 flash)로 STATUS 블록만 생성해 맨 끝에 붙인다.
    // - STATUS가 이미 존재하면(본문에 포함되어 있거나) 아무 것도 하지 않는다.
    const hasStatusFence = /(^|\n)\s*```\s*STATUS\b/i.test(String(assistantText || ""));
    const shouldStatusFallback = Boolean(authorWantsStatus && isGemini3Pro && !hasStatusFence);
    if (!STATUS_SEPARATE_MODE && shouldStatusFallback) {
      try {
        debugReasons.push("statusFallback:BEGIN");

        const sceneTail = String(assistantText || "").slice(-900);
        const contextTail = String(context || "").slice(-1400);
        const statusUser = [
          "너는 방금 답변의 장면을 기반으로, 서사/대사 없이 '상태창'만 출력하라.",
          "- 출력은 반드시 하나의 fenced 코드블록으로만 구성한다.",
          "- 첫 줄은 정확히 ```STATUS 이고, 마지막 줄은 ``` 이다.",
          "- 코드블록 밖 텍스트 금지.",
          "",
          "[최근 대화(참고)]",
          contextTail,
          "",
          "[최근 장면(참고)]",
          sceneTail,
        ].join("\n");

        const st = await generateText({
          system: systemForStatus,
          user: statusUser,
          opts: {
            ...opts,
            model: "gemini-3-flash-preview",
            // status-only는 추론을 최소화하여 출력 토큰을 최대한 확보
            maxReasoningTokens: 0,
            maxOutputTokens: 640,
          },
        });

        let metaRaw = String(st?.text || "").trim();
        // "TITLE | ```STATUS" 같은 prefix가 섞여 오면 fence 시작점부터 잘라낸다.
        const firstFenceIdx = metaRaw.indexOf("```");
        if (firstFenceIdx > 0) metaRaw = metaRaw.slice(firstFenceIdx).trimStart();
        // Gemini 3 Pro/Flash는 MAX_TOKENS/STOP 경계에서 fence가 미닫힘으로 끝나는 케이스가 많다.
        // 서버에서 안전하게 STATUS fence를 완결한다.
        metaRaw = normalizeStatusFenceOpen(metaRaw).text;
        metaRaw = repairUnclosedStatusFence(metaRaw).text;
        if (!/^```/m.test(metaRaw)) {
          metaRaw = "```STATUS\n" + metaRaw + "\n```";
        } else {
          // 시작 fence가 INFO 등으로 와도 STATUS로 통일
          metaRaw = metaRaw.replace(/^```[^\n]*/m, "```STATUS");
          if (!metaRaw.trimEnd().endsWith("```")) metaRaw = metaRaw.trimEnd() + "\n```";
        }

        // 닫힘 fence 이후의 잔여 텍스트는 잘라낸다(파서 안전).
        const closeEnd = findLastStatusFenceCloseEnd(metaRaw);
        if (closeEnd > 0) metaRaw = metaRaw.slice(0, closeEnd).trimEnd();

        assistantText = `${String(assistantText || "").trimEnd()}\n\n${metaRaw}`.trim();
        assistantText = preserveTrailingFenceBlockWithinBudget(assistantText, maxChars);
        assistantText = stripEndMarker(assistantText || "");

        // 상태창 fallback 호출의 usage도 합산(가능한 경우)
        if ((st as any)?.usage) {
          const add = (st as any).usage;
          if (!latestUsage) latestUsage = {};
          for (const k of ["promptTokens", "outputTokens", "reasoningTokens", "totalTokens", "latencyMs"]) {
            (latestUsage as any)[k] = Number((latestUsage as any)[k] || 0) + Number((add as any)[k] || 0);
          }
          if ((add as any).model) (latestUsage as any).model = (add as any).model;
          if ((add as any).finishReason) (latestUsage as any).finishReason = (add as any).finishReason;
        }

        debugReasons.push("statusFallback:OK");
      } catch {
        debugReasons.push("statusFallback:ERR");
      }
    }
    if (STATUS_SEPARATE_MODE && authorWantsStatus) {
      try {
        // 본문에 섞인 fenced 블록/미닫힘 잔해 제거
        let bodyOnly = String(assistantText || "");
        bodyOnly = bodyOnly.replace(/```[\s\S]*?```/g, "");
        bodyOnly = bodyOnly.replace(/```[\s\S]*$/g, "");
        assistantText = bodyOnly.trimEnd();

        const sceneTail = String(assistantText || "").slice(-900);
        const statusUser = [
          "너는 방금 답변의 장면을 기반으로, 서사/대사 없이 '상태창'만 출력하라.",
          "- 반드시 fenced 코드블록 1개로만 출력한다: ```STATUS ...```",
          "- 제작자/프리셋이 요구한 상태창 포맷을 최대한 따른다. (가능하면 [시간/장소], [캐릭터 상태] 포함)",
          "- 불필요한 설명/해설/지시문 금지.",
          "",
          "[최근 장면(참고)]",
          sceneTail,
        ].join("\n");

        const st = await generateText({
          system: systemStatus,
          user: statusUser,
	          opts: isGemini3Pro
	            ? { ...opts, model: "gemini-3-flash-preview", maxReasoningTokens: 0, maxOutputTokens: 640 }
	            : { ...opts, maxOutputTokens: Math.min(1024, maxOutputTokensForCall) },
        });

                                let metaRaw = String(st?.text || "").trim();
                // Gemini 3 Pro는 MAX_TOKENS로 fenced 블록이 '닫힘 없이' 잘리는 케이스가 많다.
                // 따라서 모델이 fence를 완결하지 못해도 서버에서 안전하게 감싸서 UI 파싱을 지킨다.
                let metaBody = metaRaw;
                if (metaBody.startsWith("```")) {
                  const nl = metaBody.indexOf("\n");
                  metaBody = nl >= 0 ? metaBody.slice(nl + 1) : "";
                }
                const close = metaBody.lastIndexOf("```");
                if (close >= 0) metaBody = metaBody.slice(0, close);
                metaBody = metaBody.trimEnd();
                if (metaBody) {
                  if (metaBody.length > 6000) metaBody = metaBody.slice(0, 6000).trimEnd();
                  const meta = "```STATUS\n" + metaBody + "\n```";
                  assistantText = preserveTrailingFenceBlockWithinBudget(
                    `${String(assistantText || "").trimEnd()}\n\n${meta}`.trim(),
                    maxChars
                  );
                }


        // 상태창 호출의 usage도 합산(가능한 경우)
        if ((st as any)?.usage && latestUsage) {
          const add = (st as any).usage;
          for (const k of ["promptTokens", "outputTokens", "reasoningTokens", "totalTokens", "latencyMs"]) {
            (latestUsage as any)[k] = Number((latestUsage as any)[k] || 0) + Number((add as any)[k] || 0);
          }
          if ((add as any).model) (latestUsage as any).model = (add as any).model;
          if ((add as any).finishReason) (latestUsage as any).finishReason = (add as any).finishReason;
        }

        // 예산 재적용(메타 보존)
        assistantText = preserveTrailingFenceBlockWithinBudget(assistantText, maxChars);
        if (!NO_TRUNCATE_OUTPUT) assistantText = truncateToCharBudget(assistantText, maxChars);
      } catch {
        // ignore
      }
    }

    tEnd(tGemini);
    tStart(tPost);

    // ---- Token breakdown (prompt input composition) ----
    // promptTokens(실측)을 구성요소별로 "배분"해서 보여준다.
    // 각 구성요소의 가중치는 문자 기반 추정치(rough)이며, 합계는 promptTokens(실측)과 정확히 일치한다.
    // NOTE: distribute() is imported from ./_server/distribute

    const presetPromptW = estTokens(presetBlock);
    const personaW = estTokens(personaBlock);
    const userNoteW = estTokens(noteBlock);
    const longMemoryW = estTokens(historySummary);
    const lorebookW = estTokens(typeof loreBlock === "string" ? loreBlock : "");
    const systemW = estTokens(systemMain);
    const systemAndRulesW = Math.max(0, systemW - (presetPromptW + personaW + userNoteW + longMemoryW + lorebookW));
    const recentTurnsW = estTokens(context);
    const userInputW = estTokens(userLine);

    const weights = {
      presetPrompt: presetPromptW,
      lorebookPrompt: lorebookW,
      persona: personaW,
      userNote: userNoteW,
      longMemorySummary: longMemoryW,
      systemAndRules: systemAndRulesW,
      recentTurns: recentTurnsW,
      userInput: userInputW,
    };

    // 비용 추정
    // - 기본: Gemini usageMetadata 기반(실측 input/output)
    // - UI에 표시하는 "예상 비용(추정)"은 "실측 토큰 + 입력 구성(추정)"을 합산한 값으로 계산(사용자 요청)
    const u0 = latestUsage || {};
    // NOTE: modelName is already used above for token budget caps; avoid redeclaration here.
    const modelNameForCost = String(u0.model || opts.model || "");
    const promptT = Number(u0.promptTokens || 0);
    const outT = Number(u0.outputTokens || 0);
    const cost = estimateCost(modelNameForCost, promptT, outT);

    const tokenBreakdown = distribute(promptT, weights);
    const estPromptTotal = Object.values(tokenBreakdown).reduce((a, b) => a + (Number(b) || 0), 0);

    let assistantMsg: any = {
      id: randomUUID(),
      chatId: cid,
      role: "assistant" as const,
      // (요구사항)
      // 응답 첫 줄이 인물 이름으로 시작하는 서술(예: "서윤아는...")이면
      // 억지로 "상대 |" 접두를 붙이지 않는다.
      content: ensurePrefix(assistantText || "(응답이 비었습니다.)", npcName, [personaName, npcName]),
      createdAt: Date.now(),
      usage: latestUsage
        ? {
            ...latestUsage,
            tokenBreakdown,
            estPromptTotal,
            estimatedCostUsd: cost.costUsd,
            estimatedCostKrw: cost.costKrw,
            usdToKrw: cost.usdToKrw,
            debugReasons,
          }
        : null,
    };

    if (replaceAid) {
      // 기존 assistant 메시지를 교체
      db.prepare(`UPDATE messages SET content=?, createdAt=? WHERE id=?`).run(
        encryptIfPossible(assistantMsg.content),
        assistantMsg.createdAt,
        replaceAid
      );
      assistantMsg.id = replaceAid;
    } else {
      db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt, userEmail) VALUES (?, ?, ?, ?, ?, ?)`).run(
        assistantMsg.id,
        assistantMsg.chatId,
        assistantMsg.role,
        encryptIfPossible(assistantMsg.content),
        assistantMsg.createdAt,
        u.email
      );
    }
    // (B 모드) 캐릭터/씬 등 구조화 메모리는 사용하지 않는다.


    // 메시지별 토큰/지연 정보 저장(선택 기능)
    try {
      const u = latestUsage || {};
      const modelName2 = String(u.model || opts.model || "");
      const promptT2 = Number(u.promptTokens || 0);
      const outT2 = Number(u.outputTokens || 0);
	      const reasoningT2 = Number((u as any).reasoningTokens || 0);
	      const c = estimateCost(modelName2, promptT2, outT2);
      db.prepare(
	        `INSERT OR REPLACE INTO message_usage (messageId, chatId, model, promptTokens, outputTokens, reasoningTokens, totalTokens, latencyMs, estPromptTotal, tokenBreakdown, costUsd, costKrw, usdToKrw, createdAt)
	         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(messageId) DO UPDATE SET
           model=excluded.model,
           promptTokens=excluded.promptTokens,
           outputTokens=excluded.outputTokens,
	           reasoningTokens=excluded.reasoningTokens,
           totalTokens=excluded.totalTokens,
           latencyMs=excluded.latencyMs,
           estPromptTotal=excluded.estPromptTotal,
           tokenBreakdown=excluded.tokenBreakdown,
           costUsd=excluded.costUsd,
           costKrw=excluded.costKrw,
           usdToKrw=excluded.usdToKrw,
           createdAt=excluded.createdAt`
      ).run(
        assistantMsg.id,
        cid,
        String(u.model || opts.model || ''),
        Number(u.promptTokens || 0),
	        Number(u.outputTokens || 0),
	        reasoningT2,
        Number(u.totalTokens || 0),
        Number(u.latencyMs || 0),
        Number(u.estPromptTotal || 0),
        JSON.stringify(u.tokenBreakdown || {}),
        Number(c.costUsd || 0),
        Number(c.costKrw || 0),
        Number(c.usdToKrw || DEFAULT_USD_TO_KRW),
        assistantMsg.createdAt
      );
    } catch {
      // ignore
    }

    // (선택지) 사용자가 다음에 말할만한 답변 3개를 제안
    let suggestions: string[] = [];
    if (body?.includeSuggestions === true) {
      try {
      const suggestSystem = [
        "너는 한국어 대화 보조자다.",
        "사용자가 다음에 보낼만한 짧은 답변 후보 3개를 제안한다.",
        "반드시 **주인공(사용자) 시점**의 답변으로만 구성한다.",
        "- 즉, '내/나/저/제가' 등 1인칭을 사용하거나, 주인공이 직접 말하는 문장이어야 한다.",
        "- 상대 캐릭터(서윤아/이춘복 등)의 시점/독백/지문을 쓰지 않는다.",
        "- 이름 접두(예: '서윤아 |')나 지문(*...*)를 포함하지 않는다.",
        "각 항목은 1줄, 4~40자, 존댓말/반말은 현재 톤을 유지한다.",
        "출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\",\"...\"]}",
      ].join("\n");
      const suggestUser = [
        "[최근 대화]",
        context || "",
        "[사용자 방금 입력]",
        userText,
        "[상대 방금 응답]",
        assistantMsg.content,
      ].join("\n");

      const raw = await generateText({
        system: suggestSystem,
        user: suggestUser,
        opts: { ...opts, maxOutputTokens: Math.min(256, Number(settings.maxOutputTokens ?? 1024)) },
      });
      const rawStr = String(raw?.text || "{}").trim();
      // 모델이 코드펜스/설명을 섞어도 JSON만 최대한 추출
      const a = rawStr.indexOf("{");
      const b = rawStr.lastIndexOf("}");
      const jsonStr = a !== -1 && b !== -1 && b > a ? rawStr.slice(a, b + 1) : rawStr;
      const parsed = JSON.parse(jsonStr || "{}");
      if (Array.isArray(parsed.suggestions)) {
        suggestions = parsed.suggestions.map((s: any) => String(s || "").trim()).filter(Boolean).slice(0, 3);
      }
    } catch {
      // ignore
    }

    
    }
// usage는 즉시 렌더링을 위해 함께 내려준다.
    try {
      if (debugReasons.length) {
        console.warn(`[send][${cid}][${reqId}] debug`, debugReasons);
      }
    } catch {
      // ignore
    }
    tEnd(tPost);
    tEnd(tSendTotal);
    return NextResponse.json({ chatId: cid, user: userMsg, assistant: assistantMsg, suggestions, usage: latestUsage || null, memoryRefresh, debugReasons });
  } catch (e: any) {
    // 서버 로그에 남겨서 EC2 콘솔에서 바로 원인 확인 가능
    try {
      console.error("/api/chat/send error:", e?.message || e, e?.stack);
    } catch {
      // ignore
    }

    // 클라이언트에서는 원인 파악이 필요하므로 message를 함께 내려준다(민감정보는 포함하지 않음)
    const msg = String(e?.message || "요청 처리 중 오류가 발생했습니다.");
	    // (주의) 이 함수는 try 블록 내부에서만 타이머 헬퍼가 생성된다.
	    // 에러 상황에서는 타이머 종료를 강제하지 않고 서버 로그를 우선한다.
    // (안전) 가능한 경우 타이머 종료
    try {
      _tEnd(_tPost);
      _tEnd(_tSendTotal);
    } catch {
      // ignore
    }
    if (debugReasons.length) {
      console.warn(`[send][${_cidForLog}][${_reqIdForLog}] debug`, debugReasons);
    }
    return NextResponse.json(
      {
        error: "요청 처리 중 오류가 발생했습니다. 입력값/서버 로그를 확인해 주세요.",
        detail: msg,
      },
      { status: 500 }
    );
  }
}