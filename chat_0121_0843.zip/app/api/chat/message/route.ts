import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { encryptIfPossible } from "@/lib/crypto";

function jsonError(msg: string, status: number = 400) {
  return NextResponse.json({ error: msg }, { status });
}

type MsgRow = {
  id: string;
  chatId: string;
  role: "user" | "assistant" | string;
  createdAt: number;
  chatOwner: string;
};

function getMsgWithOwner(messageId: string): MsgRow | null {
  const row = db
    .prepare(
      `SELECT m.id as id, m.chatId as chatId, m.role as role, m.createdAt as createdAt, c.userEmail as chatOwner
       FROM messages m
       JOIN chats c ON c.id = m.chatId
       WHERE m.id = ?`
    )
    .get(messageId) as any;
  if (!row) return null;
  return {
    id: String(row.id),
    chatId: String(row.chatId),
    role: String(row.role),
    createdAt: Number(row.createdAt) || 0,
    chatOwner: String(row.chatOwner || ""),
  };
}

export async function PATCH(req: Request) {
  try {
    const u = await getSessionUser();
    if (!u) return jsonError("unauthorized", 401);

    const body = await req.json();
    const messageId = String(body?.messageId || "").trim();
    const content = String(body?.content || "").trim();
    if (!messageId) return jsonError("messageId required");
    if (!content) return jsonError("content required");

    const msg = getMsgWithOwner(messageId);
    if (!msg) {
      // idempotent: if already deleted, treat as success to avoid UI "message not found" alerts
      return NextResponse.json({ ok: true, deleted: [], alreadyDeleted: true });
    }
    if (msg.chatOwner !== u.email) return jsonError("forbidden", 403);
    // Allow editing both user and assistant messages.
    // (Some story/simulation workflows require manual fixes to assistant outputs.)
    const role = String(msg.role || "");
    if (role !== "user" && role !== "assistant") {
      return jsonError("only user/assistant messages can be edited", 400);
    }

    db.prepare(`UPDATE messages SET content=?, updatedAt=?, userEmail=? WHERE id=?`).run(
      encryptIfPossible(content),
      Date.now(),
      u.email,
      messageId
    );

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return jsonError(e?.message || "error", 500);
  }
}

export async function DELETE(req: Request) {
  try {
    const u = await getSessionUser();
    if (!u) return jsonError("unauthorized", 401);

    const { searchParams } = new URL(req.url);
    const messageId = String(searchParams.get("messageId") || "").trim();
    if (!messageId) return jsonError("messageId required");

    const msg = getMsgWithOwner(messageId);
    if (!msg) {
      // idempotent: already deleted
      return NextResponse.json({ ok: true, deleted: [], alreadyDeleted: true });
    }
    if (msg.chatOwner !== u.email) return jsonError("forbidden", 403);

    const ordered = db
      .prepare(`SELECT id, role, createdAt FROM messages WHERE chatId=? ORDER BY createdAt ASC, id ASC`)
      .all(msg.chatId) as any[];

    const idx = ordered.findIndex((r) => String(r.id) === messageId);
    if (idx < 0) return jsonError("message not found", 404);

    const idsToDelete = new Set<string>([messageId]);

    // "한 문단" 삭제 규칙
    // - assistant를 지우면 직전 user도 함께 삭제
    // - user를 지우면 직후 assistant도 함께 삭제
    const curRole = String(ordered[idx]?.role || "");
    if (curRole === "assistant") {
      const prev = ordered[idx - 1];
      if (prev && String(prev.role) === "user") idsToDelete.add(String(prev.id));
    } else if (curRole === "user") {
      const next = ordered[idx + 1];
      if (next && String(next.role) === "assistant") idsToDelete.add(String(next.id));
    }

    const ids = Array.from(idsToDelete);

    db.exec("BEGIN");
    try {
      for (const id of ids) {
        db.prepare(`DELETE FROM message_usage WHERE messageId=?`).run(id);
        db.prepare(`DELETE FROM messages WHERE id=?`).run(id);
      }
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }

    return NextResponse.json({ ok: true, deleted: ids });
  } catch (e: any) {
    return jsonError(e?.message || "error", 500);
  }
}
