import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, verifySession } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";

const KRW_PER_FRIENDFEE = 1.7;

function noStore(res: NextResponse) {
  res.headers.set("Cache-Control", "no-store, max-age=0");
  res.headers.set("Pragma", "no-cache");
  res.headers.append("Vary", "Cookie");
  return res;
}

function ratePer1k(model: string) {
  const m = (model || "").toLowerCase();
  if (m.includes("flash")) return 1.0;
  if (m.includes("2.5") && m.includes("pro")) return 3.5;
  if (m.includes("3") && m.includes("pro")) return 4.5;
  // fallback: treat as pro-tier
  return 3.5;
}

function ensureWallet(email: string) {
  const now = Date.now();
  db.prepare(
    `INSERT INTO friendfee_wallet (userEmail, balance, updatedAt)
     VALUES (?, 0, ?)
     ON CONFLICT(userEmail) DO NOTHING`
  ).run(email, now);
}

export async function POST(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value ?? "";
  const session = token ? await verifySession(token) : null;
  if (!session?.email) {
    return noStore(NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 }));
  }

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    body = null;
  }

  const chatId = String(body?.chatId || "");
  const messageId = String(body?.messageId || "");
  const totalTokens = Number(body?.totalTokens ?? NaN);
  const model = String(body?.model || "");
  if (!chatId || !messageId || !Number.isFinite(totalTokens) || totalTokens <= 0) {
    return noStore(NextResponse.json({ ok: false, error: "bad_request" }, { status: 400 }));
  }

  ensureWallet(session.email);

  // friendfee_touch_user: update last seen for admin panel
  const nowIso = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (email, created_at, updated_at, last_login_at, last_seen_at)
     VALUES (?, datetime('now'), datetime('now'), ?, ?)
     ON CONFLICT(email) DO UPDATE SET
       updated_at = datetime('now'),
       last_seen_at = excluded.last_seen_at`
  ).run(session.email, nowIso, nowIso);

  const fee = (totalTokens / 1000) * ratePer1k(model);
  const krw = fee * KRW_PER_FRIENDFEE;

  // Idempotency: if already billed for this messageId, return previous result
  const existing = db
    .prepare(
      `SELECT delta, balanceAfter, totalTokens, model, createdAt
       FROM friendfee_ledger
       WHERE userEmail = ? AND kind = 'spend' AND messageId = ?`
    )
    .get(session.email, messageId) as any;

  if (existing) {
    const bal = Number(existing.balanceAfter ?? 0);
    return noStore(
      NextResponse.json({ ok: true, alreadyBilled: true, fee, krw, balance: bal, balanceRounded: Math.round(bal) })
    );
  }

  const now = Date.now();

  // Transaction: check balance then deduct
  try {
    const tx = db.transaction(() => {
      const w = db.prepare(`SELECT balance FROM friendfee_wallet WHERE userEmail = ?`).get(session!.email) as any;
      const bal = Number(w?.balance ?? 0);
      if (bal < fee) {
        return { ok: false as const, balance: bal };
      }
      const nextBal = bal - fee;
      db.prepare(`UPDATE friendfee_wallet SET balance = ?, updatedAt = ? WHERE userEmail = ?`).run(nextBal, now, session!.email);
      db.prepare(
        `INSERT INTO friendfee_ledger (userEmail, kind, delta, balanceAfter, chatId, messageId, totalTokens, model, meta, createdAt)
         VALUES (?, 'spend', ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(session!.email, -fee, nextBal, chatId, messageId, Math.round(totalTokens), model, JSON.stringify({ krw }), now);
      return { ok: true as const, balance: nextBal };
    });
    const r = tx();
    if (!r.ok) {
      return noStore(
        NextResponse.json(
          { ok: false, error: "insufficient", fee, krw, balance: r.balance, balanceRounded: Math.round(r.balance) },
          { status: 402 }
        )
      );
    }
    return noStore(
      NextResponse.json({ ok: true, fee, krw, balance: r.balance, balanceRounded: Math.round(r.balance) })
    );
  } catch (e: any) {
    return noStore(NextResponse.json({ ok: false, error: "server_error" }, { status: 500 }));
  }
}
