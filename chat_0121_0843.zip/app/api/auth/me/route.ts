import { NextRequest, NextResponse } from "next/server";
import { attachClearSessionCookie, verifySession, SESSION_COOKIE } from "@/lib/auth";
import { db, getUserByEmail } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value ?? "";
  const session = token ? await verifySession(token) : null;

  let user: any = null;
  let shouldClear = false;
  if (session?.email) {
    const row = db.prepare(`SELECT is_banned, deleted_at FROM users WHERE email = ?`).get(session.email) as any;
    if (row && (Number(row.is_banned || 0) === 1 || row.deleted_at)) {
      shouldClear = true;
      user = null;
    } else {
      const dbUser = getUserByEmail(session.email);
      user = {
        email: session.email,
        name: dbUser?.name ?? session.name ?? null,
        picture: (dbUser as any)?.image ?? (dbUser as any)?.picture ?? session.picture ?? null,
        nickname: dbUser?.nickname ?? session.nickname ?? null,
      };
    }
  }

  const res = NextResponse.json({ ok: true, user });
  if (shouldClear) {
    await attachClearSessionCookie(res);
  }

  res.headers.set("Cache-Control", "no-store, max-age=0");
  res.headers.set("Pragma", "no-cache");
  res.headers.append("Vary", "Cookie");
  return res;
}
