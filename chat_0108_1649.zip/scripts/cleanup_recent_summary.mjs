#!/usr/bin/env node
/**
 * One-time cleanup: remove URL / media-markdown junk from chat_memory_cache.recentSummary
 *
 * Usage:
 *   cd /root/ai-chat/ai
 *   # (recommended) backup DB first:
 *   cp -a data/data.sqlite3 data/data.sqlite3.bak.$(date +%Y%m%d_%H%M%S)
 *   node scripts/cleanup_recent_summary.mjs
 *
 * Notes:
 * - Uses better-sqlite3 directly (no TS runtime needed).
 * - Updates only rows where recentSummary changes.
 */

import fs from "fs";
import path from "path";
import Database from "better-sqlite3";

// ---- sanitizer (self-contained; mirrors the "stripUrlsAndMediaMarkdown" intent) ----
function stripUrlsAndMediaMarkdown(input) {
  if (!input) return "";

  let s = String(input);

  // 1) Normalize whitespace around broken URLs (common: "https://itimg.\nkr/..")
  // Join "http(s)://<chunk> \n <chunk>" when the newline splits a URL-like token.
  s = s.replace(/https?:\/\/([^\s)\]]+)\s*\n\s*([^\s)\]]+)/g, "https://$1$2");

  // 2) Remove image markdown entirely: ![alt](url)
  s = s.replace(/!\[[^\]]*?\]\((?:https?:\/\/)?[^)]*?\)/g, "");

  // 3) Replace link markdown [text](url) -> text (keep visible text)
  s = s.replace(/\[([^\]]+?)\]\((?:https?:\/\/)?[^)]*?\)/g, "$1");

  // 4) Remove bare URLs (http/https)
  s = s.replace(/https?:\/\/[^\s)\]]+/g, "");

  // 5) Remove common media path fragments that often leak in broken form
  // e.g. "itimg.kr/125/GM/51/AA.webp" or "kr/125/GM/51/AA.\nwebp"
  s = s.replace(/\bitimg\.kr\b[^\s)]+/g, "");
  s = s.replace(/\bkr\/\d+\/[A-Z]{2}\/\d+\/[A-Z]{2}\/[A-Z]{2}\.[a-z0-9]{2,5}\b/gi, "");
  s = s.replace(/\b[a-z0-9_\-\/]+\.(?:webp|png|jpe?g|gif)\b/gi, "");

  // 6) Remove leftover empty markdown image/link tokens like "[]()" or "[]"
  s = s.replace(/\[\]\([^)]*\)/g, "");
  s = s.replace(/\[\]/g, "");

  // 7) Cleanup excessive spaces
  s = s.replace(/[ \t]+\n/g, "\n");
  s = s.replace(/\n{4,}/g, "\n\n\n");

  return s.trim();
}

// ---- DB helpers ----
function existsTable(db, table) {
  const row = db
    .prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`)
    .get(table);
  return !!row;
}

function main() {
  const cwd = process.cwd(); // expected: /root/ai-chat/ai
  const dbPath = path.join(cwd, "data", "data.sqlite3");

  if (!fs.existsSync(dbPath)) {
    console.error(`[cleanup_recent_summary] DB not found: ${dbPath}`);
    console.error(`Tip: run from your app dir (e.g. cd /root/ai-chat/ai), or check your DB path.`);
    process.exit(1);
  }

  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");

  if (!existsTable(db, "chat_memory_cache")) {
    console.error(`[cleanup_recent_summary] Table chat_memory_cache not found. Is this the right DB?`);
    process.exit(1);
  }

  const rows = db
    .prepare(
      `SELECT chatId, recentSummary
       FROM chat_memory_cache
       WHERE recentSummary IS NOT NULL AND recentSummary != ''`
    )
    .all();

  const upd = db.prepare(
    `UPDATE chat_memory_cache
     SET recentSummary = ?, recentSummaryChars = ?, updatedAt = ?
     WHERE chatId = ?`
  );

  let changed = 0;
  const now = Date.now();

  const tx = db.transaction(() => {
    for (const r of rows) {
      const before = String(r.recentSummary ?? "");
      const after = stripUrlsAndMediaMarkdown(before);
      if (after !== before) {
        upd.run(after, after.length, now, r.chatId);
        changed++;
      }
    }
  });

  tx();

  console.log(
    `[cleanup_recent_summary] scanned=${rows.length} changed=${changed} db=${dbPath}`
  );
  if (changed > 0) {
    console.log(`[cleanup_recent_summary] Done. (Recommended) restart dev server to reload memory cache.`);
  }
}

main();
