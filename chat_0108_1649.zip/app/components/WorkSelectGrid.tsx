"use client";

import React, { useMemo } from "react";
import { BookOpen } from "lucide-react";

type Preset = {
  id: string;
  name: string;
  characterName?: string;
  background?: string;
  desc?: string;
  image?: string;
  gallery?: string;
  tags?: string;
  target?: string;
};

function safeString(v: any) {
  return typeof v === "string" ? v : "";
}

function compactTitle(t: string) {
  return String(t || "").trim();
}

function clampText(t: string, max = 120) {
  const s = String(t || "").replace(/\s+/g, " ").trim();
  if (!s) return "";
  if (s.length <= max) return s;
  return s.slice(0, max - 1) + "…";
}

const FALLBACK_THUMB =
  "data:image/svg+xml;charset=utf-8," +
  encodeURIComponent(`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450" viewBox="0 0 800 450">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#1b1b24"/>
      <stop offset="1" stop-color="#0b0b0f"/>
    </linearGradient>
  </defs>
  <rect width="800" height="450" fill="url(#g)"/>
  <circle cx="640" cy="120" r="110" fill="rgba(255,255,255,0.06)"/>
  <circle cx="160" cy="340" r="160" fill="rgba(255,255,255,0.04)"/>
  <g fill="rgba(255,255,255,0.14)">
    <path d="M370 166c0-16 13-30 30-30h142c16 0 30 14 30 30v118c0 16-14 30-30 30H400c-17 0-30-14-30-30V166zm38 22h126c6 0 10 4 10 10v54l-20-18c-4-3-9-3-13 0l-30 26-24-18c-4-3-10-3-14 1l-35 33v-78c0-6 4-10 10-10z"/>
  </g>
  <text x="40" y="410" font-family="system-ui,-apple-system,Segoe UI,Roboto" font-size="18" fill="rgba(255,255,255,0.38)">No Cover</text>
</svg>`);

function pickThumb(p: Preset) {
  const img = safeString((p as any).image).trim();
  if (img) return img;
  const rawGallery = safeString((p as any).gallery).trim();
  if (rawGallery) {
    try {
      const parsed = JSON.parse(rawGallery);
      if (Array.isArray(parsed)) {
        const first = parsed[0];
        if (typeof first === "string" && first.trim()) return first.trim();
        if (first && typeof first === "object") {
          const u = safeString((first as any).url || (first as any).src || (first as any).image).trim();
          if (u) return u;
        }
      }
    } catch {
      // ignore
    }
  }
  return FALLBACK_THUMB;
}

function pickDesc(p: Preset) {
  const d = safeString((p as any).desc).trim();
  if (d) return d;
  const bg = safeString((p as any).background).trim();
  if (bg) return bg;
  const tags = safeString((p as any).tags).trim();
  if (tags) return tags;
  const target = safeString((p as any).target).trim();
  return target;
}

function WorkSelectLogo() {
  return (
    <div
      aria-hidden
      style={{
        width: 26,
        height: 26,
        borderRadius: 10,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(255,255,255,0.06)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
      }}
    >
      <BookOpen size={16} style={{ opacity: 0.92 }} />
    </div>
  );
}

export default function WorkSelectGrid(props: {
  presets: Preset[];
  selectedPresetId: string | null;
  onSelect: (presetId: string) => void;
}) {
  const items = useMemo(() => props.presets || [], [props.presets]);

  return (
    <div
      style={{
        border: "1px solid rgba(255,255,255,0.10)",
        background: "rgba(255,255,255,0.04)",
        borderRadius: 18,
        padding: 16,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10, fontWeight: 900, marginBottom: 12, fontSize: 16 }}><WorkSelectLogo />작품 선택</div>

      {items.length === 0 ? (
        <div style={{ opacity: 0.8 }}>프리셋이 없습니다.</div>
      ) : (
        <>
          <style jsx>{`
            @media (max-width: 1100px) {
              .grid4 {
                grid-template-columns: repeat(2, minmax(0, 1fr));
              }
            }
            @media (max-width: 640px) {
              .grid4 {
                grid-template-columns: repeat(1, minmax(0, 1fr));
              }
            }
          `}</style>

          <div
            className="grid4"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
              gap: 12,
            }}
          >
            {items.map((p) => {
              const thumb = pickThumb(p);
              const title = compactTitle(p.name);
              const desc = clampText(pickDesc(p) || "", 140);
              const active = props.selectedPresetId === p.id;

              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => props.onSelect(p.id)}
                  style={{
                    textAlign: "left",
                    border: active ? "1px solid rgba(255,255,255,0.22)" : "1px solid rgba(255,255,255,0.10)",
                    background: active ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.03)",
                    color: "#e9eefc",
                    borderRadius: 18,
                    overflow: "hidden",
                    cursor: "pointer",
                    padding: 0,
                    boxShadow: active ? "0 0 0 1px rgba(255,255,255,0.06), 0 10px 24px rgba(0,0,0,0.35)" : "none",
                    transition: "transform 120ms ease, box-shadow 120ms ease, border-color 120ms ease",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-2px)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0px)";
                  }}
                >
                  <div
                    style={{
                      width: "100%",
                      // 더 세로로 키워서 썸네일이 꽉 차 보이게
                      aspectRatio: "4 / 5",
                      background: "linear-gradient(135deg, rgba(255,255,255,0.05), rgba(0,0,0,0.0))",
                      borderBottom: "1px solid rgba(255,255,255,0.08)",
                    }}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={thumb}
                      alt={title}
                      loading="lazy"
                      style={{
                        width: "100%",
                        height: "100%",
                        // 카드가 커진 만큼, 이미지도 꽉 차게 (원본 비율 유지 + 중앙 크롭)
                        objectFit: "cover",
                        objectPosition: "center",
                        display: "block",
                      }}
                    />
                  </div>

                  <div style={{ padding: 12 }}>
                    <div style={{ fontWeight: 900, fontSize: 14, lineHeight: 1.25 }}>{title || "(제목 없음)"}</div>
                    <div
                      style={{
                        marginTop: 6,
                        fontSize: 12,
                        opacity: 0.78,
                        lineHeight: 1.35,
                        display: "-webkit-box",
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: "vertical",
                        overflow: "hidden",
                      }}
                    >
                      {desc || "설명이 없습니다."}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
