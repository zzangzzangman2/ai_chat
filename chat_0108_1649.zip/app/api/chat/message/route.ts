import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { encryptIfPossible } from "@/lib/crypto";

function bad(msg: string, status: number = 400) {
  return NextResponse.json({ error: msg }, { status });
}

export async function PATCH(req: Request) {
  try {
    const body = await req.json();
    const messageId = String(body?.messageId || "").trim();
    const content = String(body?.content || "").trim();
    if (!messageId) return bad("messageId required");
    if (!content) return bad("content required");
    db.prepare(`UPDATE messages SET content=? WHERE id=? AND userEmail=?`).run(encryptIfPossible(content), messageId);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return bad(e?.message || "error");
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const messageId = String(searchParams.get("messageId") || "").trim();
    if (!messageId) return bad("messageId required");
    db.prepare(`DELETE FROM message_usage WHERE messageId=?`).run(messageId);
    db.prepare(`DELETE FROM messages WHERE id=? AND userEmail=?`).run(messageId);
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return bad(e?.message || "error");
  }
}
