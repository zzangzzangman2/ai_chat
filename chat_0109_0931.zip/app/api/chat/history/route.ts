import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { decryptIfPossible } from "@/lib/crypto";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const chatId = searchParams.get("chatId") || "";

  if (!chatId) {
    return NextResponse.json({ error: "chatId가 필요합니다." }, { status: 400 });
  }

  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const chat = db.prepare(`SELECT id FROM chats WHERE id=? AND userEmail=?`).get(chatId, u.email);
  if (!chat) {
    return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });
  }

  const messages = db
    .prepare(
      `SELECT m.id, m.chatId, m.role, m.content, m.createdAt,
	              u.model as usageModel, u.promptTokens, u.outputTokens, u.reasoningTokens, u.totalTokens, u.latencyMs,
              u.estPromptTotal, u.tokenBreakdown, u.costUsd, u.costKrw, u.usdToKrw
         FROM messages m
         LEFT JOIN message_usage u ON u.messageId = m.id
        WHERE m.chatId=?
        ORDER BY m.createdAt ASC`
    )
    .all(chatId)
    .map((m: any) => ({
      ...m,
      content: decryptIfPossible(String(m.content || "")),
      usage: m.usageModel
        ? {
            model: String(m.usageModel || ""),
            promptTokens: Number(m.promptTokens || 0),
	            outputTokens: Number(m.outputTokens || 0),
	            reasoningTokens: Number(m.reasoningTokens || 0),
            totalTokens: Number(m.totalTokens || 0),
            latencyMs: Number(m.latencyMs || 0),
            estPromptTotal: Number(m.estPromptTotal || 0),
            estimatedCostUsd: Number(m.costUsd || 0),
            estimatedCostKrw: Number(m.costKrw || 0),
            usdToKrw: Number(m.usdToKrw || 0),
            tokenBreakdown: (() => {
              try {
                return m.tokenBreakdown ? JSON.parse(String(m.tokenBreakdown)) : {};
              } catch {
                return {};
              }
            })(),
          }
        : null,
    }));

  return NextResponse.json({ messages });
}

