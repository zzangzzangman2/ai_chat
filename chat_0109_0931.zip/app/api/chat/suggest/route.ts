import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { decryptIfPossible } from "@/lib/crypto";
import { generateText } from "@/lib/ai";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json().catch(() => ({}));
    const chatId = String(body?.chatId || "").trim();
    // (중요) 클라이언트가 "방금 화면에 출력된" assistant 내용을 넘겨주면 그걸 우선 사용한다.
    // - DB 저장 타이밍/경쟁 상태(race) 때문에 이전 턴이 잡히는 현상 방지
    // - 스트리밍 중간/후처리로 content가 달라져도, 화면 기준으로 추천을 뽑을 수 있음
    const assistantContent = String(body?.assistantContent || "").trim();
    const personaOverride = body?.personaOverride || null;
    const previousSuggestions = Array.isArray(body?.previousSuggestions) ? body.previousSuggestions : null;

    if (!chatId) {
      return NextResponse.json({ error: "chatId가 필요합니다." }, { status: 400 });
    }

    // 마지막 assistant 메시지 가져오기
    const row = db
      .prepare(
        `SELECT m.content AS content
         FROM messages m
         WHERE m.chatId=? AND m.role='assistant'
         ORDER BY m.createdAt DESC
         LIMIT 8`
      )
      .all(chatId) as any[];

    const rows = Array.isArray(row) ? row : (row ? [row] : []);

    // 마지막 user 메시지도 함께 가져와서, 직전 assistant가 이미지/구분선뿐인 경우에도 문맥 기반 추천을 만들 수 있게 한다.
    const lastUserRow = db
      .prepare(
        `SELECT m.content AS content
         FROM messages m
         WHERE m.chatId=? AND m.role='user'
         ORDER BY m.createdAt DESC
         LIMIT 1`
      )
      .get(chatId) as any;

    const lastUserTextRaw = decryptIfPossible(String(lastUserRow?.content || "")).trim();


    const clipTail = (s: string, maxChars: number) => {
      const str = String(s || "");
      if (!maxChars || maxChars <= 0) return str;
      return str.length > maxChars ? str.slice(str.length - maxChars) : str;
    };

    const stripInfoStatusFences = (s: string) => {
      // INFO/STATUS 블록은 길고(토큰 소모), 추천 품질을 흐릴 수 있어 제거한다.
      // (문맥이 완전히 비는 경우는 아래에서 user 메시지로 보완)
      return String(s || "").replace(/```\s*(INFO|STATUS)[\s\S]*?```/gi, "");
    };

    const sanitizeForSuggest = (input: string) => {
      const normalized = stripInfoStatusFences(String(input || "").replace(/\r\n/g, "\n"));

      // 줄 단위로 가볍게 정리 (이미지/구분선 제거)
      const lines = normalized
        .split("\n")
        .map((ln) => {
          const t = String(ln || "").trim();
          if (!t) return "";
          if (/^[=＝]+$/.test(t)) return "";
          if (/^!\[[^\]]*\]\([^\)]+\)\s*$/.test(t)) return "";
          if (/^https?:\/\/\S+\.(?:png|jpe?g|gif|webp)(?:\?\S*)?$/i.test(t)) return "";
          if (/^\{\{img:[^}]+\}\}$/i.test(t)) return "";
          return ln;
        })
        .filter(Boolean);

      // 연속 공백/빈줄 정리
      return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
    };

    const extractDialogueCues = (input: string, maxItems: number = 4) => {
      // Try to extract the *last* few dialogue-ish lines so suggestions match the immediate situation.
      // Supports patterns like:
      // - "[홍시율] ...", "**엘라 54 |** ...", "엘키 98 | ...", "“...”"
      const s = stripInfoStatusFences(String(input || ""))
        .replace(/\r\n/g, "\n")
        .split("\n")
        .map((ln) => ln.trim())
        .filter(Boolean)
        .filter((ln) => {
          // drop images / urls / separators
          if (/^!\[[^\]]*\]\([^\)]+\)\s*$/i.test(ln)) return false;
          if (/^https?:\/\/\S+$/i.test(ln)) return false;
          if (/^[\-=─━]{6,}$/.test(ln)) return false;
          if (/^```/.test(ln)) return false;
          return true;
        });

      const picks: string[] = [];
      for (let i = s.length - 1; i >= 0; i--) {
        const ln = s[i];

        const isBracketSpeaker = /^\[[^\]]{1,24}\]\s+/.test(ln);              // [홍시율] ...
        const isPipeSpeaker = /(?:\|\s*)/.test(ln) && ln.length <= 180;       // 엘라 54 | ...
        const hasQuotes = /["“”]/.test(ln) && ln.length <= 220;              // "..."/“...”
        const looksDialogue = isBracketSpeaker || isPipeSpeaker || hasQuotes;

        if (!looksDialogue) continue;

        // remove markdown speaker emphasis like **엘라 54 |**
        const cleaned = ln.replace(/\*\*/g, "").trim();
        if (!cleaned) continue;

        // avoid duplicates
        if (picks.length === 0 || picks[picks.length - 1] !== cleaned) {
          picks.push(cleaned);
        }
        if (picks.length >= maxItems) break;
      }

      return picks.reverse().join("\n").trim();
    };


    const pickLastAssistantTextForSuggest = (items: any[]): string => {
      for (const it of items) {
        const raw = decryptIfPossible(String(it?.content || "")).trim();
        const cleaned = sanitizeForSuggest(raw);
        // skip if effectively empty (e.g., only images/separators)
        if (cleaned && cleaned.replace(/\s+/g, " ").trim().length >= 10) return cleaned;
      }
      return "";
    };

    // 1) 클라이언트가 준 "방금 출력된" 텍스트(최우선)
    // 2) DB에서 최근 assistant (fallback)
    // 3) 둘 다 없으면 최근 user
    const lastAssistantRaw = assistantContent || pickLastAssistantTextForSuggest(rows);
    const lastAssistant = clipTail(sanitizeForSuggest(lastAssistantRaw), 1600);
    const dialogueCues = clipTail(extractDialogueCues(lastAssistantRaw), 900);
    const lastUserText = clipTail(sanitizeForSuggest(lastUserTextRaw), 900);

    // 주인공(유저) 시점 3개 고정
    // - 부가 기능이라 속도 우선: flash 모델 + 낮은 reasoning
    const system = [
      "너는 소설형 AI 채팅의 '추천 답변' 생성기다.",
      "반드시 한국어로만 답한다.",
      "반드시 '주인공(사용자)' 1인칭 시점의 대사로만 3개를 만든다.",
      "상대(assistant) 입장의 말투/1인칭(나는/제가)로 쓰지 마라.",
      "지문(상황 설명) 금지. 대사(말)만.",
      "너무 길게 쓰지 말고(각 40자 이내), 한 줄씩 자연스럽게.",
      "반드시 방금 상황(직전 발화)에 구체적으로 반응하는 말로 써라. 뜬금없는 일반론 금지.",
      "출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\",\"...\"]}",
    ].join("\n");

    const personaLine = personaOverride
      ? `주인공 정보(참고): 이름=${String(personaOverride?.personaName || "").trim()}, 나이=${Number(personaOverride?.personaAge || 0)}, 성별=${String(personaOverride?.personaGender || "").trim()}, 설명=${String(personaOverride?.personaInfo || "").trim()}`
      : "";

    const prevLine = Array.isArray(previousSuggestions) && previousSuggestions.length > 0
      ? `이전 추천 답변(반복 금지): ${previousSuggestions.map((s: any) => String(s || "").trim()).filter(Boolean).slice(0, 8).join(" | ")}`
      : "";

    const user = [
      personaLine,
      prevLine,
      "[직전 사용자 발화]",
      lastUserText || "(직전 사용자 발화가 비어있음)",
      "[직전 상대 핵심 발화]",
      (dialogueCues || lastAssistant || "(직전 assistant 내용이 비어있음)"),
      "",
      "위 내용을 바탕으로, 주인공(사용자)이 *지금 상황에 맞게* 다음에 할 법한 대사 3개를 추천해줘.",
      "조건: 각 대사에는 위 내용에 나온 고유명사/사물/행동 중 최소 1개를 포함해라.",
    ]
      .filter(Boolean)
      .join("\n");

    const r = await generateText({
      system,
      user,
      opts: {
        model: "gemini-3-flash-preview",
        // JSON + 3개 대사를 안전하게 담기 위한 최소 여유
        maxOutputTokens: 640,
        maxReasoningTokens: 0,
      },
    });

    let suggestions: string[] = [];
    try {
      const rawText = String(r.text || "").trim();
      const a = rawText.indexOf("{");
      const b = rawText.lastIndexOf("}");
      const jsonText = a >= 0 && b > a ? rawText.slice(a, b + 1) : rawText;
      const parsed = JSON.parse(jsonText);
      if (Array.isArray(parsed?.suggestions)) {
        suggestions = parsed.suggestions
          .map((s: any) => String(s || "").trim())
          .filter(Boolean)
          .slice(0, 3);
      }
    } catch {
      suggestions = [];
    }

    // 후처리: 중복/이전추천 제거 + 최소 3개 보장
    const prevSet = new Set(
      (Array.isArray(previousSuggestions) ? previousSuggestions : [])
        .map((s: any) => String(s || "").trim())
        .filter(Boolean)
    );

    const uniq: string[] = [];
    const seen = new Set<string>();
    for (const s of suggestions) {
      const t = String(s || "").trim();
      if (!t) continue;
      if (t.length > 80) continue;
      if (prevSet.has(t)) continue;
      if (seen.has(t)) continue;
      seen.add(t);
      uniq.push(t);
    }
    suggestions = uniq.slice(0, 3);

    if (!suggestions || suggestions.length < 3) {
      const fallbackPool = [
        "…잠깐, 방금 상황을 한 문장으로 정리해줄래?",
        "지금 네가 진짜 원하는 건 뭐야? (한 가지만)",
        "그럼 나는 지금 뭘 하면 돼? 바로 다음 행동만 말해줘.",
        "그 말, 구체적으로 어떤 일이 있었는지 순서대로 말해줘.",
        "잠깐… 너 지금 무슨 의도야? 솔직하게 말해줘.",
      ];

      const off = Math.abs(Date.now()) % fallbackPool.length;
      const fill: string[] = [];
      for (let i = 0; i < fallbackPool.length && suggestions.length + fill.length < 3; i++) {
        const cand = fallbackPool[(off + i) % fallbackPool.length];
        if (!cand) continue;
        if (suggestions.includes(cand)) continue;
        if (prevSet.has(cand)) continue;
        fill.push(cand);
      }
      suggestions = [...suggestions, ...fill].slice(0, 3);
    }

    return NextResponse.json({ suggestions });
  } catch (e: any) {
    return NextResponse.json({ error: String(e?.message || "추천답변 생성 실패") }, { status: 500 });
  }
}
