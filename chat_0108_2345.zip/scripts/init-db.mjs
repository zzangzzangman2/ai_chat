import "../lib/db.ts";
console.log("DB init done");
