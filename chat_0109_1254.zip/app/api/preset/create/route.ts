// app/api/preset/create/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { randomUUID } from "crypto";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json();
    const now = Date.now();
    const id = randomUUID();

    const name = String(body?.name || "새 프리셋");
    const background = String(body?.background || "");
    const characterName = String(body?.characterName || "상대");
    const characterAge = Number(body?.characterAge || 0);
    const character = String(body?.character || "");
    const systemPrompt = String(body?.systemPrompt || "");

    const image = String(body?.image || "");
    const tags = String(body?.tags || "");
    const target = String(body?.target || "all");
    const isPublic = body?.isPublic === 0 || body?.isPublic === false ? 0 : 1;
    const gallery = String(body?.gallery || "[]");
    const firstMessages = String(body?.firstMessages || "[]");
    const lorebooks = String(body?.lorebooks || "[]");

    db.prepare(
      `INSERT INTO presets (
          id, userEmail, name, background, characterName, characterAge, character, systemPrompt,
          image, tags, target, gallery, firstMessages, lorebooks,
          createdAt, isPublic
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      u.email,
      name,
      background,
      characterName,
      characterAge,
      character,
      systemPrompt,
      image,
      tags,
      target,
      gallery,
      firstMessages,
      lorebooks,
      now,
      isPublic
    );

    return NextResponse.json({
      preset: {
        id,
        name,
        background,
        characterName,
        characterAge,
        character,
        systemPrompt,
        image,
        tags,
        target,
        gallery,
        firstMessages,
        lorebooks,
        createdAt: now,
      },
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}

