import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { decryptIfPossible } from "@/lib/crypto";
import { generateText } from "@/lib/ai";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json().catch(() => ({}));
    const chatId = String(body?.chatId || "").trim();
		// (핵심) 클라이언트가 방금 화면에 표시한 내용을 함께 보내면,
		// DB 저장 타이밍과 무관하게 정확한 추천답변을 만들 수 있다.
		const assistantContentFromClient = String(body?.assistantContent || "").trim();
		const userContentFromClient = String(body?.userContent || "").trim();
    const personaOverride = body?.personaOverride || null;
    const previousSuggestions = Array.isArray(body?.previousSuggestions) ? body.previousSuggestions : null;

    if (!chatId) {
      return NextResponse.json({ error: "chatId가 필요합니다." }, { status: 400 });
    }

    // 마지막 assistant 메시지 가져오기
    const row = db
      .prepare(
        `SELECT m.content AS content
         FROM messages m
         WHERE m.chatId=? AND m.role='assistant'
         ORDER BY m.createdAt DESC
         LIMIT 8`
      )
      .all(chatId) as any[];

    const rows = Array.isArray(row) ? row : (row ? [row] : []);

    // 마지막 user 메시지도 함께 가져와서, 직전 assistant가 이미지/구분선뿐인 경우에도 문맥 기반 추천을 만들 수 있게 한다.
    const lastUserRow = db
      .prepare(
        `SELECT m.content AS content
         FROM messages m
         WHERE m.chatId=? AND m.role='user'
         ORDER BY m.createdAt DESC
         LIMIT 1`
      )
      .get(chatId) as any;

    const lastUserTextRaw = (userContentFromClient || decryptIfPossible(String(lastUserRow?.content || ""))).trim();


    const sanitizeLastAssistantForSuggest = (input: string) => {
      const normalized = String(input || "")
        .replace(/\r\n/g, "\n")
        // 이미지 마크다운을 대사처럼 "..." 로 감싸는 케이스가 있어, 추천 프롬프트에 넣기 전에 제거
        .replace(/(^|[\n\r])\s*\\?["“”]\s*(!\[[^\]]*\]\()/g, "$1$2")
        .replace(/(\))\s*\\?["“”](?=\s*(?:[\n\r]|$))/g, "$1")
        // 스트리밍 중 URL 내부에 공백/줄바꿈이 끼는 케이스 복구
        .replace(/!\[([^\]]*)\]\(([^)]*)\)/g, (_m, alt, url) => {
          const fixedUrl = String(url || "").replace(/\s+/g, "");
          return `![${String(alt || "")}](${fixedUrl})`;
        });

      const out = normalized
        .split("\n")
        .map((ln) => {
          const t = String(ln || "").trim();
          if (!t) return "";
          // Hide stray separator lines that sometimes appear before images.
          if (/^[=＝]+$/.test(t)) return "";
          // Keep a stable token for images so the prompt is not empty.
          if (/^!\[[^\]]*\]\([^\)]+\)\s*$/.test(t)) return "[이미지]";
          if (/^https?:\/\/\S+\.(?:png|jpe?g|gif|webp)(?:\?\S*)?$/i.test(t)) return "[이미지]";
          return ln;
        })
        .filter(Boolean);
      return out.join("\n").trim();
    };


    const pickLastAssistantTextForSuggest = (items: any[]): string => {
      for (const it of items) {
        const raw = decryptIfPossible(String(it?.content || "")).trim();
        const cleaned = sanitizeLastAssistantForSuggest(raw);
        // skip if effectively empty (e.g., only images/separators)
        if (cleaned && cleaned.replace(/\s+/g, " ").trim().length >= 10) return cleaned;
      }
      return "";
    };


    const lastAssistantFromClient = sanitizeLastAssistantForSuggest(assistantContentFromClient);
    const lastAssistant = (lastAssistantFromClient && lastAssistantFromClient.replace(/\s+/g, " ").trim().length >= 10)
      ? lastAssistantFromClient
      : pickLastAssistantTextForSuggest(rows);
    if (!lastAssistant) {
      // If the latest assistant output has no usable text, fall back to the latest user text.
      // We still try model-based suggestions so they adapt to the current context.
    }

    // 주인공(유저) 시점 2개 고정
    // - 부가 기능이라 속도 우선: flash 모델 + 낮은 토큰으로 생성
    const system = [
      "너는 소설형 AI 채팅의 '추천 답변' 생성기다.",
      "반드시 한국어로만 답한다.",
      "반드시 '주인공(사용자)' 1인칭 시점의 대사로만 2개를 만든다.",
      "상대(assistant) 입장의 말투/1인칭(나는/제가)로 쓰지 마라.",
      "지문(상황 설명) 금지. 대사(말)만.",
      "너무 길게 쓰지 말고, 한 줄씩 자연스럽게.",
			"출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\"]}",
    ].join("\n");

    const personaLine = personaOverride
      ? `주인공 정보(참고): 이름=${String(personaOverride?.personaName || "").trim()}, 나이=${Number(personaOverride?.personaAge || 0)}, 성별=${String(personaOverride?.personaGender || "").trim()}, 설명=${String(personaOverride?.personaInfo || "").trim()}`
      : "";

    const user = [
      personaLine,
      "[직전 사용자 발화]",
      lastUserTextRaw,
      "\n[직전 상대 발화/지문]",
      lastAssistant,
      "\n위 내용에 대해, 주인공(사용자)이 다음에 할 법한 대사 2개를 추천해줘.",
    ]
      .filter(Boolean)
      .join("\n");

    const r = await generateText({
      system,
      user,
      opts: {
        model: "gemini-3-flash-preview",
        maxOutputTokens: 220,
        maxReasoningTokens: 0,
      },
    });

    let suggestions: string[] = [];
    try {
      const rawText = String(r.text || "").trim();
      const a = rawText.indexOf("{");
      const b = rawText.lastIndexOf("}");
      const jsonTextRaw = a >= 0 && b > a ? rawText.slice(a, b + 1) : rawText;

      // (중요) 모델이 JSON을 출력하더라도, 스마트 따옴표(“ ”)로 나오는 경우가 있어 JSON.parse가 실패한다.
      // 또한 간혹 trailing comma가 섞여 파싱이 실패하는 케이스가 있으므로 보정한다.
      const jsonText = String(jsonTextRaw)
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'")
        .replace(/,\s*([}\]])/g, "$1")
        .trim();

      let parsed: any = null;
      try {
        parsed = JSON.parse(jsonText);
      } catch {
        parsed = null;
      }

      if (parsed && Array.isArray(parsed?.suggestions)) {
        suggestions = parsed.suggestions
          .map((s: any) => String(s || "").trim())
          .filter(Boolean)
          .slice(0, 2);
      } else {
        // JSON이 깨졌더라도, 아래 형태로 나오는 경우가 많다:
        // - 1) "..."\n2) "..."
        // - - ...\n- ...
        // - ...\n...
        const lines = rawText
          .replace(/[“”]/g, '"')
          .replace(/\r\n/g, "\n")
          .split("\n")
          .map((x) => String(x || "").trim())
          .filter(Boolean);

        const picked: string[] = [];
        for (const ln of lines) {
          if (picked.length >= 2) break;
          // 1) "..." 형태
          const q = ln.match(/^"(.+?)"\s*$/);
          if (q && q[1]) {
            picked.push(String(q[1]).trim());
            continue;
          }
          // 2) 1) ... / 1. ...
          const n = ln.match(/^\d+\s*[\.)]\s*(.+)$/);
          if (n && n[1]) {
            picked.push(String(n[1]).trim().replace(/^"|"$/g, ""));
            continue;
          }
          // 3) - ... / * ...
          const b0 = ln.match(/^[-*]\s+(.+)$/);
          if (b0 && b0[1]) {
            picked.push(String(b0[1]).trim().replace(/^"|"$/g, ""));
            continue;
          }
        }
        if (picked.length >= 2) suggestions = picked.slice(0, 2);
      }
    } catch {
      suggestions = [];
    }

    if (!suggestions || suggestions.length < 2) {
      const fallbackPool = [
        "…잠깐, 방금 상황을 한 문장으로 정리해줄래?",
        "지금 네가 진짜 원하는 건 뭐야? (한 가지만)",
        "그럼 나는 지금 뭘 하면 돼? 바로 다음 행동만 말해줘.",
        "그 말, 구체적으로 어떤 일이 있었는지 순서대로 말해줘.",
        "잠깐… 너 지금 무슨 의도야? 솔직하게 말해줘.",
      ];
      const off = Math.abs(Date.now()) % fallbackPool.length;
      suggestions = [fallbackPool[off], fallbackPool[(off + 2) % fallbackPool.length]];
    }

    return NextResponse.json({ suggestions });
  } catch (e: any) {
    return NextResponse.json({ error: String(e?.message || "추천답변 생성 실패") }, { status: 500 });
  }
}
