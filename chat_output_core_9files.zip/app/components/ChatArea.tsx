"use client";

import { memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ReactElement } from "react";
import { createPortal } from "react-dom";
import type { Preset } from "@/app/page";
// lucide-react를 설치하지 않은 환경에서도 동작하도록, 필요한 아이콘은 인라인 SVG로 렌더링한다.

function Icon({
  name,
  size = 16,
}: {
  // 기존 코드에서 "refresh"라는 이름으로 호출되는 케이스가 있어 alias를 함께 허용한다.
  name: "rotate" | "refresh" | "edit" | "trash" | "info" | "check" | "close" | "chevronLeft" | "paperPlane" | "chevronDown" | "asterisk" | "sparkles" | "narration" | "magic";
  size?: number;
}) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" } as const;
  switch (name) {
    case "rotate":
    case "refresh":
      return (
        <svg {...common}>
          <path d="M3 12a9 9 0 0 1 15.3-6.3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M18 3v5h-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M21 12a9 9 0 0 1-15.3 6.3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M6 21v-5h5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "edit":
      return (
        <svg {...common}>
          <path d="M12 20h9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );
    case "trash":
      return (
        <svg {...common}>
          <path d="M3 6h18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M8 6V4h8v2" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="M6 6l1 14h10l1-14" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="M10 11v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M14 11v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "check":
      return (
        <svg {...common}>
          <path d="M20 6 9 17l-5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "close":
      return (
        <svg {...common}>
          <path d="M18 6 6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "chevronLeft":
      return (
        <svg {...common}>
          <path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "chevronDown":
      return (
        <svg {...common}>
          <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "paperPlane":
      return (
        <svg {...common}>
          <path d="M22 2 11 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M22 2 15 22l-4-9-9-4 20-7Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );

    case "asterisk":
      return (
        <svg {...common}>
          <path d="M12 2v20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M4 6l16 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M20 6L4 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "sparkles":
      return (
        <svg {...common}>
          <path d="M12 2l1.6 5.2L19 9l-5.4 1.8L12 16l-1.6-5.2L5 9l5.4-1.8L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="M4 14l.9 2.6L7.5 18l-2.6.9L4 21l-.9-2.1L.5 18l2.6-1.4L4 14Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );

    case "narration":
      // A scroll-like icon ("narration" feel)
      return (
        <svg {...common}>
          <path d="M7 4h10a3 3 0 0 1 0 6H8a2 2 0 0 0 0 4h9a3 3 0 0 1 0 6H7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 8h7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M8 16h7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );

    case "magic":
      // A wand + sparkle
      return (
        <svg {...common}>
          <path d="M3 21l6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M8 16l8-8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M12 6l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="M14.5 3.5l.6 1.7 1.7.6-1.7.6-.6 1.7-.6-1.7-1.7-.6 1.7-.6.6-1.7Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );


    case "info":
    default:
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
          <path d="M12 10v6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M12 7h.01" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );
  }
}

function SettingsIcon({
  name,
  size = 18,
}: {
  name: "persona" | "note" | "memory" | "sliders" | "pencil" | "chevronLeft";
  size?: number;
}) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" } as const;
  switch (name) {
    case "persona":
      return (
        <svg {...common}>
          <path d="M20 21a8 8 0 0 0-16 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case "note":
      return (
        <svg {...common}>
          <path d="M7 3h10a2 2 0 0 1 2 2v14l-4-2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
          <path d="M9 7h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M9 11h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "memory":
      return (
        <svg {...common}>
          <path d="M4 7c0-2 4-4 8-4s8 2 8 4-4 4-8 4-8-2-8-4Z" stroke="currentColor" strokeWidth="2" />
          <path d="M4 7v10c0 2 4 4 8 4s8-2 8-4V7" stroke="currentColor" strokeWidth="2" />
          <path d="M4 12c0 2 4 4 8 4s8-2 8-4" stroke="currentColor" strokeWidth="2" />
        </svg>
      );
    case "sliders":
      return (
        <svg {...common}>
          <path d="M4 21v-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M4 10V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M12 21v-9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M12 8V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M20 21v-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M20 12V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M2 14h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M10 12h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M18 16h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case "pencil":
      return (
        <svg {...common}>
          <path d="M12 20h9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        </svg>
      );
    case "chevronLeft":
    default:
      return (
        <svg {...common}>
          <path d="M15 18 9 12l6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
  }
}

function labelTokenKey(k: string) {
  const map: Record<string, string> = {
    presetPrompt: "캐릭터 프롬프트",
    lorebookPrompt: "활성화 로어북",
    persona: "유저 페르소나",
    userNote: "유저 노트",
    longMemorySummary: "장기 기억",
    recentTurns: "최근 대화",
    systemAndRules: "시스템/규칙",
    userInput: "사용자 입력",
    imagePrompt: "이미지 프롬프트",
    other: "기타",
  };
  return map[k] || k;
}

// -----------------------------
// 친구비(화폐) 비용 표기/차감
// -----------------------------
const FRIEND_FEE_RATE_PER_1K: Record<string, number> = {
  "gemini-3-flash-preview": 1.0,
  "gemini-2.5-pro": 3.5,
  "gemini-3-pro-preview": 4.5,
};

// 채팅 내 비용 표시는 '고정 환율'
const KRW_PER_FRIENDFEE = 1.7;

function ratePer1kForModel(model: string | undefined): number {
  if (!model) return FRIEND_FEE_RATE_PER_1K["gemini-3-flash-preview"];
  return FRIEND_FEE_RATE_PER_1K[model] ?? FRIEND_FEE_RATE_PER_1K["gemini-3-flash-preview"];
}

function calcFriendFee(totalTokens: number, model: string | undefined): number {
  const t = Number(totalTokens) || 0;
  return (t / 1000) * ratePer1kForModel(model);
}

function roundFriendFeeUi(fee: number): number {
  return Math.round(Number(fee) || 0);
}

function formatKrwUi(krw: number): string {
  const n = Math.round(Number(krw) || 0);
  return `₩${n.toLocaleString("ko-KR")}`;
}

// 친구비 0일 때 UX 팝업 멘트(랜덤)
const FRIEND_FEE_EMPTY_LINES = [
  "나 아직 할 말 많은데… 😢 조금만 더 같이 있어주면 안 될까?",
  "다음 이야기가 정말 중요한데…!",
  "헤어지기엔 아직 이르잖아…",
  "아직 끝내기엔 아쉬워…",
  "조금만 더 같이 있어줄래?",
  "이 다음이 진짜 중요한데…",
  "벌써 헤어질 시간이야…?",
  "조금만 더 이야기하면 안 될까?",
];

// FriendFee is stored per-account (so different logins don't share balances).
const FRIEND_FEE_USER_ID_KEY = "mate_friendfee_userid_v1";
function getFriendFeeUserId(): string {
  try {
    const raw = window.localStorage.getItem(FRIEND_FEE_USER_ID_KEY);
    return raw && raw.trim() ? raw.trim() : "";
  } catch {
    return "";
  }
}
function ffKey(base: string): string {
  const uid = getFriendFeeUserId();
  return uid ? `${base}__${uid}` : base;
}

function pickFriendFeeEmptyLine(): string {
  const i = Math.floor(Math.random() * FRIEND_FEE_EMPTY_LINES.length);
  return FRIEND_FEE_EMPTY_LINES[i] || FRIEND_FEE_EMPTY_LINES[0];
}

function readFriendFeeBalance(): number {
  try {
    const raw = window.localStorage.getItem(ffKey("mate_friendfee_balance_v1"));
    if (raw != null) {
      const n = Number(raw);
      return Number.isFinite(n) ? n : 0;
    }
    const legacy = window.localStorage.getItem(ffKey("mate_friend_fee_state"));
    if (!legacy) return 0;
    const j = JSON.parse(legacy);
    const t = Number((j as any)?.total ?? 0);
    return Number.isFinite(t) ? t : 0;
  } catch {
    return 0;
  }
}

function writeFriendFeeBalance(nextBalance: number) {
  // 내부는 소수 유지(서버가 실수 잔액을 반환). UI에서만 Math.round.
  const b = Math.max(0, Number(nextBalance) || 0);
  try {
    window.localStorage.setItem(ffKey("mate_friendfee_balance_v1"), String(b));
  } catch {
    // ignore
  }
  try {
    // legacy UI 호환: total은 정수로 저장
    window.localStorage.setItem(ffKey("mate_friend_fee_state"), JSON.stringify({ total: Math.round(b), updatedAt: Date.now() }));
  } catch {
    // ignore
  }
  try {
    // Include the latest balance in the event to avoid a follow-up /api/friendfee/state fetch.
    const detail = { balanceReal: b, balanceUi: Math.round(b), at: Date.now() };
    window.dispatchEvent(new CustomEvent("mate_friend_fee_updated", { detail }));
  } catch {
    try {
      window.dispatchEvent(new Event("mate_friend_fee_updated"));
    } catch {
      // ignore
    }
  }
}

type Msg = {
  id: string;
  chatId: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
  usage?: null | {
    model?: string;
    promptTokens?: number;
    outputTokens?: number;
    reasoningTokens?: number;
    totalTokens?: number;
    latencyMs?: number;
    estimatedCostUsd?: number;
    estimatedCostKrw?: number;
    usdToKrw?: number;
    // (추정) 입력 구성 토큰 합
    estPromptTotal?: number;
    // (추정) 입력 구성 분해
    tokenBreakdown?: Record<string, number>;
  };
};

type Settings = {
  chatId: string;

  personaName: string;
  personaAge: number;
  personaGender: string;
  personaInfo: string;

  memoryFrom: number;
  memoryTo: number;
  summaryEvery: number;
  summaryLength: number;

  userNote: string;
  longMemoryGuidance?: string;

  narrationColor?: string;
  renderMode: "chat" | "novel";

  model:
    | "gemini-3-pro-preview"
    | "gemini-2.5-pro"
    | "gemini-3-flash-preview";
  maxOutputTokens: number;
  maxReasoningTokens: number;

  updatedAt: number;
};

type ReasoningLevel = "low" | "middle" | "high";

function getReasoningPresets(model: Settings["model"]): Record<ReasoningLevel, number> {
  // UI는 low/middle/high로만 노출하고, 실제 저장/전송은 숫자(maxReasoningTokens)로 유지한다.
  // - gemini-3* 계열: 추론 토큰을 너무 낮추면 품질/일관성이 급락하므로 기본을 조금 높게 둔다.
  // - gemini-2.5-pro: 기존 UX(768 기본) 유지 + high는 더 넉넉하게.
  if (String(model || "").startsWith("gemini-3")) {
    // 3-pro는 의미 단위로 "묶음"을 뱉는 경우가 많아, middle을 너무 낮게 잡으면
    // (1) 대사에서 끊기기, (2) 내부 판단으로 STOP이 빨라지는 체감이 생길 수 있다.
    return { low: 512, middle: 1024, high: 1536 };
  }
  return { low: 256, middle: 768, high: 2048 };
}

function inferReasoningLevel(model: Settings["model"], tokens: number): ReasoningLevel {
  const p = getReasoningPresets(model);
  const t = Number(tokens) || 0;
  const entries: [ReasoningLevel, number][] = [
    ["low", p.low],
    ["middle", p.middle],
    ["high", p.high],
  ];
  let best: ReasoningLevel = "middle";
  let bestDist = Infinity;
  for (const [k, v] of entries) {
    const d = Math.abs(v - t);
    if (d < bestDist) {
      bestDist = d;
      best = k;
    }
  }
  return best;
}

// UI 옵션 (settings route의 허용 목록과 맞춰 둔다)
// UI 옵션 (settings route의 허용 목록과 맞춰 둔다)
const MODEL_OPTIONS = [
  "gemini-3-pro-preview",
  "gemini-2.5-pro",
  "gemini-3-flash-preview",
] as const;

const RENDER_MODE_OPTIONS = ["chat", "novel"] as const;

// 채팅 본문(대사/지문) 컬럼 최대 폭 (영상 UI처럼 가운데 좁게)
const CHAT_COLUMN_MAX = 680;

function clampInt(v: any, min: number, max: number, fallback: number) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  const i = Math.round(n);
  return Math.min(max, Math.max(min, i));
}


type ChatTheme = {
  bg: string;
  bg2: string;
  border: string;
  borderStrong: string;
  text: string;
  muted: string;
  accent: string;
  speech: string;
  narration: string;
  panel: string;
};

type MessageContentRenderer = ({ message }: { message: Msg }) => ReactElement;

const MessageItem = memo(function MessageItem(props: {
  m: Msg;
  prebufferUiActive: boolean;
  prebufferSec: number;
  prebufferDots: string;
  streamTempAssistantId: string;
  stallUiActive: boolean;
  streamTargetId: string;
  userName: string;
  npcName: string;
  theme: ChatTheme;
  iconButtonStyle: React.CSSProperties;
  MessageContent: MessageContentRenderer;


  editingAssistantId: string | null;
  editingUserId: string | null;

  assistantDraft: string;
  userDraft: string;
  onChangeAssistantDraft: (v: string) => void;
  onChangeUserDraft: (v: string) => void;

  onRegenerateFromAssistant: (m: Msg) => void;
  onRequestDeleteMessage: (m: Msg) => void;
  onStartAssistantEdit: (m: Msg) => void;
  onStartUserEdit: (m: Msg) => void;

  onOpenTokenInfo: (m: Msg, anchorEl?: HTMLElement | null) => void;

  onCancelAssistantEdit: () => void;
  onSaveAssistantEdit: () => void;
  onCancelUserEdit: () => void;
  onSaveUserEdit: () => void;
}) {
  const {
    m,
    prebufferUiActive,
    prebufferSec,
    prebufferDots,
    streamTempAssistantId,
    stallUiActive,
    streamTargetId,
    userName,
    npcName,
    theme,
    iconButtonStyle,
    MessageContent,
    editingAssistantId,
    editingUserId,
    assistantDraft,
    userDraft,
    onChangeAssistantDraft,
    onChangeUserDraft,
    onRegenerateFromAssistant,
    onRequestDeleteMessage,
    onStartAssistantEdit,
    onStartUserEdit,
    onOpenTokenInfo,
    onCancelAssistantEdit,
    onSaveAssistantEdit,
    onCancelUserEdit,
    onSaveUserEdit,
  } = props;

  return (
    // 기본 메시지 본문 폰트는 15px로 통일 (유저/AI 동일)
    <div style={{ fontSize: 15 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, opacity: 0.90, marginBottom: 6, color: theme.muted }}>{m.role === "user" ? userName : npcName}{m.role === "assistant" && prebufferUiActive && m.id === streamTempAssistantId ? (  <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "2px 8px", borderRadius: 999, border: `1px solid ${theme.border}`, background: theme.panel, color: theme.text, fontWeight: 800, fontSize: 12, opacity: 0.95 }}>    <span style={{ filter: "saturate(1.1)" }}>✨</span>    <span>{prebufferSec}초 동안 생각 중{prebufferDots}</span>  </span>) : null}
{m.role === "assistant" && stallUiActive && m.id === streamTargetId ? (
          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "2px 8px", borderRadius: 999, border: `1px solid ${theme.border}`, background: theme.panel, color: theme.text, fontWeight: 800, fontSize: 12, marginLeft: 8 }}>
            <span>생성 중…</span>
          </span>
        ) : null}</div>

      <div style={{ border: "none", borderRadius: 0, padding: 0, background: "transparent" }}>
        {m.id === editingAssistantId ? (
          <textarea
            value={assistantDraft}
            onChange={(e) => onChangeAssistantDraft(e.target.value)}
            style={{
              width: "100%",
              display: "block",
              boxSizing: "border-box",
              minHeight: 220,
              resize: "vertical",
              borderRadius: 10,
              border: `1px solid ${theme.borderStrong}`,
              background: theme.bg,
              color: theme.text,
              padding: 10,
              lineHeight: 1.35,
              fontSize: 15,
            }}
          />
        ) : m.id === editingUserId ? (
          <textarea
            value={userDraft}
            onChange={(e) => onChangeUserDraft(e.target.value)}
            style={{
              width: "100%",
              display: "block",
              boxSizing: "border-box",
              minHeight: 140,
              resize: "vertical",
              borderRadius: 10,
              border: `1px solid ${theme.borderStrong}`,
              background: theme.bg,
              color: theme.text,
              padding: 10,
              lineHeight: 1.35,
              fontSize: 15,
            }}
          />
        ) : (
          <MessageContent message={m} />
        )}
      </div>

      <div style={{ marginTop: 6, display: "flex", justifyContent: "flex-end", gap: 6, flexWrap: "wrap" }}>
        {m.role === "assistant" && !editingAssistantId && !editingUserId && (
          <>
            <button type="button" title="재생성" onClick={() => onRegenerateFromAssistant(m)} style={iconButtonStyle}>
              <Icon name="refresh" />
            </button>
            <button type="button" title="삭제" onClick={() => onRequestDeleteMessage(m)} style={iconButtonStyle}>
              <Icon name="trash" />
            </button>
            <button type="button" title="AI 답변 수정" onClick={() => onStartAssistantEdit(m)} style={iconButtonStyle}>
              <Icon name="edit" />
            </button>
            <button type="button" title="토큰/비용 정보" onClick={(e) => onOpenTokenInfo(m, e.currentTarget as HTMLElement)} style={iconButtonStyle}>
              <Icon name="info" />
            </button>
          </>
        )}

        {m.role === "user" && !editingAssistantId && !editingUserId && (
          <button type="button" title="유저 메시지 수정" onClick={() => onStartUserEdit(m)} style={iconButtonStyle}>
            <Icon name="edit" />
          </button>
        )}
      </div>

      {m.id === editingAssistantId && (
        <div style={{ marginTop: 6, display: "flex", justifyContent: "flex-end", gap: 6 }}>
          <button type="button" title="취소" onClick={onCancelAssistantEdit} style={iconButtonStyle}>
            <Icon name="close" />
          </button>
          <button type="button" title="저장" onClick={onSaveAssistantEdit} style={iconButtonStyle}>
            <Icon name="check" />
          </button>
        </div>
      )}

      {m.id === editingUserId && (
        <div style={{ marginTop: 6, display: "flex", justifyContent: "flex-end", gap: 6 }}>
          <button type="button" title="취소" onClick={onCancelUserEdit} style={iconButtonStyle}>
            <Icon name="close" />
          </button>
          <button type="button" title="저장" onClick={onSaveUserEdit} style={iconButtonStyle}>
            <Icon name="check" />
          </button>
        </div>
      )}
    </div>
  );
});

function getModelBadge(rawModel: string): { label: string; bg: string; fg: string } {
  const m = String(rawModel || "");
  if (m.includes("gemini-3-pro")) {
    return { label: "3 pro", bg: "rgba(255, 75, 75, 0.18)", fg: "rgba(255, 140, 140, 0.98)" };
  }
  if (m.includes("gemini-2.5-pro")) {
    return { label: "2 pro", bg: "rgba(180, 110, 255, 0.18)", fg: "rgba(220, 175, 255, 0.98)" };
  }
  if (m.includes("gemini-3-flash")) {
    return { label: "3 preview", bg: "rgba(255, 120, 210, 0.18)", fg: "rgba(255, 190, 230, 0.98)" };
  }
  return { label: m ? m.replace(/^google\//, "") : "...", bg: "rgba(255,255,255,0.05)", fg: "rgba(255,255,255,0.9)" };
}

const MessageList = memo(function MessageList(props: {
  messagesLength: number;
  visibleMessages: Msg[];
  modelName: string;


  hiddenMessageCount: number;
  expandOlderMessages: (mode: "more" | "all") => void;

  userName: string;
  npcName: string;
  theme: ChatTheme;
  iconButtonStyle: React.CSSProperties;
  MessageContent: MessageContentRenderer;

  prebufferUiActive: boolean;
  prebufferSec: number;
  prebufferDots: string;
  streamTempAssistantId: string;
  stallUiActive: boolean;
  streamTargetId: string;

  editingAssistantId: string | null;
  editingUserId: string | null;

  assistantDraft: string;
  userDraft: string;
  onChangeAssistantDraft: (v: string) => void;
  onChangeUserDraft: (v: string) => void;

  onRegenerateFromAssistant: (m: Msg) => void;
  onRequestDeleteMessage: (m: Msg) => void;
  onStartAssistantEdit: (m: Msg) => void;
  onStartUserEdit: (m: Msg) => void;

  onOpenTokenInfo: (m: Msg) => void;

  onCancelAssistantEdit: () => void;
  onSaveAssistantEdit: () => void;
  onCancelUserEdit: () => void;
  onSaveUserEdit: () => void;

  bottomRef: any;
}) {
  const {
    messagesLength,
    prebufferUiActive,
    prebufferSec,
    prebufferDots,
    streamTempAssistantId,
    stallUiActive,
    streamTargetId,
    visibleMessages,
    modelName,
    hiddenMessageCount,
    expandOlderMessages,
    userName,
    npcName,
    theme,
    iconButtonStyle,
    MessageContent,
    editingAssistantId,
    editingUserId,
    assistantDraft,
    userDraft,
    onChangeAssistantDraft,
    onChangeUserDraft,
    onRegenerateFromAssistant,
    onRequestDeleteMessage,
    onStartAssistantEdit,
    onStartUserEdit,
    onOpenTokenInfo,
    onCancelAssistantEdit,
    onSaveAssistantEdit,
    onCancelUserEdit,
    onSaveUserEdit,
    bottomRef,
  } = props;

  if (messagesLength === 0) {
    return (
      <div style={{ fontSize: 13, opacity: 0.7 }}>
        왼쪽에서 새 채팅 만들기 후 메시지를 보내보세요.
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {hiddenMessageCount > 0 && (
        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginBottom: 4 }}>
          <button
            type="button"
            onClick={() => expandOlderMessages("more")}
            style={{
              padding: "8px 12px",
              borderRadius: 12,
              border: `1px solid ${theme.borderStrong}`,
              background: getModelBadge(modelName).bg,
              color: theme.text,
              cursor: "pointer",
              fontSize: 12,
              fontWeight: 800,
            }}
          >
            이전 메시지 {hiddenMessageCount}개 더 보기
          </button>
          <button
            type="button"
            onClick={() => expandOlderMessages("all")}
            style={{
              padding: "8px 12px",
              borderRadius: 12,
              border: `1px solid ${theme.borderStrong}`,
              background: getModelBadge(modelName).bg,
              color: theme.text,
              cursor: "pointer",
              fontSize: 12,
              fontWeight: 800,
              opacity: 0.85,
            }}
          >
            전체 보기
          </button>
        </div>
      )}

      {visibleMessages.map((m) => (
        <MessageItem
          key={m.id}
          m={m}
          userName={userName}
          npcName={npcName}
          theme={theme}
          iconButtonStyle={iconButtonStyle}
          MessageContent={MessageContent}
          prebufferUiActive={prebufferUiActive}
          prebufferSec={prebufferSec}
          prebufferDots={prebufferDots}
          streamTempAssistantId={streamTempAssistantId}
          stallUiActive={stallUiActive}
          streamTargetId={streamTargetId}
          editingAssistantId={editingAssistantId}
          editingUserId={editingUserId}
          assistantDraft={assistantDraft}
          userDraft={userDraft}
          onChangeAssistantDraft={onChangeAssistantDraft}
          onChangeUserDraft={onChangeUserDraft}
          onRegenerateFromAssistant={onRegenerateFromAssistant}
          onRequestDeleteMessage={onRequestDeleteMessage}
          onStartAssistantEdit={onStartAssistantEdit}
          onStartUserEdit={onStartUserEdit}
          onOpenTokenInfo={onOpenTokenInfo}
          onCancelAssistantEdit={onCancelAssistantEdit}
          onSaveAssistantEdit={onSaveAssistantEdit}
          onCancelUserEdit={onCancelUserEdit}
          onSaveUserEdit={onSaveUserEdit}
        />
      ))}

      <div ref={bottomRef} />
    </div>
  );
});


export default function ChatArea(props: {
  presetId: string | null;
  presets: Preset[];
  onChangePreset: (id: string) => void;
  // UI-only options (기능 로직은 유지)
  settingsUiMode?: "inline" | "drawer";
  hideSettingsToggle?: boolean;
  externalSettingsOpen?: boolean;
  onExternalSettingsOpenChange?: (open: boolean) => void;
}) {
  const { presetId, presets, onChangePreset } = props;

  const settingsUiMode = props.settingsUiMode ?? "inline";

  const [chatId, setChatId] = useState<string>("");
  const [messages, setMessages] = useState<Msg[]>([]);
  // (성능) 채팅이 길어질수록 렌더 비용이 급증하므로, 기본은 마지막 N개만 렌더하고 필요 시 확장한다.
  // - 0이면 "자동"(짧은 채팅은 전체, 긴 채팅은 마지막 N개)
  const [visibleCount, setVisibleCount] = useState<number>(0);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  // send()에서 발생한 오류를 사용자에게 노출하기 위한 상태
  const [sendError, setSendError] = useState<string | null>(null);

  // (기존 기능 유지용)
  // - 재생성/수정 흐름에서 사용되는 선택 메시지 id
  // - send() payload/리셋에서 참조하므로 반드시 존재해야 함
  const [selectedMsgIdForRegenerate, setSelectedMsgIdForRegenerate] = useState<string | null>(null);
  const [selectedMsgIdForRewrite, setSelectedMsgIdForRewrite] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  // (UI) 추천답변 생성 중 표시/플로우 안정화
  const [suggestLoading, setSuggestLoading] = useState<boolean>(false);
  const SUGGEST_ON_DEMAND_ONLY = true;
  // (UI) 이미지 보기 토글
  // - ON: 마크다운 이미지 / 이미지 URL 라인 / {{img:..}} 이미지 모두 표시
  // - OFF: 출력된 이미지 전부 숨김 + 외부 이미지 URI/마크다운도 화면에서 제거
  const [showImages, setShowImages] = useState<boolean>(true);
  // 서버가 빈 바디로 응답하면 res.json()이 'Unexpected end of JSON input'로 터질 수 있음.
  // (특히 dev/proxy/중간 오류 상황) 모든 API 응답 파싱은 이 헬퍼로 안전 처리.
  async function safeJson(res: Response): Promise<any> {
    const text = await res.text();
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch {
      // JSON이 아닐 때도(예: HTML 에러) caller가 메시지 출력할 수 있게 raw 포함
      return { _raw: text };
    }
  }


  // 서버(DB)에 저장된 usage/cost 정보를 history에서 다시 불러와 메시지에 주입
  // - NDJSON 스트리밍(done) 응답에는 usage가 포함되어 있지 않기 때문에,
  //   토큰/비용 UI가 0 또는 공백으로 보이는 문제를 방지한다.
  const hydrateUsageForMessage = useCallback(
    async (messageId: string) => {
      if (!chatId || !messageId) return;
      try {
        const res = await fetch(`/api/chat/history?chatId=${encodeURIComponent(chatId)}`);
        if (!res.ok) return;
        const json = await safeJson(res);
        const msgs = Array.isArray(json?.messages) ? json.messages : [];
        const found = msgs.find((m: any) => m?.id === messageId)?.usage;
        if (!found) return;
        setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, usage: found } : m)));
      } catch {
        // ignore
      }
    },
    [chatId]
  );


  // 메시지별 토큰/비용 팝업
  const [tokenPopup, setTokenPopup] = useState<{ open: boolean; title: string; usage?: any }>(
    { open: false, title: "", usage: null }
  );

  const [tokenPopupAnchor, setTokenPopupAnchor] = useState<{
    left: number;
    top: number;
    right: number;
    bottom: number;
    width: number;
    height: number;
  } | null>(null);

  // -----------------------------
  // 친구비 0일 때 UX 팝업
  // -----------------------------
  const [friendFeeEmptyPopup, setFriendFeeEmptyPopup] = useState<{ open: boolean; text: string }>(
    { open: false, text: "" }
  );
  const friendFeeEmptyShownRef = useRef(false);

  const openFriendFeeEmptyPopup = useCallback(() => {
    // 과도한 연속 호출 방지(한 번 열렸으면 사용자가 닫을 때까지 유지)
    setFriendFeeEmptyPopup((prev) => {
      if (prev.open) return prev;
      return { open: true, text: pickFriendFeeEmptyLine() };
    });
  }, []);

  const closeFriendFeeEmptyPopup = useCallback(() => {
    setFriendFeeEmptyPopup({ open: false, text: "" });
  }, []);

  const goFriendFeeCharge = useCallback(() => {
    closeFriendFeeEmptyPopup();
    try {
      window.dispatchEvent(new Event("mate:openFriendFeePage"));
    } catch {
      // fallback: older modal open event
      window.dispatchEvent(new Event("mate:openFriendFee"));
    }
  }, [closeFriendFeeEmptyPopup]);

  // -----------------------------
  // 친구비 자동 차감 (assistant 메시지 완료 후)
  // -----------------------------
  const billingEnabledAtRef = useRef<number | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (billingEnabledAtRef.current != null) return;
    try {
      const k = "mate_friendfee_billing_enabled_at_v1";
      const raw = window.localStorage.getItem(k);
      const v = raw != null ? Number(raw) : NaN;
      const ts = Number.isFinite(v) && v > 0 ? v : Date.now();
      if (!Number.isFinite(v) || v <= 0) window.localStorage.setItem(k, String(ts));
      billingEnabledAtRef.current = ts;
    } catch {
      billingEnabledAtRef.current = Date.now();
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!chatId) return;
    const enabledAt = billingEnabledAtRef.current ?? 0;
    const billedKey = `mate_friendfee_billed_${chatId}_v1`;
    let billed = new Set<string>();
    try {
      const raw = window.localStorage.getItem(billedKey);
      if (raw) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) billed = new Set(arr.map((x) => String(x)));
      }
    } catch {
      // ignore
    }

    let cancelled = false;

    (async () => {
      let changed = false;

      for (const m of messages) {
        if (cancelled) return;
        if (m.role !== "assistant") continue;
        if (!m?.id) continue;
        if (billed.has(m.id)) continue;
        if ((m.createdAt ?? 0) < enabledAt) continue; // 기능 적용 이전 메시지는 소급 차감하지 않음

        const total = Number(m.usage?.totalTokens);
        if (!Number.isFinite(total) || total <= 0) continue;

        const model = (m.usage?.model as string | undefined) ?? ("" + (m as any)?.model || undefined);

        // 서버(DB)에서 원자적으로 차감 (중복 차감 방지 + 기기/브라우저 동기화)
        try {
          const r = await fetch("/api/friendfee/spend", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chatId, messageId: m.id, totalTokens: total, model }),
          });
          const j = await r.json().catch(() => null);

          if (j?.ok) {
            // 서버 잔액을 로컬 캐시에 반영 + 상단바 즉시 갱신 이벤트
            if (typeof j.balance === "number") writeFriendFeeBalance(j.balance);
            billed.add(m.id);
            changed = true;
          } else if (r.status === 402 || j?.error === "insufficient") {
            // 잔액 부족 UX 팝업(한 번만)
            if (!friendFeeEmptyShownRef.current) {
              friendFeeEmptyShownRef.current = true;
              openFriendFeeEmptyPopup();
            }
            // 부족일 때는 billed로 마킹하지 않음(충전 후 재시도 가능)
          }
        } catch {
          // 네트워크/서버 오류 시 로컬 차감은 하지 않는다.
        }
      }

      if (changed) {
        try {
          window.localStorage.setItem(billedKey, JSON.stringify(Array.from(billed)));
        } catch {
          // ignore
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [messages, chatId, openFriendFeeEmptyPopup]);

    const [deletePopup, setDeletePopup] = useState<{ open: boolean; messageId: string }>({ open: false, messageId: "" });
  const [confirmModal, setConfirmModal] = useState<{
    open: boolean;
    title: string;
    desc: string;
    confirmText: string;
    danger?: boolean;
    action?: "newChat" | "deleteChat" | "deleteProfile";
    profileId?: string;
  }>({ open: false, title: "", desc: "", confirmText: "확인" });

  const openConfirm = useCallback(
    (args: { title: string; desc: string; confirmText?: string; danger?: boolean; action: "newChat" | "deleteChat" | "deleteProfile"; profileId?: string }) => {
      setConfirmModal({
        open: true,
        title: args.title,
        desc: args.desc,
        confirmText: args.confirmText ?? "확인",
        danger: args.danger,
        action: args.action,
        profileId: args.profileId,
      });
    },
    []
  );


  // 채팅 설정 패널 접기/펼치기
  const [settingsOpen, setSettingsOpen] = useState<boolean>(() => (props.settingsUiMode === "drawer" ? false : true));
  const effectiveSettingsOpen = settingsUiMode === "drawer" ? (props.externalSettingsOpen ?? settingsOpen) : settingsOpen;

  const setUiSettingsOpen = (open: boolean) => {
    if (settingsUiMode === "drawer") {
      if (props.onExternalSettingsOpenChange) props.onExternalSettingsOpenChange(open);
      else setSettingsOpen(open);
    } else {
      setSettingsOpen(open);
    }
  };

  // 설정 Drawer 내부 뷰(홈 -> 각 설정) 전환
  const [settingsView, setSettingsView] = useState<"home" | "persona" | "userNote" | "memory" | "model">("home");

  // 페르소나 프로필(여러 개 저장/선택)
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [profiles, setProfiles] = useState<
    Array<{ id: string; personaName: string; personaAge: number; personaGender: string; personaInfo: string }>
  >([]);
  const [selectedProfileId, setSelectedProfileId] = useState<string>("");
  const selectedProfile = useMemo(
    () => profiles.find((p) => p.id === selectedProfileId) || null,
    [profiles, selectedProfileId]
  );
  const [profileDraft, setProfileDraft] = useState<{ id?: string; personaName: string; personaAge: number; personaGender: string; personaInfo: string }>(
    { personaName: "", personaAge: 0, personaGender: "남", personaInfo: "" }
  );

  const [personaApplyMsg, setPersonaApplyMsg] = useState<string>("");

  // Drawer가 열릴 때는 항상 홈으로 복귀
  useEffect(() => {
    if (settingsUiMode === "drawer" && effectiveSettingsOpen) {
      setSettingsView("home");
    }
  }, [settingsUiMode, effectiveSettingsOpen]);

  // (침범 방지) 페이지(body) 스크롤을 차단하고, 채팅 영역만 스크롤되도록 한다.
  // - 입력창이 길어져도 화면 전체가 아래로 밀리지 않게(=노란선 아래 침범 방지)
  useEffect(() => {
    const prevHtml = document.documentElement.style.overflow;
    const prevBody = document.body.style.overflow;
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";
    return () => {
      document.documentElement.style.overflow = prevHtml;
      document.body.style.overflow = prevBody;
    };
  }, []);



  // 페르소나 설정 화면으로 진입 시: 선택된 프로필을 Draft에 반영(모달 없이 인라인 편집)
  const personaInitRef = useRef(false);
  useEffect(() => {
    if (settingsView !== "persona") {
      personaInitRef.current = false;
      return;
    }
    if (personaInitRef.current) return;
    personaInitRef.current = true;

    const pick =
      (selectedProfileId ? profiles.find((x) => x.id === selectedProfileId) : null) ||
      selectedProfile ||
      (profiles.length > 0 ? profiles[0] : null);

    if (pick) {
      setSelectedProfileId(pick.id);
      setProfileDraft({
        id: pick.id,
        personaName: pick.personaName,
        personaAge: pick.personaAge,
        personaGender: pick.personaGender || "남",
        personaInfo: pick.personaInfo,
      });
    } else {
      setSelectedProfileId("");
      setProfileDraft({ personaName: "", personaAge: 0, personaGender: "남", personaInfo: "" });
    }
  }, [settingsView, profiles, selectedProfile, selectedProfileId]);

  // 장기기억(최근 요약) 상태 (설정 Drawer 내부에서 인라인 처리)
  const [memorySummary, setMemorySummary] = useState<string>("");
  const [memoryLoaded, setMemoryLoaded] = useState(false);
  const [memoryChars, setMemoryChars] = useState<number>(0);
  const [memoryEditMode, setMemoryEditMode] = useState(false);
  const [memoryDraft, setMemoryDraft] = useState<string>("");
  const [memorySaving, setMemorySaving] = useState(false);
  const [memoryLoading, setMemoryLoading] = useState(false);
  const [memoryError, setMemoryError] = useState<string>("");

  // (안전) 장기기억 요약에 모델이 프롬프트/메타 텍스트를 섞어 반환하는 케이스가 있어
  // UI 표시/편집 전에 제거한다.
  function sanitizeLongMemorySummaryUI(input: string): string {
    let t = String(input || "");
    if (!t.trim()) return "";
    t = t.replace(/\r\n/g, "\n");
    const firstIdx = t.search(/^##\s*\uC7A5\uAE30\s*\uAE30\uC5B5\s*\(/m);
    if (firstIdx > 0) t = t.slice(firstIdx);

    const headerRe = /^##\s*\uC7A5\uAE30\s*\uAE30\uC5B5\s*\(\s*(\d+)\s*[-\u2013~]\s*(\d+)\s*\uD134\s*\)\s*$/gm;
    const matches: { idx: number }[] = [];
    for (const m of t.matchAll(headerRe)) {
      matches.push({ idx: m.index ?? 0 });
    }
    if (matches.length === 0) {
      // 그래도 start_thought 같은 누설은 제거한다.
      const lines = t.split("\n").filter((ln) => {
        const l = ln.trim();
        if (!l) return true;
        if (/start_thought/i.test(l)) return false;
        if (/Long-?term\s+Memory\s+Summary\s+Writer/i.test(l)) return false;
        if (/Dialogue\s+Context/i.test(l)) return false;
        if (/Summary of the provided/i.test(l)) return false;
        return true;
      });
      return lines.join("\n").trim();
    }

    const stripBadLines = (block: string) => {
      const out: string[] = [];
      for (const line of String(block || "").split("\n")) {
        const l = String(line || "");
        const s = l.trim();
        if (!s) {
          out.push(l);
          continue;
        }
        if (/start_thought/i.test(s)) continue;
        if (/Long-?term\s+Memory\s+Summary\s+Writer/i.test(s)) continue;
        if (/^Korean\s+only\.?$/i.test(s)) continue;
        if (/^Markdown\.?$/i.test(s)) continue;
        if (/Summary of the provided/i.test(s)) continue;
        if (/Dialogue\s+Context/i.test(s)) continue;
        if (/Correction on Turn Indexing/i.test(s)) continue;
        if (/^\s*-\s*(Total length|Density|Format|Continuity|Content|Specific Turn Range)/i.test(l)) continue;

        // (가독성) "### 제목 (4-6턴)" 형태는 제목과 턴 범위를 줄바꿈으로 분리한다.
        // - 최근 요약은 pre-wrap으로 그대로 표시되므로, 한 줄에 붙어 있으면 가독성이 떨어짐
        // - (요약) 같은 접두어도 함께 제거한다.
        const hm = s.match(/^(#{3,6})\s+(.+?)\s*\(\s*(\d+\s*[-\u2013~]\s*\d+|\d+)\s*턴\s*\)\s*$/);
        if (hm) {
          const prefix = String(hm[1] || "###");
          const rawTitle = String(hm[2] || "").trim().replace(/^\(\s*요약\s*\)\s*/i, "").trim();
          const rawRange = String(hm[3] || "").replace(/\s+/g, "").trim();
          out.push(`${prefix} ${rawTitle}`);
          out.push(`(${rawRange}턴)`);
          continue;
        }

        out.push(l);
      }
      return out.join("\n");
    };

    const blocks: string[] = [];
    for (let i = 0; i < matches.length; i++) {
      const curIdx = matches[i].idx;
      const nextIdx = i + 1 < matches.length ? matches[i + 1].idx : t.length;
      let block = stripBadLines(t.slice(curIdx, nextIdx)).trim();
      const body = block
        .split("\n")
        .map((x) => x.trim())
        .filter((x) => x && !/^##\s*\uC7A5\uAE30\s*\uAE30\uC5B5\s*\(/.test(x));
      if (body.length === 0) continue;
      blocks.push(block);
    }
    return blocks.join("\n\n").trim();
  }

// (UI 안정화) 장기기억 자동 갱신/경쟁 상태(race) 방지용
// - 빠른 연속 호출/탭 이동/자동 폴링에서 "이전 응답이 최신을 덮어쓰는" 현상을 방지한다.
// - 페이지 새로고침 시에도 직전 요약을 즉시 보여주기 위해 sessionStorage 캐시를 사용한다.
const memoryReqRef = useRef<{
  seq: number;
  abort?: AbortController;
  lastAppliedKey: string;
  lastFetchAt: number;
}>({ seq: 0, lastAppliedKey: "", lastFetchAt: 0 });

const memoryCacheKey = useMemo(() => {
  return chatId ? `memorySummary:${chatId}` : "";
}, [chatId]);

const memoryCharsCacheKey = useMemo(() => {
  return chatId ? `memorySummaryChars:${chatId}` : "";
}, [chatId]);


  // (UI) chatId가 바뀌거나 새로고침되면, sessionStorage에 저장해둔 최근 요약을 즉시 표시한다.
// 이후 openMemorySummary()가 최신 상태로 갱신한다.
useEffect(() => {
  // chatId 변경 시 상태 초기화(다른 채팅의 요약이 섞이지 않게)
  setMemoryLoaded(false);
  setMemorySummary("");
  setMemoryDraft("");
  setMemoryChars(0);
  setMemoryEditMode(false);
  setMemoryError("");
  setMemoryLoading(false);

  if (!chatId) return;

  try {
    const cached = memoryCacheKey ? sessionStorage.getItem(memoryCacheKey) : null;
    const cachedChars = memoryCharsCacheKey ? sessionStorage.getItem(memoryCharsCacheKey) : null;
    if (cached && cached.trim()) {
      const s = cached.trim();
      setMemorySummary(s);
      setMemoryDraft(s);
      const n = cachedChars ? Number(cachedChars) : s.length;
      setMemoryChars(Number.isFinite(n) ? n : s.length);
      setMemoryLoaded(true);
    }
  } catch {}
}, [chatId, memoryCacheKey, memoryCharsCacheKey]);

// 장기기억(요약) 화면 진입 시: '불러오기' 버튼 없이 자동 로드
  useEffect(() => {
    if (settingsView !== "memory") return;
    if (!chatId) return;
    if (memoryLoaded || memoryLoading) return;
    void openMemorySummary();
  }, [settingsView, chatId, memoryLoaded, memoryLoading]);


// (UI) 장기기억 화면을 열어둔 상태에서: 주기적으로 최신 요약을 재조회한다.
// - Gemini 요약이 늦게 생성되는 경우에도 UI가 따라오게 하기 위함
// - 편집 중에는 자동 갱신을 중단한다.
useEffect(() => {
  if (settingsView !== "memory") return;
  if (!chatId) return;
  if (memoryEditMode) return;

  const t = setInterval(() => {
    void openMemorySummary({ reason: "poll" });
  }, 30000);

  return () => clearInterval(t);
}, [settingsView, chatId, memoryEditMode]);

// (UI) 새로운 assistant 메시지가 확정되면(=send 완료) 장기기억 화면에서 자동 갱신한다.
const lastAssistantKey = useMemo(() => {
  if (!chatId) return "";
  const last = messages.length ? messages[messages.length - 1] : null;
  if (!last || last.role !== "assistant") return "";
  return `${chatId}:${last.id}`;
}, [chatId, messages]);

useEffect(() => {
  if (!chatId) return;
  if (busy) return;
  if (memoryEditMode) return;
  if (!lastAssistantKey) return;

  // 동일한 assistant에 대해 중복 호출 방지
  if (memoryReqRef.current.lastAppliedKey === lastAssistantKey) return;
  memoryReqRef.current.lastAppliedKey = lastAssistantKey;

  const silent = settingsView !== "memory";
  void openMemorySummary({ force: true, reason: "assistant_done", silent });
}, [settingsView, chatId, busy, memoryEditMode, lastAssistantKey]);



  // 채팅방 이름(제목) UI-only 저장 (DB/API는 건드리지 않음)
  const [chatTitle, setChatTitle] = useState<string>("");
  const [editingChatTitle, setEditingChatTitle] = useState(false);
  const [chatTitleDraft, setChatTitleDraft] = useState<string>("");
  const chatTitleInputRef = useRef<HTMLInputElement | null>(null);

  // 입력창 하단 모델 선택 드롭다운
  const [modelMenuOpen, setModelMenuOpen] = useState(false);
  const modelMenuRef = useRef<HTMLDivElement | null>(null);
  const modelBtnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!modelMenuOpen) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node | null;
      if (!t) return;
      if (modelMenuRef.current?.contains(t)) return;
      if (modelBtnRef.current?.contains(t)) return;
      setModelMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setModelMenuOpen(false);
    };
    window.addEventListener("mousedown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [modelMenuOpen]);

  useEffect(() => {
    if (!chatId) {
      setChatTitle("");
      setEditingChatTitle(false);
      setChatTitleDraft("");
      return;
    }
    try {
      if (typeof window === "undefined") return;
      const k = `chatTitle:${chatId}`;
      const v = window.localStorage.getItem(k) || "";
      setChatTitle(v);
    } catch {
      // ignore
    }
  }, [chatId]);

  useEffect(() => {
    if (editingChatTitle) {
      requestAnimationFrame(() => {
        chatTitleInputRef.current?.focus();
        chatTitleInputRef.current?.select();
      });
    }
  }, [editingChatTitle]);

  const effectiveChatTitle = useMemo(() => {
    const t = (chatTitle || "").trim();
    if (t) return t;
    return "채팅";
  }, [chatTitle]);

  const beginEditChatTitle = useCallback(() => {
    setChatTitleDraft(chatTitle || "");
    setEditingChatTitle(true);
  }, [chatTitle]);

  const cancelEditChatTitle = useCallback(() => {
    setEditingChatTitle(false);
    setChatTitleDraft("");
  }, []);

  const saveEditChatTitle = useCallback(() => {
    if (!chatId) {
      cancelEditChatTitle();
      return;
    }
    const v = (chatTitleDraft || "").trim();
    setChatTitle(v);
    try {
      if (typeof window !== "undefined") {
        const k = `chatTitle:${chatId}`;
        if (!v) window.localStorage.removeItem(k);
        else window.localStorage.setItem(k, v);
      }
    } catch {
      // ignore
    }
    setEditingChatTitle(false);
  }, [chatId, chatTitleDraft, cancelEditChatTitle]);



  // (요구사항) 최근 AI 답변 1개만 인라인 수정
  const [editingAssistantId, setEditingAssistantId] = useState<string>("");
  const [assistantDraft, setAssistantDraft] = useState<string>("");

  // (요구사항) 유저 메시지 수정: 해당 지점의 다음 AI 답변까지 재생성할 수 있도록
  const [editingUserId, setEditingUserId] = useState<string>("");
  const [userDraft, setUserDraft] = useState<string>("");

  // (성능) drafts 변경 핸들러를 안정화해서, 메인 입력 타이핑 시 메시지 리스트가 불필요하게 리렌더되지 않게 함
  const onChangeAssistantDraft = useCallback((v: string) => setAssistantDraft(v), []);
  const onChangeUserDraft = useCallback((v: string) => setUserDraft(v), []);

  const lastAssistantId = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i]?.role === "assistant") return messages[i].id;
    }
    return undefined;
  }, [messages]);

  const lastUserId = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i]?.role === "user") return messages[i].id;
    }
    return undefined;
  }, [messages]);

  // (성능) 긴 채팅은 기본적으로 마지막 N개만 렌더
  const CHAT_RENDER_TAIL_THRESHOLD = 240;
  const CHAT_RENDER_TAIL_DEFAULT = 160;
  const CHAT_RENDER_TAIL_STEP = 120;

  const effectiveVisibleCount = useMemo(() => {
    if (messages.length === 0) return 0;
    // 사용자가 명시적으로 확장한 경우
    if (visibleCount > 0) return Math.min(messages.length, visibleCount);
    // 자동 모드
    if (messages.length >= CHAT_RENDER_TAIL_THRESHOLD) return Math.min(messages.length, CHAT_RENDER_TAIL_DEFAULT);
    return messages.length;
  }, [messages.length, visibleCount]);

  const visibleMessages = useMemo(() => {
    if (effectiveVisibleCount >= messages.length) return messages;
    const start = Math.max(0, messages.length - effectiveVisibleCount);
    return messages.slice(start);
  }, [messages, effectiveVisibleCount]);

  const hiddenMessageCount = messages.length - visibleMessages.length;

  // (요구사항 #4) 같은 작품(프리셋) 안에서 여러 채팅을 선택할 수 있어야 함
  const [chatList, setChatList] = useState<
    Array<{ id: string; createdAt: number; title: string; lastMessage: string }>
  >([]);

  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const contentRef = useRef<HTMLDivElement | null>(null);
  const nearBottomRef = useRef(true);

  // 하단 고정 입력창 높이를 실시간으로 측정해 메시지 영역이 절대 침범되지 않도록 한다.
  const inputBarRef = useRef<HTMLDivElement | null>(null);
  const [bottomInset, setBottomInset] = useState(360);

  // 입력창 높이가 변해 bottomInset이 달라질 때, 사용자가 바닥을 보고 있는 상태면
  // 마지막 메시지가 다시 입력창 아래로 '가려져 보이는' 것을 방지하기 위해 자동으로 끝으로 재정렬한다.
  useEffect(() => {
    if (!nearBottomRef.current) return;
    const el = scrollRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        el.scrollTop = el.scrollHeight;
      });
    });
  }, [bottomInset]);

  // {{img:REFKEY}} 토큰 파서
  // NOTE: 이미지 기능은 현재 '정상 기준선' 밖이지만, 기존 렌더링이 이 함수를 참조하므로
  //       런타임 ReferenceError가 나지 않도록 컴포넌트 스코프에 안전하게 고정한다.
  function splitByImgToken(input: string) {
    const blocks: Array<{ type: "text"; text: string } | { type: "img"; key: string }> = [];
    const re = /\{\{img:([^}]+)\}\}/g;
    let last = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(input)) !== null) {
      const start = m.index;
      const end = re.lastIndex;
      const before = input.slice(last, start);
      if (before) blocks.push({ type: "text", text: before });
      const key = String(m[1] || "").trim();
      if (key) blocks.push({ type: "img", key });
      last = end;
    }
    const tail = input.slice(last);
    if (tail) blocks.push({ type: "text", text: tail });
    return blocks.length ? blocks : [{ type: "text" as const, text: input }];
  }

  useEffect(() => {
    const el = inputBarRef.current;
    if (!el) return;

    const update = () => {
      const h = Math.ceil(el.getBoundingClientRect().height || 0);
      // 안전 여백(여유 공간) 포함 (고정 입력창/하단 칩/그림자 등 포함해서 넉넉히)
      setBottomInset(Math.max(200, h + 64));
      // (UI) 메인 레이아웃이 바뀌어도 입력창이 채팅 컬럼과 항상 수평 정렬되도록 도킹 좌표를 갱신한다.
      try {
        const c = contentRef.current;
        if (c) {
          const r = c.getBoundingClientRect();
          const left = Math.max(0, Math.round(r.left));
          const width = Math.max(320, Math.round(r.width));
          document.documentElement.style.setProperty("--chatDockLeft", `${left}px`);
          document.documentElement.style.setProperty("--chatDockWidth", `${width}px`);
        }
      } catch {}
    };

    update();

    const ro = new ResizeObserver(() => update());
    ro.observe(el);
    window.addEventListener("resize", update);
    return () => {
      try {
        ro.disconnect();
      } catch {}
      window.removeEventListener("resize", update);
    };
  }, []);

  const isNearBottom = useCallback((el: HTMLDivElement | null) => {
    if (!el) return true;
    const gap = el.scrollHeight - el.scrollTop - el.clientHeight;
    return gap < 120;
  }, []);

  const updateNearBottom = useCallback(() => {
    const el = scrollRef.current;
    nearBottomRef.current = isNearBottom(el);
  }, [isNearBottom]);

  const expandOlderMessages = useCallback(
    (mode: "more" | "all") => {
      const el = scrollRef.current;
      const beforeH = el?.scrollHeight ?? 0;
      const beforeTop = el?.scrollTop ?? 0;

      const currentlyVisible = visibleMessages.length;
      const nextVisible =
        mode === "all"
          ? messages.length
          : Math.min(messages.length, currentlyVisible + CHAT_RENDER_TAIL_STEP);

      // 사용자 의도(확장)로 들어가면 visibleCount를 명시값으로 유지한다.
      setVisibleCount(nextVisible);

      // 위쪽 메시지를 추가 렌더링해도 화면이 튀지 않도록 현재 뷰포트 위치를 보정
      requestAnimationFrame(() => {
        if (!el) return;
        const afterH = el.scrollHeight;
        const deltaH = afterH - beforeH;
        el.scrollTop = beforeTop + deltaH;
      });
    },
    [messages.length, visibleMessages.length]
  );

  const scrollToBottomIfAllowed = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (!nearBottomRef.current) return;
    requestAnimationFrame(() => {
      // requestAnimationFrame으로 DOM height 반영 후 스크롤 이동
      el.scrollTop = el.scrollHeight;
    });
  }, []);

  const scrollToBottomForce = useCallback(() => {
    const el = scrollRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollTop = el.scrollHeight;
    });
  }, []);

  // settings state (저장 후 유지)
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);

  // 공통 토스트(알림) - 브라우저 alert 대신 앱 내 UI로 표시
  type ToastVariant = "success" | "error" | "info";
  const [toast, setToast] = useState<null | {
    open: boolean;
    title: string;
    message?: string;
    variant: ToastVariant;
  }>(null);
  const toastTimerRef = useRef<any>(null);

  const showToast = useCallback((title: string, message?: string, variant: ToastVariant = "info", ms = 2200) => {
    try {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    } catch {}
    setToast({ open: true, title, message, variant });
    toastTimerRef.current = setTimeout(() => {
      setToast((t) => (t ? { ...t, open: false } : t));
    }, ms);
  }, []);



  const bottomRef = useRef<HTMLDivElement | null>(null);


  const consumeForceNewChatFlag = useCallback(
    (pid: string) => {
      // 작품 탭에서 "새 대화 시작" 버튼을 누르면 localStorage에 presetId를 기록해둠.
      // 채팅 탭 진입 시 이 플래그가 있으면 최신 채팅을 로드하지 말고 새 채팅을 생성한다.
      try {
        const key = "forceNewChatPresetId";
        const v = window.localStorage.getItem(key) || "";
        if (v && v === pid) {
          window.localStorage.removeItem(key);
          return true;
        }
      } catch {
        // ignore
      }
      return false;
    },
    []
  );

  const selectedPreset = useMemo(() => {
    if (!presetId) return null;
    return presets.find((p) => p.id === presetId) || null;
  }, [presetId, presets]);

  // (UI) 이미지 보기 토글: 채팅별로 저장(localStorage)
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const scope = chatId ? `chat:${chatId}` : presetId ? `preset:${presetId}` : "global";
      const key = `ai:showImages:${scope}`;
      const v = window.localStorage.getItem(key);
      if (v === "0") setShowImages(false);
      else if (v === "1") setShowImages(true);
      // 없으면 기본값(true) 유지
    } catch {
      // ignore
    }
  }, [chatId, presetId]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const scope = chatId ? `chat:${chatId}` : presetId ? `preset:${presetId}` : "global";
      const key = `ai:showImages:${scope}`;
      window.localStorage.setItem(key, showImages ? "1" : "0");
    } catch {
      // ignore
    }
  }, [chatId, presetId, showImages]);



// 갤러리(Workspace) 이미지: {{img:REFKEY}} 토큰으로 채팅/소설 출력 중간에 삽입 가능
// preset.gallery는 JSON 문자열로 저장된다. (GalleryItem[] 포맷)
type GalleryItemForChat = { id?: string; dataUrl?: string; refKey?: string; desc?: string } | any;

function parsePresetGallery(raw?: string | null): { refKey: string; dataUrl: string; desc: string }[] {
  if (!raw) return [];
  const txt = String(raw || "").trim();
  if (!txt) return [];
  try {
    const j = JSON.parse(txt) as GalleryItemForChat[] | any;
    if (!Array.isArray(j)) return [];
    const out: { refKey: string; dataUrl: string; desc: string }[] = [];
    for (const it of j) {
      if (it && typeof it === "object") {
        const refKey = String((it as any).refKey || "").trim();
        const dataUrl = String((it as any).dataUrl || "").trim();
        const desc = String((it as any).desc || "").trim();
        if (refKey && dataUrl) out.push({ refKey, dataUrl, desc });
      }
    }
    return out;
  } catch {
    return [];
  }
}

const galleryMap = useMemo(() => {
  const map = new Map<string, { src: string; desc: string }>();
  const items = parsePresetGallery((selectedPreset as any)?.gallery);
  for (const it of items) map.set(it.refKey, { src: it.dataUrl, desc: it.desc });
  return map;
}, [selectedPreset]);

  const npcName = (selectedPreset?.characterName || "상대").trim() || "상대";
  const userName = (settings?.personaName || selectedProfile?.personaName || "나").trim() || "나";

  // Chat UI theme (dark, novel-focused). 다른 화면(작업실 등) 테마는 추후 분리 가능.
  // (성능) 렌더마다 객체가 새로 생성되면 하위 콜백/컴포넌트가 매번 새 타입으로 인식될 수 있으므로 고정한다.
// NOTE: Input preview uses "dialogue" color even without quotes.
// Keep this at component scope so runtime references remain defined.
// (renderNovel defines its own NOVEL_DIALOGUE inside renderNovel; this one is for input/UI only.)
const NOVEL_DIALOGUE = "#ffffff";

  const CHAT_THEME = useMemo(
    () => ({
    // 영상 스타일에 맞춰 '완전 블랙' 기반으로 정리
    bg: "#000",
    bg2: "#000",
    panel: "transparent",
    bubbleUser: "transparent",
    bubbleAssistant: "transparent",
    border: "rgba(255,255,255,0.10)",
    borderStrong: "rgba(255,255,255,0.16)",
    text: "#e5e7eb",
    muted: "rgba(229,231,235,0.70)",
    // 보조 패널/카드 배경
    panel2: "rgba(255,255,255,0.04)",
    // 강조색(버튼/하이라이트)
    accent: "#a78bfa",
    iconBg: "rgba(255,255,255,0.06)",
    iconBorder: "rgba(255,255,255,0.14)",
    // 기본 지문 색상(요청): rgb(204,199,199)
    // (헌법) 소설 지문은 항상 흰색 고정 (회색 금지)
    narration: "#ffffff",
    speech: "#e5e7eb",
    thought: "#c7d2fe",
    name: "#a78bfa",
    }),
    []
  );

  const renderInline = useCallback(
    (text: string) => {
      // *...* 구간은 "지문"으로 취급하지만,
      // - 지문은 항상 흰색(회색 금지)
      // - 기울임(이탤릭/합성 이탤릭) 금지
      const parts: React.ReactNode[] = [];
      let i = 0;
      while (i < text.length) {
        const a = text.indexOf("*", i);
        if (a === -1) {
          parts.push(text.slice(i));
          break;
        }
        const b = text.indexOf("*", a + 1);
        if (b === -1) {
          parts.push(text.slice(i));
          break;
        }
        if (a > i) parts.push(text.slice(i, a));
        const italic = text.slice(a + 1, b);
        parts.push(
          <span key={`${a}-${b}`} style={{ color: CHAT_THEME.narration, fontStyle: "normal" }}>
            {italic}
          </span>
        );
        i = b + 1;
      }
      return <>{parts}</>;
    },
    [CHAT_THEME.narration]
  );

  // 스트리밍 중에도 [END]가 UI에 잠깐이라도 노출되지 않게 클라이언트에서도 제거
  const stripEndMarkerClient = (t: string) =>
    String(t || "")
      .replace(/\n?\[END\]\s*$/i, "")
      .replace(/\n?<END>\s*$/i, "")
      .trimEnd();

  // 메시지 액션 버튼(인라인 SVG) 공통 스타일
  // - 런타임에서 undefined가 되지 않도록 반드시 한 곳에서 정의
  // (성능) 매 렌더마다 새 객체 생성 방지
  const iconButtonStyle: React.CSSProperties = useMemo(
    () => ({
      width: 34,
      height: 34,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 10,
      background: CHAT_THEME.iconBg,
      border: `1px solid ${CHAT_THEME.iconBorder}`,
      color: CHAT_THEME.text,
      cursor: "pointer",
    }),
    [CHAT_THEME.iconBg, CHAT_THEME.iconBorder, CHAT_THEME.text]
  );

  // 입력창 미리보기(색상 하이라이트): *...* / **...** 는 지문(흰색), 그 외는 대사(주황)
  // - 입력 중에만 사용(출력/렌더 기준선에는 영향 없음)
  const buildInputPreviewNodes = (raw: string) => {
    const text = String(raw ?? "");
    if (!text) return null;

    // 매치: **...** 또는 *...*
    const re = /(\*\*[^*]+\*\*|\*[^*]+\*)/g;
    const parts: { t: string; kind: "n" | "d" }[] = [];
    let last = 0;

    for (const m of text.matchAll(re)) {
      const i = m.index ?? 0;
      if (i > last) parts.push({ t: text.slice(last, i), kind: "d" });
      const seg = m[0];
      const inner = seg.startsWith("**") ? seg.slice(2, -2) : seg.slice(1, -1);
      parts.push({ t: inner, kind: "n" });
      last = i + seg.length;
    }
    if (last < text.length) parts.push({ t: text.slice(last), kind: "d" });

    return (
      <>
        {parts.map((p, idx) => (
          <span
            key={idx}
            style={{
              color: "#ffffff",
              fontWeight: p.kind === "n" ? 400 : 500,
              whiteSpace: "pre-wrap",
            }}
          >
            {p.t}
          </span>
        ))}
      </>
    );
  };


  const renderNovel = useCallback(
    (text: string) => {
    const lines = text.split("\n");
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 6, color: CHAT_THEME.text }}>
        {lines.map((raw, idx) => {
          const line = raw.trimEnd();
          if (!line) return <div key={idx} style={{ height: 4 }} />;

          // (UX) 모델이 가끔 "=" / "＝" 같은 노이즈 라인을 섞어 출력하는 경우가 있어,
          // 본문 가독성을 위해 단독 구분선 라인은 제거한다.
          if (/^[=＝]+$/.test(line.trim())) {
            return <div key={idx} style={{ height: 4 }} />;
          }

          // 전체가 *...* 이면 서술
          if (line.startsWith("*") && line.endsWith("*") && line.length >= 2) {
            const inner = line.slice(1, -1);
            return (
              <div
                key={idx}
                style={{ color: CHAT_THEME.narration, fontStyle: "normal", lineHeight: 1.6 }}
              >
                {inner}
              </div>
            );
          }

          const m = line.match(/^(.+?)\s*\|\s*(.+)$/);
          if (m) {
            // (요구사항 #1)
            // 지문(서술)은 이름 접두를 표시하지 않는다.
            // 예: "서윤아 | *...*" 또는 "서윤아 | *..."(중간 끊김)
            const rhs = (m[2] || "").trim();
            if (rhs.startsWith("*")) {
              const inner = rhs.endsWith("*") && rhs.length >= 2 ? rhs.slice(1, -1) : rhs.slice(1);
              return (
                <div
                  key={idx}
                  style={{ color: CHAT_THEME.narration, fontStyle: "normal", lineHeight: 1.6 }}
                >
                  {renderInline(inner)}
                </div>
              );
            }
            return (
              <div key={idx} style={{ lineHeight: 1.6 }}>
                <span style={{ fontWeight: 800, color: CHAT_THEME.name }}>{m[1]}</span>
                {" | "}
                {(() => {
                  const rhs2 = String(m[2] ?? "");
                  const trimmed = rhs2.trim();
                  const isThought =
                    trimmed.startsWith("(") ||
                    trimmed.startsWith("（") ||
                    trimmed.startsWith("…") ||
                    trimmed.startsWith("...") ||
                    /^\[(속마음|생각|내적)\]/.test(trimmed) ||
                    /^(속마음|생각|내적)[:：]/.test(trimmed);
                  const contentStyle = isThought
                    ? ({ color: CHAT_THEME.thought, fontStyle: "italic" } as const)
                    : ({ color: CHAT_THEME.speech } as const);
                  return <span style={contentStyle}>{renderInline(rhs2)}</span>;
                })()}
              </div>
            );
          }

          return (
            <div key={idx} style={{ lineHeight: 1.6 }}>
              {(() => {
                const trimmed = line.trim();

                // (추가) "[낭인] \"...\"" / "[낭인]“...”" / \"...\" 같은 따옴표 대사 라인 처리
                // - [낭인] 같은 접두는 지문(흰색)으로 두고, 따옴표 구간만 대사색(주황)으로 표시
                {
                  const speakerM = trimmed.match(/^(\[[^\]]+\])\s*(.*)$/);
                  const speaker = speakerM ? speakerM[1] : "";
                  const rest0 = speakerM ? String(speakerM[2] || "") : trimmed;
                  const rest = rest0.trimStart();

                  const openIdx = rest.search(/[“"]/);
                  if (openIdx === 0) {
                    const openCh = rest[0];
                    let closeIdx = -1;
                    if (openCh === "“") {
                      closeIdx = rest.indexOf("”", 1);
                      if (closeIdx < 0) closeIdx = rest.indexOf("\"", 1);
                    } else {
                      closeIdx = rest.indexOf("\"", 1);
                      if (closeIdx < 0) closeIdx = rest.indexOf("”", 1);
                    }
                    if (closeIdx > 0) {
                      const quoted = rest.slice(0, closeIdx + 1);
                      const tail = rest.slice(closeIdx + 1);

                      return (
                        <>
                          {speaker ? <span style={{ color: CHAT_THEME.narration }}>{speaker}</span> : null}
                          {speaker ? " " : null}
                          <span style={{ color: CHAT_THEME.speech }}>{renderInline(quoted)}</span>
                          {tail ? <span style={{ color: CHAT_THEME.narration }}>{renderInline(tail)}</span> : null}
                        </>
                      );
                    }
                  }
                }

                // (요구사항 #4)
                // assistant 메시지에서 "이름 | 대사" 형태가 아닌 줄은 전부 지문으로 본다.
                // - 일부 출력이 *...* 형태가 아니어도 지문으로 회색 처리되어야 한다.
                // - 단, *...*는 기존처럼 이탤릭 유지.
                if (trimmed.startsWith("*")) {
                  const inner = trimmed.endsWith("*") && trimmed.length >= 2 ? trimmed.slice(1, -1) : trimmed.slice(1);
                  return (
                    <span style={{ color: CHAT_THEME.narration, fontStyle: "normal" }}>
                      {renderInline(inner)}
                    </span>
                  );
                }

                const isThought =
                  trimmed.startsWith("(") ||
                  trimmed.startsWith("（") ||
                  trimmed.startsWith("…") ||
                  trimmed.startsWith("...") ||
                  /^\[(속마음|생각|내적)\]/.test(trimmed) ||
                  /^(속마음|생각|내적)[:：]/.test(trimmed);

                // 지문은 모두 narration 색으로 통일
                const style = isThought
                  ? ({ color: CHAT_THEME.narration, fontStyle: "normal" } as const)
                  : ({ color: CHAT_THEME.narration } as const);
                return <span style={style}>{renderInline(line)}</span>;
              })()}
            </div>
          );
        })}
      </div>
    );
    },
    [CHAT_THEME, renderInline]
  );

  // (Chat 모드) 최소 마크다운 렌더러
  // - 목적: 채팅 모드에서도 ```status 같은 코드블록/외부 이미지 마크다운이 UI에 그대로 보이게
  // - 주의: renderNovel(소설 모드) 로직/스타일은 절대 건드리지 않는다.
  function renderMarkdownLite(text: string): React.ReactNode {
    const t = String(text || "");
    if (!t) return null;

    type Block =
      | { type: "text"; value: string }
      | { type: "code"; lang: string; value: string }
      | { type: "img"; url: string; alt: string };

    const blocks: Block[] = [];

    // 1) 코드블록 분리 (```lang ... ```)
    const codeRe = /```([^\n`]*)\n([\s\S]*?)```/g;
    let last = 0;
    let m: RegExpExecArray | null;
    while ((m = codeRe.exec(t))) {
      const start = m.index;
      const end = codeRe.lastIndex;
      if (start > last) blocks.push({ type: "text", value: t.slice(last, start) });
      const lang = String(m[1] || "").trim().toLowerCase();
      const value = String(m[2] || "").replace(/\r\n/g, "\n").trimEnd();
      blocks.push({ type: "code", lang, value });
      last = end;
    }
    if (last < t.length) blocks.push({ type: "text", value: t.slice(last) });

    // 2) 텍스트 블록 내부에서 마크다운 이미지(![](...))만 추가 분리
    const out: Block[] = [];
    const imgRe = /!\[([^\]]*)\]\(([^)\s]+)\)/g;
    for (const b of blocks) {
      if (b.type !== "text") {
        out.push(b);
        continue;
      }
      const s = b.value;
      let p = 0;
      let im: RegExpExecArray | null;
      while ((im = imgRe.exec(s))) {
        const a = im.index;
        const z = imgRe.lastIndex;
        if (a > p) out.push({ type: "text", value: s.slice(p, a) });
        const alt = String(im[1] || "");
        const url = String(im[2] || "");
        out.push({ type: "img", url, alt });
        p = z;
      }
      if (p < s.length) out.push({ type: "text", value: s.slice(p) });
    }

    const renderTextBlock = (value: string, key: string) => {
      let lines = String(value || "").replace(/\r\n/g, "\n").split("\n");
      if (!showImages) {
        const imgLineRe = /^\s*"?(?:https?:\/\/|\/\/)[^\s"]+\.(?:png|jpe?g|gif|webp)(?:\?[^\s"]*)?"?\s*$/i;
        lines = lines.filter((ln) => !imgLineRe.test(String(ln || "")));
      }
      return (
        <div key={key} style={{ display: "flex", flexDirection: "column", gap: 6, whiteSpace: "pre-wrap" }}>
	      	  {lines.map((line, idx) => {
	      	    const raw = String(line || "");
	      	    const trimmed = raw.trim();
	      	    if (!trimmed) return <div key={idx} style={{ height: 4 }} />;
	      	    // Hide stray standalone separator lines (often appears right before an image)
	      	    if (/^[=＝]+$/.test(trimmed)) return <div key={idx} style={{ height: 4 }} />;
	      	    const t2 = raw.trimEnd();
	      	    return (
	      	      <div key={idx} style={{ lineHeight: 1.6 }}>
	      	        <span style={{ color: CHAT_THEME.speech }}>{renderInline(t2)}</span>
	      	      </div>
	      	    );
	      	  })}
        </div>
      );
    };

    const renderCodeBlock = (lang: string, value: string, key: string) => {
      // (요구) 가로 스크롤(옆으로 밀림) 대신 줄바꿈으로 보이게
      // - status 블록이 특히 길어지므로 pre-wrap + break-word 강제
      return (
        <pre
          key={key}
          style={{
            margin: 0,
            padding: 14,
            borderRadius: 12,
            background: "rgba(255,255,255,0.06)",
            border: "none",
            color: CHAT_THEME.text,
            fontFamily:
              "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
            fontSize: 13,
            lineHeight: 1.55,
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            overflowX: "hidden",
          }}
        >
          {value}
        </pre>
      );
    };

    const renderImageBlock = (url: string, alt: string, key: string) => {
      if (!showImages) return null;
      const safeUrl = String(url || "");
      return (
        <div key={key} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={safeUrl}
            alt={alt || ""}
            style={{
              maxWidth: "100%",
              height: "auto",
              borderRadius: 14,
              border: "none",
              background: "rgba(255,255,255,0.02)",
            }}
          />
        </div>
      );
    };

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {out.map((b, i) => {
          if (b.type === "code") return renderCodeBlock(b.lang, b.value, `md-code-${i}`);
          if (b.type === "img") return renderImageBlock(b.url, b.alt, `md-img-${i}`);
          return renderTextBlock(b.value, `md-txt-${i}`);
        })}
      </div>
    );
  }

  // (템플릿) 프리셋 첫 메시지 등에 {{user}} placeholders가 남아있는 경우
  // 현재 선택된 페르소나로 최소 치환한다.
  function applyPersonaTemplate(t: string, p: { personaName: string; personaAge: number; personaGender: string } | null): string {
    let s = String(t || "");
    if (!p) return s;
    // 구체 토큰을 먼저 치환(순서 중요)
    s = s.replace(/\{\{user\}\}의\s*성별/g, String(p.personaGender || ""));
    s = s.replace(/\{\{user\}\}의\s*나이/g, String(p.personaAge ?? ""));
    // 남은 {{user}} 치환
    s = s.replace(/\{\{user\}\}/g, String(p.personaName || ""));
    return s;
  }

  // (UI) 이미지 보기 OFF일 때: 이미지 마크다운/URL 라인을 본문에서 제거한다.
  // - 소설 모드(renderNovel) 본문은 건드리지 않고, 입력 텍스트만 정리한다.
  function stripImageLines(t: string): string {
    const s0 = String(t || "");
    // 마크다운 이미지 태그 제거 (![](...))
    const s1 = s0.replace(/!\[[^\]]*\]\([^\)]+\)/g, "");
    const lines = s1.replace(/\r\n/g, "\n").split("\n");
    const imgLineRe = /^\s*"?(?:https?:\/\/|\/\/)[^\s"]+\.(?:png|jpe?g|gif|webp)(?:\?[^\s"]*)?"?\s*$/i;
    const cleaned = lines.filter((ln) => !imgLineRe.test(String(ln || "")));
    return cleaned.join("\n");
  }

  // 메시지 본문 렌더러
  // - assistant: 소설형(대사/지문) 파서 적용
  // - user: 줄바꿈/이탤릭(*...*)만 유지해서 표시
  const MessageContent = useCallback(
    ({ message }: { message: Msg }) => {
      if (message.role === "assistant") {
        const txtRaw = applyPersonaTemplate(String(message.content || ""), selectedProfile);
        const txt = showImages ? txtRaw : stripImageLines(txtRaw);


        const renderImageCut = (key: string, k: string) => {
          if (!showImages) return null;
          const found = galleryMap.get(key);
          if (!found?.src) {
            return (
              <div
                key={k}
                style={{
                  border: "none",
                  background: CHAT_THEME.panel2,
                  borderRadius: 18,
                  padding: 14,
                  color: CHAT_THEME.muted,
                  maxWidth: 860,
                }}
              >
                이미지 없음: {key}
              </div>
            );
          }
          return (
            <div
              key={k}
              style={{
                border: "none",
                background: "rgba(255,255,255,0.03)",
                borderRadius: 20,
                padding: 10,
                maxWidth: 900,
              }}
            >
              <img
                src={found.src}
                alt={found.desc || key}
                style={{
                  width: "100%",
                  height: "auto",
                  borderRadius: 16,
                  display: "block",
                  objectFit: "contain",
                }}
              />
            </div>
          );
        };
        // renderMode는 채팅별 설정 값이지만, 로딩/마이그레이션 구간에서는 undefined가 될 수 있음.
        // 요구사항: 기본은 '소설' 모드로 안전하게 폴백.
        const effectiveRenderMode: "chat" | "novel" =
          (settings as any)?.renderMode === "chat" || (settings as any)?.renderMode === "novel"
            ? ((settings as any).renderMode as "chat" | "novel")
            : "novel";

        if (effectiveRenderMode === "novel") {
          // (novel) INFO 블록은 현재 사용하지 않으므로 표시하지 않는다.
          const stripInfo = (t: string) => {
            // 기존 구현은 "INFO" 라인이 등장하면 그 아래를 통째로 잘라내는데,
            // 사용자가 프롬프트에서 상태창/일지 등을 출력하는 경우
            // 모델이 "INFO"를 중간에 끼워넣으면(혹은 과거 로그에 남아 있으면)
            // 상태창 본문이 통째로 사라지는 문제가 발생할 수 있다.
            //
            // 안전 규칙:
            // - "INFO" 아래에 상태창(STATUS/일지 등)으로 보이는 내용이 있으면 절대 절단하지 않고,
            //   "INFO" 라인만 제거한다.
            // - 진짜 메타 블록(끝부분에 붙는 INFO)인 경우에만 기존처럼 절단한다.
            const lines = String(t || "").replace(/\r\n/g, "\n").split("\n");
            const idx = lines.findIndex((ln) => String(ln || "").trim() === "INFO");
            if (idx < 0) return String(t || "").trimEnd();

            const tail = lines.slice(idx + 1).join("\n");
            const tailHasStatusLike =
              /```\s*STATUS\b/i.test(tail) ||
              /status_window\s*:/i.test(tail) ||
              /^\s*\[일지\d\s*\/\s*3\]/m.test(tail) ||
              /^\s*\[내공\s*:/m.test(tail) ||
              /^\s*\[무공\s*:/m.test(tail);

            if (tailHasStatusLike) {
              // 절단 금지: INFO 라인만 제거
              const kept = lines.filter((_, i) => i !== idx).join("\n");
              return kept.trimEnd();
            }

            // 진짜 INFO 메타 블록으로 판단되면 기존처럼 INFO 아래는 숨김
            return lines.slice(0, idx).join("\n").trimEnd();
          };

					// 소설 모드 UI: 지문은 항상 흰색(회색/기울임 금지)
					const NOVEL_NARRATION = "#ffffff";
          // (눈부신 노랑 방지) 은은한 웜톤(과한 노랑 ↓)
          const NOVEL_DIALOGUE = "#ffffff";
          const NOVEL_BASE_FONT_SIZE = 15;
          const NOVEL_LINE_HEIGHT = 1.85;

					// 소설 모드에서도 코드블록/마크다운 이미지가 동작해야 한다.
					// - 기존 소설 렌더(대사/지문 톤, 개행/문단)는 유지
					// - 코드펜스/이미지 등 "블록"만 안전하게 마크다운 렌더러로 넘긴다.
					const normalizeForNovelMarkdown = (t: string) => {
					// 일부 모델/프롬프트는 opening fence(```LABEL)와 첫 줄 내용을 같은 라인에 붙여 출력한다.
					// 예) ```STATUS [일지0/3]...
					// 예) ```HELLO something...
					// splitByFencedCode는 opening fence가 단독 라인일 때만 안정적으로 분리하므로,
					// LABEL 종류에 상관없이 fence 라인을 분리해 준다.
					const s0 = String(t || "");

					// 모델이 이미지 라인을 대사처럼 따옴표로 감싸 출력하는 경우가 있다.
					// 예) "![](https://...png)"  /  “![](https://...png)”
					// → 따옴표만 제거하여 정상적인 마크다운 이미지로 렌더되게 한다.
					const s0u = s0
						// 1) 라인 단위로: "![](url)" / “![](url)” 처럼 이미지 마크다운만 따옴표로 감싼 경우
						.replace(/^\s*(?:["“”])\s*(!\[[^\]]*\]\([\s\S]*?\))\s*(?:["“”])\s*$/gm, "$1")
						// 2) 혹시 라인 단위 매칭이 빠지는 경우를 대비한 인라인 처리(한 줄 범위로만)
						.replace(/(["“”])\s*(!\[[^\]]*\]\([^\n]*?\))\s*\1/g, "$2");

					const s1 = s0u.replace(/^\s*```\s*([^\s`]+)\s+(.+)$/gim, "```$1\n$2");

					// 과거 프롬프트/로그에 남아 있는 "!!URL" 또는 "\"!!URL\"" 형태를
					// 표준 마크다운 이미지로 흡수한다.
					const s2 = s1.replace(/^\s*"?!!\s*([^"\s]+)"?\s*$/gm, "![]($1)");

					// 과거/일부 출력에서 이미지 URL만 단독으로(따옴표/괄호 포함) 오는 경우를
					// 표준 마크다운 이미지로 흡수한다. 예: "//itimg.kr/a.webp" 또는 (https://...png)
					const s3 = s2.replace(/^\s*"?\(?\s*((?:https?:\/\/|\/\/)[^\s"()]+?\.(?:png|jpe?g|gif|webp)(?:\?[^\s"()]*)?)\s*\)?"?\s*$/gmi, "![]($1)");

					// 스트리밍/정규화 과정에서 URL 내부가 잘려 공백이 끼는 경우(예: dyd1. speedgabia.com)
					// 마크다운 이미지 URL 괄호 안의 공백은 모두 제거하여 복구한다.
					const s4 = s3.replace(/!\[([^\]]*)\]\(([^)]*)\)/g, (_m, alt, url) => {
						const fixedUrl = String(url || "").replace(/\s+/g, "");
						return `![${String(alt || "")}](${fixedUrl})`;
					});

					return s4;
				};


					const splitByFencedCode = (t: string, allowAutoClose: boolean = true) => {
						// ```LANG ... ``` 형태를 줄 단위로 안전하게 분리한다.
						// - allowAutoClose=true: 닫는 ``` 가 누락되어도(모델 출력 실수) 문서 끝에서 자동으로 닫아준다.
						// - allowAutoClose=false(스트리밍 중): 닫는 ``` 가 오기 전까지는 강제 닫기를 하지 않는다.
						//   (강제 닫기를 해버리면, 이후 실제 ``` 가 도착했을 때 블록 경계가 꼬이거나
						//    코드/지문 섞임이 발생할 수 있다.)
						const lines = String(t || "").replace(/\r\n/g, "\n").split("\n");
						const out: { type: "text" | "code"; value: string }[] = [];
						let textBuf: string[] = [];
						let fenceBuf: string[] = [];
							let inFence = false;
							let fenceLang = "";

						for (const line of lines) {
							if (!inFence) {
								// opening fence: allow leading/trailing whitespace
								const m = String(line || "").match(/^\s*```([^\s`]*)\s*$/);
								if (m) {
									if (textBuf.length) {
										out.push({ type: "text", value: textBuf.join("\n") });
										textBuf = [];
									}
									inFence = true;
									const lang = String(m[1] || "");
									fenceLang = lang;
									fenceBuf = [`\`\`\`${lang}`];
									continue;
								}
								textBuf.push(line);
							} else {
								// closing fence
								if (/^\s*```\s*$/.test(String(line || ""))) {
									fenceBuf.push("```");
									out.push({ type: "code", value: fenceBuf.join("\n") });
									fenceBuf = [];
									inFence = false;
									fenceLang = "";
									continue;
								}
								fenceBuf.push(line);
							}
						}

						if (inFence) {
							// 스트리밍 중에는 어떤 펜스도 강제 닫기를 하지 않는다.
							// (중요) STATUS/INFO(상태창/일지/요약)가 본문 중간에 끼어드는 UX 문제를 막기 위해,
							// 스트리밍 동안엔 닫힘이 오기 전까지는 "텍스트"로 유지해(렌더 분리 최소화)
							// 이후 done 재렌더 시에만 정상적으로 코드펜스로 분리/표시되게 한다.
							if (allowAutoClose) {
								// 닫는 ``` 가 없으면 강제로 닫아준다.
								fenceBuf.push("```");
								out.push({ type: "code", value: fenceBuf.join("\n") });
							} else {
								out.push({ type: "text", value: fenceBuf.join("\n") });
							}
								fenceBuf = [];
								inFence = false;
								fenceLang = "";
							}

						if (textBuf.length) out.push({ type: "text", value: textBuf.join("\n") });
						return out;
					};


					const normalizeNovelLine = (lineRaw: string) => {
            const raw = String(lineRaw || "").trim();
            if (!raw) return { kind: "blank" as const, text: "" };

            // 기존 데이터에 남아 있는 INFO/메타 라인은 소설 모드에서 숨김
            if (/^INFO\b/i.test(raw)) return { kind: "skip" as const, text: "" };
            if (/^(📆|📌|💡|❤️)\s*/.test(raw)) return { kind: "skip" as const, text: "" };

            // 과거 메시지에 남아 있는 '이름 | 대사' 포맷을 소설 포맷으로 흡수
            // 예: 임서원 | "..."  -> "..."  /  임서원 | 네, ... -> "네, ..."
            const pipe = raw.match(/^(.+?)\s*\|\s*(.+)$/);
            if (pipe) {
              const rhs = (pipe[2] || "").trim();
              const body = rhs.replace(/^(["“”])\s*/, "").replace(/\s*(["“”])$/, "");
              return { kind: "dialogue" as const, text: `"${body}"` };
            }

            // 과거 메시지에 남아 있는 '이름: 대사' 포맷도 소설 포맷으로 흡수
            // 예: 오지명: 말...  -> "말..."
            const colon = raw.match(/^([^\s]{1,20})\s*[:：]\s*(.+)$/);
            if (colon) {
              const rhs = (colon[2] || "").trim();
              const body = rhs.replace(/^(["“”])\s*/, "").replace(/\s*(["“”])$/, "");
              return { kind: "dialogue" as const, text: `"${body}"` };
            }


						// (Option A) 지문은 반드시 *...* 로 감싸는 규칙.
						// - 스트리밍 중에는 닫는 * 가 늦게 올 수 있으므로, 시작 * 만 있는 경우도 지문으로 취급해
						//   화면에 불필요한 '*'가 튀지 않게 한다.
						const isWrappedNarration = raw.startsWith("*") && raw.endsWith("*") && raw.length >= 2;
						if (isWrappedNarration) {
							return { kind: "narration" as const, text: raw.slice(1, -1) };
						}

						const rawLS = raw.replace(/^[\uFEFF\u200B\u200C\u200D\u2060]+/g, "").trimStart();
						// 화자 마커(\u2063U\u2063 / \u2063N\u2063)가 앞에 붙은 경우에도 대사 판별이 깨지지 않도록 제거
						const rawLS2 = rawLS.replace(/^\u2063[UN]\u2063/, "");

						// "[낭인] \"...\"" 처럼 화자 태그 + 따옴표 대사를 한 줄에 쓰는 경우도
						// '대사'로 분류해서 막대(파란/빨간)가 적용되게 한다.
						// - 대사는 따옴표(" / “ / ”)로 시작하는 구간이 포함되면 대사로 본다.
						// - 기본 색/따옴표 렌더링은 renderInline이 처리.
						const bracketSpeaker = rawLS2.match(/^\[[^\]]+\]\s*(.*)$/);
						if (bracketSpeaker) {
							const rest = String(bracketSpeaker[1] || "").trimStart();
							const hasQuote = rest.startsWith('"') || rest.startsWith("“") || rest.startsWith("”");
							if (hasQuote) return { kind: "dialogue" as const, text: rawLS2 };
						}
						const isQuote = rawLS2.startsWith('"') || rawLS2.startsWith("“") || rawLS2.startsWith("”");
						return { kind: isQuote ? ("dialogue" as const) : ("narration" as const), text: rawLS2 };     };

					// (Option A) 스트리밍 중에는 지문 마커 '*'가 한쪽만 먼저 도착하는 경우가 있다.
					// 텍스트 청크에서만, 코드펜스 밖의 '*' 개수가 홀수이면 임시로 '*'를 하나 더 붙여
					// 화면에 고아('*')가 노출되는 것을 줄인다. (다음 델타에서 전체 텍스트로 재렌더되므로 안전)
					const stabilizeNarrationAsterisks = (textChunk: string) => {
						const s = String(textChunk || "");
						let starCount = 0;
						for (let i = 0; i < s.length; i++) if (s[i] === "*") starCount++;
						if (starCount % 2 === 1) return `${s}*`;
						return s;
					};

					const isStreamingMsg = message.id === streamTempAssistantIdRef.current;
					const t0 = normalizeForNovelMarkdown(txt);
					const chunksRaw = splitByFencedCode(t0, !isStreamingMsg);
					// INFO 트림은 '텍스트 청크'에만 적용해서 코드펜스(STATUS) 내부 내용은 보존한다.
					const chunks = chunksRaw.map((c) => {
						if (c.type !== "text") return c;
						let v = stripInfo(c.value);
						// (중요) 스트리밍 중에는 상태창/일지/요약(STATUS/INFO)이 화면에 끼어들면
						// UX가 크게 흔들린다. 서버에서 턴 끝으로 밀어내더라도, done 직전 델타로
						// 붙는 경우가 있으므로, 스트리밍 동안엔 해당 블록을 숨긴다.
						// (중요) 작품/제작자마다 fenced block 라벨(STATUS/INFO/HELLO 등)이 수백 가지가 될 수 있으므로,
						// 소설 모드에서는 라벨 기반으로 fenced block을 숨기지 않는다.
						if (isStreamingMsg) v = stabilizeNarrationAsterisks(v);
						return { ...c, value: v } as const;
					});
          return (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 16,
                lineHeight: NOVEL_LINE_HEIGHT,
                whiteSpace: "pre-wrap",
                fontSize: NOVEL_BASE_FONT_SIZE,
								color: NOVEL_NARRATION,
								fontStyle: "normal",
								fontSynthesis: "none",
								wordBreak: "break-word",
								overflowWrap: "anywhere",
              }}
            >
							{chunks.map((chunk, ci) => {
								// 1) 코드펜스 블록은 마크다운 렌더러로 처리
								if (chunk.type === "code") {
									return (
										<div key={`code-${ci}`} style={{ color: NOVEL_NARRATION }}>
											{renderMarkdownLite(chunk.value)}
										</div>
									);
								}

								// 2) 텍스트 청크는 문단 단위로(기존 소설 렌더 유지)
								const parts = String(chunk.value || "").split(/\n{2,}/g);
								return parts.map((p, idx) => {
									// 마크다운 이미지가 포함된 문단은 렌더러로 처리 (이미지/링크/인라인코드 등)
									if (/!\[[^\]]*\]\([^\)]+\)/.test(p) || /\[[^\]]+\]\([^\)]+\)/.test(p)) {
										return (
											<div key={`md-${ci}-${idx}`} style={{ color: NOVEL_NARRATION }}>
												{renderMarkdownLite(p)}
											</div>
										);
									}

										const lines = String(p || "").split("\n");

										// (Option A) 지문은 *...* 로 감싸되, 한 줄/여러 줄 모두 허용한다.
										// - 여러 줄 지문: 첫 줄에만 시작 '*', 마지막 줄에만 종료 '*'가 오는 케이스를 지원
										// - 스트리밍 중에는 종료 '*'가 늦게 도착할 수 있으므로, 끝까지 지문으로 묶어 표시한다.
										const groupNovelLines = (ls: string[]) => {
											const out: { kind: "blank" | "skip" | "dialogue" | "narration"; text: string }[] = [];
											let i = 0;
											while (i < ls.length) {
												const rawLine = String(ls[i] ?? "");
												const trimmedEnd = rawLine.trimEnd();
												if (!trimmedEnd.trim()) {
													out.push({ kind: "blank", text: "" });
													i++;
													continue;
												}

												// 멀티라인 지문 시작: 첫 줄에 시작 '*'
												const leftTrim = trimmedEnd.trimStart();
												const startsNarr = leftTrim.startsWith("*");
												const endsNarrSameLine = leftTrim.startsWith("*") && leftTrim.endsWith("*") && leftTrim.length >= 2;

												if (startsNarr && !endsNarrSameLine) {
													// 시작 '*' 제거(첫 줄)
													const first = leftTrim.slice(1);
													const buf: string[] = [first];
													i++;
													let closed = false;
													while (i < ls.length) {
														const r = String(ls[i] ?? "").trimEnd();
														if (!r.trim()) {
															// 빈 줄을 만났는데 아직 닫히지 않았다면, 스트리밍 중(혹은 모델 실수)로 보고 지문을 계속 이어간다.
															buf.push("");
															i++;
															continue;
														}
														const rTrim = r.trim();
														if (rTrim.endsWith("*") && rTrim.length >= 2) {
															// 마지막 줄의 종료 '*' 제거
															buf.push(rTrim.slice(0, -1));
															closed = true;
															i++;
															break;
														}
														buf.push(r);
														i++;
													}

													// 닫히지 않았더라도(스트리밍 중) 지문으로 렌더
													out.push({ kind: "narration", text: buf.join("\n").trimEnd() });
													// closed 플래그는 현재는 사용하지 않지만, 디버그 확장 여지가 있어 남겨둔다.
													void closed;
													continue;
												}

												// 그 외는 기존 normalizeNovelLine 규칙으로 처리
												const norm = normalizeNovelLine(trimmedEnd);
												out.push({ kind: norm.kind, text: norm.text });
												i++;
											}
											return out;
										};

										
												// (UI) assistant 출력 안에 "내 대사"가 인용되어 나오는 경우(오타 교정 등),
												// 실제 user 대사로 보이면 파란 막대(=user)로 렌더링한다.
												// (규약) 보이지 않는 화자 마커로 주인공/상대를 확정한다.
												//  - 주인공 대사: "\u2063U\u2063..." (따옴표 안 맨 앞)
												//  - 상대 대사:   "\u2063N\u2063..."
												const INV = "\u2063";
												const USER_MARK = `${INV}U${INV}`;
												const NPC_MARK = `${INV}N${INV}`;
												const stripSpeakerMarks = (s: string) => String(s || "").split(USER_MARK).join("").split(NPC_MARK).join("");
												const stripQuotes = (s: string) => { const t = String(s || "").trim(); if (t.length >= 2 && ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("“") && t.endsWith("”")))) return t.slice(1, -1); return t; };
												const detectSpeakerMark = (s: string) => {
													const t = String(s || "");
													if (t.includes(USER_MARK)) return "user" as const;
												if (t.includes(NPC_MARK)) return "npc" as const;
													return null;
												};
												const normalizeForEchoMatch = (s: string) =>
													stripSpeakerMarks(String(s || ""))
														.trim()
														.replace(/[“”]/g, '"')
														.replace(/^"+|"+$/g, "")
														.replace(/\s+/g, " ")
														.replace(/[\.,!\?~…·:;\-—_()\[\]{}<>]/g, "")
														.toLowerCase();
												const bigramSet = (s: string) => {
													const t = normalizeForEchoMatch(s).replace(/\s/g, "");
													const set = new Set<string>();
													for (let i = 0; i < t.length - 1; i++) set.add(t.slice(i, i + 2));
													// 길이가 1 이하인 경우도 비교가 되게
													if (t.length <= 1) set.add(t);
													return set;
												};
												const jaccard = (a: Set<string>, b: Set<string>) => {
													if (!a.size || !b.size) return 0;
													let inter = 0;
													for (const x of a) if (b.has(x)) inter++;
													const uni = a.size + b.size - inter;
													return uni ? inter / uni : 0;
												};
												const userDialogueCandidates = (() => {
													try {
														const ms = (messages || []).slice(-40).filter((m: any) => m?.role === "user");
														const out: string[] = [];
														for (const m of ms) {
															const raw = String(m?.content || "").replace(/\r\n/g, "\n");
															for (const ln of raw.split("\n")) {
																const t0 = String(ln || "").trim();
																if (!t0) continue;
																// 지문(*...*)은 제외
																if ((t0.startsWith("**") && t0.endsWith("**") && t0.length >= 4) || (t0.startsWith("*") && t0.endsWith("*") && t0.length >= 2)) continue;
																out.push(normalizeForEchoMatch(t0));
															}
														}
														return Array.from(new Set(out)).filter(Boolean);
													} catch {
														return [] as string[];
													}
												})();
												const isUserEchoDialogue = (line: string) => {
													const n = normalizeForEchoMatch(line);
													if (!n) return false;
													// 빠른 경로: 완전 동일/부분 포함
													for (const c of userDialogueCandidates) {
														if (!c) continue;
														if (n === c) return true;
														if (n.length >= 6 && (n.includes(c) || c.includes(n))) return true;
													}
													// 느린 경로: 오타 교정 등 유사도(2-gram Jaccard)
													const a = bigramSet(n);
													for (const c of userDialogueCandidates) {
														const sim = jaccard(a, bigramSet(stripQuotes(stripSpeakerMarks(c))));
														if (sim >= 0.60) return true;
													}
													return false;
												};
const grouped = groupNovelLines(lines);
										return (
											<div key={`p-${ci}-${idx}`} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
												{grouped.map((g, j) => {
														if (g.kind === "skip") return null;
														if (g.kind === "blank") return <div key={j} style={{ height: 6 }} />;

													const isDialogue = g.kind === "dialogue";
													const textLine = g.text;


												// (UI) 역할별 막대(주인공=파란, 상대=빨간)
												// 1) 보이지 않는 화자 마커가 있으면 그걸로 확정
												// 2) 마커가 없으면 기존 유사도 매칭으로 fallback
												const barForDialogue = (line: string) => {
													const marked = detectSpeakerMark(line);
													if (marked === "user") return "#3b82f6";
													if (marked === "npc") return "#ef4444";
													return isUserEchoDialogue(stripSpeakerMarks(line)) ? "#3b82f6" : "#ef4444";
												};
												const bgForDialogue = (bar: string) =>
													bar === "#3b82f6" ? "rgba(59,130,246,0.08)" : "rgba(239,68,68,0.08)";
												const dialogueBoxStyle = (bar: string): React.CSSProperties => ({
													borderLeft: `4px solid ${bar}`,
													background: bgForDialogue(bar),
													borderRadius: 14,
													padding: "10px 12px",
													margin: "6px 0",
													maxWidth: 980,
												});
												if (isDialogue) {
													const bar = barForDialogue(textLine);
													return (
														<div key={j} style={dialogueBoxStyle(bar)}>
														<span style={{ color: NOVEL_NARRATION, fontWeight: 600 }}>{renderInline(stripSpeakerMarks(textLine))}</span>
														</div>
													);
												}
												return (
													<div key={j} style={{ color: NOVEL_NARRATION, lineHeight: NOVEL_LINE_HEIGHT }}>
														{renderInline(textLine)}
													</div>
												);
													})}
										</div>
									);
								});
							})}
            </div>
          );
        }

        // (chat) 채팅 모드에서도 마크다운(코드블록/외부 이미지)을 렌더링한다.
        // - 소설 모드(renderNovel)는 그대로 유지
        // - {{img:...}} 토큰은 기존과 동일하게 갤러리 이미지로 렌더링
        const blocks = splitByImgToken(txt);
        return (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, lineHeight: 1.6, whiteSpace: "pre-wrap" }}>
            {blocks.map((b, bi) => {
              if (b.type === "img") return renderImageCut(b.key, `img-chat-${bi}`);
              return <div key={`blk-${bi}`}>{renderMarkdownLite(String(b.text || ""))}</div>;
            })}
          </div>
        );
      }

      // --- user message rendering ---
      // (요구사항) 입력창 미리보기와 동일 규칙:
      //   *...* / **...** 는 지문(흰색), 그 외는 대사(주황)
      // - 출력(assistant) 소설 렌더 기준선은 유지 (여기는 user 전용)
      const rawUser = String(message.content || "");
      const effectiveRenderMode: "chat" | "novel" =
        (settings as any)?.renderMode === "chat" || (settings as any)?.renderMode === "novel"
          ? ((settings as any).renderMode as "chat" | "novel")
          : "novel";

      
      if (effectiveRenderMode === "novel") {
        const ls = String(rawUser || "").replace(/\r\n/g, "\n").split("\n");

        // user(내 메시지)도 소설 모드 규칙 동일 적용:
        // - 지문(*...* / **...**) => 막대 없음
        // - 그 외(대사) => 파란 막대
        const dialogueBar = "#3b82f6";
        const dialogueBg = "rgba(59,130,246,0.08)";
        const dialogueBoxStyle: React.CSSProperties = {
          borderLeft: `4px solid ${dialogueBar}`,
          background: dialogueBg,
          borderRadius: 14,
          padding: "10px 12px",
          margin: "6px 0",
          maxWidth: 980,
        };

        // 멀티라인 지문도 지원(*로 시작해서 *로 닫힐 때까지)
        const out: { kind: "blank" | "narration" | "dialogue"; text: string }[] = [];
        for (let i = 0; i < ls.length; ) {
          const raw = String(ls[i] ?? "").trimEnd();
          if (!raw.trim()) {
            out.push({ kind: "blank", text: "" });
            i++;
            continue;
          }
          const leftTrim = raw.trimStart();
          const startsNarr = leftTrim.startsWith("*");
          const endsNarrSameLine = startsNarr && leftTrim.endsWith("*") && leftTrim.length >= 2;

          if (startsNarr && !endsNarrSameLine) {
            const first = leftTrim.slice(1);
            const buf: string[] = [first];
            i++;
            while (i < ls.length) {
              const r = String(ls[i] ?? "").trimEnd();
              if (!r.trim()) {
                buf.push("");
                i++;
                continue;
              }
              const rTrim = r.trim();
              if (rTrim.endsWith("*") && rTrim.length >= 2) {
                buf.push(rTrim.slice(0, -1));
                i++;
                break;
              }
              buf.push(r);
              i++;
            }
            out.push({ kind: "narration", text: buf.join("\n").trimEnd() });
            continue;
          }

          // 단일 라인 지문(*...* / **...**)
          if ((leftTrim.startsWith("**") && leftTrim.endsWith("**") && leftTrim.length >= 4) || endsNarrSameLine) {
            const inner = leftTrim.startsWith("**") ? leftTrim.slice(2, -2) : leftTrim.slice(1, -1);
            out.push({ kind: "narration", text: inner });
            i++;
            continue;
          }

          out.push({ kind: "dialogue", text: raw });
          i++;
        }

        return (
          <div style={{ fontSize: 15, lineHeight: 1.85, whiteSpace: "pre-wrap" }}>
            {out.map((g, j) => {
              if (g.kind === "blank") return <div key={j} style={{ height: 6 }} />;
              if (g.kind === "narration") {
                return (
                  <div key={j} style={{ color: "#ffffff", lineHeight: 1.85 }}>
                    {renderInline(g.text)}
                  </div>
                );
              }
              return (
                <div key={j} style={dialogueBoxStyle}>
                  <span style={{ color: "#ffffff", fontWeight: 600 }}>{renderInline(g.text)}</span>
                </div>
              );
            })}
          </div>
        );
      }


      return (
        <div style={{ lineHeight: 1.6, whiteSpace: "pre-wrap" }}>
          {renderMarkdownLite(rawUser)}
        </div>
      );
    },
	    [CHAT_THEME, galleryMap, renderInline, renderNovel, renderMarkdownLite, buildInputPreviewNodes, (settings as any)?.renderMode, selectedProfile, showImages, messages]
  );

  // Gemini API Studio 가격(대략). 모델/정책에 따라 변동될 수 있음.
  // 키는 settings.model 값과 반드시 일치해야 함.
  const priceTable: Record<string, { inUsdPer1M: number; outUsdPer1M: number }> = {
    // Gemini 3 preview
    "gemini-3-pro-preview": { inUsdPer1M: 2, outUsdPer1M: 12 },
    "gemini-3-flash-preview": { inUsdPer1M: 0.5, outUsdPer1M: 3 },
    // Gemini 2.5
    "gemini-2.5-pro": { inUsdPer1M: 1.25, outUsdPer1M: 10 },
  };
  const usdToKrw = 1434; // 대략치(환율은 변동)
  function estimateTokensFromChars(chars: number) {
    // 대략적인 추정치: 한국어/혼합 텍스트는 토큰이 더 잘게 쪼개질 수 있음
    // "가격이 어떻게 변하는지"를 보여주는 목적의 rough estimate
    return Math.ceil(chars / 2);
  }

  const est = useMemo(() => {
    if (!settings) return null;
    const rates = priceTable[settings.model] || priceTable["gemini-2.5-pro"];
    const recentTextChars = (messages.slice(-20) || []).reduce((acc, m) => acc + (m.content?.length || 0), 0);
    // 요약본은 "이전 대화 전체"를 대체하는 텍스트라서 길이가 커질수록 입력 토큰이 늘어남.
    // summaryLength는 "턴당 글자수(자/턴)" 이므로, 최소한 1블록(=summaryEvery턴) 정도를
    // 대략치로 잡아 입력 토큰 변화를 보여준다.
    const perTurn = Number(settings.summaryLength || 50);
    const every = Number(settings.summaryEvery || 5);
    const summaryChars = Math.max(0, perTurn) * Math.max(1, every);
    const presetChars = (selectedPreset?.background?.length || 0) + (selectedPreset?.character?.length || 0) + (selectedPreset?.extra?.length || 0);
    const inputChars =
      (input?.length || 0) +
      recentTextChars +
      summaryChars +
      presetChars +
      (settings.userNote?.length || 0) +
      (settings.personaInfo?.length || 0) +
      (settings.personaName?.length || 0);
    const inTok = estimateTokensFromChars(inputChars);
    // 모델에 보낼 "최대 출력" + "추론(Thinking)"을 모두 output으로 잡아 가격이 변하는 게 보이게 함.
    const outTok = Number(settings.maxOutputTokens || 1300) + Number(settings.maxReasoningTokens || 0);
    const usd = (inTok / 1_000_000) * rates.inUsdPer1M + (outTok / 1_000_000) * rates.outUsdPer1M;
    const krw = usd * usdToKrw;
    return { inTok, outTok, usd, krw };
  }, [settings, messages, input, selectedPreset]);

  // (성능) 토큰 팝업 오픈 핸들러를 안정화해서, 입력창 타이핑마다 MessageList가 재렌더되는 것을 줄인다.
  const openTokenInfo = useCallback((m: Msg, anchorEl?: HTMLElement | null) => {
    if (anchorEl) {
      const r = anchorEl.getBoundingClientRect();
      setTokenPopupAnchor({ left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height });
    } else {
      setTokenPopupAnchor(null);
    }
    setTokenPopup({ open: true, title: "토큰 사용량", usage: m.usage ?? null });
  }, []);


  async function loadProfile() {
    const res = await fetch(`/api/profile`);
    const json = await safeJson(res);
    if (!res.ok) throw new Error(json?.error || "프로필 불러오기 실패");
    const list = (json.profiles || []) as any[];
    setProfiles(list);
    // 기본 선택: 기존 선택 유지, 아니면 최신 1개
    if (list.length > 0) {
      setSelectedProfileId((prev) => prev || String(list[0].id));
    } else {
      setSelectedProfileId("");
    }
  }

  async function saveProfile(next: { id?: string; personaName: string; personaAge: number; personaGender: string; personaInfo: string }) {
    const res = await fetch(`/api/profile`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(next),
    });
    const json = await safeJson(res);
    if (!res.ok) throw new Error(json?.error || "프로필 저장 실패");
    await loadProfile();
    if (json.id) setSelectedProfileId(String(json.id));
  }

  async function deleteProfile(id: string) {
    const res = await fetch(`/api/profile?id=${encodeURIComponent(id)}`, { method: "DELETE" });
    const json = await safeJson(res);
    if (!res.ok) throw new Error(json?.error || "프로필 삭제 실패");
    await loadProfile();
  }

  // 최초 1회: 전역 페르소나 불러오기
  useEffect(() => {
    loadProfile().catch(() => {});
  }, []);

  async function createChat(replaceExisting: boolean = false, confirmed: boolean = false) {
    if (!presetId) return alert("작품을 먼저 선택해 주세요.");

    // 새로 시작(replaceExisting=true)일 때는 기존 대화가 삭제됩니다.
    if (replaceExisting && chatList.length > 0 && !confirmed) {
      openConfirm({
        title: "새 대화 시작",
        desc: "기존 대화는 삭제됩니다. 정말 새 대화를 시작하시겠습니까?",
        confirmText: "새 대화 시작",
        danger: true,
        action: "newChat",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/chat/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ presetId, replaceExisting }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "채팅 생성 실패");
      setChatId(json.chatId);
      setMessages([]);
      setVisibleCount(0);
      setInput("");
      // 새 채팅 시작 시 이전 추천답변이 남아있지 않도록 초기화
      setSuggestions([]);
      await loadChatList(presetId);
      // 새 채팅 생성 시 settings 로드
      await loadSettings(json.chatId);
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setBusy(false);
    }
  }


  async function deleteChatAndExit(confirmed: boolean = false) {
    if (!chatId) return;
    if (!confirmed) {
      openConfirm({
        title: "채팅 삭제",
        desc: "이 채팅을 즉시 삭제하고 나갈까요? (히스토리/설정/요약도 함께 삭제됩니다.)",
        confirmText: "삭제",
        danger: true,
        action: "deleteChat",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/chat/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chatId }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "채팅 삭제 실패");

      // UI 초기화
      const pid = presetId;
      setChatId("");
      setMessages([]);
      setVisibleCount(0);
      setSettings(null);
      setInput("");
      setSuggestions([]);
      setMemorySummary("");
    setMemoryLoaded(false);
      setMemoryChars(0);
      if (pid) await loadChatList(pid);
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setBusy(false);
    }
  }

  async function loadHistory(targetChatId: string) {
    const res = await fetch(`/api/chat/history?chatId=${encodeURIComponent(targetChatId)}`);
    const json = await safeJson(res);
    if (!res.ok) throw new Error(json?.error || "히스토리 불러오기 실패");
    setMessages(json.messages || []);
    setVisibleCount(0);
    // 다른 채팅으로 이동 시, 이전 채팅의 추천답변이 남아있지 않도록 초기화
    setSuggestions([]);
  }

  async function loadSettings(targetChatId: string) {
    const res = await fetch(`/api/chat/settings?chatId=${encodeURIComponent(targetChatId)}`);
    const json = await safeJson(res);
    if (!res.ok) throw new Error(json?.error || "설정 불러오기 실패");
    const s = json.settings as any;
    // 과거에 잘못 저장된 모델명(gemini-2-5-flash 등) 정규화
    const rawModel = String(s?.model || "");
    const normalizedModel = rawModel
      .replace("gemini-2-5-flash", "gemini-2.5-pro")
      .replace("gemini-2-5-pro", "gemini-2.5-pro")
      .replace("gemini-3-pro", "gemini-3-pro-preview")
      .replace("gemini-3-flash", "gemini-3-flash-preview");
    if (normalizedModel && MODEL_OPTIONS.includes(normalizedModel as any)) {
      s.model = normalizedModel;
    } else if (!MODEL_OPTIONS.includes(s.model as any)) {
      s.model = "gemini-2.5-pro";
    }
    // 기본 모드: 소설 (채팅 모드 임시 비활성화)
    s.renderMode = "novel";

    // 최근 원문(유저 입력) 턴수(K)는 시스템 기본값을 유지 (서버 범위 12~20)
    const mf = Number(s?.memoryFrom ?? 12);
    s.memoryFrom = Number.isFinite(mf) ? Math.max(12, Math.min(20, mf)) : 12;

    // 장기 기억 요약 주기: 기본 5턴, 범위 3~12
    const se = Number(s?.summaryEvery ?? 5);
    s.summaryEvery = Number.isFinite(se) ? Math.max(3, Math.min(12, se)) : 5;

    // summaryLength = 장기기억 요약 "턴당 글자수" (10~200, step 10)
    const sl = Number(s?.summaryLength ?? 50);
    if (!Number.isFinite(sl)) s.summaryLength = 50;
    else {
      const snapped = Math.round(sl / 10) * 10;
      s.summaryLength = Math.max(10, Math.min(200, snapped));
    }

    setSettings(s);
  }

  async function loadChatList(pid: string) {
    try {
      const res = await fetch(`/api/chat/list?presetId=${encodeURIComponent(pid)}&limit=20`);
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "채팅 목록 불러오기 실패");
      setChatList(json.chats || []);
    } catch {
      setChatList([]);
    }
  }

  async function saveSettings() {
    if (!chatId) {
      showToast("채팅이 없습니다", "먼저 채팅을 생성해 주세요.", "error");
      return;
    }
    if (!settings) return;

    setSaving(true);
    try {
      const res = await fetch("/api/chat/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...settings, chatId }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "설정 저장 실패");

      // 저장 후에도 값 유지(서버 저장값으로 다시 세팅 + 범위 보정)
      if (json?.settings) {
        const ss = { ...(json.settings as any) };
        const se2 = Number(ss?.summaryEvery ?? 5);
        ss.summaryEvery = Number.isFinite(se2) ? Math.max(3, Math.min(12, se2)) : 5;
        const sl2 = Number(ss?.summaryLength ?? 50);
        if (!Number.isFinite(sl2)) ss.summaryLength = 50;
        else {
          const snapped = Math.round(sl2 / 10) * 10;
          ss.summaryLength = Math.max(10, Math.min(200, snapped));
        }
        setSettings(ss);
      }
      showToast("설정 저장 완료", undefined, "success");
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setSaving(false);
    }
  }

  // 일부 UI(색상 등)에서 즉시 반영이 필요할 때, 알림 없이 조용히 저장합니다.
  async function saveSettingsSilent(partial: Partial<Settings>) {
    if (!chatId) return;
    if (!settings) return;
    const merged = { ...settings, ...partial } as Settings;
    try {
      const res = await fetch("/api/chat/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...merged, chatId }),
      });
      const json = await safeJson(res);
      if (res.ok && json?.settings) {
        setSettings(json.settings);
      }
    } catch {
      // ignore
    }
  }

  

  // --- Stream pacer (UI only): 서버 델타(불규칙) → 화면 표출(규칙/부드러움)로 변환 ---
  // Gemini 3 Pro 계열은 "묶음 생성 → 묶음 방출" 성향이 강해서, 그대로 뿌리면 "멈춤→쏟아짐" 체감이 커진다.
  // 그래서 UI에서는 작은 조각으로 균일하게 흘려보내는 'artificial stream'을 더 적극적으로 적용한다.
  const STREAM_PACE_MS = 40;
  const STREAM_CHARS_PER_TICK = 14;
  // (추가) 프리버퍼 + backlog 유지: '멈췄다 한 번에 쏟아짐' 완화
  const STREAM_PREBUFFER_CHARS = 240; // 첫 출력 시작 전 최소 누적 문자수(너무 길면 체감 멈춤이 커짐)
  const STREAM_TARGET_BACKLOG = 180; // 스트리밍 중에는 항상 이 정도 뒤처지게(버퍼 고갈 방지)
  const STREAM_MIN_PREBUFFER_UI_MS = 700; // prebuffer 배지 최소 노출 시간
  const STREAM_IDLE_FLUSH_MS = 280;  // 이 시간 이상 델타가 없으면 backlog 제한을 풀고 남은 버퍼를 끝까지 출력

  
  // prebuffer 표시/해제 판단용: 공백/제로폭 문자만 있는 경우를 '비어있음'으로 취급
  function __isEffectivelyEmptyForPrebuffer(s: string): boolean {
    const t = String(s || "").replace(/[\s\u200b\u200c\u200d\uFEFF]/g, "");
    return t.length === 0;
  }

const streamLastDeltaAtRef = useRef<number>(0);
  const streamLastPingAtRef = useRef<number>(0);
  const streamHasDeltaRef = useRef<boolean>(false);

  // (UI) 프리버퍼 구간에만 '생각 중...' 배지 표시
  const [prebufferUiActive, setPrebufferUiActive] = useState(false);
  const [stallUiActive, setStallUiActive] = useState(false);
  const prebufferUiActiveRef = useRef(false);
  const prebufferStartRef = useRef<number>(0);
  const [prebufferSec, setPrebufferSec] = useState(0);
  const [prebufferDots, setPrebufferDots] = useState("");

  // interval 내부(클로저)에서 최신 prebufferUiActive를 읽기 위한 ref (deps/TDZ 문제 회피)
  useEffect(() => {
    prebufferUiActiveRef.current = prebufferUiActive;
  }, [prebufferUiActive]);


  const streamTargetRef = useRef<string>("");
  const streamShownRef = useRef<string>("");
  const streamTempAssistantIdRef = useRef<string>("");
  const streamPaceTimerRef = useRef<number | null>(null);

  // 최신 추천 생성용(ref): 스트리밍 완료본을 state 레이스 없이 사용
  const lastAssistantForSuggestRef = useRef<string>("");
  const lastUserForSuggestRef = useRef<string>("");

  const startStreamPacer = useCallback(
    (tempAssistantId: string) => {
      streamTempAssistantIdRef.current = tempAssistantId;
      streamTargetRef.current = "";
      streamShownRef.current = "";

      // prebuffer UI ON (shown until first visible token is rendered)
      prebufferStartRef.current = Date.now();
      setPrebufferSec(1);
      setPrebufferDots("");
      setPrebufferUiActive(true);
      setStallUiActive(false);

      // delta tracking
      streamHasDeltaRef.current = false;
      streamLastDeltaAtRef.current = 0;

      if (streamPaceTimerRef.current) {
        window.clearInterval(streamPaceTimerRef.current);
        streamPaceTimerRef.current = null;
      }

      streamPaceTimerRef.current = window.setInterval(() => {
        const id = streamTempAssistantIdRef.current;
        if (!id) return;

        const target = streamTargetRef.current;
        const shown = streamShownRef.current;

        // prebuffer 구간: target이 충분히 쌓이기 전까지는 출력 시작을 지연(elyn 스타일)
        const now = Date.now();
        const lastDeltaAt = streamLastDeltaAtRef.current;
        const allowFlushAll =
          streamHasDeltaRef.current && lastDeltaAt > 0 && (now - lastDeltaAt) >= STREAM_IDLE_FLUSH_MS;

        if (prebufferUiActive && !allowFlushAll) {
          const elapsed = now - (prebufferStartRef.current || now);
          if (elapsed < STREAM_MIN_PREBUFFER_UI_MS || target.length < STREAM_PREBUFFER_CHARS) {
            return;
          }
        }
        // prebuffer 배지는 '실제 첫 글자 출력' 시점에 끈다(아래 nextLen>0 처리)

        if (shown.length >= target.length) return;

        // backlog 유지: 스트리밍 중에는 항상 약간 뒤처지게 해서 버퍼 고갈로 인한 '멈춤'을 완화
        const desiredMaxLen = Math.max(0, target.length - (allowFlushAll ? 0 : STREAM_TARGET_BACKLOG));
        if (shown.length >= desiredMaxLen) return;

        const backlog = target.length - shown.length;
        // backlog가 크면 더 빠르게 따라잡되, 여전히 "타자 치듯" 보이도록 조절
        const step =
          backlog > 5000 ? 80 :
          backlog > 3000 ? 64 :
          backlog > 1800 ? 48 :
          backlog > 1000 ? 32 :
          backlog > 600 ? 24 :
          backlog > 320 ? 18 :
          STREAM_CHARS_PER_TICK;

        const nextLen = Math.min(desiredMaxLen, shown.length + step);
        const nextText = target.slice(0, nextLen);
        streamShownRef.current = nextText;

        setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: nextText } : m)));
        if (prebufferUiActiveRef.current && !__isEffectivelyEmptyForPrebuffer(nextText)) {
          prebufferUiActiveRef.current = false;
          setPrebufferUiActive(false);
      setStallUiActive(false);
        }
        // 스트리밍 중 자동 스크롤: chat 모드에서만(소설 모드는 시작 지점을 유지)
        const rm = (settings as any)?.renderMode;
        if (rm === "chat") {
          scrollToBottomIfAllowed();
        }
      }, STREAM_PACE_MS);
    },
    [scrollToBottomIfAllowed]
  );

  const stopStreamPacer = useCallback((opts?: { flush?: boolean }) => {
    const id = streamTempAssistantIdRef.current;

    if (opts?.flush && id) {
      const finalText = streamTargetRef.current;
      streamShownRef.current = finalText;
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: finalText } : m)));
    }

    if (streamPaceTimerRef.current) {
      window.clearInterval(streamPaceTimerRef.current);
      streamPaceTimerRef.current = null;
    }

    

    setPrebufferUiActive(false);
      setStallUiActive(false);
streamTempAssistantIdRef.current = "";
  }, []);

  useEffect(() => {
    return () => {
      if (streamPaceTimerRef.current) {
        window.clearInterval(streamPaceTimerRef.current);
        streamPaceTimerRef.current = null;
      }
    };
  }, []);

  // (UI) 프리버퍼 배지: prebufferUiActive 동안 초/점 애니메이션
  useEffect(() => {
    if (!prebufferUiActive) {
      setPrebufferSec(0);
      setPrebufferDots("");
      return;
    }
    const start = prebufferStartRef.current || Date.now();
    prebufferStartRef.current = start;
    let tick = 0;
    const t = window.setInterval(() => {
      const now = Date.now();
      const sec = Math.max(0, Math.floor((now - start) / 1000));
      setPrebufferSec(sec);
      tick = (tick + 1) % 4;
      setPrebufferDots(tick === 0 ? "" : ".".repeat(tick));
    }, 250);
    return () => window.clearInterval(t);
  }, [prebufferUiActive]);
async function send() {
  if (busy) return;

	  // 친구비가 0이면 전송을 막고, 충전 유도 팝업을 띄운다.
	  // (서버 주입/DB 연동 전 단계: 로컬 잔액 기준)
	  try {
	    const bal = readFriendFeeBalance();
	    if (bal <= 0) {
	      friendFeeEmptyShownRef.current = true;
	      openFriendFeeEmptyPopup();
	      return;
	    }
	  } catch {
	    // ignore
	  }

	  const text = input.trim();
	  if (!text) return;
  // 추천답변 문맥 정확도를 위해: 방금 보낸 user 텍스트를 ref에 저장(React state 레이스 방지)
  lastUserForSuggestRef.current = text;

  setBusy(true);
  setSendError(null);

  const tempUserId = `temp-u-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const tempAssistantId = `temp-a-${Date.now()}-${Math.random().toString(16).slice(2)}`;

  const now = Date.now();
  const tempUser: Msg = { id: tempUserId, chatId, role: "user", content: text, createdAt: now };
  const tempAssistant: Msg = { id: tempAssistantId, chatId, role: "assistant", content: "", createdAt: now + 1 };

  setMessages((prev) => [...prev, tempUser, tempAssistant]);

  // ✅ UX: 사용자가 "전송(Enter)"한 순간에는 항상 맨 아래로 점프한다.
  // (완료(done) 시점 자동 스크롤은 금지 — 읽던 위치를 보호)
  nearBottomRef.current = true;
  requestAnimationFrame(() => requestAnimationFrame(() => scrollToBottomForce()));

  startStreamPacer(tempAssistantId);
  setInput("");
  // (요구사항) 추천답변은 "직전 assistant(마지막 지문)" 기준으로 매번 새로 갱신되어야 한다.
  // 기존 suggestions가 남아있으면 자동 생성 useEffect가 동작하지 않으므로, 새 요청 시작 시 항상 초기화한다.
  setSuggestions([]);


  try {
    // (중요) 서버 프롬프트/요약 로직은 persona/runtime 값에 의존한다.
    // - personaOverride가 없으면 서버는 주인공 이름을 기본값("주인공")으로 사용해 출력에 반영될 수 있다.
    // - runtime이 없으면 요약/컨텍스트 구성 파라미터가 DB 저장값과 어긋나거나(특히 UI 슬라이더) 기본값으로 떨어질 수 있다.
    const personaOverride = {
      personaName: (settings?.personaName || selectedProfile?.personaName || "").trim(),
      personaAge: Number(settings?.personaAge || selectedProfile?.personaAge || 0),
      personaGender: String(settings?.personaGender || selectedProfile?.personaGender || "").trim(),
      personaInfo: String(settings?.personaInfo || selectedProfile?.personaInfo || "").trim(),
    };

    const payload = {
      chatId,
      userText: text,
      personaOverride,
      runtime: {
        model: settings?.model,
        maxOutputTokens: settings?.maxOutputTokens,
        maxReasoningTokens: settings?.maxReasoningTokens,
        keepUserTurns: settings?.memoryFrom,
        perTurnChars: settings?.summaryLength,
      },
      currentMsgId: selectedMsgIdForRegenerate || null,
      rewriteFromMsgId: selectedMsgIdForRewrite || null,
      stream: true,
    };

      const dbgId = `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
      console.debug(`[ui][send][${dbgId}] POST /api/chat/send`, payload);

      const res = await fetch("/api/chat/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const ct = (res.headers.get("content-type") || "").toLowerCase();
      console.debug(`[ui][send][${dbgId}] status=${res.status} ct=${ct}`);

      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        console.error(`[ui][send][${dbgId}] non-OK response`, errText);
        throw new Error(errText || `HTTP ${res.status}`);
      }


    
    // ---- NDJSON streaming ----
    if (ct.includes("application/x-ndjson")) {
      const reader = res.body?.getReader();
      if (!reader) throw new Error("No stream body");

      const dec = new TextDecoder();
      let buf = "";
      let realUser: Msg | null = null;
      let realAssistant: Msg | null = null;
      let streamed = "";

      // stream stall diagnostics (helps distinguish "app stalled" vs "proxy timeout")
      const STALL_WARN_MS = 15000;
      let lastStallWarnAt = 0;
      const stallTimer = window.setInterval(() => {
        const last = streamLastDeltaAtRef.current;
        const lastPing = streamLastPingAtRef.current;
        if (!last && !lastPing) return;
        const now = Date.now();
        const gap = last ? now - last : Number.POSITIVE_INFINITY;
        const pingGap = lastPing ? now - lastPing : Number.POSITIVE_INFINITY;

        // UI: If pings are coming in but deltas are not, show an on-screen "generating" indicator
        // to reduce the "stuck" feeling (Gemini 3 Pro can be silent for long stretches).
        if (pingGap < 20000 && gap > 5000) {
          setStallUiActive(true);
        } else {
          setStallUiActive(false);
        }

        if (last && gap >= STALL_WARN_MS && now - lastStallWarnAt >= STALL_WARN_MS) {
          lastStallWarnAt = now;
          console.warn(
            `[ui][stream][${dbgId}] stalled gap=${gap}ms (targetLen=${streamTargetRef.current.length} shownLen=${streamShownRef.current.length})`
          );
        }
      }, 2000);

      try {
        while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buf += dec.decode(value, { stream: true });

        let idx;
        while ((idx = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, idx).trim();
          buf = buf.slice(idx + 1);

          if (!line) continue;

          let obj: any = null;
          try {
            obj = JSON.parse(line);
          } catch {
            continue;
          }

          if (obj.type === "delta") {
            const d = String(obj.text || "");
            if (!d) continue;

            streamHasDeltaRef.current = true;
            streamLastDeltaAtRef.current = Date.now();

            // 델타는 버퍼에만 누적하고, 화면 반영은 pacer가 담당
            streamTargetRef.current = stripEndMarkerClient(streamTargetRef.current + d);
            continue;
          }

          if (obj.type === "ping") {
            // keep-alive (Gemini 3 Pro can be silent for a while)
            streamLastPingAtRef.current = Date.now();
            console.debug(`[ui][stream][${dbgId}] ping recv`);
            continue;
          }

          if (obj.type === "done") {
            // 스트리밍 종료: 남은 버퍼를 즉시 flush하고 맨 아래로 이동
            stopStreamPacer({ flush: true });
            // 완료 시 자동 스크롤 금지(읽던 위치 유지)
            // scrollToBottomForce();
            nearBottomRef.current = false;

            realUser = obj.user || null;
            realAssistant = obj.assistant || null;
            const doneUsage = (obj as any)?.usage ?? null;

            setMessages((prev) => {
              return prev.map((m) => {
                if (m.id === tempUserId && realUser) return realUser;
                if (m.id === tempAssistantId && realAssistant) {
                    const buffered = stripEndMarkerClient(String(streamTargetRef.current || ""));
                    const fromServer = stripEndMarkerClient(String(realAssistant.content || ""));
                    const picked = buffered.length >= fromServer.length ? buffered : fromServer;
                    // 추천 생성은 이 텍스트를 1순위로 사용
                    lastAssistantForSuggestRef.current = picked;
                    return {
                      ...realAssistant,
                      content: picked,
                      // (토큰/비용) done 패킷에 usage가 있으면 즉시 주입해 "계산중"을 방지
                      // - 없으면 기존/서버값을 유지하고, 이후 history hydration으로 보강
                      usage: doneUsage ?? (realAssistant as any).usage ?? (m as any).usage ?? null,
                    };
                }
                return m;
              });
            });

			// (가독성 우선) 출력 완료 후 자동으로 맨 아래로 강제 이동하지 않는다.
			// requestAnimationFrame(() => requestAnimationFrame(() => scrollToBottomForce()));

            // usage/cost 메타데이터는 서버 DB에 저장되므로, done 이후 history에서 한번 더 하이드레이션
            if (realAssistant?.id) hydrateUsageForMessage(realAssistant.id);
            // 서버 스트리밍 응답에는 suggestions를 넣지 않음(별도 /api/chat/suggest 호출 흐름 유지)
            break;
          }

          if (obj.type === "error") {
            throw new Error(String(obj.error || "Streaming error"));
          }
        }
      }

      } finally {
        window.clearInterval(stallTimer);
      }

      setBusy(false);
      return;
    }

    // ---- JSON fallback ----
    let json: any = null;
    try {
      json = await safeJson(res);
    } catch {
      const textBody = await res.text().catch(() => "");
      throw new Error(textBody || `Request failed (${res.status})`);
    }

    if (!res.ok) throw new Error(json?.error || "Request failed");

    const userMsg: Msg = json.user;
    const assistantMsg: Msg = json.assistant;

    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === tempUserId) return userMsg;
        if (m.id === tempAssistantId) return assistantMsg;
        return m;
      })
    );

    // 완료 시 자동 스크롤 금지(읽던 위치 유지)
    // scrollToBottomForce();
    nearBottomRef.current = false;

    if (Array.isArray(json.suggestions)) setSuggestions(json.suggestions);
    else setSuggestions([]);

    setBusy(false);
  } catch (err: any) {
    setBusy(false);

    // 스트림이 중간에 끊겨도(타임아웃/네트워크) 이미 출력된 내용은 유지한다.
    try {
      stopStreamPacer({ flush: true });
    } catch {}

    const partial = stripEndMarkerClient(streamShownRef.current || streamTargetRef.current || "");
    if (partial && partial.trim().length > 0) {
      console.error(`[ui][stream] aborted-but-keep-partial`, err);
      setMessages((prev) =>
        prev.map((m) => (m.id === tempAssistantId ? { ...m, content: partial } : m))
      );
    } else {
      // temp 메시지 제거(기존 동작 유지)
      setMessages((prev) => prev.filter((m) => m.id !== tempUserId && m.id !== tempAssistantId));
    }

    setSendError(err?.message || "요청 처리 중 오류가 발생했습니다.");
    alert(`요청 처리 중 오류가 발생했습니다.\n${err?.message ? `(${err.message})` : ""}`);
  } finally {
    stopStreamPacer();

    // 리셋(기존 동작 유지)
    setSelectedMsgIdForRegenerate(null);
    setSelectedMsgIdForRewrite(null);

    // (요구사항) 답변이 모두 출력되면 입력창으로 포커스를 복귀
    // - rAF로 한 번 미뤄 렌더 완료 후 포커스
    try {
      if (!editingAssistantId && !profileModalOpen ) {
        requestAnimationFrame(() => inputRef.current?.focus());
      }
    } catch {}
  }
}

  // 삭제(브라우저 confirm 대신 UI 팝업으로 톤 통일)
  async function onDeleteMessageConfirmed(messageId: string) {
    if (!chatId) return;
    try {
      const res = await fetch(`/api/chat/message?messageId=${encodeURIComponent(messageId)}`, { method: "DELETE" });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "삭제 실패");
      setMessages((prev) => prev.filter((m) => m.id !== messageId));
    } catch (e: any) {
      alert(e?.message || "오류");
    }
  }

  // UI에서 메시지 객체를 넘기는 형태를 유지하기 위한 래퍼
  function requestDeleteMessage(m: Msg) {
    if (!m?.id) return;
    setDeletePopup({ open: true, messageId: m.id });
  }


  function startEditLastAssistant() {
    if (!lastAssistantId) return;
    const target = messages.find((m) => m.id === lastAssistantId && m.role === "assistant");
    if (!target) return;
    setEditingAssistantId(target.id);
    setAssistantDraft(target.content);
  }

  // (버그픽스) 버튼 onClick이 startAssistantEdit를 호출하고 있는데,
  // 리팩터링 과정에서 startEditLastAssistant로 이름이 바뀌며 참조가 끊긴 상태였다.
  // 요구사항: "최근 AI 답변 1개만" 수정 가능해야 하므로, 마지막 assistant만 열리도록 보장한다.
  function startAssistantEdit(messageOrId: any) {
    const id = String((typeof messageOrId === "string" ? messageOrId : messageOrId?.id) || "").trim();
    if (!id) return;
    // 안전장치: 마지막 assistant가 아니면 무시
    if (!lastAssistantId || id !== lastAssistantId) return;
    startEditLastAssistant();
  }

  function startUserEdit(m: Msg) {
    if (!m?.id) return;
    if (editingAssistantId) return;
    setEditingUserId(m.id);
    setUserDraft(m.content || "");
  }

  function cancelUserEdit() {
    setEditingUserId("");
    setUserDraft("");
  }

  async function saveUserEdit() {
    if (!chatId) return;
    if (!editingUserId) return;
    const content = String(userDraft || "").trim();
    if (!content) return alert("내용이 비어있습니다.");

    setBusy(true);
    try {
      // 1) 유저 메시지 DB/로컬 수정
      const res = await fetch(`/api/chat/message`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messageId: editingUserId, content }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "수정 실패");

      setMessages((prev) => prev.map((m) => (m.id === editingUserId ? { ...m, content } : m)));

      // 2) 해당 유저 메시지 다음의 첫 assistant가 있으면 그 assistant를 재생성
      const idx = messages.findIndex((m) => m.id === editingUserId);
      const nextAssistant = idx >= 0 ? messages.slice(idx + 1).find((m) => m.role === "assistant") : null;
      cancelUserEdit();
      if (nextAssistant?.id) {
        await onRegenerate(nextAssistant.id);
      }
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setBusy(false);
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }

  function cancelAssistantEdit() {
    setEditingAssistantId("");
    setAssistantDraft("");
  }

  async function saveAssistantEdit() {
    if (!chatId) return;
    if (!editingAssistantId) return;
    const content = String(assistantDraft || "").trim();
    if (!content) return alert("내용이 비어있습니다.");

    setBusy(true);
    try {
      const res = await fetch(`/api/chat/message`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messageId: editingAssistantId, content }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "수정 실패");

      setMessages((prev) => prev.map((m) => (m.id === editingAssistantId ? { ...m, content } : m)));
      cancelAssistantEdit();
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setBusy(false);
    }
  }

  async function onRegenerate(assistantMessageId: string) {
    if (!chatId) return;
    // assistant 바로 이전의 user 메시지를 찾아서 그 입력으로 재생성
    const idx = messages.findIndex((m) => m.id === assistantMessageId);
    if (idx <= 0) return alert("재생성할 기준 메시지를 찾지 못했습니다.");
    const prevUser = [...messages].slice(0, idx).reverse().find((m) => m.role === "user");
    if (!prevUser) return alert("직전 유저 메시지를 찾지 못했습니다.");

    setBusy(true);
    try {
      const personaOverride = {
        personaName: (settings?.personaName || selectedProfile?.personaName || "").trim(),
        personaAge: Number(settings?.personaAge || selectedProfile?.personaAge || 0),
        personaGender: String(settings?.personaGender || selectedProfile?.personaGender || "").trim(),
        personaInfo: String(settings?.personaInfo || selectedProfile?.personaInfo || "").trim(),
      };

      const res = await fetch("/api/chat/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chatId,
          message: prevUser.content,
          personaOverride,
          runtime: {
            model: settings?.model,
            maxOutputTokens: settings?.maxOutputTokens,
            maxReasoningTokens: settings?.maxReasoningTokens,
            keepUserTurns: settings?.memoryFrom,
          },
          regenerate: true,
          userMessageId: prevUser.id,
          replaceAssistantId: assistantMessageId,
        }),
      });
      const json = await safeJson(res);
      if (!res.ok) {
        const base = String(json?.error || "재생성 실패");
        const detail = String(json?.detail || "").trim();
        throw new Error(detail ? `${base}\n(${detail})` : base);
      }

      // 서버가 assistant를 교체해서 내려주면 로컬도 교체
      if (json?.assistant) {
        setMessages((prev) => prev.map((m) => (m.id === assistantMessageId ? json.assistant : m)));
      }
      setSuggestions(Array.isArray(json?.suggestions) ? json.suggestions : []);
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setBusy(false);
    }
  }

  // 마지막 AI 응답 재생성(버튼에서 사용)
  async function onRegenerateLast() {
    if (!lastAssistantId) return;
    await onRegenerate(lastAssistantId);
  }

  // UI에서 assistant 메시지 객체를 넘기는 형태를 유지하기 위한 래퍼
  function regenerateFromUser(m: Msg) {
    if (!m?.id) return;
    void onRegenerate(m.id);
  }


  async function openMemorySummary(opts?: { force?: boolean; reason?: string; silent?: boolean }) {
  if (!chatId) return;

  const silent = Boolean(opts?.silent);

  // 편집 중에는 자동 갱신으로 draft가 덮어씌워지지 않게 한다.
  // (수동으로 다시시도 버튼을 누르면 force로 호출 가능)
  const force = Boolean(opts?.force);
  const now = Date.now();
  const minIntervalMs = 1200;

  if (!force) {
    if (memoryLoading) return;
    if (now - (memoryReqRef.current.lastFetchAt || 0) < minIntervalMs) return;
  }

  // 요청 시퀀스 증가 + 이전 요청 abort (경쟁 상태 방지)
  const seq = (memoryReqRef.current.seq || 0) + 1;
  memoryReqRef.current.seq = seq;
  memoryReqRef.current.lastFetchAt = now;

  try {
    if (memoryReqRef.current.abort) {
      try {
        memoryReqRef.current.abort.abort();
      } catch {}
    }
    const ac = new AbortController();
    memoryReqRef.current.abort = ac;

    if (!silent) {
      setMemoryLoading(true);
      setMemoryError("");
    }

    // 캐시/프록시 영향 최소화
    const url = `/api/chat/memory?chatId=${encodeURIComponent(chatId)}&_ts=${now}`;
    const res = await fetch(url, { cache: "no-store", signal: ac.signal });
    const json = await safeJson(res);
    if (seq !== memoryReqRef.current.seq) return; // 더 최신 요청이 이미 시작됨

    if (!res.ok) throw new Error(json?.error || "요약 불러오기 실패");
    const mem = json?.memory;

    const raw = String(mem?.recentSummary ?? "");
    const s = sanitizeLongMemorySummaryUI(raw).trim();

    // 서버가 아직 요약을 만들지 못했거나 빈 값인 경우:
    // - 기존 요약이 있으면 덮어쓰지 않는다(플리커/사라짐 방지)
    if (!s) {
      if (!memoryLoaded) {
        setMemorySummary("");
        setMemoryDraft("");
        setMemoryChars(0);
        setMemoryLoaded(true);
      }
      return;
    }

    // 정상 요약 반영
    setMemorySummary(s);
    if (!memoryEditMode) setMemoryDraft(s);
    setMemoryEditMode(false);
    const chars = Number(mem?.recentSummaryChars || s.length || 0);
    setMemoryChars(chars);
    setMemoryLoaded(true);

    // sessionStorage 캐시(새로고침 시 즉시 표시)
    try {
      if (memoryCacheKey) sessionStorage.setItem(memoryCacheKey, s);
      if (memoryCharsCacheKey) sessionStorage.setItem(memoryCharsCacheKey, String(chars));
    } catch {}
  } catch (e: any) {
    // Abort는 오류로 취급하지 않음
    const msg = String(e?.message || "");
    if (msg.toLowerCase().includes("aborted")) return;
    if (!silent) setMemoryError(msg || "오류");
    // 기존 요약은 유지(사용자 체감 안정화)
    if (!memoryLoaded) {
      setMemoryLoaded(true);
      setMemorySummary("");
      setMemoryDraft("");
      setMemoryChars(0);
    }
  } finally {
    // 최신 요청만 로딩 해제
    if (!silent && seq === memoryReqRef.current.seq) setMemoryLoading(false);
  }
}



  async function saveMemorySummaryEdit() {
    if (!chatId) return;
    try {
      setMemorySaving(true);
      const res = await fetch(`/api/chat/memory`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chatId, recentSummary: memoryDraft }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "요약 저장 실패");
      const mem = json?.memory;
      const s = String(mem?.recentSummary || memoryDraft || "");
      setMemorySummary(s);
      setMemoryChars(Number(mem?.recentSummaryChars || s.length || 0));
      setMemoryEditMode(false);
      setMemoryLoaded(true);
    } catch (e: any) {
      showToast("설정 저장 실패", (e?.message || "오류"), "error", 3500);
    } finally {
      setMemorySaving(false);
    }
  }

  // chatId 바뀌면: 히스토리 + 설정 로드
  useEffect(() => {
    if (!chatId) return;
    loadHistory(chatId).catch(() => {});
    loadSettings(chatId).catch(() => {});
  }, [chatId]);

  // (요구) 추천답변은 자동 생성하지 않고, 사용자가 버튼을 눌렀을 때만 생성한다.
  const requestSuggestionsOnDemand = useCallback(async () => {
    if (!chatId) return;

    // 스트리밍/전송 중에는 "방금 출력된 문맥"이 완성되지 않아 엉뚱한 추천이 나올 수 있으므로 차단
    if (busy) {
      showToast("추천답변", "답변 생성이 끝난 뒤에 눌러주세요.", "info", 2400);
      return;
    }

    // 1) 방금 스트리밍으로 완성된 텍스트(ref)가 있으면 1순위로 사용
    const refAssistant = String(lastAssistantForSuggestRef.current || "").trim();

    // 2) 없으면, 마지막 완성된 assistant 메시지(temporal/temp 제외)
    let lastAssistant: Msg | null = null;
    for (let i = messages.length - 1; i >= 0; i--) {
      const m = messages[i] as any;
      if (m?.role === "assistant" && !String(m?.id || "").startsWith("temp-")) {
        const c = String(m?.content || "").trim();
        if (c.length > 0) {
          lastAssistant = m as Msg;
          break;
        }
      }
    }

    const assistantContent = (refAssistant || String((lastAssistant as any)?.content || "")).trim();
    if (!assistantContent) {
      showToast("추천답변", "추천을 만들 수 있는 답변이 아직 없어요.", "info", 2400);
      return;
    }

    // 직전 user 메시지 (ref 우선)
    let userContent = String(lastUserForSuggestRef.current || "").trim();
    if (!userContent) {
      for (let i = messages.length - 1; i >= 0; i--) {
        const m = messages[i] as any;
        if (m?.role === "user" && !String(m?.id || "").startsWith("temp-")) {
          userContent = String(m?.content || "").trim();
          if (userContent) break;
        }
      }
    }

    const personaOverride = {
      personaName: (settings?.personaName || selectedProfile?.personaName || "").trim(),
      personaAge: Number(settings?.personaAge || selectedProfile?.personaAge || 0),
      personaGender: String(settings?.personaGender || selectedProfile?.personaGender || "").trim(),
      personaInfo: String(settings?.personaInfo || selectedProfile?.personaInfo || "").trim(),
    };

    // 최근 메시지(요약용) - 상태가 살짝 늦어도 ref 텍스트를 주입해서 최신 문맥을 보장
    const recentMessages = (() => {
      const arr = (Array.isArray(messages) ? messages : [])
        .filter((m: any) => m && (m.role === "user" || m.role === "assistant") && !String(m.id || "").startsWith("temp-"))
        .slice(-18)
        .map((m: any) => ({ role: m.role, content: String(m.content || "").slice(0, 5000) }));
      if (arr.length > 0) {
        const lastIdx = arr.length - 1;
        if (arr[lastIdx].role === "assistant") {
          arr[lastIdx].content = assistantContent;
        }
      }
      return arr;
    })();

    // 새로 만들 때는 기존 추천을 비우고 로딩 표시
    setSuggestions([]);
    setSuggestLoading(true);

    try {
      const res = await fetch("/api/chat/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chatId,
          personaOverride,
          assistantContent,
          userContent,
          recentMessages,
          previousSuggestions: suggestions,
        }),
      });
      const json = await safeJson(res);
      if (!res.ok) throw new Error(json?.error || "추천답변 생성 실패");
      const next = Array.isArray(json?.suggestions) ? json.suggestions : [];
      if (!next || next.length < 2) throw new Error("추천답변이 비어있음");
      setSuggestions(next.slice(0, 2));
    } catch (e: any) {
      console.warn("[ui][suggest][manual] failed", e);
      // 서버/네트워크 실패 시에도 "대사만" 2개는 보이게 한다.
      setSuggestions([
        "…좋아. 그럼 네가 원하는 게 뭔지 똑바로 말해.",
        "한 번만 더 그 말 해봐. 내가 어디까지 참아야 하지?",
      ]);
      showToast("추천답변 생성 실패", String(e?.message || "오류"), "error", 3000);
    } finally {
      setSuggestLoading(false);
    }
  }, [chatId, busy, messages, settings, selectedProfile, safeJson, suggestions]);

const insertNarrationMarkers = useCallback(() => {
    const open = "*";
    const close = "*";
    const el = inputRef.current;

    // textarea ref가 아직 없으면 단순 append
    if (!el) {
      setInput((prev) => String(prev || "") + open + close);
      return;
    }

    const start = typeof el.selectionStart === "number" ? el.selectionStart : input.length;
    const end = typeof el.selectionEnd === "number" ? el.selectionEnd : input.length;
    const selected = input.slice(start, end);

    // 선택 영역이 있으면 감싸고, 없으면 **|** 형태로 삽입
    const next = input.slice(0, start) + open + selected + close + input.slice(end);
    setInput(next);

    requestAnimationFrame(() => {
      try {
        el.focus();
        // 커서를 마커 사이로
        const caret = start + open.length;
        el.setSelectionRange(caret, caret + (selected ? selected.length : 0));
      } catch {}
    });
  }, [input]);


  useEffect(() => {
    scrollToBottomIfAllowed();
  }, [messages.length, scrollToBottomIfAllowed]);

  // (버그픽스) assistant 메시지 내부 지문이 길어지며 DOM 높이가 변해도
  // messages.length가 변하지 않으면 스크롤이 따라가지 못한다.
  // ResizeObserver로 content height 변화를 감지해, 사용자가 바닥을 보고 있을 때만 자동 스크롤한다.
  useEffect(() => {
    const container = scrollRef.current;
    const content = contentRef.current;
    if (!container || !content) return;

    // 초기값 계산
    updateNearBottom();

    const ro = new ResizeObserver(() => {
      if (!nearBottomRef.current) return;
      requestAnimationFrame(() => {
        container.scrollTop = container.scrollHeight;
      });
    });
    ro.observe(content);
    return () => ro.disconnect();
  }, [updateNearBottom]);

  // 프리셋 변경되면: 채팅 컨텍스트 초기화(고정 문제 방지)
  useEffect(() => {
    // 프리셋 바뀌면: 해당 프리셋의 최근 채팅을 자동으로 불러오고(이어하기),
    // 없으면 새로 만들기 상태로 둔다.
    setMessages([]);
    setVisibleCount(0);
    setSettings(null);
    setInput("");
    setSuggestions([]);
    
    if (!presetId) {
      setChatId("");
      setChatList([]);
      return;
    }

    loadChatList(presetId).catch(() => {});

    (async () => {
      try {
        // 작품 탭에서 "새 대화 시작"을 눌러 들어온 경우: 강제 새 채팅
        if (consumeForceNewChatFlag(presetId)) {
          setChatId("");
          // createChat() 내부에서 presetId 확인
          await createChat(true);
          return;
        }
        const res = await fetch(`/api/chat/latest?presetId=${encodeURIComponent(presetId)}`);
        const json = await safeJson(res);
        if (!res.ok) throw new Error(json?.error || "최근 채팅 조회 실패");
        if (json?.chat) {
          setChatId(json.chat.id);
        } else {
          setChatId("");
        }
      } catch {
        setChatId("");
      }
    })();
  }, [presetId, consumeForceNewChatFlag]);

  // 앱 진입 시 전역 페르소나 로드
  useEffect(() => {
    loadProfile().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      style={{
        display: settingsUiMode === "drawer" ? "block" : "grid",
        gridTemplateColumns: settingsUiMode === "drawer" ? "1fr" : (effectiveSettingsOpen ? "360px 1fr" : "0px 1fr"),
        gap: settingsUiMode === "drawer" ? 0 : 16,
        height: "calc(100dvh - 56px)",
        minHeight: "calc(100dvh - 56px)",
        overflow: "hidden",
        transition: "grid-template-columns 180ms ease",
        background: CHAT_THEME.bg,
        color: CHAT_THEME.text,
      }}
>
  {settingsUiMode === "drawer" && effectiveSettingsOpen ? (
    <div
      onClick={() => setUiSettingsOpen(false)}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.45)",
        zIndex: 70,
      }}
    />
  ) : null}

  {toast ? (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: "fixed",
        top: 14,
        right: 14,
        zIndex: 9999,
        maxWidth: 360,
      }}
    >
      <div
        style={{
          background: "rgba(20, 20, 22, 0.88)",
          border: `1px solid ${CHAT_THEME.borderStrong}`,
          boxShadow: "0 18px 60px rgba(0,0,0,0.55)",
          backdropFilter: "blur(10px)",
          borderRadius: 14,
          padding: "12px 12px",
          color: CHAT_THEME.text,
        }}
      >
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}
        >
          <div
            style={{
              width: 10,
              height: 10,
              borderRadius: 999,
              marginTop: 6,
              background:
                toast.variant === "success"
                  ? "rgba(115, 255, 165, 0.85)"
                  : toast.variant === "error"
                    ? "rgba(255, 120, 120, 0.9)"
                    : "rgba(140, 180, 255, 0.85)",
            }}
          />
          <div style={{ flex: 1 }}
          >
            <div style={{ fontSize: 13, fontWeight: 800, marginBottom: toast.message ? 4 : 0 }}
            >
              {toast.title}
            </div>
            {toast.message ? (
              <div style={{ fontSize: 12, opacity: 0.86, lineHeight: 1.4, whiteSpace: "pre-wrap" }}
              >
                {toast.message}
              </div>
            ) : null}
          </div>
          <button
            onClick={() => {
              setToast(null);
            }}
            title="닫기"
            style={{
              border: `1px solid ${CHAT_THEME.borderStrong}`,
              background: "rgba(255,255,255,0.06)",
              color: CHAT_THEME.text,
              borderRadius: 999,
              width: 28,
              height: 28,
              display: "grid",
              placeItems: "center",
              cursor: "pointer",
            }}
          >
            ✕
          </button>
        </div>
      </div>
    </div>
  ) : null}
  {/* LEFT settings (접기/펼치기) */}

      <div
        style={{
          position: settingsUiMode === "drawer" ? ("fixed" as const) : ("relative" as const),
          top: settingsUiMode === "drawer" ? 64 : undefined,
          right: settingsUiMode === "drawer" ? 12 : undefined,
          bottom: settingsUiMode === "drawer" ? 12 : undefined,
          width: settingsUiMode === "drawer" ? 360 : undefined,
          maxWidth: settingsUiMode === "drawer" ? "calc(100vw - 24px)" : undefined,
          zIndex: settingsUiMode === "drawer" ? 80 : undefined,

          border: effectiveSettingsOpen ? `1px solid ${CHAT_THEME.borderStrong}` : "1px solid transparent",
          borderRadius: 16,
          padding: effectiveSettingsOpen ? 14 : 0,
          overflow: effectiveSettingsOpen ? "auto" : "hidden",
          opacity: effectiveSettingsOpen ? 1 : 0,
          transform: effectiveSettingsOpen
            ? "translateX(0)"
            : settingsUiMode === "drawer"
              ? "translateX(10px)"
              : "translateX(-8px)",
          transition: "opacity 160ms ease, transform 160ms ease, padding 160ms ease",
          pointerEvents: effectiveSettingsOpen ? ("auto" as const) : ("none" as const),
          background: settingsUiMode === "drawer" ? "#050505" : "transparent",
          boxShadow: settingsUiMode === "drawer" ? "0 10px 30px rgba(0,0,0,0.45)" : "none",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {settingsUiMode === "drawer" && settingsView !== "home" ? (
              <button
                type="button"
                onClick={() => setSettingsView("home")}
                title="뒤로"
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 12,
                  border: "none",
                  background: CHAT_THEME.iconBg,
                  color: CHAT_THEME.text,
                  cursor: "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <SettingsIcon name="chevronLeft" />
              </button>
            ) : null}

            <div style={{ fontSize: 16, fontWeight: 900 }}>
              {settingsView === "home"
                ? "설정"
                : settingsView === "persona"
                  ? "페르소나 설정"
                  : settingsView === "userNote"
                    ? "유저 노트"
                    : settingsView === "memory"
                      ? "장기기억"
                      : "출력/추론"}
            </div>
          </div>

          {settingsUiMode === "drawer" ? (
            <button
              type="button"
              onClick={() => setUiSettingsOpen(false)}
              title="닫기"
              style={{
                width: 34,
                height: 34,
                borderRadius: 12,
                border: "none",
                background: CHAT_THEME.iconBg,
                color: CHAT_THEME.text,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: 900,
              }}
            >
              ✕
            </button>
          ) : null}
        </div>

        {settingsView === "home" ? (
          <div style={{}}>
            {/* 채팅방 이름(수정 가능) */}
            <div style={{ marginBottom: 10 }}>
              {!editingChatTitle ? (
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        fontSize: 18,
                        fontWeight: 900,
                        lineHeight: 1.2,
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                      title={effectiveChatTitle}
                    >
                      {effectiveChatTitle}
                    </div>
                    <div style={{ fontSize: 12, opacity: 0.6, marginTop: 4 }}>채팅창 이름</div>
                  </div>
                  <button
                    type="button"
                    onClick={beginEditChatTitle}
                    title="이름 수정"
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 12,
                      border: "none",
                      background: CHAT_THEME.iconBg,
                      color: CHAT_THEME.text,
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <SettingsIcon name="pencil" />
                  </button>
                </div>
              ) : (
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <input
                    ref={chatTitleInputRef}
                    value={chatTitleDraft}
                    onChange={(e) => setChatTitleDraft(e.target.value)}
                    placeholder="채팅 이름"
                    style={{
                      flex: 1,
                      padding: 10,
                      borderRadius: 12,
                      border: "none",
                      background: CHAT_THEME.bg,
                      color: CHAT_THEME.text,
                      fontSize: 13,
                    }}
                  />
                  <button
                    type="button"
                    onClick={cancelEditChatTitle}
                    title="취소"
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 12,
                      border: "none",
                      background: CHAT_THEME.iconBg,
                      color: CHAT_THEME.text,
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon name="close" />
                  </button>
                  <button
                    type="button"
                    onClick={saveEditChatTitle}
                    title="저장"
                    style={{
                      width: 36,
                      height: 36,
                      borderRadius: 12,
                      border: `1px solid ${CHAT_THEME.borderStrong}`,
                      background: "#000",
                      color: "#fff",
                      cursor: "pointer",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon name="check" />
                  </button>
                </div>
              )}
            </div>

            <button
              onClick={() => createChat(true)}
              disabled={busy || !presetId}
              style={{
                width: "100%",
                padding: 12,
                borderRadius: 12,
                border: "none",
                background: busy ? "rgba(255,255,255,0.06)" : "#000",
                color: busy ? "rgba(229,231,235,0.45)" : "#fff",
                cursor: "pointer",
                fontWeight: 900,
              }}
            >
              새 대화 시작
            </button>

            <div style={{ height: 12 }} />

            {/* 설정 메뉴 */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {(
                [
                  { k: "persona", label: "페르소나 설정", icon: "persona", sub: "주인공" },
                  { k: "userNote", label: "유저 노트", icon: "note", sub: "메모" },
                  { k: "memory", label: "장기기억", icon: "memory", sub: "요약" },
                  { k: "model", label: "출력/추론", icon: "sliders", sub: "옵션" },
                ] as const
              ).map((it) => (
                <button
                  key={it.k}
                  type="button"
                  disabled={!settings}
                  onClick={() => setSettingsView(it.k as any)}
                  style={{
                    padding: 12,
                    borderRadius: 14,
                    border: "none",
                    background: CHAT_THEME.panel,
                    color: CHAT_THEME.text,
                    cursor: !settings ? "not-allowed" : "pointer",
                    opacity: !settings ? 0.5 : 1,
                    display: "flex",
                    gap: 10,
                    alignItems: "center",
                    textAlign: "left",
                  }}
                >
                  <div
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 12,
                      border: "none",
                      background: CHAT_THEME.iconBg,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flex: "0 0 auto",
                    }}
                  >
                    <SettingsIcon name={it.icon as any} />
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 900, lineHeight: 1.2 }}>{it.label}</div>
                    <div style={{ fontSize: 12, opacity: 0.6, marginTop: 2 }}>{it.sub}</div>
                  </div>
                </button>
              ))}
            </div>

            {/* 이미지 보기 토글 (장기기억 아래) */}
            <div style={{ height: 10 }} />
            <div
              style={{
                width: "100%",
                padding: 12,
                borderRadius: 14,
                border: "none",
                background: CHAT_THEME.panel,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 12,
              }}
            >
              <div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 900, lineHeight: 1.2 }}>이미지 보기</div>
                <div style={{ fontSize: 12, opacity: 0.6, lineHeight: 1.2 }}>
                  OFF 시 이미지/이미지 URL 표기 숨김
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowImages((v) => !v)}
                style={{
                  width: 44,
                  height: 24,
                  borderRadius: 999,
                  border: "none",
                  background: showImages ? "#ef4444" : "rgba(255,255,255,0.12)",
                  position: "relative",
                  cursor: "pointer",
                  flex: "0 0 auto",
                }}
                aria-label="이미지 보기 토글"
              >
                <div
                  style={{
                    width: 18,
                    height: 18,
                    borderRadius: 999,
                    background: "#fff",
                    position: "absolute",
                    top: 2,
                    left: showImages ? 22 : 2,
                    transition: "left 140ms ease",
                  }}
                />
              </button>
            </div>

            {!settings ? (
              <div style={{ fontSize: 12, opacity: 0.65, marginTop: 10 }}>
                채팅을 만든 후 설정을 편집할 수 있어요.
              </div>
            ) : null}
          </div>
        ) : !settings ? (
          <div style={{ fontSize: 13, opacity: 0.7 }}>
            채팅을 만든 후 설정을 편집할 수 있어요.
          </div>
        ) : (
          <div style={{}}>
            
{settingsView === "persona" && (
  <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
      <div style={{ fontSize: 12, opacity: 0.8, lineHeight: 1.4 }}>
        현재 적용: <strong>{settings?.personaName || selectedProfile?.personaName || "(미설정)"}</strong>
        {settings?.personaAge ? ` / ${settings.personaAge}세` : ""}
        {settings?.personaGender ? ` / ${settings.personaGender}` : ""}
      </div>
      {personaApplyMsg ? <div style={{ fontSize: 12, color: CHAT_THEME.muted }}>{personaApplyMsg}</div> : null}
    </div>

    {/* 프로필 선택 + 삭제 */}
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <select
        value={selectedProfileId}
        onChange={(e) => {
          const id = e.target.value;
          setSelectedProfileId(id);
          const p = profiles.find((x) => x.id === id);
          if (p) {
            setProfileDraft({
              id: p.id,
              personaName: p.personaName,
              personaAge: p.personaAge,
              personaGender: p.personaGender || "남",
              personaInfo: p.personaInfo,
            });
          }
        }}
        style={{
          flex: 1,
          padding: 10,
          borderRadius: 12,
          border: "none",
          background: CHAT_THEME.bg,
          color: CHAT_THEME.text,
        }}
      >
        {profiles.length === 0 ? <option value="">(프로필 없음)</option> : null}
        {profiles.map((p) => (
          <option key={p.id} value={p.id}>
            {p.personaName}
          </option>
        ))}
      </select>

      <button
        type="button"
        title="프로필 삭제"
        onClick={() => {
          if (!profileDraft.id) return;
          openConfirm({
            title: "프로필 삭제",
            desc: "이 프로필을 삭제할까요? 삭제 후에는 복구할 수 없습니다.",
            confirmText: "삭제",
            danger: true,
            action: "deleteProfile",
            profileId: profileDraft.id,
          });
        }}
        disabled={!profileDraft.id}
        style={{
          width: 40,
          height: 40,
          borderRadius: 12,
          border: "none",
          background: CHAT_THEME.iconBg,
          color: CHAT_THEME.text,
          cursor: !profileDraft.id ? "not-allowed" : "pointer",
          opacity: !profileDraft.id ? 0.35 : 1,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon name="trash" />
      </button>
    </div>

    {/* 편집 */}
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
      <div style={{ gridColumn: "1 / -1" }}>
        <div style={{ fontSize: 12, fontWeight: 800 }}>이름</div>
        <input
          value={profileDraft.personaName}
          onChange={(e) => setProfileDraft((p) => ({ ...p, personaName: e.target.value }))}
          placeholder="프로필 이름"
          style={{
            width: "100%",
            padding: 10,
            borderRadius: 12,
            border: "none",
            background: CHAT_THEME.bg,
            color: CHAT_THEME.text,
          }}
        />
      </div>

      <div>
        <div style={{ fontSize: 12, fontWeight: 800 }}>나이</div>
        <input
          value={String(profileDraft.personaAge || 0)}
          onChange={(e) => setProfileDraft((p) => ({ ...p, personaAge: Number(e.target.value || 0) }))}
          style={{
            width: "100%",
            padding: 10,
            borderRadius: 12,
            border: "none",
            background: CHAT_THEME.bg,
            color: CHAT_THEME.text,
          }}
        />
      </div>

      <div>
        <div style={{ fontSize: 12, fontWeight: 800 }}>성별</div>
        <select
          value={profileDraft.personaGender || "남"}
          onChange={(e) => setProfileDraft((p) => ({ ...p, personaGender: e.target.value }))}
          style={{
            width: "100%",
            padding: 10,
            borderRadius: 12,
            border: "none",
            background: CHAT_THEME.bg,
            color: CHAT_THEME.text,
          }}
        >
          <option value="남">남</option>
          <option value="여">여</option>
        </select>
      </div>
    </div>

    <div>
      <div style={{ fontSize: 12, fontWeight: 800 }}>상세</div>
      <textarea
        value={profileDraft.personaInfo}
        onChange={(e) => setProfileDraft((p) => ({ ...p, personaInfo: e.target.value }))}
        placeholder="(선택) 배경/성격/말투 등"
        style={{
          width: "100%",
          minHeight: 160,
          padding: 10,
          borderRadius: 12,
          border: "none",
          background: CHAT_THEME.bg,
          color: CHAT_THEME.text,
          lineHeight: 1.6,
          whiteSpace: "pre-wrap",
          resize: "vertical",
          outline: "none",
        }}
      />
    </div>

    {/* 저장 & 적용: (1) 프로필 저장/신규 생성 (2) 채팅 설정 즉시 저장/반영 (3) 닫기 */}
    <button
      type="button"
      disabled={!chatId || saving}
      onClick={async () => {
        if (!chatId || !settings) return;
        const name = (profileDraft.personaName || "").trim();
        if (!name) {
          showToast("이름이 필요합니다", "프로필 이름을 입력해 주세요.", "error");
          return;
        }

        // 이름을 바꾸면 '신규 프로필'로 저장되도록: (선택된 프로필과 이름이 다르면 id 제거)
        const selected = profiles.find((x) => String(x.id) === String(selectedProfileId));
        const shouldCreateNew = !!profileDraft.id && !!selected && name !== String(selected.personaName || "").trim();
        const savePayload = {
          ...(shouldCreateNew ? {} : { id: profileDraft.id }),
          personaName: name,
          personaAge: Number(profileDraft.personaAge || 0),
          personaGender: (profileDraft.personaGender || "남") as any,
          personaInfo: String(profileDraft.personaInfo || ""),
        };

        setSaving(true);
        try {
          // 1) 프로필 저장/생성
          await saveProfile(savePayload as any);

          // 2) 채팅에 즉시 적용 + 저장(조용히)
          const partial = {
            personaName: savePayload.personaName,
            personaAge: savePayload.personaAge,
            personaGender: savePayload.personaGender,
            personaInfo: savePayload.personaInfo,
          } as Partial<Settings>;
          setSettings((s) => (s ? ({ ...s, ...partial } as any) : s));
          await saveSettingsSilent(partial);

          // 3) 닫기
          setPersonaApplyMsg("");
          setUiSettingsOpen(false);
          setSettingsView("home");
        } catch (e: any) {
          showToast("저장 실패", (e?.message || "오류"), "error", 3500);
        } finally {
          setSaving(false);
        }
      }}
      style={{
        width: "100%",
        padding: 12,
        borderRadius: 12,
        border: "none",
        background: CHAT_THEME.accent,
        color: "#fff",
        cursor: "pointer",
        fontWeight: 900,
        opacity: saving ? 0.7 : 1,
      }}
    >
      {saving ? "저장 중..." : "저장 & 적용"}
    </button>
  </div>
)}

{settingsView === "userNote" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                <textarea
                  value={settings.userNote}
                  onChange={(e) => setSettings({ ...settings, userNote: e.target.value })}
                  style={{ width: "100%", padding: 10, borderRadius: 12, border: "none", minHeight: 140, background: CHAT_THEME.bg, color: CHAT_THEME.text, fontSize: 12, resize: "vertical" }}
                  placeholder="AI가 답변 생성 시 참조할 노트"
                />
                <button
                  onClick={saveSettings}
                  disabled={saving}
                  type="button"
                  style={{ width: "100%", padding: 12, borderRadius: 12, border: `1px solid ${CHAT_THEME.borderStrong}`, background: "#000", color: "#fff", cursor: "pointer", fontWeight: 900, opacity: saving ? 0.6 : 1 }}
                >
                  {saving ? "저장 중..." : "유저노트 저장"}
                </button>
              </div>
            )}

            
{settingsView === "memory" && (
  <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
    <div style={{ fontSize: 12, opacity: 0.75, lineHeight: 1.4 }}>
      * 요약 주기/턴당 글자 설정은 서버에서 Rolling Summary로 반영됩니다.
    </div>

    <div>
  <div style={{ fontSize: 12, fontWeight: 700 }}>요약 주기(3~12)</div>
  <input
    type="range"
    min={3}
    max={12}
    step={1}
    value={Number(settings.summaryEvery ?? 5) || 5}
    onChange={(e) => setSettings({ ...settings, summaryEvery: Number(e.target.value || 5) })}
    style={{ width: "100%", accentColor: CHAT_THEME.name }}
  />
  <div style={{ fontSize: 12, opacity: 0.7 }}>현재: {Number(settings.summaryEvery ?? 5) || 5}턴</div>
</div>

<div>
  <div style={{ fontSize: 12, fontWeight: 700 }}>턴당 글자(10~200, 10단위)</div>
  <input
    type="range"
    min={10}
    max={200}
    step={10}
    value={Math.max(10, Math.min(200, Math.round((Number(settings.summaryLength ?? 50) || 50) / 10) * 10))}
    onChange={(e) => {
      const v = Number(e.target.value || 50);
      const snapped = Math.max(10, Math.min(200, Math.round(v / 10) * 10));
      setSettings({ ...settings, summaryLength: snapped });
    }}
    style={{ width: "100%", accentColor: CHAT_THEME.name }}
  />
  <div style={{ fontSize: 12, opacity: 0.7 }}>현재: {Math.max(10, Math.min(200, Math.round((Number(settings.summaryLength ?? 50) || 50) / 10) * 10))}자</div>
</div>

    <div>
      <div style={{ fontSize: 12, fontWeight: 700 }}>요약/기억 안내 (프롬프트에 포함)</div>
      <textarea
        value={settings.longMemoryGuidance || ""}
        onChange={(e) => setSettings({ ...settings, longMemoryGuidance: e.target.value })}
        placeholder={"예) 장기요약은 사실관계/관계/사건만 요약해라. 감정/추측은 배제."}
        style={{
          width: "100%",
          minHeight: 110,
          padding: 10,
          borderRadius: 12,
          border: "none",
          background: CHAT_THEME.bg,
          color: CHAT_THEME.text,
          outline: "none",
          resize: "vertical",
          lineHeight: 1.6,
        }}
      />
    </div>

    {/* 최근 요약: 모달이 아니라 이 화면 안에서 바로 보기/편집 */}
    <div
      style={{
        border: `1px solid ${CHAT_THEME.borderStrong}`,
        borderRadius: 14,
        background: CHAT_THEME.panel,
        padding: 12,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ fontSize: 13, fontWeight: 900 }}>최근 요약</div>
        <div style={{ marginLeft: "auto", fontSize: 12, opacity: 0.7 }}>
          {memoryLoading ? "불러오는 중..." : memoryError ? "불러오기 실패" : memoryLoaded ? `${memoryChars}자` : ""}
        </div>
      </div>

      {memoryError ? (
        <div style={{ marginTop: 10 }}>
          <div style={{ fontSize: 13, opacity: 0.85, lineHeight: 1.5 }}>{memoryError}</div>
          <div style={{ height: 10 }} />
          <button
            onClick={() => void openMemorySummary({ force: true, reason: "retry" })}
            style={{
              height: 38,
              padding: "0 14px",
              borderRadius: 12,
              border: `1px solid ${CHAT_THEME.borderStrong}`,
              background: CHAT_THEME.panel2,
              color: CHAT_THEME.text,
              fontWeight: 800,
              cursor: "pointer",
            }}
          >
            다시 시도
          </button>
        </div>
      ) : !memoryEditMode ? (
        <div style={{ marginTop: 10, whiteSpace: "pre-wrap", fontSize: 13, lineHeight: 1.6 }}>
          {memorySummary || (memoryLoading ? "불러오는 중..." : "(요약이 없습니다.)")}
        </div>
      ) : (
        <textarea
          value={memoryDraft}
          onChange={(e) => setMemoryDraft(e.target.value)}
          style={{
            width: "100%",
            minHeight: 240,
            marginTop: 10,
            padding: 12,
            borderRadius: 12,
            border: `1px solid ${CHAT_THEME.borderStrong}`,
            background: CHAT_THEME.panel2,
            color: CHAT_THEME.text,
            fontSize: 13,
            lineHeight: 1.6,
            whiteSpace: "pre-wrap",
            resize: "vertical",
            outline: "none",
          }}
        />
      )}

      {memoryLoaded ? (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, marginTop: 12 }}>
          {!memoryEditMode ? (
            <button
              type="button"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(String(memorySummary || ""));
                } catch {
                  try {
                    const ta = document.createElement("textarea");
                    ta.value = String(memorySummary || "");
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand("copy");
                    document.body.removeChild(ta);
                  } catch {}
                }
              }}
              style={{
                padding: "8px 10px",
                borderRadius: 12,
                border: `1px solid ${CHAT_THEME.borderStrong}`,
                background: CHAT_THEME.iconBg,
                color: CHAT_THEME.text,
                cursor: "pointer",
                fontWeight: 900,
              }}
            >
              복사
            </button>
          ) : (
            <span />
          )}

          {!memoryEditMode ? (
            <button
              type="button"
              onClick={() => {
                setMemoryDraft(memorySummary || "");
                setMemoryEditMode(true);
              }}
              style={{
                padding: "8px 10px",
                borderRadius: 12,
                border: `1px solid ${CHAT_THEME.borderStrong}`,
                background: CHAT_THEME.panel2,
                color: CHAT_THEME.text,
                cursor: "pointer",
                fontWeight: 900,
              }}
            >
              편집
            </button>
          ) : (
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button
                type="button"
                onClick={() => {
                  setMemoryDraft(memorySummary || "");
                  setMemoryEditMode(false);
                }}
                disabled={memorySaving}
                style={{
                  padding: "8px 10px",
                  borderRadius: 12,
                  border: `1px solid ${CHAT_THEME.borderStrong}`,
                  background: CHAT_THEME.panel2,
                  color: CHAT_THEME.text,
                  cursor: "pointer",
                  fontWeight: 900,
                  opacity: memorySaving ? 0.6 : 1,
                }}
              >
                취소
              </button>
              <button
                type="button"
                onClick={saveMemorySummaryEdit}
                disabled={memorySaving}
                style={{
                  padding: "8px 10px",
                  borderRadius: 12,
                  border: "none",
                  background: CHAT_THEME.accent,
                  color: "#fff",
                  cursor: "pointer",
                  fontWeight: 900,
                  opacity: memorySaving ? 0.6 : 1,
                }}
              >
                저장
              </button>
            </div>
          )}
        </div>
      ) : null}
    </div>

    <button
      onClick={saveSettings}
      disabled={saving}
      type="button"
      style={{ width: "100%", padding: 12, borderRadius: 12, border: `1px solid ${CHAT_THEME.borderStrong}`, background: "#000", color: "#fff", cursor: "pointer", fontWeight: 900, opacity: saving ? 0.6 : 1 }}
    >
      {saving ? "저장 중..." : "장기기억 설정 저장"}
    </button>
  </div>
)}

{settingsView === "model" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 700 }}>출력길이</div>

                  {(() => {
                    // 서버(route.ts)는 settings.maxOutputTokens 값을 "목표 글자수"(targetChars)로 해석합니다.
                    // 따라서 UI도 토큰이 아닌 "글자수 프리셋"으로 노출합니다.
                    // (요구) 1200/1700/2500자 프리셋
                    const presets: Record<ReasoningLevel, number> = { low: 1200, middle: 1700, high: 2500 };
                    const v = Number(settings.maxOutputTokens || presets.high);
                    const level: ReasoningLevel = v <= (presets.low + presets.middle) / 2 ? "low" : v <= (presets.middle + presets.high) / 2 ? "middle" : "high";
                    const btnStyle = (active: boolean): React.CSSProperties => ({
                      flex: 1,
                      padding: "10px 0",
                      borderRadius: 12,
                      border: `1px solid ${active ? CHAT_THEME.accent : CHAT_THEME.borderStrong}`,
                      background: active ? "rgba(255,255,255,0.06)" : CHAT_THEME.panel2,
                      color: CHAT_THEME.text,
                      cursor: "pointer",
                      fontWeight: 900,
                    });
                    const label: Record<ReasoningLevel, string> = { low: "1200자", middle: "1700자", high: "2500자" };
                    return (
                      <>
                        <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                          {(Object.keys(presets) as ReasoningLevel[]).map((k) => (
                            <button
                              key={k}
                              type="button"
                              onClick={() => setSettings({ ...settings, maxOutputTokens: presets[k] })}
                              style={btnStyle(level === k)}
                            >
                              {label[k]}
                            </button>
                          ))}
                        </div>
                        <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
                          현재: {label[level]} (목표 {presets[level]}자)
                        </div>
                      </>
                    );
                  })()}
                </div>

                <div>
                  <div style={{ fontSize: 12, fontWeight: 700 }}>추론길이</div>

                  {(() => {
                    const presets = getReasoningPresets(settings.model);
                    const level = inferReasoningLevel(settings.model, Number(settings.maxReasoningTokens));
                    const btnStyle = (active: boolean): React.CSSProperties => ({
                      flex: 1,
                      padding: "10px 0",
                      borderRadius: 12,
                      border: `1px solid ${active ? CHAT_THEME.accent : CHAT_THEME.borderStrong}`,
                      background: active ? "rgba(255,255,255,0.06)" : CHAT_THEME.panel2,
                      color: CHAT_THEME.text,
                      cursor: "pointer",
                      fontWeight: 900,
                    });
                    const label: Record<ReasoningLevel, string> = { low: "low", middle: "middle", high: "high" };
                    return (
                      <>
                        <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                          {(Object.keys(presets) as ReasoningLevel[]).map((k) => (
                            <button
                              key={k}
                              type="button"
                              onClick={() => setSettings({ ...settings, maxReasoningTokens: presets[k] })}
                              style={btnStyle(level === k)}
                            >
                              {label[k]}
                            </button>
                          ))}
                        </div>
                        <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
                          현재: {label[level]} ({presets[level]} tokens)
                        </div>
                      </>
                    );
                  })()}
                </div>

                <button
                  onClick={saveSettings}
                  disabled={!chatId || saving}
                  type="button"
                  style={{ width: "100%", padding: 12, borderRadius: 12, border: `1px solid ${CHAT_THEME.borderStrong}`, background: "#000", color: "#fff", cursor: "pointer", fontWeight: 900, opacity: saving ? 0.6 : 1 }}
                >
                  {saving ? "저장 중..." : "출력/추론 저장"}
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* RIGHT chat */}
      {/* 메인 채팅 영역: 테두리/카드 제거(영상처럼 자연스럽게) */}
      <div style={{ border: "none", background: "transparent", borderRadius: 16, padding: 0, overflow: "hidden", color: CHAT_THEME.text, display: "flex", flexDirection: "column", height: "100vh", minHeight: 0 }}>
        <div
          ref={scrollRef}
          onScroll={updateNearBottom}
          className="chatScroll"
		      	  style={{
		      	    // 채팅 로그 영역은 뷰포트의 2/3 지점(66vh)까지만 차지하고,
		      	    // 그 안에서만 스크롤되도록 분리한다.
		      	    // NOTE: flex: 0 (grow만 0) 이면 shrink/basis 영향으로 스크롤이 깨질 수 있어
		      	    //       안전하게 shorthand를 고정한다.
		      	    flex: "0 0 auto" as any,
            height: "66vh",
            maxHeight: "66vh",
            minHeight: 0,
            overflowY: "auto",
            border: "none",
            borderRadius: 0,
            padding: "4px 0",
            background: "transparent",
            width: "100vw",
            marginLeft: "calc(50% - 50vw)",
            display: "flex",
            justifyContent: "center",
            // 하단 고정 입력창 높이만큼 스크롤 패딩을 줘서 마지막 줄이 가려지지 않게 한다.
	            // scrollPaddingBottom만으로는 레이아웃/폰트 변경 시 마지막 줄이 다시 겹치는 경우가 있어
	            // 실제 paddingBottom도 동일하게 적용해 '상한선'을 강제한다.
	            scrollPaddingBottom: bottomInset,
	            paddingBottom: bottomInset,
            scrollbarWidth: "thin",
            scrollbarColor: "rgba(255,255,255,0.12) transparent",
          }}
        >
          <div
            ref={contentRef}
            style={{
              width: "100%",
              maxWidth: CHAT_COLUMN_MAX,
              padding: "0 14px",
              // 하단 고정 입력창과 절대 겹치지 않도록 입력창 높이 기반으로 하단 여백을 확보
              paddingBottom: bottomInset,
              boxSizing: "border-box",
            }}
          >
            <MessageList
  messagesLength={messages.length}
  visibleMessages={visibleMessages}
  modelName={settings?.model || ""}
  hiddenMessageCount={hiddenMessageCount}
  expandOlderMessages={expandOlderMessages}
  userName={userName}
  npcName={npcName}
  theme={CHAT_THEME as ChatTheme}
  iconButtonStyle={iconButtonStyle}
  MessageContent={MessageContent}
	  // 프리버퍼 UI: 스트리밍 초반 2초 동안 임시 assistant 말풍선(대사 옆)에 "✨ N초 동안 생각 중..." 표시
	  // - 실제 글자(공백 제외) 1자라도 출력되면 즉시 사라진다.
	  prebufferUiActive={prebufferUiActive}
	  prebufferSec={prebufferSec}
	  prebufferDots={prebufferDots}
	  streamTempAssistantId={streamTempAssistantIdRef.current}
		  stallUiActive={stallUiActive}
		  streamTargetId={streamTempAssistantIdRef.current}
  editingAssistantId={editingAssistantId}
  editingUserId={editingUserId}
  assistantDraft={assistantDraft}
  userDraft={userDraft}
  onChangeAssistantDraft={onChangeAssistantDraft}
  onChangeUserDraft={onChangeUserDraft}
  onRegenerateFromAssistant={regenerateFromUser}
  onRequestDeleteMessage={requestDeleteMessage}
  onStartAssistantEdit={startAssistantEdit}
  onStartUserEdit={startUserEdit}
  onOpenTokenInfo={openTokenInfo}
  onCancelAssistantEdit={cancelAssistantEdit}
  onSaveAssistantEdit={saveAssistantEdit}
  onCancelUserEdit={cancelUserEdit}
  onSaveUserEdit={saveUserEdit}
  bottomRef={bottomRef}
/>
          </div>
        </div>
        {/* 토큰 팝업 (UI 톤 통일) */}
        
        {/* 공통 확인 모달 (새 대화 시작 / 채팅 삭제 / 프로필 삭제) */}
        {confirmModal.open && (
          <div
            onClick={() => setConfirmModal((p) => ({ ...p, open: false }))}
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 95,
              background: "rgba(0,0,0,0.45)",
              backdropFilter: "blur(4px)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: 12,
            }}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                width: "min(520px, calc(100vw - 24px))",
                border: `1px solid ${CHAT_THEME.borderStrong}`,
                borderRadius: 20,
                padding: 16,
                background: "linear-gradient(180deg, rgba(18,18,22,0.98), rgba(10,10,12,0.92))",
                color: CHAT_THEME.text,
                boxShadow: "0 22px 70px rgba(0,0,0,0.65)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 12,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      background: confirmModal.danger ? "rgba(255,90,90,0.14)" : "rgba(255,255,255,0.10)",
                      border: `1px solid ${confirmModal.danger ? "rgba(255,90,90,0.35)" : CHAT_THEME.border}`,
                      color: confirmModal.danger ? "#ff8a8a" : CHAT_THEME.text,
                    }}
                  >
                    <Icon name={confirmModal.danger ? "trash" : "info"} size={18} />
                  </div>
                  <div style={{ fontWeight: 900, fontSize: 14 }}>{confirmModal.title}</div>
                </div>

                <button
                  type="button"
                  onClick={() => setConfirmModal((p) => ({ ...p, open: false }))}
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 12,
                    border: "none",
                    background: "rgba(255,255,255,0.06)",
                    color: CHAT_THEME.text,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Icon name="close" size={18} />
                </button>
              </div>

              <div style={{ marginTop: 10, fontSize: 13, lineHeight: 1.6, opacity: 0.85, whiteSpace: "pre-wrap" }}>
                {confirmModal.desc}
              </div>

              <div style={{ marginTop: 14, display: "flex", gap: 10, justifyContent: "flex-end" }}>
                <button
                  type="button"
                  onClick={() => setConfirmModal((p) => ({ ...p, open: false }))}
                  style={{
                    border: "none",
                    background: "rgba(255,255,255,0.06)",
                    color: CHAT_THEME.text,
                    borderRadius: 14,
                    padding: "10px 14px",
                    fontWeight: 900,
                    cursor: "pointer",
                  }}
                >
                  취소
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    const action = confirmModal.action;
                    const profileId = confirmModal.profileId;
                    setConfirmModal((p) => ({ ...p, open: false }));
                    // NOTE: 기존 기능 로직 유지 (UI에서만 확인 모달 처리)
                    if (action === "newChat") {
                      await createChat(true, true);
                    } else if (action === "deleteChat") {
                      await deleteChatAndExit(true);
                    } else if (action === "deleteProfile") {
                      if (!profileId) return;
                      try {
                        await deleteProfile(profileId);
                        setProfileDraft({ personaName: "", personaAge: 0, personaGender: "남", personaInfo: "" });
                        setSelectedProfileId("");
                        setPersonaApplyMsg("프로필 삭제 완료");
                        window.setTimeout(() => setPersonaApplyMsg(""), 2000);
                      } catch (e: any) {
                        alert(e?.message || "오류");
                      }
                    }
                  }}
                  style={{
                    border: `1px solid ${confirmModal.danger ? "rgba(255,90,90,0.55)" : CHAT_THEME.borderStrong}`,
                    background: confirmModal.danger ? "rgba(255,90,90,0.16)" : `rgba(93, 154, 255, 0.18)`,
                    color: CHAT_THEME.text,
                    borderRadius: 14,
                    padding: "10px 14px",
                    fontWeight: 900,
                    cursor: "pointer",
                  }}
                >
                  {confirmModal.confirmText}
                </button>
              </div>
            </div>
          </div>
        )}

{tokenPopup.open && (
          <div
            onClick={() => {
              setTokenPopup((p) => ({ ...p, open: false }));
              setTokenPopupAnchor(null);
            }}
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 120,
              background: "rgba(0,0,0,0.45)",
              backdropFilter: "blur(4px)",
              display: "flex",
              justifyContent: "center",
              alignItems: "flex-start",
              padding: "18px 12px",
            }}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                width: "min(560px, calc(100vw - 24px))",
                position: "fixed",
                left: tokenPopupAnchor
                  ? `clamp(12px, ${tokenPopupAnchor.left + tokenPopupAnchor.width / 2}px, calc(100vw - 12px))`
                  : "50%",
                top: tokenPopupAnchor
                  ? tokenPopupAnchor.top < 180
                    ? `clamp(12px, ${tokenPopupAnchor.bottom + 10}px, calc(100vh - 12px))`
                    : `clamp(12px, ${tokenPopupAnchor.top - 10}px, calc(100vh - 12px))`
                  : "50%",
                transform: tokenPopupAnchor
                  ? tokenPopupAnchor.top < 180
                    ? "translate(-50%, 0)"
                    : "translate(-50%, -100%)"
                  : "translate(-50%, -50%)",
                maxHeight: "82vh",
                overflowY: "auto",
                border: `1px solid ${CHAT_THEME.borderStrong}`,
                borderRadius: 16,
                padding: 14,
                background: "rgba(12,12,14,0.92)",
                color: CHAT_THEME.text,
                boxShadow: "0 18px 50px rgba(0,0,0,0.60)",
                fontSize: 12,
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 12,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      background: "rgba(255,255,255,0.10)",
                      border: "none",
                      color: CHAT_THEME.text,
                    }}
                  >
                    <Icon name="info" size={18} />
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                    <div style={{ fontWeight: 900, fontSize: 14 }}>{tokenPopup.title}</div>

{!tokenPopup.usage && (
  <div style={{ marginTop: 8, fontSize: 12, opacity: 0.75, lineHeight: 1.4 }}>
    이 메시지에는 사용량 메타데이터가 저장되어 있지 않습니다. (보통 유저 메시지이거나, 응답 저장 중 오류가 있었던 경우입니다.)
  </div>
)}
                    <div style={{ fontSize: 12, opacity: 0.65 }}>사용량/비용 메타데이터</div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setTokenPopup((p) => ({ ...p, open: false }));
                    setTokenPopupAnchor(null);
                  }}
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 12,
                    border: "none",
                    background: "rgba(255,255,255,0.06)",
                    color: CHAT_THEME.text,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Icon name="close" size={18} />
                </button>
              </div>

              <div style={{ height: 12 }} />

              {(() => {
                // (A) 이번 응답 비용
                const totalTokens = Number(tokenPopup.usage?.totalTokens);
                const model = (tokenPopup.usage?.model as string | undefined) ?? settings?.model;

                const hasUsage = Number.isFinite(totalTokens) && totalTokens > 0;
                const fee = hasUsage ? calcFriendFee(totalTokens, model) : NaN;
                const feeUi = hasUsage ? roundFriendFeeUi(fee) : NaN;
                const krwUi = hasUsage ? formatKrwUi(fee * KRW_PER_FRIENDFEE) : "";

                // (B) 이 채팅 누적 비용
                const sum = (() => {
                  let tokens = 0;
                  let feeRaw = 0;
                  for (const m of messages) {
                    if (m.role !== "assistant") continue;
                    const t = Number(m.usage?.totalTokens);
                    if (!Number.isFinite(t) || t <= 0) continue;
                    const mm = (m.usage?.model as string | undefined) ?? settings?.model;
                    tokens += t;
                    feeRaw += calcFriendFee(t, mm);
                  }
                  return { feeRaw };
                })();
                const sumFeeUi = roundFriendFeeUi(sum.feeRaw);
                const sumKrwUi = formatKrwUi(sum.feeRaw * KRW_PER_FRIENDFEE);

                return (
                  <>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span style={{ opacity: 0.7, fontWeight: 900 }}>이번 응답 비용</span>
                      <strong>
                        {hasUsage ? `${feeUi.toLocaleString()} 친구비 · ${krwUi}` : "계산 중…"}
                      </strong>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                      <span style={{ opacity: 0.7, fontWeight: 900 }}>이 채팅 누적</span>
                      <strong>
                        {`${sumFeeUi.toLocaleString()} 친구비 · ${sumKrwUi}`}
                      </strong>
                    </div>
                    <div style={{ height: 10 }} />
                    <div style={{ height: 1, background: "rgba(255,255,255,0.10)" }} />
                    <div style={{ height: 10 }} />
                  </>
                );
              })()}

              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.7 }}>입력 토큰(실측)</span>
                <strong>{tokenPopup.usage ? tokenPopup.usage.promptTokens ?? 0 : "—"}</strong>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.7 }}>출력 토큰(실측)</span>
                <strong>{tokenPopup.usage ? tokenPopup.usage.outputTokens ?? 0 : "—"}</strong>
              </div>
              {Number(tokenPopup.usage?.reasoningTokens ?? 0) > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ opacity: 0.7 }}>추론 토큰(실측)</span>
                  <strong>{tokenPopup.usage?.reasoningTokens ?? 0}</strong>
                </div>
              )}
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ opacity: 0.7 }}>총 토큰(실측)</span>
                <strong>{tokenPopup.usage ? tokenPopup.usage.totalTokens ?? 0 : "—"}</strong>
              </div>
              {tokenPopup.usage?.finishReason && (
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ opacity: 0.7 }}>종료 사유(finishReason)</span>
                  <strong>{String(tokenPopup.usage.finishReason)}</strong>
                </div>
              )}

              {Array.isArray(tokenPopup.usage?.debugReasons) && tokenPopup.usage.debugReasons.length > 0 && (
                <div style={{ marginTop: 8, opacity: 0.85, lineHeight: 1.5 }}>
                  <div style={{ fontWeight: 900, marginBottom: 4 }}>중단/트림 원인(서버 진단)</div>
                  <div>{tokenPopup.usage.debugReasons.join(" · ")}</div>
                </div>
              )}

              {tokenPopup.usage?.tokenBreakdown && (
                <>
                  <div style={{ height: 12 }} />
                  <div style={{ fontWeight: 900, marginBottom: 6 }}>입력 토큰 구성(실측 입력토큰 배분)</div>
                  {(() => {
                    const promptMeasured = Number(tokenPopup.usage?.promptTokens ?? 0) || 0;
                    const breakdown = tokenPopup.usage!.tokenBreakdown!;
                    const order = [
                      "presetPrompt",
                      "lorebookPrompt",
                      "persona",
                      "userNote",
                      "longMemorySummary",
                      "recentTurns",
                      "userInput",
                      "systemAndRules",
                    ];
                    const entries = Object.entries(breakdown);
                    entries.sort((a, b) => {
                      const ia = order.indexOf(a[0]);
                      const ib = order.indexOf(b[0]);
                      return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib);
                    });
                    return entries.map(([k, v]) => {
                      const n = Number(v) || 0;
                      const pct = promptMeasured > 0 ? Math.round((n / promptMeasured) * 100) : 0;
                      return (
                        <div key={k} style={{ display: "flex", justifyContent: "space-between", gap: 10 }}>
                          <span style={{ opacity: 0.75 }}>
                            {labelTokenKey(k)}
                            {promptMeasured > 0 && (
                              <span style={{ opacity: 0.55, marginLeft: 8 }}>{pct}%</span>
                            )}
                          </span>
                          <strong>{n}</strong>
                        </div>
                      );
                    });
                  })()}
                  <div style={{ height: 8 }} />
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ opacity: 0.75 }}>추정 합계(출력/추론 실측 + 입력 배분)</span>
                    <strong>
                      {(
                        Number(tokenPopup.usage.outputTokens ?? 0) +
                        Number(tokenPopup.usage.reasoningTokens ?? 0) +
                        Number(tokenPopup.usage.estPromptTotal ?? 0)
                      )}
                    </strong>
                  </div>
                  {typeof tokenPopup.usage?.estimatedCostKrw === "number" && tokenPopup.usage.estimatedCostKrw > 0 && (
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ opacity: 0.75 }}>예상 비용(실측 prompt/output 기준)</span>
                      <strong>₩{Math.round(tokenPopup.usage.estimatedCostKrw).toLocaleString("ko-KR")}</strong>
                    </div>
                  )}
                  <div style={{ marginTop: 8, opacity: 0.6 }}>* 각 항목은 입력 토큰(실측)을 구성요소별로 배분한 값입니다.</div>
                </>
              )}
            </div>
          </div>
        )}

        {/* 삭제 확인 팝업 (UI 톤 통일) */}
        {deletePopup.open && (
          <div
            onClick={() => setDeletePopup({ open: false, messageId: "" })}
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 120,
              background: "rgba(0,0,0,0.45)",
              backdropFilter: "blur(4px)",
              display: "flex",
              justifyContent: "center",
              alignItems: "flex-start",
              padding: "18px 12px",
            }}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                width: "min(560px, calc(100vw - 24px))",
                border: `1px solid ${CHAT_THEME.borderStrong}`,
                borderRadius: 20,
                padding: 16,
                background: "linear-gradient(180deg, rgba(18,18,22,0.98), rgba(10,10,12,0.92))",
                color: CHAT_THEME.text,
                boxShadow: "0 22px 70px rgba(0,0,0,0.65)",
                fontSize: 12,
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 12,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      background: "rgba(255,90,90,0.14)",
                      border: `1px solid rgba(255,90,90,0.35)`,
                      color: "#ff8a8a",
                    }}
                  >
                    <Icon name="trash" size={18} />
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                    <div style={{ fontWeight: 900, fontSize: 15 }}>메시지 삭제</div>
                    <div style={{ fontSize: 12, opacity: 0.65 }}>삭제 후에는 복구할 수 없습니다</div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setDeletePopup({ open: false, messageId: "" })}
                  style={{
                    width: 34,
                    height: 34,
                    borderRadius: 12,
                    border: "none",
                    background: "rgba(255,255,255,0.06)",
                    color: CHAT_THEME.text,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                  }}
                >
                  <Icon name="close" size={18} />
                </button>
              </div>

              <div
                style={{
                  marginTop: 12,
                  padding: "12px 12px",
                  borderRadius: 16,
                  border: "none",
                  background: "rgba(255,255,255,0.06)",
                  opacity: 0.9,
                  lineHeight: 1.6,
                  fontSize: 13,
                  whiteSpace: "pre-wrap",
                }}
              >
                이 메시지를 삭제할까요?
삭제하면 복구할 수 없습니다.
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 14 }}>
                <button
                  type="button"
                  onClick={() => setDeletePopup({ open: false, messageId: "" })}
                  style={{
                    border: "none",
                    background: "rgba(255,255,255,0.06)",
                    cursor: "pointer",
                    fontSize: 12,
                    color: CHAT_THEME.text,
                    borderRadius: 12,
                    padding: "10px 14px",
                    fontWeight: 900,
                  }}
                >
                  취소
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const id = deletePopup.messageId;
                    setDeletePopup({ open: false, messageId: "" });
                    if (id) await onDeleteMessageConfirmed(id);
                  }}
                  style={{
                    border: `1px solid ${CHAT_THEME.borderStrong}`,
                    background: "rgba(255,60,60,0.20)",
                    cursor: "pointer",
                    fontSize: 12,
                    color: CHAT_THEME.text,
                    borderRadius: 12,
                    padding: "10px 14px",
                    fontWeight: 900,
                  }}
                >
                  삭제
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 입력창 내부에 '추천 답변(2개)'을 노출 + 전송/모델 선택을 input 안에 배치 */}
	        <div
	          ref={inputBarRef}
	          style={{
	            position: "fixed",
            left: "var(--chatDockLeft, 0px)",
            right: "auto",
            bottom: 0,
            width: "var(--chatDockWidth, 100vw)",
	            display: "flex",
	            justifyContent: "center",
	            // 아래 고정 입력창. 위쪽 출력과의 간격은 메시지 영역 paddingBottom으로 확보
	            padding: "14px 0 16px",
	            pointerEvents: "none",
	          }}
	        >
	          <div style={{ width: "100%", maxWidth: CHAT_COLUMN_MAX, padding: "0 14px", pointerEvents: "auto" }}>
	            <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
	          <div
	            style={{
	              flex: 1,
	              borderRadius: 16,
	              border: "none",
	              // 입력창 뒤로 대사/지문이 비치지 않도록 불투명도↑
	              background: "rgba(12,12,14,0.96)",
	              padding: "8px 10px",
	              position: "relative",
	            }}
	          >
	            {/* 전송 아이콘(메시지 박스 내부 우측 상단) */}
	            <button
	              type="button"
	              onClick={send}
	              disabled={busy || !!editingAssistantId || !chatId}
	              title={messages.length === 0 ? "시작" : "전송"}
	              style={{
	                position: "absolute",
	                top: 8,
	                right: 8,
	                width: 34,
	                height: 34,
	                borderRadius: 10,
	                border: "none",
	                background: busy || editingAssistantId ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.06)",
	                color: busy || editingAssistantId ? "rgba(255,255,255,0.35)" : CHAT_THEME.text,
	                cursor: busy || editingAssistantId ? "not-allowed" : "pointer",
	                display: "flex",
	                alignItems: "center",
	                justifyContent: "center",
	              }}
	            >
	              <Icon name="paperPlane" size={16} />
	            </button>

	            {(suggestions.length > 0 || suggestLoading) && (
	            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8, paddingRight: 44 }}>
		              {suggestions.length > 0 ? (
		                suggestions.slice(0, 2).map((s, i) => (
                  <button
                    key={`${i}-${s}`}
                    type="button"
                    onClick={() => {
                      setInput(s);
                      requestAnimationFrame(() => inputRef.current?.focus());
                    }}
                    style={{
                      maxWidth: "100%",
                      padding: "6px 10px",
                      borderRadius: 999,
                      border: "none",
                      background: getModelBadge(settings?.model || "").bg,
                      color: CHAT_THEME.text,
                      cursor: "pointer",
                      textAlign: "left",
                      fontSize: 12,
                      fontWeight: 700,
                      opacity: 0.9,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                    title={s}
                  >
                    {s}
                  </button>
	              ))
	              ) : (
	                <div
	                  style={{
	                    padding: "6px 10px",
	                    borderRadius: 999,
	                    border: "none",
	                    background: "rgba(255,255,255,0.03)",
	                    color: CHAT_THEME.muted,
	                    fontSize: 12,
	                    fontWeight: 700,
	                    opacity: 0.9,
	                  }}
	                >
	                  추천 생성 중…
	                </div>
	              )}
              </div>
            )}
              <textarea
	              ref={inputRef}
	              value={input}
	              onChange={(e) => setInput(e.target.value)}
	              placeholder={editingAssistantId ? "수정 중... (저장/취소 후 전송)" : busy ? "채팅 입력중..." : "대사를 입력하세요. 예) 반가워!"}
	              disabled={busy || !!editingAssistantId}
	              onKeyDown={(e) => {
	                if (e.key === "Enter") {
	                  e.preventDefault();
	                  if (!busy && !editingAssistantId) send();
	                }
	              }}
	              rows={1}
	              style={{
	                width: "100%",
	                padding: "6px 44px 34px 0",
	                borderRadius: 0,
	                border: "none",
	                outline: "none",
	                background: "transparent",
	                color: "#ffffff",
	                caretColor: "#ffffff",
	                resize: "none",
	                minHeight: 44,
	                maxHeight: 160,
	                overflowY: "auto",
	                lineHeight: 1.45,
	                fontSize: 15,
	              }}
	            />

	            {/* 하단: 좌측(지문) / 우측(모델) */}
	            <div style={{ marginTop: 8, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
              <div />

	              <div style={{ position: "relative", marginLeft: "auto", display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
	                
	                <div
	                  style={{
	                    display: "none",
	                    borderRadius: 999,
	                    overflow: "hidden",
	                    border: "none",
	                    background: "rgba(255,255,255,0.03)",
	                  }}
	                >
	                  <button
	                    type="button"
	                    disabled={!chatId || !settings}
	                    onClick={() => {
	                      if (!settings) return;
	                      if (settings.renderMode === "chat") return;
	                      setSettings({ ...settings, renderMode: "chat" });
	                      saveSettingsSilent({ renderMode: "chat" as any });
	                    }}
	                    style={{
	                      padding: "6px 10px",
	                      fontSize: 12,
	                      fontWeight: 800,
	                      lineHeight: 1,
	                      border: "none",
	                      background: settings?.renderMode === "chat" ? "rgba(255,255,255,0.10)" : "transparent",
	                      color:
	                        !chatId || !settings
	                          ? "rgba(255,255,255,0.35)"
	                          : settings?.renderMode === "chat"
	                            ? CHAT_THEME.text
	                            : "rgba(255,255,255,0.65)",
	                      cursor: !chatId || !settings ? "not-allowed" : "pointer",
	                    }}
	                    title="채팅 모드"
	                  >
	                    채팅
	                  </button>
	                  <button
	                    type="button"
	                    disabled={!chatId || !settings}
	                    onClick={() => {
	                      if (!settings) return;
	                      if (settings.renderMode === "novel") return;
	                      setSettings({ ...settings, renderMode: "novel" });
	                      saveSettingsSilent({ renderMode: "novel" as any });
	                    }}
	                    style={{
	                      padding: "6px 10px",
	                      fontSize: 12,
	                      fontWeight: 800,
	                      lineHeight: 1,
	                      border: "none",
	                      background: settings?.renderMode === "novel" ? "rgba(255,255,255,0.10)" : "transparent",
	                      color:
	                        !chatId || !settings
	                          ? "rgba(255,255,255,0.35)"
	                          : settings?.renderMode === "novel"
	                            ? CHAT_THEME.text
	                            : "rgba(255,255,255,0.65)",
	                      cursor: !chatId || !settings ? "not-allowed" : "pointer",
	                    }}
	                    title="소설 모드"
	                  >
	                    소설
	                  </button>
	                </div>

                {/* 입력 도우미: 지문(*) / 추천(✨) */}
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <button
                    type="button"
                    onClick={insertNarrationMarkers}
                    disabled={busy || !!editingAssistantId}
                    title="지문 마커(* * ) 삽입"
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: 10,
                      border: "none",
                      background: busy || editingAssistantId ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.06)",
                      color: busy || editingAssistantId ? "rgba(255,255,255,0.35)" : CHAT_THEME.text,
                      cursor: busy || editingAssistantId ? "not-allowed" : "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon name="narration" size={16} />
                  </button>

                  <button
                    type="button"
                    onClick={requestSuggestionsOnDemand}
                    disabled={busy || !!editingAssistantId || !chatId}
                    title="추천답변 생성"
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: 10,
                      border: "none",
                      background: busy || editingAssistantId ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.06)",
                      color: busy || editingAssistantId ? "rgba(255,255,255,0.35)" : CHAT_THEME.text,
                      cursor: busy || editingAssistantId ? "not-allowed" : "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Icon name="magic" size={16} />
                  </button>
                </div>


<button
	                  ref={modelBtnRef}
	                  type="button"
	                  disabled={!chatId || !settings}
	                  onClick={() => setModelMenuOpen((v) => !v)}
	                  title={settings?.model || ""}
	                  style={{
	                    display: "flex",
	                    alignItems: "center",
	                    gap: 8,
	                    maxWidth: "min(360px, 64vw)",
	                    padding: "6px 10px",
	                    borderRadius: 999,
	                    border: "none",
	                    background: getModelBadge(settings?.model || "").bg,
	                    color: !chatId || !settings ? "rgba(255,255,255,0.35)" : getModelBadge(settings?.model || "").fg,
	                    cursor: !chatId || !settings ? "not-allowed" : "pointer",
	                    fontSize: 12,
	                    fontWeight: 800,
	                    lineHeight: 1,
	                    whiteSpace: "nowrap",
	                    overflow: "hidden",
	                    textOverflow: "ellipsis",
	                  }}
	                >
	                  <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{getModelBadge(settings?.model || "").label}</span>
	                  <Icon name="chevronDown" size={14} />
	                </button>

	                {modelMenuOpen && settings && (
	                  <div
	                    ref={modelMenuRef}
	                    style={{
	                      position: "absolute",
	                      right: 0,
	                      bottom: 40,
	                      width: "min(360px, 72vw)",
	                      borderRadius: 14,
	                      border: `1px solid ${CHAT_THEME.borderStrong}`,
	                      background: "rgba(12,12,14,0.92)",
	                      backdropFilter: "blur(8px)",
	                      boxShadow: "0 14px 34px rgba(0,0,0,0.55)",
	                      padding: 8,
	                      zIndex: 80,
	                    }}
	                  >
	                    {MODEL_OPTIONS.map((m) => {
	                      const active = settings.model === m;
	                      return (
	                        <button
	                          key={m}
	                          type="button"
	                          onClick={() => {
	                            if (!settings) return;
	                            setSettings({ ...settings, model: m as any });
	                            saveSettingsSilent({ model: m as any });
	                            setModelMenuOpen(false);
	                          }}
	                          style={{
	                            width: "100%",
	                            display: "flex",
	                            alignItems: "center",
	                            gap: 10,
	                            padding: "10px 10px",
	                            borderRadius: 12,
	                            border: `1px solid ${active ? CHAT_THEME.borderStrong : "transparent"}`,
	                            background: active ? "rgba(255,255,255,0.06)" : "transparent",
	                            color: CHAT_THEME.text,
	                            cursor: "pointer",
	                            textAlign: "left",
	                            fontSize: 12,
	                            fontWeight: active ? 900 : 700,
	                          }}
	                        >
	                          <span style={{ width: 18, opacity: active ? 1 : 0.25 }} aria-hidden>
	                            ✓
	                          </span>
	                          <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{m}</span>
	                        </button>
	                      );
	                    })}
	                  </div>
	                )}
	              </div>
	            </div>
	          </div>
	        </div>
	      </div>
	    </div>

	    {/* 친구비 0일 때: 조그마한 팝업 + 충전 유도 */}
	    {friendFeeEmptyPopup.open && typeof document !== "undefined" &&
	      createPortal(
	        <div
	          style={{
	            position: "fixed",
	            right: 18,
	            bottom: 98,
	            zIndex: 160,
	            width: "min(320px, calc(100vw - 24px))",
	            border: `1px solid ${CHAT_THEME.borderStrong}`,
	            borderRadius: 16,
	            background: "rgba(12,12,14,0.94)",
	            boxShadow: "0 18px 50px rgba(0,0,0,0.60)",
	            padding: 12,
	            color: CHAT_THEME.text,
	          }}
	        >
	          <div style={{ fontWeight: 900, fontSize: 13, lineHeight: 1.4, marginBottom: 10 }}>
	            {friendFeeEmptyPopup.text}
	          </div>
	          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
	            <button
	              type="button"
	              onClick={goFriendFeeCharge}
	              style={{
	                border: `1px solid ${CHAT_THEME.borderStrong}`,
	                background: "rgba(255,255,255,0.10)",
	                color: CHAT_THEME.text,
	                borderRadius: 12,
	                padding: "8px 10px",
	                fontWeight: 900,
	                cursor: "pointer",
	              }}
	            >
	              친구비 입금
	            </button>
	            <button
	              type="button"
	              onClick={closeFriendFeeEmptyPopup}
	              style={{
	                border: "none",
	                background: "transparent",
	                color: CHAT_THEME.text,
	                borderRadius: 12,
	                padding: "8px 10px",
	                fontWeight: 800,
	                cursor: "pointer",
	                opacity: 0.9,
	              }}
	            >
	              닫기
	            </button>
	          </div>
	        </div>,
	        document.body
	      )}

          </div>
        </div>
  );
}
