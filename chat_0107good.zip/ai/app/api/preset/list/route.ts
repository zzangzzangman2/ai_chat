import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, isAdminEmail } from "@/lib/auth";

export async function GET(request: Request) {
  // 프리셋 목록
  // - scope=mine: (작업실) 로그인 => 내 프리셋(공개/비공개) / 비로그인 => []
  // - 기본: (작품 선택/홈) 비로그인 => 공개 프리셋만
  // - 기본: (작품 선택/홈) 로그인   => 공개 프리셋 전체 + 내 비공개
  const url = new URL(request.url);
  const scope = (url.searchParams.get("scope") || "").toLowerCase();

  const u = await getSessionUser();
  const email = u?.email ?? "";
  const isAdmin = isAdminEmail(email);

  if (scope === "mine") {
    if (!email) return NextResponse.json({ presets: [] });
    const rows = isAdmin
      ? db
          .prepare(
            `SELECT
              id, name, background, characterName, characterAge, character, systemPrompt,
              image, tags, target, gallery, firstMessages, lorebooks, createdAt,
              COALESCE(userEmail,'') AS userEmail, COALESCE(isPublic,1) AS isPublic
            FROM presets
            ORDER BY createdAt DESC`
          )
          .all()
      : db
          .prepare(
            `SELECT
              id, name, background, characterName, characterAge, character, systemPrompt,
              image, tags, target, gallery, firstMessages, lorebooks, createdAt,
              COALESCE(userEmail,'') AS userEmail, COALESCE(isPublic,1) AS isPublic
            FROM presets
            WHERE COALESCE(userEmail,'') = ?
            ORDER BY createdAt DESC`
          )
          .all(email);
    return NextResponse.json({ presets: rows });
  }

  // 기본(홈/작품선택)
  if (isAdmin) {
    const rows = db
      .prepare(
        `SELECT
          id, name, background, characterName, characterAge, character, systemPrompt,
          image, tags, target, gallery, firstMessages, lorebooks, createdAt,
          COALESCE(userEmail,'') AS userEmail, COALESCE(isPublic,1) AS isPublic
        FROM presets
        ORDER BY createdAt DESC`
      )
      .all();
    return NextResponse.json({ presets: rows });
  }

  if (!email) {
    const rows = db
      .prepare(
        `SELECT
          id, name, background, characterName, characterAge, character, systemPrompt,
          image, tags, target, gallery, firstMessages, lorebooks, createdAt,
          COALESCE(userEmail,'') AS userEmail, COALESCE(isPublic,1) AS isPublic
        FROM presets
        WHERE COALESCE(isPublic,1) = 1
        ORDER BY createdAt DESC`
      )
      .all();
    return NextResponse.json({ presets: rows });
  }

  const rows = db
    .prepare(
      `SELECT
        id, name, background, characterName, characterAge, character, systemPrompt,
        image, tags, target, gallery, firstMessages, lorebooks, createdAt,
        COALESCE(userEmail,'') AS userEmail, COALESCE(isPublic,1) AS isPublic
      FROM presets
      WHERE COALESCE(isPublic,1) = 1 OR COALESCE(userEmail,'') = ?
      ORDER BY createdAt DESC`
    )
    .all(email);

  return NextResponse.json({ presets: rows });
}
