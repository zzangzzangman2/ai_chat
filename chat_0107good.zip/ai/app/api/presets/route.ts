import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import crypto from "crypto";

export async function GET() {
  const rows = db.prepare("SELECT * FROM presets ORDER BY createdAt DESC").all();
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  const body = await req.json();
  const u = await getSessionUser();
  const ownerEmail = (u?.email || "").trim();
  const id = crypto.randomUUID();
  const createdAt = Date.now();

  const name = String(body.name ?? "").trim();
  const background = String(body.background ?? "");
  const character = String(body.character ?? "");
  const systemPrompt = String(body.systemPrompt ?? "");

  if (!name) return NextResponse.json({ error: "name required" }, { status: 400 });

  db.prepare(
    `INSERT INTO presets (id, ownerEmail, name, background, character, systemPrompt, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, ownerEmail, name, background, character, systemPrompt, createdAt);

  const row = db.prepare("SELECT * FROM presets WHERE id=?").get(id);
  return NextResponse.json(row);
}
