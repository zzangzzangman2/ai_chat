import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";

type RouteCtx = { params: { id: string } | Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: RouteCtx) {
  const { id } = await ctx.params;
  const row = db.prepare("SELECT * FROM presets WHERE id=?").get(id);
  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });
  return NextResponse.json(row);
}

export async function PUT(req: NextRequest, ctx: RouteCtx) {
  const body = await req.json();
  const { id } = await ctx.params;

  const row = db.prepare("SELECT * FROM presets WHERE id=?").get(id);
  if (!row) return NextResponse.json({ error: "not found" }, { status: 404 });

  const name = String(body.name ?? row.name).trim();
  const background = String(body.background ?? row.background);
  const character = String(body.character ?? row.character);
  const systemPrompt = String(body.systemPrompt ?? row.systemPrompt);

  db.prepare(
    `UPDATE presets SET name=?, background=?, character=?, systemPrompt=? WHERE id=?`
  ).run(name, background, character, systemPrompt, id);

  const updated = db.prepare("SELECT * FROM presets WHERE id=?").get(id);
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, ctx: RouteCtx) {
  const { id } = await ctx.params;
  db.prepare("DELETE FROM presets WHERE id=?").run(id);
  return NextResponse.json({ ok: true });
}

