import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { randomUUID } from "crypto";
import { encryptIfPossible } from "@/lib/crypto";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const { presetId, replaceExisting } = await req.json();

  if (!presetId) {
    return NextResponse.json({ error: "프리셋을 먼저 선택해 주세요." }, { status: 400 });
  }

  const preset = db
    .prepare(`SELECT id, characterName, firstMessages FROM presets WHERE id=? AND (userEmail=? OR userEmail='')`)
    .get(presetId, u.email) as any;
  if (!preset) {
    return NextResponse.json({ error: "선택한 프리셋을 찾지 못했습니다." }, { status: 404 });
  }

  const chatId = randomUUID();
  const now = Date.now();

  const profile = db
    .prepare(`SELECT personaName, personaAge, personaGender, personaInfo FROM user_profile WHERE id=1`)
    .get() as any;

  // 같은 작품에 여러 채팅을 쌓지 않도록: "새 대화 시작" 시 기존 대화를 삭제
  if (replaceExisting) {
    const oldChats = db.prepare(`SELECT id FROM chats WHERE presetId=? AND userEmail=?`).all(presetId, u.email) as any[];
    for (const c of oldChats) {
      const id = String(c.id);
      db.prepare(`DELETE FROM message_usage WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM messages WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM chat_settings WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM chat_memory_cache WHERE chatId=?`).run(id);
      db.prepare(`DELETE FROM chats WHERE id=? AND userEmail=?`).run(id, u.email);
    }
  }

  db.prepare(`INSERT INTO chats (id, userEmail, presetId, title, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
    chatId,
    u.email,
    presetId,
    null,
    now
  );

  // (요구사항)
  // 채팅을 시작할 때, 작업실에서 설정한 "첫 메시지"를 자동으로 출력(assistant 첫 메시지로 저장)한다.
  // - firstMessages는 JSON 배열 문자열이며, 첫 번째 항목을 사용한다.
  // - 저장 시에는 가능한 한 "상대 | \"...\"" 형태로 보정한다.
  try {
    const raw = String(preset?.firstMessages || "[]");
    let arr: any[] = [];
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) arr = parsed;
    } catch {
      arr = [];
    }

    // firstMessages는 작업실에서 JSON.stringify([{ text: "..." }]) 형태로 저장된다.
    // 과거/호환을 위해 string 배열(["..."])도 함께 지원한다.
    const firstEntry = arr?.[0];
    const first = (
      typeof firstEntry === "string"
        ? firstEntry
        : (firstEntry && typeof firstEntry === "object")
          ? String((firstEntry as any).text ?? (firstEntry as any).content ?? "")
          : ""
    ).trim();
    if (first) {
      const npc = String(preset?.characterName || "상대").trim() || "상대";
      const hasPrefix = new RegExp(`^${npc.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\$&")}\\s*\\|`).test(first);
      const contentOnly = hasPrefix ? first.replace(/^.+?\s*\|\s*/, "").trim() : first;
      const looksNarration = contentOnly.startsWith("*") || contentOnly.startsWith("[");
      let finalText = first;
      if (!hasPrefix && !looksNarration) {
        // 대사로 시작하는 경우: 따옴표 보정
        const q = contentOnly.startsWith("\"") || contentOnly.startsWith("“") ? contentOnly : `\"${contentOnly}\"`;
        finalText = `${npc} | ${q}`;
      } else if (hasPrefix) {
        // 접두가 있으면 따옴표만 보정
        const q = contentOnly.startsWith("\"") || contentOnly.startsWith("“") || looksNarration
          ? contentOnly
          : `\"${contentOnly}\"`;
        finalText = looksNarration ? first : `${npc} | ${q}`;
      }

      db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
        randomUUID(),
        chatId,
        "assistant",
        encryptIfPossible(finalText),
        now
      );
    }
  } catch {
    // ignore
  }

  // 기본 설정 row 생성 (전역 페르소나 기본값을 복사)
  {
    const personaName = profile?.personaName ?? null;
    const personaAge = profile?.personaAge ?? null;
    const personaGender = profile?.personaGender ?? null;
    const personaInfo = profile?.personaInfo ?? null;

    // 모델/출력/추론 기본값 (chat_settings 스키마 컬럼명에 맞춤)
    const defaultModel = "gemini-2.5-pro";
    const defaultMaxOutputTokens = 1300;
    const defaultMaxReasoningTokens = 768;

    // 장기기억(새 시스템) 기본값
    const defaultMemoryFrom = 12;
    const defaultSummaryEvery = 5;
    const defaultPerTurnChars = 100;
    const defaultNarrationColor = "#CCC7C7";

    db.prepare(
      `INSERT OR IGNORE INTO chat_settings (
        chatId,
        personaName, personaAge, personaGender, personaInfo,
        model, maxOutputTokens, maxReasoningTokens,
        memoryFrom, summaryEvery, summaryLength,
        narrationColor,
        updatedAt
      ) VALUES (
        ?,
        ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?,
        ?,
        ?
      )`
    ).run(
      chatId,
      personaName, personaAge, personaGender, personaInfo,
      defaultModel, defaultMaxOutputTokens, defaultMaxReasoningTokens,
      defaultMemoryFrom, defaultSummaryEvery, defaultPerTurnChars,
      defaultNarrationColor,
      now
    );
  }

  return NextResponse.json({ chatId });
}
