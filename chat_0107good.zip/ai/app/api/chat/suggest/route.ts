import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { decryptIfPossible } from "@/lib/crypto";
import { generateText } from "@/lib/ai";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  try {
    const body = await req.json().catch(() => ({}));
    const chatId = String(body?.chatId || "").trim();
    const personaOverride = body?.personaOverride || null;

    if (!chatId) {
      return NextResponse.json({ error: "chatId가 필요합니다." }, { status: 400 });
    }

    // 마지막 assistant 메시지 가져오기
    const row = db
      .prepare(
        `SELECT m.content AS content
         FROM messages m
         WHERE m.chatId=? AND m.role='assistant'
         ORDER BY m.createdAt DESC
         LIMIT 1`
      )
      .get(chatId) as any;

    const lastAssistant = decryptIfPossible(String(row?.content || "")).trim();
    if (!lastAssistant) {
      return NextResponse.json({ suggestions: [] });
    }

    // 주인공(유저) 시점 3개 고정
    // - 부가 기능이라 속도 우선: flash 모델 + 낮은 토큰으로 생성
    const system = [
      "너는 소설형 AI 채팅의 '추천 답변' 생성기다.",
      "반드시 한국어로만 답한다.",
      "반드시 '주인공(사용자)' 1인칭 시점의 대사로만 3개를 만든다.",
      "상대(assistant) 입장의 말투/1인칭(나는/제가)로 쓰지 마라.",
      "지문(상황 설명) 금지. 대사(말)만.",
      "너무 길게 쓰지 말고, 한 줄씩 자연스럽게.",
      "출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\",\"...\"]}",
    ].join("\n");

    const personaLine = personaOverride
      ? `주인공 정보(참고): 이름=${String(personaOverride?.personaName || "").trim()}, 나이=${Number(personaOverride?.personaAge || 0)}, 성별=${String(personaOverride?.personaGender || "").trim()}, 설명=${String(personaOverride?.personaInfo || "").trim()}`
      : "";

    const user = [
      personaLine,
      "[직전 상대 발화/지문]",
      lastAssistant,
      "\n위 내용에 대해, 주인공(사용자)이 다음에 할 법한 대사 3개를 추천해줘.",
    ]
      .filter(Boolean)
      .join("\n");

    const r = await generateText({
      system,
      user,
      opts: {
        model: "gemini-3-flash-preview",
        maxOutputTokens: 220,
        maxReasoningTokens: 0,
      },
    });

    let suggestions: string[] = [];
    try {
      const parsed = JSON.parse(r.text);
      if (Array.isArray(parsed?.suggestions)) {
        suggestions = parsed.suggestions
          .map((s: any) => String(s || "").trim())
          .filter(Boolean)
          .slice(0, 3);
      }
    } catch {
      suggestions = [];
    }

    return NextResponse.json({ suggestions });
  } catch (e: any) {
    return NextResponse.json({ error: String(e?.message || "추천답변 생성 실패") }, { status: 500 });
  }
}
