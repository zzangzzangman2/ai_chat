import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(process.cwd(), "data", "data.sqlite3");
export const db = new Database(dbPath);

db.pragma("journal_mode = WAL");

function hasColumn(table: string, column: string) {
  const rows = db.prepare(`PRAGMA table_info(${table})`).all() as any[];
  return rows.some((r) => r.name === column);
}

function ensureTableAndMigrations() {
  // 1) base tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS presets (
      id TEXT PRIMARY KEY,
      ownerEmail TEXT NOT NULL DEFAULT '',
      name TEXT NOT NULL,
      background TEXT NOT NULL,
      character TEXT NOT NULL,
      systemPrompt TEXT NOT NULL,
      statusPrompt TEXT NOT NULL DEFAULT '',
      image TEXT NOT NULL DEFAULT '',
      tags TEXT NOT NULL DEFAULT '',
      target TEXT NOT NULL DEFAULT 'all',
      gallery TEXT NOT NULL DEFAULT '[]',
      firstMessages TEXT NOT NULL DEFAULT '[]',
      lorebooks TEXT NOT NULL DEFAULT '[]',
      createdAt INTEGER NOT NULL
    );

    
    CREATE TABLE IF NOT EXISTS banners (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      imageUrl TEXT NOT NULL,
      linkUrl TEXT NOT NULL DEFAULT '',
      isActive INTEGER NOT NULL DEFAULT 1,
      sortOrder INTEGER NOT NULL DEFAULT 0,
      createdAt INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_banners_active_sort ON banners(isActive, sortOrder, createdAt);

    -- banners_live: what the public homepage actually reads.
    -- Admin edits go to "banners" (draft). Changes are published to banners_live only when admin clicks "적용".
    CREATE TABLE IF NOT EXISTS banners_live (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      imageUrl TEXT NOT NULL,
      linkUrl TEXT NOT NULL DEFAULT '',
      isActive INTEGER NOT NULL DEFAULT 1,
      sortOrder INTEGER NOT NULL DEFAULT 0,
      createdAt INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_banners_live_active_sort ON banners_live(isActive, sortOrder, createdAt);

    CREATE TABLE IF NOT EXISTS chats (
      id TEXT PRIMARY KEY,
      presetId TEXT NOT NULL,
      userEmail TEXT NOT NULL DEFAULT '',
      title TEXT,
      lastStatusText TEXT NOT NULL DEFAULT '',
      lastStatusUpdatedAt INTEGER NOT NULL DEFAULT 0,
      createdAt INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      chatId TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      email TEXT PRIMARY KEY,
      name TEXT,
      image TEXT,
      nickname TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      is_banned INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      last_login_at TEXT,
      last_seen_at TEXT
    );
    
`);

  // users columns migrations (role/admin, ban, last login/seen)
  if (!hasColumn("users", "role")) {
    db.exec(`ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'`);
  }
  if (!hasColumn("users", "is_banned")) {
    db.exec(`ALTER TABLE users ADD COLUMN is_banned INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("users", "last_login_at")) {
    db.exec(`ALTER TABLE users ADD COLUMN last_login_at TEXT`);
  }
  if (!hasColumn("users", "last_seen_at")) {
    db.exec(`ALTER TABLE users ADD COLUMN last_seen_at TEXT`);
  }

  // presets columns migrations
  // (작품 제작자 표시를 위해 ownerEmail 저장)
  if (!hasColumn("presets", "ownerEmail")) {
    db.exec(`ALTER TABLE presets ADD COLUMN ownerEmail TEXT NOT NULL DEFAULT ''`);
  }

  // statusPrompt: 상태창 전용 포맷(선택)
  if (!hasColumn("presets", "statusPrompt")) {
    db.exec(`ALTER TABLE presets ADD COLUMN statusPrompt TEXT NOT NULL DEFAULT ''`);
  }

  // banners_live bootstrap (one-time): if live table is empty but draft table has data,
  // copy current ACTIVE draft banners into live so existing deployments don't suddenly show no banners.
  try {
    const liveCnt = db.prepare(`SELECT COUNT(1) AS n FROM banners_live`).get() as any;
    const draftCnt = db.prepare(`SELECT COUNT(1) AS n FROM banners`).get() as any;
    if ((liveCnt?.n ?? 0) === 0 && (draftCnt?.n ?? 0) > 0) {
      db.exec(`DELETE FROM banners_live`);
      db.exec(`
        INSERT INTO banners_live (imageUrl, linkUrl, isActive, sortOrder, createdAt)
        SELECT imageUrl, linkUrl, isActive, sortOrder, createdAt
        FROM banners
        WHERE isActive = 1
        ORDER BY sortOrder ASC, createdAt DESC
      `);
    }
  } catch {
    // ignore
  }

  // 0) friendfee (서버 영속화: 계정/기기 무관)
  // - wallet: 현재 잔액(실수)
  // - ledger: 증감 이력(중복 차감 방지용 messageId UNIQUE)
  // - attendance: 출석(하루 1회) + 연속 출석 계산용
  db.exec(`
    CREATE TABLE IF NOT EXISTS friendfee_wallet (
      userEmail TEXT PRIMARY KEY,
      balance REAL NOT NULL DEFAULT 0,
      updatedAt INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS friendfee_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userEmail TEXT NOT NULL,
      kind TEXT NOT NULL, -- spend/checkin/admin/adjust
      delta REAL NOT NULL,
      balanceAfter REAL NOT NULL,
      chatId TEXT,
      messageId TEXT,
      totalTokens INTEGER,
      model TEXT,
      meta TEXT NOT NULL DEFAULT '{}',
      createdAt INTEGER NOT NULL,
      UNIQUE(userEmail, kind, messageId)
    );

    CREATE TABLE IF NOT EXISTS friendfee_attendance (
      userEmail TEXT NOT NULL,
      dayKey TEXT NOT NULL, -- YYYY-MM-DD
      createdAt INTEGER NOT NULL,
      PRIMARY KEY(userEmail, dayKey)
    );

    CREATE INDEX IF NOT EXISTS idx_friendfee_ledger_user ON friendfee_ledger(userEmail);
    CREATE INDEX IF NOT EXISTS idx_friendfee_ledger_chat ON friendfee_ledger(userEmail, chatId);
    CREATE INDEX IF NOT EXISTS idx_friendfee_att_user ON friendfee_attendance(userEmail);
  `);

// (추가) 멀티 유저 분리: 소유자 컬럼
if (!hasColumn("presets", "userEmail")) {
  db.exec(`ALTER TABLE presets ADD COLUMN userEmail TEXT NOT NULL DEFAULT ''`);
}

if (!hasColumn("presets", "isPublic")) {
  db.exec(`ALTER TABLE presets ADD COLUMN isPublic INTEGER NOT NULL DEFAULT 1`);
  // 기존 작품은 모두 공개로
  db.exec(`UPDATE presets SET isPublic = 1 WHERE isPublic IS NULL OR isPublic = `);
}
if (!hasColumn("chats", "userEmail")) {
  db.exec(`ALTER TABLE chats ADD COLUMN userEmail TEXT NOT NULL DEFAULT ''`);
}

if (!hasColumn("chats", "title")) {
  db.exec(`ALTER TABLE chats ADD COLUMN title TEXT`);
}
if (!hasColumn("chats", "lastStatusText")) {
  db.exec(`ALTER TABLE chats ADD COLUMN lastStatusText TEXT NOT NULL DEFAULT ''`);
}
if (!hasColumn("chats", "lastStatusUpdatedAt")) {
  db.exec(`ALTER TABLE chats ADD COLUMN lastStatusUpdatedAt INTEGER NOT NULL DEFAULT 0`);
}

if (!hasColumn("messages", "userEmail")) {
  db.exec(`ALTER TABLE messages ADD COLUMN userEmail TEXT NOT NULL DEFAULT ''`);
}
if (!hasColumn("persona_profiles", "userEmail")) {
  db.exec(`ALTER TABLE persona_profiles ADD COLUMN userEmail TEXT NOT NULL DEFAULT ''`);
}
if (!hasColumn("user_profile", "userEmail")) {
  db.exec(`ALTER TABLE user_profile ADD COLUMN userEmail TEXT NOT NULL DEFAULT ''`);
}

// 인덱스(조회 성능)
db.exec(`CREATE INDEX IF NOT EXISTS idx_presets_userEmail ON presets(userEmail)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_chats_userEmail ON chats(userEmail)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_messages_userEmail ON messages(userEmail)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_persona_profiles_userEmail ON persona_profiles(userEmail)`);

  // 2) presets columns (추가)
  if (!hasColumn("presets", "characterName")) {
    db.exec(`ALTER TABLE presets ADD COLUMN characterName TEXT NOT NULL DEFAULT ''`);
  }
  if (!hasColumn("presets", "characterAge")) {
    db.exec(`ALTER TABLE presets ADD COLUMN characterAge INTEGER NOT NULL DEFAULT 0`);
  }

  // 3) workspace builder columns
  if (!hasColumn("presets", "image")) {
    db.exec(`ALTER TABLE presets ADD COLUMN image TEXT NOT NULL DEFAULT ''`);
  }
  if (!hasColumn("presets", "tags")) {
    db.exec(`ALTER TABLE presets ADD COLUMN tags TEXT NOT NULL DEFAULT ''`);
  }
  if (!hasColumn("presets", "target")) {
    db.exec(`ALTER TABLE presets ADD COLUMN target TEXT NOT NULL DEFAULT 'all'`);
  }
  if (!hasColumn("presets", "gallery")) {
    db.exec(`ALTER TABLE presets ADD COLUMN gallery TEXT NOT NULL DEFAULT '[]'`);
  }
  if (!hasColumn("presets", "firstMessages")) {
    db.exec(`ALTER TABLE presets ADD COLUMN firstMessages TEXT NOT NULL DEFAULT '[]'`);
  }
  if (!hasColumn("presets", "lorebooks")) {
    db.exec(`ALTER TABLE presets ADD COLUMN lorebooks TEXT NOT NULL DEFAULT '[]'`);
  }

  // 3) chat_settings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS chat_settings (
      chatId TEXT PRIMARY KEY,

      personaName TEXT NOT NULL DEFAULT '',
      personaAge INTEGER NOT NULL DEFAULT 0,
      personaGender TEXT NOT NULL DEFAULT '',
      personaInfo TEXT NOT NULL DEFAULT '',

      memoryFrom INTEGER NOT NULL DEFAULT 12,
      memoryTo INTEGER NOT NULL DEFAULT 24,
      -- 최근 원문(유저 입력) 턴 수 (user 메시지 1개 = 1턴)
      keepUserTurns INTEGER NOT NULL DEFAULT 12,
      recentSummaryN INTEGER NOT NULL DEFAULT 50,
      summaryEvery INTEGER NOT NULL DEFAULT 5,
      -- 턴당 글자수: 10~200(step 10) (default 50)
      summaryLength INTEGER NOT NULL DEFAULT 50,

      userNote TEXT NOT NULL DEFAULT '',

	      model TEXT NOT NULL DEFAULT 'gemini-2.5-pro',
	      maxOutputTokens INTEGER NOT NULL DEFAULT 1300,
      maxReasoningTokens INTEGER NOT NULL DEFAULT 768,

      narrationColor TEXT NOT NULL DEFAULT '#666666',

      -- 렌더링 모드: chat(기존 채팅) / novel(소설형)
      renderMode TEXT NOT NULL DEFAULT 'novel',
      updatedAt INTEGER NOT NULL
    );
  `);

  // 3-1) chat_settings columns (추가)
  if (!hasColumn("chat_settings", "summaryEvery")) {
    db.exec(`ALTER TABLE chat_settings ADD COLUMN summaryEvery INTEGER NOT NULL DEFAULT 5`);
  }
  if (!hasColumn("chat_settings", "summaryLength")) {
    // 턴당 글자수: 10~200(step 10), default 50
    db.exec(`ALTER TABLE chat_settings ADD COLUMN summaryLength INTEGER NOT NULL DEFAULT 50`);
  }
  
  
  // chat_settings: keepUserTurns (최근 원문으로 포함할 user턴 수)
  if (!hasColumn("chat_settings", "keepUserTurns")) {
    db.exec(`ALTER TABLE chat_settings ADD COLUMN keepUserTurns INTEGER NOT NULL DEFAULT 12`);
  }

// chat_settings: longMemoryGuidance (장기기억 생성 가이던스 - 채팅별)
  if (!hasColumn("chat_settings", "longMemoryGuidance")) {
    db.exec(`ALTER TABLE chat_settings ADD COLUMN longMemoryGuidance TEXT NOT NULL DEFAULT ''`);
  }

if (!hasColumn("chat_settings", "narrationColor")) {
    db.exec(`ALTER TABLE chat_settings ADD COLUMN narrationColor TEXT NOT NULL DEFAULT '#666666'`);
  }

  // chat_settings: renderMode (채팅/소설 렌더링 모드)
  if (!hasColumn("chat_settings", "renderMode")) {
    db.exec(`ALTER TABLE chat_settings ADD COLUMN renderMode TEXT NOT NULL DEFAULT 'novel'`);
  }
  // 4) chat_memory_cache (최근 요약/길이 확인용)
  db.exec(`
    CREATE TABLE IF NOT EXISTS chat_memory_cache (
      chatId TEXT PRIMARY KEY,
      recentSummary TEXT NOT NULL DEFAULT '',
      recentSummaryChars INTEGER NOT NULL DEFAULT 0,
      summaryEvery INTEGER NOT NULL DEFAULT 5,
      summaryLength INTEGER NOT NULL DEFAULT 50,
      updatedAt INTEGER NOT NULL
    );
  `);

  // chat_memory_cache columns (누적 요약을 위한 포인터)
  if (!hasColumn("chat_memory_cache", "summaryEvery")) {
    db.exec(`ALTER TABLE chat_memory_cache ADD COLUMN summaryEvery INTEGER NOT NULL DEFAULT 5`);
  }
  if (!hasColumn("chat_memory_cache", "summaryLength")) {
    db.exec(`ALTER TABLE chat_memory_cache ADD COLUMN summaryLength INTEGER NOT NULL DEFAULT 50`);
  }
  if (!hasColumn("chat_memory_cache", "lastSummarizedAt")) {
    db.exec(`ALTER TABLE chat_memory_cache ADD COLUMN lastSummarizedAt INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("chat_memory_cache", "rolledUpCount")) {
    db.exec(`ALTER TABLE chat_memory_cache ADD COLUMN rolledUpCount INTEGER NOT NULL DEFAULT 0`);
  }

  // chat_memory_cache: summarizedEndTurn (요약이 어디까지 생성되었는지 포인터)
  // - recentSummary 텍스트(헤더) 파싱에만 의존하면, 사용자가 수동 편집하거나 모델이 포맷을 바꾸는 경우
  //   다음 구간(예: 6-10)이 1-5로 반복 생성되는 문제가 발생할 수 있어 별도 포인터를 둔다.
  if (!hasColumn("chat_memory_cache", "summarizedEndTurn")) {
    db.exec(`ALTER TABLE chat_memory_cache ADD COLUMN summarizedEndTurn INTEGER NOT NULL DEFAULT 0`);
  }

  // 4-0) chat_memory_blocks (장기기억 블록 단위 저장; append-only)
  db.exec(`
    CREATE TABLE IF NOT EXISTS chat_memory_blocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chatId TEXT NOT NULL,
      startTurn INTEGER NOT NULL,
      endTurn INTEGER NOT NULL,
      summary TEXT NOT NULL DEFAULT '',
      summaryChars INTEGER NOT NULL DEFAULT 0,
      summaryEvery INTEGER NOT NULL DEFAULT 5,
      summaryLength INTEGER NOT NULL DEFAULT 50,
      model TEXT NOT NULL DEFAULT '',
      meta TEXT NOT NULL DEFAULT '',
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL,
      UNIQUE(chatId, startTurn)
    );
  `);
  // Ensure UNIQUE(chatId, startTurn) even if the table existed before without the constraint.
  // (CREATE TABLE IF NOT EXISTS does not retrofit constraints on existing tables.)
  db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_chat_memory_blocks_chat_start ON chat_memory_blocks(chatId, startTurn)`);


  // chat_memory_blocks column migrations (forward compatible)
  if (!hasColumn("chat_memory_blocks", "summaryEvery")) {
    db.exec(`ALTER TABLE chat_memory_blocks ADD COLUMN summaryEvery INTEGER NOT NULL DEFAULT 5`);
  }
  if (!hasColumn("chat_memory_blocks", "summaryLength")) {
    db.exec(`ALTER TABLE chat_memory_blocks ADD COLUMN summaryLength INTEGER NOT NULL DEFAULT 50`);
  }
  if (!hasColumn("chat_memory_blocks", "model")) {
    db.exec(`ALTER TABLE chat_memory_blocks ADD COLUMN model TEXT NOT NULL DEFAULT ''`);
  }
  if (!hasColumn("chat_memory_blocks", "meta")) {
    db.exec(`ALTER TABLE chat_memory_blocks ADD COLUMN meta TEXT NOT NULL DEFAULT ''`);
  }
  if (!hasColumn("chat_memory_blocks", "createdAt")) {
    db.exec(`ALTER TABLE chat_memory_blocks ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("chat_memory_blocks", "updatedAt")) {
    db.exec(`ALTER TABLE chat_memory_blocks ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0`);
  }
  // 4-0-1) chat_memory_override (수동 편집/오버라이드 요약; 블록 자동 생성과 분리)
  db.exec(`
    CREATE TABLE IF NOT EXISTS chat_memory_override (
      chatId TEXT PRIMARY KEY,
      summary TEXT NOT NULL DEFAULT '',
      summaryChars INTEGER NOT NULL DEFAULT 0,
      updatedAt INTEGER NOT NULL
    );
  `);




  // 4-1) message_usage (메시지별 토큰/지연 정보)
  db.exec(`
    CREATE TABLE IF NOT EXISTS message_usage (
      messageId TEXT PRIMARY KEY,
      chatId TEXT NOT NULL,
      model TEXT NOT NULL DEFAULT '',
	      promptTokens INTEGER NOT NULL DEFAULT 0,
	      outputTokens INTEGER NOT NULL DEFAULT 0,
	      reasoningTokens INTEGER NOT NULL DEFAULT 0,
      totalTokens INTEGER NOT NULL DEFAULT 0,
      latencyMs INTEGER NOT NULL DEFAULT 0,
      estPromptTotal INTEGER NOT NULL DEFAULT 0,
      tokenBreakdown TEXT NOT NULL DEFAULT '',
      createdAt INTEGER NOT NULL
    );
  `);


  // message_usage columns (추가)
  if (!hasColumn("message_usage", "estPromptTotal")) {
    db.exec(`ALTER TABLE message_usage ADD COLUMN estPromptTotal INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("message_usage", "reasoningTokens")) {
    db.exec(`ALTER TABLE message_usage ADD COLUMN reasoningTokens INTEGER NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("message_usage", "tokenBreakdown")) {
    db.exec(`ALTER TABLE message_usage ADD COLUMN tokenBreakdown TEXT NOT NULL DEFAULT ''`);
  }

  // (추가) 비용 추정용 컬럼
  if (!hasColumn("message_usage", "costUsd")) {
    db.exec(`ALTER TABLE message_usage ADD COLUMN costUsd REAL NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("message_usage", "costKrw")) {
    db.exec(`ALTER TABLE message_usage ADD COLUMN costKrw REAL NOT NULL DEFAULT 0`);
  }
  if (!hasColumn("message_usage", "usdToKrw")) {
    db.exec(`ALTER TABLE message_usage ADD COLUMN usdToKrw REAL NOT NULL DEFAULT 0`);
  }

  // 5) user_profile (전 채팅 공통으로 쓰는 페르소나 기본값)
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_profile (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      personaName TEXT NOT NULL DEFAULT '',
      personaAge INTEGER NOT NULL DEFAULT 0,
      personaGender TEXT NOT NULL DEFAULT '',
      personaInfo TEXT NOT NULL DEFAULT '',
      updatedAt INTEGER NOT NULL
    );
  `);

  // 6) persona_profiles (여러 개 저장/선택 가능한 페르소나)
  db.exec(`
    CREATE TABLE IF NOT EXISTS persona_profiles (
      id TEXT PRIMARY KEY,
      personaName TEXT NOT NULL DEFAULT '',
      personaAge INTEGER NOT NULL DEFAULT 0,
      personaGender TEXT NOT NULL DEFAULT '',
      personaInfo TEXT NOT NULL DEFAULT '',
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL
    );
  `);

  // --- Preset social (views/likes/follows/comments) ---
  // NOTE: This is additive and safe to run multiple times.
  db.exec(`
    CREATE TABLE IF NOT EXISTS preset_stats (
      presetId TEXT PRIMARY KEY,
      views INTEGER NOT NULL DEFAULT 0,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS preset_follows (
      presetId TEXT NOT NULL,
      userEmail TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      PRIMARY KEY (presetId, userEmail)
    );

    CREATE TABLE IF NOT EXISTS preset_likes (
      presetId TEXT NOT NULL,
      userEmail TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      PRIMARY KEY (presetId, userEmail)
    );

    CREATE TABLE IF NOT EXISTS preset_comments (
      id TEXT PRIMARY KEY,
      presetId TEXT NOT NULL,
      userEmail TEXT NOT NULL,
      content TEXT NOT NULL,
      createdAt INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS preset_comment_likes (
      commentId TEXT NOT NULL,
      userEmail TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      PRIMARY KEY (commentId, userEmail)
    );

    CREATE INDEX IF NOT EXISTS idx_preset_comments_preset_createdAt ON preset_comments (presetId, createdAt DESC);
    CREATE INDEX IF NOT EXISTS idx_preset_follows_preset ON preset_follows (presetId);
    CREATE INDEX IF NOT EXISTS idx_preset_likes_preset ON preset_likes (presetId);
    CREATE INDEX IF NOT EXISTS idx_preset_comment_likes_comment ON preset_comment_likes (commentId);
  `);



  // (호환) 기존 단일 user_profile이 있고 persona_profiles가 비어있으면 1개를 마이그레이션
  try {
    const cnt = db.prepare(`SELECT COUNT(1) AS c FROM persona_profiles`).get() as any;
    if (Number(cnt?.c || 0) === 0) {
      const row = db
        .prepare(`SELECT personaName, personaAge, personaGender, personaInfo, updatedAt FROM user_profile WHERE id=1`)
        .get() as any;
      if (row && (row.personaName || row.personaInfo)) {
        const now = Date.now();
        db.prepare(
          `INSERT INTO persona_profiles (id, personaName, personaAge, personaGender, personaInfo, createdAt, updatedAt)
           VALUES (@id, @personaName, @personaAge, @personaGender, @personaInfo, @createdAt, @updatedAt)`
        ).run({
          id: `p_${now}`,
          personaName: row.personaName || "기본",
          personaAge: Number(row.personaAge || 0),
          personaGender: row.personaGender || "",
          personaInfo: row.personaInfo || "",
          createdAt: now,
          updatedAt: now,
        });
      }
    }
  } catch {
    // ignore
  }
}

ensureTableAndMigrations();



export type DbUser = {
  email: string;
  name?: string | null;
  image?: string | null;
  nickname?: string | null;
};

export function getUserByEmail(email: string): DbUser | null {
  const row = db
    .prepare("SELECT email, name, image, nickname FROM users WHERE email = ?")
    .get(email) as DbUser | undefined;
  return row ?? null;
}

export function upsertUserByEmail(user: { email: string; name?: string; image?: string }): DbUser {
  db.prepare(
    `INSERT INTO users (email, name, image, nickname)
     VALUES (?, ?, ?, NULL)
     ON CONFLICT(email) DO UPDATE SET
       name=excluded.name,
       image=excluded.image,
       updated_at=datetime('now')`
  ).run(user.email, user.name ?? null, user.image ?? null);

  const saved = getUserByEmail(user.email);
  if (!saved) {
    return { email: user.email, name: user.name ?? null, image: user.image ?? null, nickname: null };
  }
  return saved;
}

export function setUserNicknameByEmail(email: string, nickname: string) {
  // Upsert so nickname persists even if the user row wasn't created yet
  db.prepare(
    `INSERT INTO users (email, name, image, nickname)
     VALUES (?, NULL, NULL, ?)
     ON CONFLICT(email) DO UPDATE SET
       nickname=excluded.nickname,
       updated_at=datetime('now')`
  ).run(email, nickname);
}


// ------------------------------
// Preset social helpers
// ------------------------------

export type PresetMeta = {
  presetId: string;
  views: number;
  likeCount: number;
  followCount: number;
  chatCount: number;
  likedByMe: boolean;
  followedByMe: boolean;
};

export type PresetComment = {
  id: string;
  presetId: string;
  userEmail: string;
  content: string;
  createdAt: number;
  likeCount: number;
  likedByMe: boolean;
};

function ensurePresetStatsRow(presetId: string) {
  const now = Date.now();
  db.prepare(
    `INSERT INTO preset_stats (presetId, views, createdAt, updatedAt)
     VALUES (?, 0, ?, ?)
     ON CONFLICT(presetId) DO NOTHING`
  ).run(presetId, now, now);
}

export function incrementPresetViews(presetId: string) {
  ensurePresetStatsRow(presetId);
  const now = Date.now();
  db.prepare(`UPDATE preset_stats SET views = views + 1, updatedAt = ? WHERE presetId = ?`).run(now, presetId);
}

export function getPresetMeta(presetId: string, userEmail?: string | null): PresetMeta {
  ensurePresetStatsRow(presetId);

  const stats = db.prepare(`SELECT views FROM preset_stats WHERE presetId = ?`).get(presetId) as any;
  const views = Number(stats?.views || 0);

  const chatRow = db.prepare(`SELECT COUNT(1) AS c FROM chats WHERE presetId = ?`).get(presetId) as any;
  const chatCount = Number(chatRow?.c || 0);

  const likeRow = db.prepare(`SELECT COUNT(1) AS c FROM preset_likes WHERE presetId = ?`).get(presetId) as any;
  const likeCount = Number(likeRow?.c || 0);

  const followRow = db.prepare(`SELECT COUNT(1) AS c FROM preset_follows WHERE presetId = ?`).get(presetId) as any;
  const followCount = Number(followRow?.c || 0);

  let likedByMe = false;
  let followedByMe = false;
  const email = (userEmail || "").trim();
  if (email) {
    const lr = db.prepare(`SELECT 1 FROM preset_likes WHERE presetId = ? AND userEmail = ?`).get(presetId, email);
    likedByMe = !!lr;
    const fr = db.prepare(`SELECT 1 FROM preset_follows WHERE presetId = ? AND userEmail = ?`).get(presetId, email);
    followedByMe = !!fr;
  }

  return { presetId, views, likeCount, followCount, chatCount, likedByMe, followedByMe };
}

export function getPresetCreator(presetId: string): {
  email: string | null;
  nickname: string | null;
  name: string | null;
  image: string | null;
} {
  const row = db.prepare(`SELECT ownerEmail FROM presets WHERE id = ?`).get(presetId) as any;
  const email = String(row?.ownerEmail || "").trim();
  if (!email) return { email: null, nickname: null, name: null, image: null };

  const u = getUserByEmail(email);
  return {
    email,
    nickname: u?.nickname ? String(u.nickname) : null,
    name: u?.name ? String(u.name) : null,
    image: u?.image ? String(u.image) : null,
  };
}

export function togglePresetLike(presetId: string, userEmail: string) {
  const email = (userEmail || "").trim();
  if (!email) throw new Error("userEmail required");
  const now = Date.now();

  const exists = db.prepare(`SELECT 1 FROM preset_likes WHERE presetId = ? AND userEmail = ?`).get(presetId, email);
  if (exists) {
    db.prepare(`DELETE FROM preset_likes WHERE presetId = ? AND userEmail = ?`).run(presetId, email);
  } else {
    db.prepare(`INSERT INTO preset_likes (presetId, userEmail, createdAt) VALUES (?, ?, ?)`).run(presetId, email, now);
  }

  const likeRow = db.prepare(`SELECT COUNT(1) AS c FROM preset_likes WHERE presetId = ?`).get(presetId) as any;
  const likeCount = Number(likeRow?.c || 0);
  const likedByMe = !exists;
  return { likeCount, likedByMe };
}

export function togglePresetFollow(presetId: string, userEmail: string) {
  const email = (userEmail || "").trim();
  if (!email) throw new Error("userEmail required");
  const now = Date.now();

  const exists = db.prepare(`SELECT 1 FROM preset_follows WHERE presetId = ? AND userEmail = ?`).get(presetId, email);
  if (exists) {
    db.prepare(`DELETE FROM preset_follows WHERE presetId = ? AND userEmail = ?`).run(presetId, email);
  } else {
    db.prepare(`INSERT INTO preset_follows (presetId, userEmail, createdAt) VALUES (?, ?, ?)`).run(presetId, email, now);
  }

  const followRow = db.prepare(`SELECT COUNT(1) AS c FROM preset_follows WHERE presetId = ?`).get(presetId) as any;
  const followCount = Number(followRow?.c || 0);
  const followedByMe = !exists;
  return { followCount, followedByMe };
}

export function listPresetComments(presetId: string, userEmail?: string | null, limit = 50): PresetComment[] {
  const email = (userEmail || "").trim();
  const rows = db
    .prepare(
      `SELECT c.id, c.presetId, c.userEmail, c.content, c.createdAt,
              (SELECT COUNT(1) FROM preset_comment_likes l WHERE l.commentId = c.id) AS likeCount,
              (SELECT 1 FROM preset_comment_likes l2 WHERE l2.commentId = c.id AND l2.userEmail = ?) AS likedByMe
       FROM preset_comments c
       WHERE c.presetId = ?
       ORDER BY c.createdAt DESC
       LIMIT ?`
    )
    .all(email, presetId, limit) as any[];

  return rows.map((r) => ({
    id: String(r.id),
    presetId: String(r.presetId),
    userEmail: String(r.userEmail),
    content: String(r.content),
    createdAt: Number(r.createdAt || 0),
    likeCount: Number(r.likeCount || 0),
    likedByMe: !!r.likedByMe,
  }));
}

export function addPresetComment(presetId: string, userEmail: string, content: string): PresetComment {
  const email = (userEmail || "").trim();
  if (!email) throw new Error("userEmail required");
  const text = String(content || "").trim();
  if (!text) throw new Error("content required");
  const id = `c_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  const now = Date.now();

  db.prepare(`INSERT INTO preset_comments (id, presetId, userEmail, content, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
    id,
    presetId,
    email,
    text,
    now
  );

  return { id, presetId, userEmail: email, content: text, createdAt: now, likeCount: 0, likedByMe: false };
}

export function toggleCommentLike(commentId: string, userEmail: string) {
  const email = (userEmail || "").trim();
  if (!email) throw new Error("userEmail required");
  const now = Date.now();

  const exists = db.prepare(`SELECT 1 FROM preset_comment_likes WHERE commentId = ? AND userEmail = ?`).get(commentId, email);
  if (exists) {
    db.prepare(`DELETE FROM preset_comment_likes WHERE commentId = ? AND userEmail = ?`).run(commentId, email);
  } else {
    db.prepare(`INSERT INTO preset_comment_likes (commentId, userEmail, createdAt) VALUES (?, ?, ?)`).run(commentId, email, now);
  }

  const row = db.prepare(`SELECT COUNT(1) AS c FROM preset_comment_likes WHERE commentId = ?`).get(commentId) as any;
  return { likeCount: Number(row?.c || 0), likedByMe: !exists };
}
