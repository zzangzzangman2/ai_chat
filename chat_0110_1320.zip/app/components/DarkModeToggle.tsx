"use client";

import { useEffect, useState } from "react";

function getInitialTheme(): "light" | "dark" {
  if (typeof window === "undefined") return "light";
  const saved = window.localStorage.getItem("theme") as any;
  if (saved === "dark" || saved === "light") return saved;
  // 기본은 OS 설정을 따르되, 저장값이 없으면 light로 시작
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export default function DarkModeToggle() {
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useEffect(() => {
    const t = getInitialTheme();
    setTheme(t);
    document.documentElement.dataset.theme = t;
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.dataset.theme = next;
    try {
      window.localStorage.setItem("theme", next);
    } catch {
      // ignore
    }
  }

  return (
    <button
      onClick={toggle}
      type="button"
      aria-label="다크모드 전환"
      style={{
        padding: "8px 12px",
        borderRadius: 12,
        border: "1px solid #ddd",
        background: "var(--background)",
        color: "var(--foreground)",
        cursor: "pointer",
        fontSize: 12,
        fontWeight: 700,
      }}
    >
      {theme === "dark" ? "라이트" : "다크"}
    </button>
  );
}
