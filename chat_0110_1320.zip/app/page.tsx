"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Home, MessageCircle, Wrench, Heart, PanelLeft, Settings, BookOpen, ChevronLeft, ChevronRight } from "lucide-react";
import ChatArea from "./components/ChatArea";
import Workspace from "./components/Workspace";
import WorkSelectGrid from "./components/WorkSelectGrid";
import WorkSelectModal from "./components/WorkSelectModal";
import BannerCarousel from "./components/BannerCarousel";
import AuthControls from "./components/auth/AuthControls";
import FriendFeePage from "./components/FriendFeePage";

// NOTE: 이 파일은 UI 구조만 바꾸는 용도입니다.
//       채팅/요약/장기기억/추천/스트리밍 등 서버 기능은 건드리지 않습니다.

export type Preset = {
  id: string;
  name: string;
  characterName: string;
  background?: string;
  desc?: string;
  // Workspace/editor fields
  characterAge?: number;
  character?: string;
  systemPrompt?: string;
  statusPrompt?: string;
  extra?: string;
  image?: string;
  tags?: string;
  target?: string;
  gallery?: string;
  firstMessages?: string;
  lorebooks?: string;
  isPublic?: 0 | 1;
  createdAt?: number;
  updatedAt?: number;
};

type View = "home" | "chat" | "workspace" | "friendfee";

type RecentChat = {
  id: string;
  presetId: string;
  presetName: string;
  image?: string;
  createdAt: number;
};

function compactTitle(t: string) {
  return String(t || "").replace(/\s+/g, "");
}


type FriendFeeState = { lastCheckin: string; streak: number; total: number };

function getKSTDateKey(d: Date = new Date()) {
  try {
    const fmt = new Intl.DateTimeFormat("sv-SE", {
      timeZone: "Asia/Seoul",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
    return fmt.format(d);
  } catch {
    return d.toISOString().slice(0, 10);
  }
}

function addDaysKST(dateKey: string, days: number) {
  const [y, m, d] = dateKey.split("-").map((v) => parseInt(v, 10));
  const base = new Date(Date.UTC(y, (m || 1) - 1, d || 1, 12, 0, 0));
  base.setUTCDate(base.getUTCDate() + days);
  return getKSTDateKey(base);
}

function FriendFeePanel() {
  const [state, setState] = useState<FriendFeeState>({ lastCheckin: "", streak: 0, total: 0 });
  const [toast, setToast] = useState("");

  useEffect(() => {
    try {
      const raw = localStorage.getItem("mate_friend_fee_state");
      if (raw) setState(JSON.parse(raw));
    } catch {
      // ignore
    }
  }, []);

  const persist = useCallback((next: FriendFeeState) => {
    setState(next);
    try {
      localStorage.setItem("mate_friend_fee_state", JSON.stringify(next));
    } catch {
      // ignore
    }
  }, []);

  const today = getKSTDateKey();
  const checkedToday = state.lastCheckin === today;

  const onCheckin = useCallback(() => {
    const todayKey = getKSTDateKey();
    if (state.lastCheckin === todayKey) {
      setToast("오늘은 이미 출석체크 했어요 💜");
      return;
    }
    const yesterday = addDaysKST(todayKey, -1);
    const nextStreak = state.lastCheckin === yesterday ? Math.max(1, (state.streak || 0) + 1) : 1;
    const nextTotal = (state.total || 0) + 10;
    persist({ lastCheckin: todayKey, streak: nextStreak, total: nextTotal });
    setToast("출석체크 완료! 친구비 +10 💕");
  }, [persist, state.lastCheckin, state.streak, state.total]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  return (
    <div
      style={{
        borderRadius: 16,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(255,255,255,0.05)",
        padding: 14,
        display: "grid",
        gap: 10,
        maxWidth: 520,
      }}
    >
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 12 }}>
        <div style={{ fontWeight: 900, color: "#e9eefc" }}>오늘 출석</div>
        <div style={{ fontSize: 12, opacity: 0.7 }}>{today}</div>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <div style={{ fontSize: 13, opacity: 0.86 }}>
          상태: <span style={{ fontWeight: 900 }}>{checkedToday ? "출석 완료 ✅" : "미출석"}</span>
        </div>
        <div style={{ fontSize: 13, opacity: 0.86 }}>
          연속: <span style={{ fontWeight: 900 }}>{state.streak || 0}일</span>
        </div>
        <div style={{ fontSize: 13, opacity: 0.86 }}>
          누적 친구비: <span style={{ fontWeight: 900 }}>{state.total || 0}</span>
        </div>
      </div>

      <button
        type="button"
        onClick={onCheckin}
        disabled={checkedToday}
        style={{
          height: 40,
          borderRadius: 14,
          border: "none",
          background: checkedToday ? "rgba(255,255,255,0.06)" : "rgba(168,85,247,0.28)",
          color: "#e9eefc",
          cursor: checkedToday ? "not-allowed" : "pointer",
          fontWeight: 950,
        }}
      >
        출석체크
      </button>

      {toast ? (
        <div style={{ fontSize: 12, opacity: 0.85 }}>{toast}</div>
      ) : (
        <div style={{ fontSize: 12, opacity: 0.55 }}>* 출석체크는 하루 1회 가능 (KST 기준)</div>
      )}
    </div>
  );
}

export default function Page() {
  // 홈(작품 선택): 공개 + 내 프리셋
  const [presets, setPresets] = useState<Preset[]>([]);

  const presetNameById = useMemo(() => {
    const map: Record<string, string> = {};
    for (const p of presets as any[]) {
      const id = String((p as any)?.id || "");
      if (!id) continue;
      const name = String((p as any)?.name || (p as any)?.characterName || "");
      if (name) map[id] = name;
    }
    return map;
  }, [presets]);

  const presetImageById = useMemo(() => {
    const map: Record<string, string> = {};
    for (const p of presets as any[]) {
      const id = String((p as any)?.id || "");
      if (!id) continue;
      const img = (p as any)?.image;
      if (typeof img === "string" && img.trim()) map[id] = img;
    }
    return map;
  }, [presets]);

  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null);

  // 작업실: 내 프리셋만 (처음 로그인 유저는 0개가 정상)
  const [myPresets, setMyPresets] = useState<Preset[]>([]);
  const [workspacePresetId, setWorkspacePresetId] = useState<string | null>(null);

  // 로그인 상태(작업실용 리스트 갱신 트리거)
  const [meEmail, setMeEmail] = useState<string | null>(null);

  useEffect(() => {
    if (!meEmail) return;
    void refreshRecentChats();
    // presets가 로드된 뒤 제목 매핑이 반영되도록 1번 더 갱신
  }, [meEmail, presets]);
  const [meStatus, setMeStatus] = useState<"unknown" | "guest" | "authed">("unknown");
  const [loginGateOpen, setLoginGateOpen] = useState(false);
  const [latestChatId, setLatestChatId] = useState<string | null>(null);
  const [latestChatLoaded, setLatestChatLoaded] = useState<boolean>(false);

  // 좌측 메뉴에 보여줄 최근 채팅 리스트(최소 5개)
  const [recentChats, setRecentChats] = useState<RecentChat[]>([]);

  // 좌측 메뉴 접힘/펼침 (기본: 펼침)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const [workModalOpen, setWorkModalOpen] = useState(false);

  // 진입 시: 항상 작품 선택 화면부터
  const [view, setView] = useState<View>("home");
  // 기본 상태는 항상 펼쳐진 좌측 메뉴
  // 좌측 메뉴는 기본 펼침 상태 고정
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedPreset = useMemo(
    () => presets.find((p) => p.id === selectedPresetId) || null,
    [presets, selectedPresetId]
  );
const THEME = useMemo(
  () => ({
    bg: "#000",
    panel: "rgba(255,255,255,0.04)",
    panel2: "rgba(255,255,255,0.06)",
    border: "rgba(255,255,255,0.14)",
    borderSoft: "rgba(255,255,255,0.10)",
    text: "#e9eefc",
    muted: "rgba(233,238,252,0.72)",
  }),
  []
);

const handleUpdatePreset = async (p: Preset) => {
  // 입력 중 자동 저장(POST) 금지: 변경 사항은 로컬 상태에만 반영하고,
  // 실제 저장은 Workspace 하단 고정 "캐릭터 생성/수정" 버튼에서만 1회 수행한다.
  const patch = (prev: Preset[]) => {
    const i = prev.findIndex((it) => it.id === p.id);
    if (i >= 0) {
      const next = prev.slice();
      next[i] = { ...next[i], ...p };
      return next;
    }
    // 새 프리셋 생성 케이스: 리스트 상단에 추가
    return [p, ...prev];
  };

  // 작업실(내 프리셋)과 홈(공개+내 프리셋) 양쪽 상태를 함께 갱신
  setMyPresets(patch);
  setPresets(patch);

  // 선택 유지: 작업실에서 새로 만든 경우를 대비
  if (!workspacePresetId) setWorkspacePresetId(p.id);
  if (!selectedPresetId) setSelectedPresetId(p.id);
};

const handleDeletePreset = async (id: string) => {
  const res = await fetch("/api/preset/delete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) throw new Error(await res.text());

  setMyPresets((prev) => prev.filter((x) => x.id !== id));
  setPresets((prev) => prev.filter((x) => x.id !== id));

  setWorkspacePresetId((cur) => (cur === id ? null : cur));
  setSelectedPresetId((cur) => (cur === id ? null : cur));
};



// 로그인 상태 확인(비로그인에서 채팅/작업실 진입을 막기 위함)
const refreshMe = async (): Promise<string> => {
  try {
    const res = await fetch("/api/auth/me", { cache: "no-store" });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json().catch(() => ({} as any));
    const email = typeof (data as any)?.user?.email === "string" ? String((data as any).user.email) : (typeof (data as any)?.email === "string" ? String((data as any).email) : "");
    setMeEmail(email);
    setMeStatus(email ? "authed" : "guest");
    return email;
  } catch {
    setMeEmail("");
    setMeStatus("guest");
    return "";
  }
};

// 초기 마운트 시 로그인 상태를 먼저 확정한다.
useEffect(() => {
  void refreshMe();
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);

const refreshRecentChats = async () => {
  // NOTE: meStatus는 setState라 즉시 반영되지 않으므로, refreshMe()의 반환값(email)로 판단한다.
  let email = meEmail || "";
  if (!email) {
    email = await refreshMe();
  }
  if (!email) {
    setRecentChats([]);
    return;
  }
  try {
    const r = await fetch("/api/chat/recent?limit=5", { cache: "no-store" });
    if (!r.ok) throw new Error(await r.text());
    const j = await r.json().catch(() => ({} as any));
    const items = Array.isArray((j as any)?.items) ? (j as any).items : [];
    setRecentChats(
      items
        .filter((x: any) => x && typeof x.id === "string")
        .map((x: any) => ({
          id: String(x.id),
          presetId: String(x.presetId || ""),
          presetName: String(presetNameById[String(x.presetId || "")] || x.presetName || x.title || "채팅"),
          image:
            typeof x.image === "string" && x.image.trim()
              ? x.image
              : presetImageById[String(x.presetId || "")] || undefined,
          createdAt:
            typeof x.createdAt === "number"
              ? x.createdAt
              : typeof x.updatedAt === "string" && /^\d+$/.test(x.updatedAt)
              ? Number(x.updatedAt)
              : Date.now(),
        }))
    );
  } catch {
    // 메뉴는 부가 기능: 실패해도 화면 전체를 깨지지 않게
    setRecentChats([]);
  }
}

// Sidebar collapse persistence
useEffect(() => {
  if (typeof window === "undefined") return;
  try {
    const v = window.localStorage.getItem("sj:sidebarCollapsed");
    if (v === "1") setSidebarCollapsed(true);
  } catch {}
}, []);

useEffect(() => {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem("sj:sidebarCollapsed", sidebarCollapsed ? "1" : "0");
  } catch {}
}, [sidebarCollapsed]);

;

// Ensure logout clears any cached auth state immediately
useEffect(() => {
  const handler = () => {
    setMeEmail("");
    setMeStatus("guest");
    setLoginGateOpen(false);
    setView("home");
  };
  window.addEventListener("sj:logout", handler);
  return () => window.removeEventListener("sj:logout", handler);
}, []);

// 비로그인 상태에서 chat/workspace로 마운트 자체를 막아서
// unauthorized 토스트(설정 저장 실패 등)가 먼저 뜨는 현상을 방지한다.
const requireLoginThen = async (next: View) => {
  let email = meEmail || "";
  // If auth state is unknown OR we previously evaluated as guest, re-check once.
  // This allows immediate access after a fresh login without requiring a hard refresh.
  if (meStatus === "unknown" || !email) {
    email = await refreshMe();
  }
  if (!email) {
    setLoginGateOpen(true);
    // view 전환은 하지 않는다(마운트 차단)
    return;
  }
  setLoginGateOpen(false);
  setView(next);
};

// (UX) ChatArea 등 다른 컴포넌트에서 "친구비 입금"으로 바로 보내고 싶을 때
// - CustomEvent를 받아서 로그인 게이트를 거친 뒤 friendfee 화면으로 이동
useEffect(() => {
  if (typeof window === "undefined") return;
  const onOpen = () => {
    void requireLoginThen("friendfee");
  };
  window.addEventListener("mate:openFriendFeePage", onOpen as any);
  return () => window.removeEventListener("mate:openFriendFeePage", onOpen as any);
  // requireLoginThen은 컴포넌트 내부 함수지만, 의존성에 넣으면 리스너가 과도하게 재등록될 수 있어
  // 여기서는 현재 렌더 기준의 함수 참조로 충분하다.
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);

// 초기 진입: 로그인 상태 + 작품 리스트를 먼저 로드한다.
useEffect(() => {
  void refreshMe();
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);

// 로그인 상태가 바뀌면 좌측 최근 채팅을 갱신한다.
useEffect(() => {
  void refreshRecentChats();
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [meStatus, meEmail]);

useEffect(() => {
  let cancelled = false;
  (async () => {
    try {
      const res = await fetch("/api/preset/list", { cache: "no-store" });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json().catch(() => ({} as any));
      const list: Preset[] = Array.isArray((data as any)?.presets) ? (data as any).presets : [];
      if (cancelled) return;
      setPresets(list);
      if (!selectedPresetId && list.length > 0) setSelectedPresetId(list[0].id);
    } catch (e: any) {
      if (cancelled) return;
      setPresets([]);
      setError(e?.message || "프리셋 목록을 불러오지 못했습니다.");
    }
  })();
  return () => {
    cancelled = true;
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);

// 작업실(내 프리셋) 로드: 로그인 계정의 것만
useEffect(() => {
  let cancelled = false;
  (async () => {
    let email = meEmail || "";
    if (meStatus === "unknown") {
      email = await refreshMe();
    }

    // 비로그인 상태에선 작업실은 빈 리스트가 정상
    if (!email) {
      setMyPresets([]);
      setWorkspacePresetId(null);
      return;
    }

    try {
      const res = await fetch("/api/preset/list?scope=mine", { cache: "no-store" });
      const data = await res.json().catch(() => ({} as any));
      const list: Preset[] = Array.isArray((data as any)?.presets) ? (data as any).presets : [];
      if (cancelled) return;
      setMyPresets(list);
      if (!workspacePresetId && list.length > 0) setWorkspacePresetId(list[0].id);
      if (list.length === 0) setWorkspacePresetId(null);
    } catch {
      if (cancelled) return;
      setMyPresets([]);
      setWorkspacePresetId(null);
    }
  })();
  return () => {
    cancelled = true;
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [view, meEmail, meStatus]);

  // 선택된 프리셋의 최신 채팅 ID 로드
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!selectedPresetId) return;
      setLatestChatLoaded(false);
      try {
        const res = await fetch(`/api/chat/latest?presetId=${encodeURIComponent(selectedPresetId)}`, {
          cache: "no-store",
        });
        if (!res.ok) throw new Error(await res.text());
        const data = await res.json();
        if (cancelled) return;
        setLatestChatId(data?.chat?.id || null);
        setLatestChatLoaded(true);
      } catch {
        if (cancelled) return;
        setLatestChatId(null);
        setLatestChatLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedPresetId]);

  // 상단 좌측 제목은 '채팅' 화면에서만 표시 (작업실/홈/친구비 등 다른 화면에서는 숨김)
  const workTitle = view === "chat" ? compactTitle(selectedPreset?.name || "채팅") : "";

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#000",
        color: "#e9eefc",
      }}
    >
      <style jsx global>{`
        /* 메시지 스크롤바: 화면 우측에 자연스럽게, 배경과 비슷한 톤 */
        .chat-scroll {
          scrollbar-color: rgba(255,255,255,0.18) rgba(0,0,0,0.2);
        }
        .chat-scroll::-webkit-scrollbar {
          width: 10px;
        }
        .chat-scroll::-webkit-scrollbar-track {
          background: rgba(0,0,0,0.2);
        }
        .chat-scroll::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.16);
          border-radius: 999px;
          border: 2px solid rgba(0,0,0,0.25);
        }
        .chat-scroll::-webkit-scrollbar-thumb:hover {
          background: rgba(255,255,255,0.24);
        }
      `}</style>

      {/* Top bar */}
      <div
        style={{
          height: 56,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 14px",
          // 사이드바가 fixed로 덮지 않도록 Top bar를 사이드바 폭만큼 오른쪽으로 밀고 폭을 줄인다.
          marginLeft: sidebarCollapsed ? 72 : 320,
          width: `calc(100% - ${sidebarCollapsed ? 72 : 320}px)`,
          borderBottom: "1px solid rgba(255,255,255,0.08)",
          position: "sticky",
          top: 0,
          background: "rgba(0,0,0,0.85)",
          backdropFilter: "blur(10px)",
          zIndex: 40,
        }}
      >
	      <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 200 }}>
	        <div style={{ fontWeight: 800, letterSpacing: "0.2px" }}>{workTitle}</div>
	      </div>

	      <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 200, justifyContent: "flex-end" }}>
          {/* Auth: 로그인은 반드시 /api/auth/google 로만 진입 */}
          <AuthControls onOpenFriendFeePage={() => void requireLoginThen("friendfee")} />
	        {view === "chat" && (
	          <button
	            type="button"
	            onClick={() => setSettingsOpen(true)}
	            aria-label="설정 열기"
	            style={{
	              width: 36,
	              height: 36,
	              borderRadius: 12,
	              border: "none",
	              background: "transparent",
	              color: "#e9eefc",
	              cursor: "pointer",
	            }}
	          >
	            ⚙️
	          </button>
	        )}
        </div>
      </div>

      {/* Left menu (항상 펼쳐진 상태) */}
      <aside
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          bottom: 0,
          width: sidebarCollapsed ? 72 : 320,
          background:
            "#121316",
          borderRight: "1px solid rgba(255,255,255,0.10)",
          zIndex: 40,
          padding: sidebarCollapsed ? 10 : 14,
          paddingTop: sidebarCollapsed ? 56 : 14,
          overflow: "auto",
        }}
      >
        {/* Collapse toggle (상단 우측) */}
        <button
          type="button"
          aria-label={sidebarCollapsed ? "사이드바 펼치기" : "사이드바 접기"}
          onClick={() => setSidebarCollapsed((v) => !v)}
          style={{
            position: "absolute",
            top: 10,
            right: 10,
            width: 32,
            height: 32,
            borderRadius: 12,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(255,255,255,0.04)",
            color: "#e9eefc",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {sidebarCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>

        {/* Brand */}
        {!sidebarCollapsed && (
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 6px 10px" }}>
            <div
              style={{
                width: 52,
                height: 52,
                borderRadius: 12,
                border: "none",
                background: "transparent",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                overflow: "hidden",
              }}
            >
              <img
                src="/logo-ribbon.png"
                alt="메이트"
                style={{ width: "100%", height: "100%", objectFit: "contain" }}
                draggable={false}
              />
            </div>
            <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.05, minWidth: 0 }}>
              <div style={{ fontSize: 16, fontWeight: 900, letterSpacing: 0.2 }}>메이트</div>
            </div>
          </div>
        )}

        {/* Nav */}
        <div style={{ display: "grid", gap: sidebarCollapsed ? 12 : 10, marginTop: sidebarCollapsed ? 8 : 6 }}>
          <button type="button" onClick={() => setView("home")} style={navBtnStyle(view === "home", sidebarCollapsed)}>
            <span style={{ display: "inline-flex", width: 22, justifyContent: "center" }}>
              <Home size={18} />
            </span>
            {!sidebarCollapsed && "홈"}
          </button>
          <button type="button" onClick={() => void requireLoginThen("chat")} style={navBtnStyle(view === "chat", sidebarCollapsed)}>
            <span style={{ display: "inline-flex", width: 22, justifyContent: "center" }}>
              <MessageCircle size={18} />
            </span>
            {!sidebarCollapsed && "채팅"}
          </button>
          <button
            type="button"
            onClick={() => void requireLoginThen("workspace")}
            style={navBtnStyle(view === "workspace", sidebarCollapsed)}
          >
            <span style={{ display: "inline-flex", width: 22, justifyContent: "center" }}>
              <Wrench size={18} />
            </span>
            {!sidebarCollapsed && "작업실"}
          </button>
          <button
            type="button"
            onClick={() => void requireLoginThen("friendfee")}
            style={navBtnStyle(view === "friendfee", sidebarCollapsed)}
          >
            <span style={{ display: "inline-flex", width: 22, justifyContent: "center" }}>
              <span aria-hidden style={{ fontSize: 16, lineHeight: "16px" }}>💕</span>
            </span>
            {!sidebarCollapsed && "친구비 입금"}
          </button>

        </div>

        {/* Recent */}
        <div style={{ marginTop: 28, opacity: 0.9, fontSize: 13, display: "flex", flexDirection: "column", alignItems: "stretch" }}>
          {!sidebarCollapsed && (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, width: "100%" }}>

              <span>최근 채팅</span>
          <button
            type="button"
            onClick={() => void refreshRecentChats()}
            style={{
              border: "none",
              background: "transparent",
              color: "rgba(233,238,252,0.75)",
              cursor: "pointer",
              fontSize: 12,
              fontWeight: 700,
            }}
          >
            새로고침
          </button>
        </div>

        <div style={{ marginTop: 22, display: "grid", gap: 10 }}>
          {!meEmail && (
            <div style={{ fontSize: 12, opacity: 0.7, padding: "10px 6px" }}>로그인 후 최근 채팅이 표시됩니다.</div>
          )}

          {!!meEmail && recentChats.length === 0 && (
            <div style={{ fontSize: 12, opacity: 0.7, padding: "10px 6px" }}>최근 채팅이 없습니다.</div>
          )}

          {recentChats.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setSelectedPresetId(c.presetId);
                void requireLoginThen("chat");
              }}
              style={{
                width: "100%",
                display: "flex",
                gap: 10,
                alignItems: "center",
                textAlign: "left",
                border: "1px solid rgba(255,255,255,0.10)",
                background: "rgba(255,255,255,0.04)",
                borderRadius: 16,
                padding: 10,
                cursor: "pointer",
                color: "#e9eefc",
              }}
            >
              <div
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 12,
                  border: "none",
                  background: "transparent",
                  overflow: "hidden",
                  flex: "0 0 auto",
                }}
              >
                <img
                  src={c.image || presetImageById[String(c.presetId || "")] || "/logo-ribbon.png"}
                  alt=""
                  style={{ width: "100%", height: "100%", objectFit: "contain" }}
                  draggable={false}
                />
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 900, fontSize: 13, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {(presetNameById[String(c.presetId || "")] || c.presetName || "채팅")}
                </div>
              </div>
            </button>
          ))}
        </div>
          </>
        )}

        </div>

      </aside>

      {/* Main */}
      <div style={{ padding: "18px 14px 28px", marginLeft: sidebarCollapsed ? 72 : 320 }}>
        {error && (
          <div
            style={{
              maxWidth: 760,
              margin: "0 auto 16px",
              border: "1px solid rgba(255,120,120,0.25)",
              background: "rgba(255,120,120,0.08)",
              borderRadius: 16,
              padding: 12,
              color: "#ffd6d6",
              fontWeight: 700,
            }}
          >
            {error}
          </div>
        )}

		{view === "chat" && meStatus === "authed" && (
			<ChatArea
              presetId={selectedPresetId}
              presets={presets as any}
              onChangePreset={(id) => setSelectedPresetId(id)}
              settingsUiMode="drawer"
              hideSettingsToggle
              externalSettingsOpen={settingsOpen}
              onExternalSettingsOpenChange={setSettingsOpen}
			/>
		)}

        {view === "workspace" && meStatus === "authed" && (
          <div style={{ maxWidth: 1100, margin: "0 auto" }}>
            <Workspace
              theme={THEME as any}
              // 작업실은 "내 프리셋만" 보여야 함 (처음 로그인 유저면 빈 리스트가 정상)
              presets={myPresets as any}
              selectedPresetId={workspacePresetId}
              onSelectPreset={(id) => setWorkspacePresetId(id)}
              onUpdatePreset={handleUpdatePreset as any}
              onDeletePreset={handleDeletePreset as any}
            />
          </div>
        )}

        
        {view === "friendfee" && meStatus === "authed" && (
          <div style={{ maxWidth: 1100, margin: "0 auto" }}>
            <FriendFeePage onExitToChat={() => void requireLoginThen("chat")} />
          </div>
        )}

{view === "home" && (
          <div style={{ maxWidth: 1100, margin: "0 auto" }}>
            
            <div style={{ marginTop: 14 }}>
              <BannerCarousel height={210} />
            </div>
<WorkSelectGrid
              presets={presets}
              selectedPresetId={selectedPresetId}
              onSelect={(id) => {
                setSelectedPresetId(id);
                setWorkModalOpen(true);
              }}
            />

            <WorkSelectModal
              open={workModalOpen}
              onClose={() => setWorkModalOpen(false)}
              preset={selectedPreset}
              latestChatLoaded={latestChatLoaded}
              hasLatestChat={!!latestChatId}
              onContinue={() => {
                // ChatArea가 내부에서 presetId 기준으로 최신 채팅을 자동 로드(이어하기)
                setWorkModalOpen(false);
                void requireLoginThen("chat");
              }}
              onNew={() => {
                // ChatArea의 기존 로직(강제 새 채팅 플래그)을 그대로 사용한다.
                try {
                  if (selectedPresetId) window.localStorage.setItem("forceNewChatPresetId", selectedPresetId);
                } catch {
                  // ignore
                }
                setWorkModalOpen(false);
                void requireLoginThen("chat");
              }}
            />
          </div>
        )}
      </div>


{/* Login gate (full-screen) */}
{loginGateOpen && (
  <div
    role="dialog"
    aria-modal="true"
    style={{
      position: "fixed",
      inset: 0,
      zIndex: 200,
      background: "rgba(0,0,0,0.78)",
      backdropFilter: "blur(10px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 16,
    }}
    onMouseDown={(e) => {
      // 바깥 클릭으로 닫히지 않게(게이트)
      e.preventDefault();
      e.stopPropagation();
    }}
  >
    <div
      style={{
        width: "min(720px, 96vw)",
        border: "1px solid rgba(255,255,255,0.10)",
        background: "rgba(255,255,255,0.04)",
        borderRadius: 22,
        padding: 18,
        boxShadow: "none",
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, padding: "10px 0 6px" }}>
        <img src="/logo-ribbon.png" alt="메이트" style={{ width: 92, height: 92, borderRadius: 22, objectFit: "contain" }} />
        <div style={{ fontSize: 30, fontWeight: 900, letterSpacing: "-0.5px", color: "#9b5cff" }}>메이트</div>
        <div style={{ fontSize: 13, opacity: 0.8 }}>계속하려면 로그인이 필요합니다.</div>
      </div>

      <div style={{ display: "flex", justifyContent: "center", paddingTop: 14 }}>
        <a
          href="/api/auth/google"
          style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            width: "min(420px, 100%)",
            borderRadius: 16,
            padding: "12px 14px",
            border: "none",
            background: "rgba(155,92,255,0.18)",
            color: "#e9eefc",
            textDecoration: "none",
            fontWeight: 900,
          }}
        >
          Google로 계속하기
        </a>
      </div>

      <div style={{ display: "flex", justifyContent: "center", paddingTop: 10 }}>
        <button
          type="button"
          onClick={() => setLoginGateOpen(false)}
          style={{
            border: "1px solid rgba(255,255,255,0.12)",
            background: "rgba(255,255,255,0.04)",
            color: "rgba(233,238,252,0.85)",
            borderRadius: 14,
            padding: "10px 12px",
            cursor: "pointer",
            fontWeight: 800,
          }}
        >
          닫기
        </button>
      </div>
    </div>
  </div>
)}

    </div>
  );
}

function navBtnStyle(active: boolean, collapsed: boolean): React.CSSProperties {
  return {
    width: "100%",
    textAlign: collapsed ? "center" : "left",
    border: "1px solid rgba(255,255,255,0.12)",
    background: active ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.03)",
    color: "#e9eefc",
    borderRadius: 16,
    padding: collapsed ? "10px" : "12px 12px",
    cursor: "pointer",
    fontWeight: 800,
    display: "flex",
    alignItems: "center",
    justifyContent: collapsed ? "center" : "flex-start",
    gap: collapsed ? 0 : 10,
  };
}
