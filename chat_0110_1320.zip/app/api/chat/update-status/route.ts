import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { generateText } from "@/lib/ai";
import { decryptIfPossible, encryptIfPossible } from "@/lib/crypto";

function bad(msg: string, code: number = 400) {
  return NextResponse.json({ error: msg }, { status: code });
}

type Role = "user" | "assistant";

type ChatMessage = {
  role: Role;
  content: string;
};

function looksLikeHasStatusFormat(ruleText: string): boolean {
  const s = (ruleText || "").toLowerCase();
  // Heuristics: any fenced block + keywords that imply "status/info window"
  if (s.includes("```") && (s.includes("status") || s.includes("상태") || s.includes("정보"))) return true;
  // Some creators define special tags without backticks (rare), still allow model attempt.
  if (s.includes("상태창") || s.includes("status window") || s.includes("스테이터스")) return true;
  return false;
}

function extractFirstFencedBlock(text: string): string {
  const t = String(text || "").trim();
  if (!t) return "";
  if (t === "NO_UPDATE") return "NO_UPDATE";
  // Be tolerant: some inputs omit the newline just before the closing fence.
  const m = t.match(/```[^\n]*\n[\s\S]*?```/);
  if (m) return m[0].trim();

  // Last resort: slice between first and last fences.
  const first = t.indexOf("```");
  const last = t.lastIndexOf("```");
  if (first >= 0 && last > first) return t.slice(first, last + 3).trim();
  return "";
}

function parseFencedBlock(block: string): { label: string; body: string } | null {
  const t = String(block || "").trim();
  // Tolerate missing newline before closing fence.
  const m = t.match(/^```([^\n]*)\n([\s\S]*?)```$/);
  if (!m) return null;
  let body = String(m[2] || "");
  // If body ends with a trailing newline, drop only one.
  if (body.endsWith("\n")) body = body.slice(0, -1);
  return { label: String(m[1] || "").trim(), body };
}

function buildStatusFromTemplate(params: {
  templateBlock: string;
  lastStatusBlock: string;
  convoText: string;
}): string {
  const tpl = parseFencedBlock(params.templateBlock);
  if (!tpl) return "NO_UPDATE";

  const prev = parseFencedBlock(params.lastStatusBlock);
  const prevBody = prev?.body || "";

  let body = tpl.body;

  // Replace common placeholders (keep minimal; creator can refine later)
  body = body.replace(/\{\{\s*user\s*\}\}/gi, "주인공");

  // Carry forward date/time/location line if it exists in previous status.
  const prevDTL = prevBody.match(/📅[^\n]*\n?/);
  if (prevDTL) {
    body = body.replace(/📅[^\n]*\n?/, prevDTL[0]);
  } else {
    // If template still has placeholders, set a sensible starting point.
    body = body.replace(/📅\([^\)]*\)\s*🕛\([^\)]*\)\s*🗺️\([^\)]*\)/, "📅1784년 7월 1일 🕛09시 🗺️연무장");
  }

  // Diary counter update: [일지N/3](P/3...)
  const re = /\[일지(\d+)\/3\]\((\d+)\/3[^\)]*\)/;
  const mPrev = prevBody.match(re);
  const mTpl = body.match(re);
  const base = mPrev || mTpl;
  if (base) {
    let diaryIdx = Number(base[1] || 0);
    let prog = Number(base[2] || 0);
    if (Number.isFinite(prog)) {
      if (prog < 3) {
        prog = prog + 1;
      } else {
        prog = 0;
        diaryIdx = diaryIdx + 1;
      }
    }
    body = body.replace(re, `[일지${diaryIdx}/3](${prog}/3에서매 대화 시 1씩증가. 0/3, 1/3, 2/3, 3/3)`);
  }

  const label = tpl.label || "STATUS";
  return `\`\`\`${label}\n${body}\n\`\`\``;
}


function applyDeterministicRules(params: { currentBlock: string; lastBlock: string; templateBlock?: string }): string {
  const cur = parseFencedBlock(params.currentBlock);
  if (!cur) return params.currentBlock;

  const last = parseFencedBlock(params.lastBlock);
  const prevBody = String(last?.body || "");

  let body = String(cur.body || "");

  // Normalize common placeholders even if the model echoed them.
  body = body.replace(/\{\{\s*user\s*\}\}/gi, "주인공");

  // Carry forward the last known date/time/location line if present.
  const prevDTL = prevBody.match(/📅[^\n]*\n?/);
  if (prevDTL) {
    body = body.replace(/📅[^\n]*\n?/, prevDTL[0]);
  } else if (/📅\([^\)]*\)/.test(body)) {
    body = body.replace(/📅[^\n]*\n?/, "📅1784년 7월 1일 🕛09시 🗺️연무장\n");
  }

  // Diary counter: always advance based on the previous status if available.
  const re = /\[일지(\d+)\/3\]\((\d+)\/3[^\)]*\)/;
  const mPrev = prevBody.match(re);
  const mCur = body.match(re);
  const base = mPrev || mCur;
  if (base) {
    let diaryIdx = Number(base[1] || 0);
    let prog = Number(base[2] || 0);

    if (Number.isFinite(prog)) {
      if (prog < 3) {
        prog = prog + 1;
      } else {
        prog = 0;
        diaryIdx = diaryIdx + 1;
      }
    }
    body = body.replace(re, `[일지${diaryIdx}/3](${prog}/3에서매 대화 시 1씩증가. 0/3, 1/3, 2/3, 3/3)`);
  }

  const label = cur.label || "STATUS";
  return `\`\`\`${label}\n${body}\n\`\`\``;
}

const systemPromptForStatus = `
당신은 AI 채팅 시스템의 [상태창(Status Window) 렌더러]입니다.
당신의 목표는 아래 제공되는 [게임 규칙(System Prompt)]을 분석하여, 현재 상황에 맞는 상태창을 출력하는 것입니다.

[입력 데이터]
1. 게임 규칙(System Prompt): 제작자가 설정한 캐릭터/게임의 규칙입니다. 여기에 상태창 출력 포맷(예: \`\`\`STATUS ... \`\`\`, \`\`\`INFO ... \`\`\` 등)이 정의되어 있습니다.
2. 이전 상태창: 직전 턴까지의 상태입니다.
3. 현재 상태창(초안): 시스템이 제공하는 최신 상태창 초안(보통 이전 상태를 기반으로 생성됨)입니다.
4. 최근 대화: 방금 주고받은 사용자와 AI의 대화입니다.

[수행 절차]
1. [게임 규칙]을 읽고, 제작자가 의도한 "상태창/정보창 출력 포맷"이 무엇인지 파악하십시오.
2. 반드시 [현재 상태창(초안)]을 기준으로 내용을 갱신하십시오. (템플릿을 그대로 복사하지 말 것)
3. [최근 대화]의 내용을 분석하여, 체력/호감도/소지품/시간/위치/명성·악명/일정 변화를 감지하십시오.
4. 감지된 변화를 반영하되, 확실하지 않은 항목은 **기존 값(초안/이전 상태)**을 유지하십시오.
5. 특히 [일지N/3] 카운트는 **직전 상태창을 기준으로 절대 되돌리지 말고**, 한 대화마다 1단계 진행시키십시오.
6. **반드시 [게임 규칙]에 정의된 "코드 펜스(\`\`\`... \`\`\`)" 형태로만 출력하십시오.**
7. 사족(설명)은 절대 붙이지 마십시오. 오직 코드 펜스 블록 하나만 출력하십시오.

[예외]
- 만약 [게임 규칙]에 상태창/정보창의 정의가 전혀 없다면, 반드시 'NO_UPDATE' 한 단어만 출력하십시오.
`;

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return bad("unauthorized", 401);

  const body = await req.json().catch(() => ({} as any));
  const chatId = String(body?.chatId || "").trim();
  if (!chatId) return bad("chatId가 필요합니다.");

  // 1) auth & load chat/preset
  let chat: any;
  try {
    chat = db
      .prepare(`SELECT id, presetId, userEmail, lastStatusText FROM chats WHERE id=? AND userEmail=?`)
      .get(chatId, u.email) as any;
  } catch {
    // Older DB schema may not have lastStatusText yet.
    chat = db
      .prepare(`SELECT id, presetId, userEmail FROM chats WHERE id=? AND userEmail=?`)
      .get(chatId, u.email) as any;
    if (chat) chat.lastStatusText = "";
  }
  if (!chat) return bad("채팅을 찾지 못했습니다.", 404);

  const preset = db
    .prepare(`SELECT id, name, background, character, systemPrompt, statusPrompt, lorebooks FROM presets WHERE id=?`)
    .get(String(chat.presetId || "")) as any;
  if (!preset) return bad("작품(preset)을 찾지 못했습니다.", 404);

  // 2) input
  const inputMessages = Array.isArray(body?.messages) ? body.messages : [];
  const recent: ChatMessage[] = inputMessages
    .filter((m: any) => (m?.role === "user" || m?.role === "assistant") && typeof m?.content === "string")
    .slice(-12)
    .map((m: any) => ({ role: m.role as Role, content: String(m.content || "") }));
  if (recent.length === 0) return bad("messages가 필요합니다.");

  const lastStatus = String(
    typeof body?.lastStatus === "string" && body.lastStatus.trim().length
      ? body.lastStatus
      : decryptIfPossible(String(chat.lastStatusText || ""))
  );

  const lastBlock = extractFirstFencedBlock(lastStatus);

  // Allow client-supplied systemPrompt override (optional).
  // Prefer the dedicated statusPrompt (fast + stable) when present.
  const systemPromptRaw = String(body?.systemPrompt || "").trim();
  const statusPromptRaw = String(preset?.statusPrompt || "").trim();
  const usedStatusPrompt = !systemPromptRaw && Boolean(statusPromptRaw);

  // If the creator provided a dedicated status prompt, prefer its first fenced block as a template.
  // This guarantees we can always render *something* even if the model responds with NO_UPDATE.
  const statusTemplateBlock = statusPromptRaw ? extractFirstFencedBlock(statusPromptRaw) : "";

  const ruleText = systemPromptRaw
    ? systemPromptRaw
    : statusPromptRaw
      ? statusPromptRaw
      : [
          preset?.background ? `# BACKGROUND\n${String(preset.background)}` : "",
          preset?.character ? `# CHARACTER\n${String(preset.character)}` : "",
          preset?.systemPrompt ? `# SYSTEM_PROMPT\n${String(preset.systemPrompt)}` : "",
          preset?.lorebooks ? `# LOREBOOKS\n${String(preset.lorebooks)}` : "",
        ]
          .filter(Boolean)
          .join("\n\n");

  // 3) quick short-circuit
  if (!looksLikeHasStatusFormat(ruleText)) {
    // If creator explicitly provided a template block, render from it without calling the model.
    if (statusTemplateBlock && statusTemplateBlock !== "NO_UPDATE") {
      const statusText = buildStatusFromTemplate({
        templateBlock: statusTemplateBlock,
        lastStatusBlock: lastBlock,
        convoText: "",
      });
      return NextResponse.json({ ok: true, statusText, status: statusText, usedStatusPrompt });
    }
    // Backward/forward compatible response keys:
    // - statusText: canonical
    // - status: legacy (some clients expect this)
    return NextResponse.json({ ok: true, statusText: "NO_UPDATE", status: "NO_UPDATE", usedStatusPrompt });
  }

  const convoText = recent
    .map((m) => (m.role === "user" ? `사용자: ${m.content}` : `AI: ${m.content}`))
    .join("\n");

  // Draft status window: prefer the previous saved status; otherwise build from the creator's template.
  let draftStatusBlock = (lastBlock && lastBlock !== "NO_UPDATE") ? lastBlock : "";
  if (!draftStatusBlock && statusTemplateBlock && statusTemplateBlock !== "NO_UPDATE") {
    draftStatusBlock = buildStatusFromTemplate({
      templateBlock: statusTemplateBlock,
      lastStatusBlock: lastBlock,
      convoText: "",
    });
  }

  const user = [
    "[게임 규칙(System Prompt)]",
    ruleText,
    "",
    "[이전 상태창]",
    lastStatus || "(없음)",
    "",
    "[현재 상태창(초안)]",
    draftStatusBlock || "(없음)",
    "",
    "[최근 대화]",
    convoText,
  ].join("\n");

  // 4) call lightweight model
  const r = await generateText({
    system: systemPromptForStatus,
    user,
    opts: {
      model: "gemini-2.5-flash",
      // Status window should be compact.
      maxOutputTokens: 700,
      maxReasoningTokens: 0,
    },
  });

  const raw = String(r?.text || "").trim();
  const fenced = extractFirstFencedBlock(raw);
  let statusText = fenced || (raw === "NO_UPDATE" ? "NO_UPDATE" : "NO_UPDATE");

  // If we have an explicit template and the model still responded NO_UPDATE/invalid, fall back.
  if ((statusText === "NO_UPDATE" || !statusText) && statusTemplateBlock && statusTemplateBlock !== "NO_UPDATE") {
    statusText = buildStatusFromTemplate({
      templateBlock: statusTemplateBlock,
      lastStatusBlock: lastBlock,
      convoText,
    });
  }

  // Deterministic guardrails: never regress diary/date-time and always advance diary based on previous status.
  if (statusText !== "NO_UPDATE") {
    try {
      statusText = applyDeterministicRules({ currentBlock: statusText, lastBlock: lastBlock || "", templateBlock: statusTemplateBlock });
    } catch {
      // ignore
    }
  }


  // 5) persist (only if updated)
  if (statusText !== "NO_UPDATE") {
    try {
      db.prepare(`UPDATE chats SET lastStatusText=?, lastStatusUpdatedAt=? WHERE id=? AND userEmail=?`).run(
        encryptIfPossible(statusText),
        Date.now(),
        chatId,
        u.email
      );
    } catch {
      // If the DB hasn't been migrated yet, don't fail the request.
    }
  }

  return NextResponse.json({ ok: true, statusText, status: statusText, usedStatusPrompt });
}
