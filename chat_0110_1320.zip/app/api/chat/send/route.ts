console.log("[chat/send] module loaded", new Date().toISOString());
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { randomUUID } from "crypto";
import { generateText, generateTextStream, summarizeKorean } from "@/lib/ai";
import { decryptIfPossible, encryptIfPossible } from "@/lib/crypto";

import { stripUrlsAndMediaMarkdown, LONG_MEMORY_SUMMARY_RULES } from "@/lib/memory_sanitize";// ---- 비용 추정(간단 버전) ----
// Gemini Developer API(유료) 가격표(프롬프트 <= 200k tokens 구간)의 input/output 단가만 사용한다.
// 참고: https://ai.google.dev/gemini-api/docs/pricing
// 환율은 실시간이 아니라 기본값(환경변수로 덮어쓰기 가능)로 처리한다.
const DEFAULT_USD_TO_KRW = Number(process.env.USD_TO_KRW || 1434); // 대략값

function isChatDebug() {
  return String(process.env.CHAT_DEBUG || "").trim() === "1";
}

function dbg(obj: any) {
  if (!isChatDebug()) return;
  try {
    console.log(JSON.stringify(obj));
  } catch {
    // ignore
  }
}

type ModelPricing = { inPer1M: number; outPer1M: number };

function getModelPricing(model: string): ModelPricing {
  const m = String(model || "").trim();
  // 기본값은 2.5-pro로 둔다(프로젝트 기본 모델).
  const table: Record<string, ModelPricing> = {
    // Gemini 2.5
    "gemini-2.5-pro": { inPer1M: 1.25, outPer1M: 10.0 },
    // Gemini 3 (preview 이름을 UI에서 간단히 gemini-3-pro / gemini-3-flash 로 노출하는 경우가 있어 별칭도 추가)
    "gemini-3-flash": { inPer1M: 0.5, outPer1M: 3.0 },
    "gemini-3-flash-preview": { inPer1M: 0.5, outPer1M: 3.0 },
    "gemini-3-pro": { inPer1M: 2.0, outPer1M: 12.0 },
    "gemini-3-pro-preview": { inPer1M: 2.0, outPer1M: 12.0 },
  };
  return table[m] || table["gemini-2.5-pro"];
}

function estimateCost(model: string, promptTokens: number, outputTokens: number) {
  const p = getModelPricing(model);
  const usd = (promptTokens / 1_000_000) * p.inPer1M + (outputTokens / 1_000_000) * p.outPer1M;
  const krw = usd * DEFAULT_USD_TO_KRW;
  return { costUsd: usd, costKrw: krw, usdToKrw: DEFAULT_USD_TO_KRW, pricing: p };
}

function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}

function formatTurns(messages: any[]) {
  return messages
    .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
    .join("\n");
}

type PersonaOverride = {
  personaName?: string;
  personaAge?: number;
  personaGender?: string;
  personaInfo?: string;
} | null;

function resolvePersona(settings: any, personaOverride: PersonaOverride) {
  const ov = personaOverride && typeof personaOverride === "object" ? personaOverride : null;

  const name = String(settings?.personaName || "").trim() || String(ov?.personaName || "").trim();
  const age = Number(settings?.personaAge || 0) || Number(ov?.personaAge || 0) || 0;
  const gender = String(settings?.personaGender || "").trim() || String(ov?.personaGender || "").trim();
  const info = String(settings?.personaInfo || "").trim() || String(ov?.personaInfo || "").trim();

  return { name, age, gender, info };
}

function persistPersonaIfMissing(chatId: string, settings: any, persona: { name: string; age: number; gender: string; info: string }) {
  if (!persona.name) return;
  if (String(settings?.personaName || "").trim()) return;

  try {
    db.prepare(
      `UPDATE chat_settings SET personaName=?, personaAge=?, personaGender=?, personaInfo=?, updatedAt=? WHERE chatId=?`
    ).run(persona.name, persona.age || 0, persona.gender, persona.info, Date.now(), chatId);
    settings.personaName = persona.name;
    settings.personaAge = persona.age || 0;
    settings.personaGender = persona.gender;
    settings.personaInfo = persona.info;
  } catch {
    // ignore
  }
}

// 최근 컨텍스트를 "유저 입력" 기준 K턴만 포함시키기 (user 메시지 1개 = 1턴)
function selectRecentByUserTurns(messages: any[], keepUserTurns: number) {
  if (keepUserTurns <= 0) return [];
  const totalUserTurns = messages.reduce((acc, m) => acc + (m.role === "user" ? 1 : 0), 0);
  const startTurn = Math.max(1, totalUserTurns - keepUserTurns + 1);

  const picked: any[] = [];
  let u = 0;
  for (const msg of messages) {
    if (msg.role === "user") u += 1;
    if (u >= startTurn) picked.push(msg);
  }
  return picked;
}

// lastN 메시지는 그대로 전달하고, 그 이전은 요약으로 대체하는 용도
function formatStoryTurns(messages: any[], personaName: string, npcName: string) {
  return messages
    .map((m) => {
      const who = m.role === "user" ? personaName : npcName;
      // 컨텍스트에는 "이름 |"을 최대한 유지하되,
      // 첫 줄이 인물 이름으로 시작하는 서술(예: "서윤아는...")에는 접두를 붙이지 않는다.
      return ensurePrefix(m.content, who, [personaName, npcName]);
    })
    .join("\n\n");
}

function ensurePrefix(text: string, who: string, noPrefixIfStartsWithNames?: string[]) {
  // (요구사항)
  // 지문은 이름 접두를 붙이지 않는다. ("서윤아 | *...*" 같은 출력이 UI에서 어색해짐)
  // 또한 모델이 이미 "이름 |" 형식을 썼다면 중복 접두를 붙이지 않는다.
  const raw = String(text || "");
  const lines = raw.split("\n");
  const firstIdx = lines.findIndex((l) => l.trim().length > 0);
  if (firstIdx === -1) return raw.trim();

  const first = lines[firstIdx].trimStart();
  // 1) 첫 줄이 지문이면 접두 없음
  if (first.startsWith("*")) return raw.trim();
  // 2) 이미 "이름 |" 형태면 그대로
  if (/^.+?\s*\|\s*/.test(first)) return raw.trim();
  // 3) 첫 줄이 특정 이름으로 시작하는 서술이면 접두 없음
  //    (예: "서윤아는..." 같은 서술에 "상대 |"가 붙는 문제 방지)
  const avoid = (noPrefixIfStartsWithNames || []).map((s) => String(s || "").trim()).filter(Boolean);
  if (avoid.length) {
    for (const nm of avoid) {
      if (first.startsWith(nm) && !first.slice(nm.length).trimStart().startsWith("|")) {
        return raw.trim();
      }
    }
  }

  const prefix = `${who} | `;
  lines[firstIdx] = prefix + first;
  return lines.join("\n").trim();
}

function stripEndMarker(text: string) {
  const t = String(text || "");
  return t
    .replace(new RegExp("\\n?\\[END\\]\\s*$", "i"), "")
    .replace(new RegExp("\\n?<END>\\s*$", "i"), "")
    .trim();
}

// (마크다운 안정화)
// 일부 세션/모델에서 ```STATUS 코드펜스를 열고 닫는 ```를 누락하는 경우가 있다.
// - 닫는 펜스가 누락되면 UI/저장된 로그에서 상태창이 깨지거나(일부 렌더러는 통째로 텍스트 처리),
//   이후 본문까지 코드블록으로 흡수되는 현상이 발생한다.
// - STATUS 창은 사용자 요구사항상 “항상 고정 형식”이므로, 누락 시 서버에서 최소 복구를 수행한다.
function repairUnclosedStatusFence(text: string): { text: string; repaired: boolean; hadStatus: boolean } {
  const s0 = String(text || "");
  const idx = s0.search(/(^|\n)\s*```\s*STATUS\b/i);
  if (idx < 0) return { text: s0, repaired: false, hadStatus: false };

  const after = s0.slice(idx + 1);
  const hasClose = /(^|\n)\s*```\s*(\n|$)/.test(after);
  if (hasClose) return { text: s0, repaired: false, hadStatus: true };

  const needsNewline = !s0.endsWith("\n");
  const fixed = s0 + (needsNewline ? "\n" : "") + "```";
  return { text: fixed, repaired: true, hadStatus: true };
}

// 일부 모델이 opening fence와 첫 줄을 같은 라인에 붙여 출력하는 케이스 정규화
// 예) ```STATUS [일지0/3] ...  ->  ```STATUS\n[일지0/3] ...
function normalizeStatusFenceOpen(text: string): { text: string; normalized: boolean } {
  const s0 = String(text || "");
  const s1 = s0.replace(/(^|\n)\s*```\s*STATUS\b\s+([^\n]+)/gi, (_m, p1, rest) => `${p1}\n\`\`\`STATUS\n${rest}`);
  return { text: s1, normalized: s1 !== s0 };
}


/**
 * Label-agnostic fenced-block helpers
 * - normalizeAnyFenceOpen: if an opening fence has trailing content on same line, split into two lines
 * - repairUnclosedAnyFence: if a fence is opened but not closed, close it at the end
 * - wrapLooseMetaAsFence: conservatively wrap likely meta blocks (without fences) into a ```META ... ``` fence
 *
 * NOTE: These are intentionally non-destructive and append-only friendly.
 */

function normalizeAnyFenceOpen(text: string): string {
  const s0 = String(text || "");
  // Convert CRLF/CR to LF to simplify processing
  const s = s0.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  // If a line starts with ```<label> and also has extra content, split it into two lines.
  return s.replace(/(^|\n)(\s*```[^\s`]+)\s+([^\n]+)/g, (_m, p1, fence, rest) => {
    return `${p1}${fence}\n${rest}`;
  });
}

function repairUnclosedAnyFence(text: string): string {
  const s0 = String(text || "");
  const s = s0.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = s.split("\n");

  let open = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/^\s*```/.test(line)) {
      open = !open;
    }
  }

  if (open) {
    // Close the fence at end (ensure newline before closing)
    const t = s.endsWith("\n") ? s : s + "\n";
    return t + "```";
  }
  return s;
}

function wrapLooseMetaAsFence(text: string): { text: string; wrapped: boolean } {
  const s0 = String(text || "");
  const s = s0.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  // If there's already any fence, don't try to wrap; just return.
  if (s.includes("```")) return { text: s, wrapped: false };

  const lines = s.split("\n");
  // Find a likely "meta header" line near the end.
  // This is conservative to avoid wrapping normal prose.
  const metaHeader = /^\s*(?:\[?(?:STATUS|INFO|SUMMARY|META|DEBUG)\]?\s*:|\[?(?:상태|요약|메모)\]?\s*:)\s*/i;

  let startIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (metaHeader.test(lines[i])) startIdx = i;
  }
  if (startIdx < 0) return { text: s, wrapped: false };

  // Only wrap if the header appears in the last ~35% of the text (typical "end-of-response meta")
  const threshold = Math.floor(lines.length * 0.65);
  if (startIdx < threshold) return { text: s, wrapped: false };

  const before = lines.slice(0, startIdx).join("\n");
  const meta = lines.slice(startIdx).join("\n");

  const wrappedText = `${before}${before ? "\n" : ""}` + "```META\n" + meta + "\n```";
  return { text: wrappedText, wrapped: true };
}


// 가끔 지문 줄 앞에 `이름 | ...` 접두가 붙는 케이스 제거
// - RHS가 따옴표("/“/')로 시작하면 대사로 보고 유지
// - 그렇지 않으면 지문으로 보고 `이름 | ` 제거

// --- renderMode helpers (chat vs novel) ---
function stripInfoBlock(text: string): string {
  const t = String(text || "");
  if (!t.trim()) return t;
  const lines = t.split(/\r?\n/);
  let cut = -1;

  // legacy: explicit INFO header
  const idxInfo = lines.findIndex((ln) => ln.trim() === "INFO");
  if (idxInfo >= 0) cut = idxInfo;

  // emoji style INFO block (📆📌💡❤️ ...)
  const idxEmoji = lines.findIndex((ln) => /^\s*[📆📌💡❤️]/.test(String(ln || "").trim()));
  if (idxEmoji >= 0) cut = cut >= 0 ? Math.min(cut, idxEmoji) : idxEmoji;

  if (cut >= 0) return lines.slice(0, cut).join("\n").trimEnd();
  return t;
}

function stripSpeakerPrefixLine(line: string): string {
  const s = String(line || "");
  const m = s.match(/^\s*[^|]{1,40}\s*\|\s*(.+)$/);
  return m ? String(m[1] || "") : s;
}

function ensureQuoted(text: string): string {
  let s = String(text || "").trim();
  if (!s) return '""';
  // if already quoted (straight/smart), keep
  if (s.startsWith("\"") || s.startsWith("“")) {
    if (!(s.endsWith("\"") || s.endsWith("”"))) s = s + "\"";
    return s;
  }
  return `"${s}"`;
}

function normalizeNovelPlain(text: string): string {
  // novel 컨텍스트에서는 지문/대사 마킹(*...*, "..." 등)을 최대한 보존한다.
  // - END 마커만 제거
  // - `이름 | ...` 접두가 붙은 라인은 제거하되, RHS가 따옴표 대사면 유지
  // - fenced 메타 패널( ```ANY_LABEL ...``` )은 그대로 유지
  const t0 = stripEndMarker(String(text || ""));
  if (!t0.trim()) return t0.trim();

  const src = t0.split(/\r?\n/);
  const out: string[] = [];

  let inFence = false;
  for (const ln of src) {
    const raw = String(ln || "");

    // fence toggle (preserve fences verbatim)
    if (/^\s*```/.test(raw)) {
      inFence = !inFence;
      out.push(raw.trimEnd());
      continue;
    }
    if (inFence) {
      out.push(raw.trimEnd());
      continue;
    }

    let s = stripSpeakerPrefixLine(raw);
    s = String(s || "").trimEnd();
    const trimmed = s.trimStart();

    // preserve narration marker
    if (trimmed.startsWith("*") && trimmed.endsWith("*")) {
      out.push(trimmed);
      continue;
    }

    // preserve dialogue quotes (straight/smart)
    if (/^["“]/.test(trimmed)) {
      out.push(ensureQuoted(trimmed));
      continue;
    }

    out.push(s);
  }

  let joined = out.join("\n");
  joined = joined.replace(/[ \t]+\n/g, "\n");
  joined = joined.replace(/\n{3,}/g, "\n\n");
  return joined.trim();
}
function enforceNoPreDialogueTokenLeakForMode(text: string, mode: "chat" | "novel"): string {
  if (mode === "chat") return enforceNoPreDialogueTokenLeak(text);
  const raw = String(text || "");
  if (!raw.trim()) return raw.trim();
  const lines = raw.split(/\r?\n/);

  const getDialogueContent = (line: string): string | null => {
    const s = String(line || "").trim();
    const m = s.match(/^["“]([\s\S]*?)["”]\s*$/);
    if (!m) return null;
    const inside = String(m[1] || "").trim();
    return inside ? inside : null;
  };

  const firstDialogueIdx = lines.findIndex((l) => !!getDialogueContent(l));
  if (firstDialogueIdx < 0) return raw.trim();

  const dialogueContents: string[] = [];
  for (let i = firstDialogueIdx; i < lines.length; i++) {
    const c = getDialogueContent(lines[i]);
    if (c) dialogueContents.push(c);
  }
  if (!dialogueContents.length) return raw.trim();

  const stop = new Set(
    [
      "그리고","하지만","그런데","그래서","그러나","그냥","그저","정말","진짜","일단","지금","오늘","내일","어제","너","나","우리","그","이","저","것","수","때","좀","더","잘","못","왜","뭐","뭔","뭐야","어떤","이런","그런","저런","여기","거기","저기","같이","아마","벌써","다시","계속","이제","또","너무","조금",
    ].map((s) => s.toLowerCase())
  );

  const tokensSet = new Set<string>();
  for (const t of dialogueContents) {
    const ko = t.match(/[가-힣]{2,}/g) || [];
    const en = t.match(/[A-Za-z]{3,}/g) || [];
    for (const w of [...ko, ...en]) {
      const ww = String(w || "").trim();
      if (!ww) continue;
      const key = ww.toLowerCase();
      if (stop.has(key)) continue;
      tokensSet.add(ww);
    }
  }
  const tokens = Array.from(tokensSet);
  if (!tokens.length) return raw.trim();

  const pre = lines.slice(0, firstDialogueIdx);
  const post = lines.slice(firstDialogueIdx);
  const moved: string[] = [];
  const kept: string[] = [];

  const containsAnyToken = (line: string) => {
    const s = String(line || "");
    if (!s.trim()) return false;
    if (getDialogueContent(s)) return false;
    for (const tok of tokens) {
      if (tok.length < 2) continue;
      if (s.includes(tok)) return true;
      const low = tok.toLowerCase();
      if (/[A-Za-z]/.test(tok) && s.toLowerCase().includes(low)) return true;
    }
    return false;
  };

  for (const line of pre) {
    if (containsAnyToken(line)) moved.push(line);
    else kept.push(line);
  }

  const merged = [...kept, ...post, ...moved].join("\n");
  return merged.replace(/\n{3,}/g, "\n\n").trim();
}

function formatStoryTurnsForMode(msgs: any[], personaName: string, npcName: string, mode: "chat" | "novel"): string {
  if (mode === "chat") return formatStoryTurns(msgs, personaName, npcName);
  const parts: string[] = [];
  for (const m of msgs || []) {
    const c = String((m as any)?.content || "");
    const cleaned = normalizeNovelPlain(c);
    if (cleaned) parts.push(cleaned);
  }
  return parts.join("\n\n").trim();
}

function buildUserLineForMode(userText: string, personaName: string, mode: "chat" | "novel"): string {
  if (mode === "chat") {
    // 기존 채팅모드 규칙 유지: 주인공 | "..."
    const userLineRaw = ensurePrefix(userText, personaName);
    const m = userLineRaw.match(/^(.+?)\s*\|\s*(.+)$/);
    if (!m) return userLineRaw;
    const speaker = m[1].trim();
    let content = m[2].trim();
    if (!(content.startsWith("\"") || content.startsWith("“"))) {
      content = `\"${content}\"`;
    }
    return `${speaker} | ${content}`;
  }
  // novel: 기본은 큰따옴표(대사)로 보내되, 사용자가 명시한 형식은 보존한다.
  // - *지문* 은 지문으로 그대로 전달
  // - ```ANY_LABEL ...``` 메타 패널은 그대로 전달
  // - 이미 따옴표로 감싼 대사는 유지(끝따옴표만 보정)
  const stripped = String(stripSpeakerPrefixLine(String(userText || "")) || "").trim();
  if (!stripped) return '""';

  // fenced meta block (any label) - preserve as-is
  if (/^```/.test(stripped)) return stripped;

  // narration explicitly marked
  if (stripped.startsWith("*") && stripped.endsWith("*")) return stripped;

  // default: dialogue
  return ensureQuoted(stripped);
}

function stripNamePrefixFromNarration(line: string) {
  const s = String(line || "");
  const m = s.match(/^(.+?)\s*\|\s*(.+)$/);
  if (!m) return s;
  const rhs = String(m[2] || "").trimStart();
  if (!rhs) return rhs;
  const first = rhs[0];
  const isQuoted = first === '"' || first === "'" || first === "“" || first === "‘";
  return isQuoted ? s : rhs;
}

// 대사 포맷으로 감싸진 지문을 감지해 지문으로 되돌립니다.
// 예) 이름 | "지은이는 ..."  ->  *지은이는 ...*
function stripDialogueWrappedNarration(raw: string): string {
  const lines = String(raw || "").split(/\r?\n/);
  const out: string[] = [];
  for (const line of lines) {
    const m = line.match(/^\s*([^|]{1,40})\s*\|\s*["“”]\s*([\s\S]*?)\s*["”]\s*$/);
    if (!m) {
      out.push(line);
      continue;
    }
    const inside = (m[2] || "").trim();
    // 명백한 대사 특징(물음/느낌, 인용, 직접호칭 등)이 없고 서술형 동사가 있으면 지문으로 간주
    const looksDialogue = /[?!！？]/.test(inside) || /"|“|”/.test(inside);
    const looksNarrationVerb = /(했다|있었다|없었다|이었다|였다|느꼈|생각했|바라봤|놀랐|붙잡|속삭|말했|되었|되어|흔들|굳어|달아올)/.test(inside);
    if (!looksDialogue && looksNarrationVerb) {
      out.push(`*${inside}*`);
    } else {
      out.push(line);
    }
  }
  return out.join("\n");
}

function removeEndMarker(s: string): string {
  return String(s || "")
    .replace(/\r?\n?\[END\]\s*$/i, "")
    .replace(/\[END\]\s*$/i, "")
    .replace(/\r?\n\s*\[END\]\s*\r?\n/g, "\n")
    .trimEnd();
}

// (강화) "대사가 나오기도 전에 지문에서 그 대사(단어/표현)에 반응"하는 미래침범을 최대한 억제한다.
// - 같은 답변 안에서 지문 → 대사 순서일 때,
//   지문(대사 이전 구간)에 곧이어 나올 대사 내용(단어/표현)을 먼저 쓰지 않도록
//   **대사에 등장하는 핵심 토큰이 포함된 지문 라인**을 대사 뒤로 이동한다.
// - 완벽한 의미적 차단은 아니지만, 실제로 자주 나오는 "'사장'이라는 단어에..." 류의
//   노골적인 선행 언급을 강하게 줄인다.
function enforceNoPreDialogueTokenLeak(text: string): string {
  const raw = String(text || "");
  if (!raw.trim()) return raw.trim();

  const lines = raw.split(/\r?\n/);

  const getDialogueContent = (line: string): string | null => {
    // 이름 | "..." (큰따옴표/스마트따옴표 지원)
    const m = String(line || "").match(/^\s*[^|]{1,40}\s*\|\s*["“]([\s\S]*?)["”]\s*$/);
    if (!m) return null;
    const inside = String(m[1] || "").trim();
    return inside ? inside : null;
  };

  const firstDialogueIdx = lines.findIndex((l) => !!getDialogueContent(l));
  if (firstDialogueIdx < 0) return raw.trim();

  const dialogueContents: string[] = [];
  for (let i = firstDialogueIdx; i < lines.length; i++) {
    const c = getDialogueContent(lines[i]);
    if (c) dialogueContents.push(c);
  }
  if (!dialogueContents.length) return raw.trim();

  // 토큰 추출: 한글은 2자 이상, 영문은 3자 이상만.
  const stop = new Set(
    [
      // 아주 흔한 기능어/대명사/접속어(오탐 줄이기)
      "그리고",
      "하지만",
      "그런데",
      "그래서",
      "그러나",
      "그냥",
      "그저",
      "정말",
      "진짜",
      "일단",
      "지금",
      "오늘",
      "내일",
      "어제",
      "너",
      "나",
      "우리",
      "그",
      "이",
      "저",
      "것",
      "수",
      "때",
      "좀",
      "더",
      "잘",
      "못",
      "왜",
      "뭐",
      "뭔",
      "뭐야",
      "어떤",
      "이런",
      "그런",
      "저런",
      "여기",
      "거기",
      "저기",
      "같이",
      "아마",
      "벌써",
      "다시",
      "계속",
      "이제",
      "또",
      "너무",
      "조금",
    ].map((s) => s.toLowerCase())
  );

  const tokensSet = new Set<string>();
  for (const t of dialogueContents) {
    const ko = t.match(/[가-힣]{2,}/g) || [];
    const en = t.match(/[A-Za-z]{3,}/g) || [];
    for (const w of [...ko, ...en]) {
      const ww = String(w || "").trim();
      if (!ww) continue;
      const key = ww.toLowerCase();
      if (stop.has(key)) continue;
      tokensSet.add(ww);
    }
  }
  const tokens = Array.from(tokensSet);
  if (!tokens.length) return raw.trim();

  const pre = lines.slice(0, firstDialogueIdx);
  const post = lines.slice(firstDialogueIdx);

  const moved: string[] = [];
  const kept: string[] = [];

  const containsAnyToken = (line: string) => {
    const s = String(line || "");
    if (!s.trim()) return false;
    // 대사 라인은 건드리지 않는다.
    if (getDialogueContent(s)) return false;
    for (const tok of tokens) {
      if (tok.length < 2) continue;
      if (s.includes(tok)) return true;
      // 영문 토큰은 대소문자 흔들림이 있어 추가로 케이스 인센서티브 검사
      if (/[A-Za-z]/.test(tok) && s.toLowerCase().includes(tok.toLowerCase())) return true;
    }
    return false;
  };

  for (const line of pre) {
    if (containsAnyToken(line)) moved.push(line);
    else kept.push(line);
  }

  if (!moved.length) return raw.trim();

  // 첫 대사 줄 바로 뒤로 이동시켜 "대사 이전 지문"에서의 선행 언급을 제거한다.
  const out = [
    ...kept,
    ...(post.length ? [post[0], ...moved, ...post.slice(1)] : [...moved]),
  ]
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return out;
}



// 모델 출력의 흔한 형태 오류를 최소한으로 정리한다.
// - 지문인데 "이름 | 서윤아는..." 같이 이름 접두가 붙는 케이스
// - 사용자의 최신 대사가 상대(NPC) 쪽으로 잘못 붙는 케이스
function stripTrailingTextAfterFinalFence(text: string): string {
  const s = String(text || "");
  // Find the last complete fenced block ```...```
  const lastClose = s.lastIndexOf("```");
  if (lastClose < 0) return s;
  // Ensure there is an opening fence before the lastClose.
  const before = s.slice(0, lastClose);
  const lastOpen = before.lastIndexOf("```");
  if (lastOpen < 0) return s;
  // We need an even count of fences for a complete block at end.
  // If the final closing fence isn't the end, truncate trailing text.
  const after = s.slice(lastClose + 3);
  if (after.trim().length === 0) return s;
  return (s.slice(0, lastClose + 3)).trimEnd();
}

function stripStandaloneSeparatorLines(s: string): string {
  // Remove noisy standalone separator lines that sometimes appear around images or status blocks.
  // Keeps meaningful content intact.
  return s
    .split(/\r?\n/)
    .filter((line) => {
      const t = line.trim();
      if (!t) return true;
      // '=' or '＝'
      if (/^[=＝]+$/.test(t)) return false;
      // Long dashes/underscores
      if (/^-{3,}$/.test(t)) return false;
      if (/^_{3,}$/.test(t)) return false;
      // Em-dash like separators
      if (/^[—–‐‑‒―━]{3,}$/.test(t)) return false;
      return true;
    })
    .join("\n");
}

function _charLen(s: string): number {
  return Array.from(String(s || "")).length;
}
function _sliceChars(s: string, n: number): string {
  return Array.from(String(s || "")).slice(0, n).join("");
}

function splitTrailingFenceBlockAtEnd(text: string): { body: string; meta: string } {
  const t = String(text || "").trimEnd();
  const re = /```[^\n]*\n[\s\S]*?\n```\s*$/;
  const m = t.match(re);
  if (!m) return { body: t.trim(), meta: "" };
  const meta = String(m[0] || "").trim();
  const body = t.slice(0, t.length - m[0].length).trim();
  return { body, meta };
}

// If a trailing fenced block is too long for the output char budget, truncate its *inside*
// while keeping a valid opening/closing fence.
function truncateFenceBlockToBudget(fenceBlock: string, budget: number): string {
  const fb = String(fenceBlock || "").trim();
  if (!fb.startsWith("```")) return fb;
  if (_charLen(fb) <= budget) return fb;

  const firstNl = fb.indexOf("\n");
  const lastFence = fb.lastIndexOf("```");
  if (firstNl < 0 || lastFence <= 0) return _sliceChars(fb, budget).trim();

  const open = fb.slice(0, firstNl + 1); // includes newline
  const close = "```";
  const inner = fb.slice(firstNl + 1, lastFence).replace(/\s+$/g, "");
  const reserve = _charLen(open) + _charLen("\n…(생략)\n") + _charLen(close);
  const availInner = Math.max(0, budget - reserve);
  const innerCut = _sliceChars(inner, availInner).trimEnd();
  return `${open}${innerCut}\n…(생략)\n${close}`.trim();
}

// Preserve a trailing fenced meta/status block within the char budget by trimming the body first.
// This prevents cases where the narrative consumes the whole budget and the status window gets dropped or cut.
function preserveTrailingFenceBlockWithinBudget(text: string, budget: number): string {
  const t0 = String(text || "").trim();
  const { body, meta } = splitTrailingFenceBlockAtEnd(t0);
  if (!meta) return t0;

  // NOTE:
  // Previously we forced the narrative body to end with a placeholder narration line (`*...*`)
  // right before the trailing meta/status fence. That created unwanted trailing "*...*" lines
  // (especially when the scene already felt concluded).
  // Now we keep the body as-is and only trim it to fit the budget, preserving the fence block.
  let b = String(body || "").trimEnd();

  const metaLen = _charLen(meta);
  const total = _charLen(b) + 2 + metaLen;
  if (total <= budget) return `${b}

${meta}`.trim();

  const availBody = budget - metaLen - 2;
  if (availBody < 10) {
    // Body is too small to keep; prefer preserving the meta fence.
    return truncateFenceBlockToBudget(meta, Math.max(60, budget));
  }

  // Trim body to fit, preferring paragraph/line/sentence boundaries
  let bt = b;
  if (_charLen(bt) > availBody) {
    const head = _sliceChars(bt, availBody);
    // Prefer cutting on paragraph, then line, then sentence boundaries.
    const candidates = ["\n\n", "\n", ".", "!", "?", "\"", "'", ")", "]"];
    let cut = -1;
    for (const c of candidates) {
      const idx = head.lastIndexOf(c);
      if (idx > cut) cut = idx;
    }
    bt = (cut >= Math.floor(availBody * 0.55)) ? head.slice(0, cut + 1) : head;
    bt = bt.trimEnd();
  }

  return `${bt}

${meta}`.trim();
}

// main 출력에서 모든 fenced 코드블록을 제거한다.
// (상태창/메타는 /api/chat/update-status 에서 별도 렌더링)
function stripAllFencedBlocks(text: string): string {
  const s0 = String(text || "");
  // 1) 완전한 fenced 블록 제거
  let s = s0.replace(/```[\s\S]*?```/g, "");
  // 2) 혹시 남은 백틱 라인 제거
  s = s.replace(/(^|\n)\s*```[^\n]*\n?/g, "$1");
  // 3) 과도한 줄바꿈 정리
  s = s.replace(/\n{3,}/g, "\n\n");
  return s.trim();
}



function endsWithCompleteFence(text: string): boolean {
  const s = String(text || "").trimEnd();
  if (!s.endsWith("```")) return false;
  // Find the last two fences
  const last = s.lastIndexOf("```");
  const prev = s.lastIndexOf("```", last - 1);
  return prev >= 0;
}

function findLastStatusFenceCloseEnd(text: string): number {
  const s = String(text || "");
  const re = /(^|\n)\s*```\s*STATUS\b/gi;
  let m: RegExpExecArray | null = null;
  let lastIdx = -1;
  while ((m = re.exec(s))) {
    // m.index points at start of match; find the first backticks in this match
    const mi = m.index;
    const bt = s.indexOf("```", mi);
    if (bt >= 0) lastIdx = bt;
  }
  if (lastIdx < 0) return -1;
  const closeIdx = s.indexOf("```", lastIdx + 3);
  if (closeIdx < 0) return -1;
  return closeIdx + 3;
}

function normalizeNovelOutput(text: string, personaName: string, npcName: string, latestUserLine?: string) {
  const raw = String(text || "");
  const norm = (s: string) =>
    String(s || "")
      .replace(/[\s\u200b\u200c\u200d]+/g, "")
      .replace(/["'“”‘’\.,!?！？。…]/g, "")
      .trim();
  const latestNorm = latestUserLine ? norm(latestUserLine.replace(new RegExp(`^${personaName}\s*\|\s*`), "")) : "";

  const out: string[] = [];
  for (const line0 of raw.split("\n")) {
    // (1) 지문 앞에 이름 접두가 붙는 경우 제거
    const line = stripNamePrefixFromNarration(line0);
    const m = line.match(/^(.+?)\s*\|\s*(.+)$/);
    if (!m) {
      out.push(line);
      continue;
    }
	    let speaker = String(m[1] || "").trim();
    const rhs = String(m[2] || "").trim();

	    // 모델이 습관적으로 주인공 화자를 "주인공"으로 고정해서 출력하는 경우가 있어,
	    // 실제 설정된 페르소나명이 있으면 강제로 교정한다.
	    if (speaker === "주인공" && personaName && personaName !== "주인공") {
	      speaker = personaName;
	    }

    // 0) (요구사항)
    // 지문(서술) 앞에 "이름 |"가 붙는 형태를 제거한다.
    // - 대사는 반드시 큰따옴표로 감싸야 하므로(규칙), 따옴표가 없으면 지문으로 간주한다.
    // - 예: "서윤아 | 사무실의 공기는..." -> "*사무실의 공기는...*"
    const looksLikeDialogue = rhs.startsWith("\"") || rhs.startsWith("“");
    if (!looksLikeDialogue && !rhs.startsWith("*")) {
      out.push(`*${rhs}*`);
      continue;
    }

    // 1) 지문인데 "이름 | 서윤아는..." 형태로 온 경우: 접두를 제거하고 *...*로 감싼다.
    const looksLikeNarration =
      rhs.startsWith(personaName + "는") ||
      rhs.startsWith(personaName + "은") ||
      rhs.startsWith(personaName + "이") ||
      rhs.startsWith(personaName + "가") ||
      rhs.startsWith(npcName + "는") ||
      rhs.startsWith(npcName + "은") ||
      rhs.startsWith(npcName + "이") ||
      rhs.startsWith(npcName + "가");
    // 1) 지문인데 "이름 | 서윤아는..." 형태로 온 경우: 접두를 제거하고 *...*로 감싼다.
    if (looksLikeNarration && !rhs.startsWith("*") && !looksLikeDialogue) {
      out.push(`*${rhs}*`);
      continue;
    }

    // NOTE: 0)에서 이미 "따옴표 없는 speaker|"는 지문으로 정리되므로,
    // 여기서는 추가 휴리스틱이 필요 없다.

    // 2) 최신 유저 대사가 NPC에 붙는 경우: speaker를 주인공으로 교정
	    if (latestNorm && speaker === npcName && norm(rhs) === latestNorm) {
      out.push(`${personaName} | ${rhs}`);
      continue;
    }

    out.push(line);
  }
  return stripTrailingTextAfterFinalFence(out.join("\n").trim());
}

function normalizeSummaryTail(summaryText: string): string {
  const t = String(summaryText || "").trimEnd();
  if (!t) return t;

  const lines = t.split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i--) {
    const lnRaw = lines[i];
    const ln = String(lnRaw || "").trim();
    if (!ln) continue;

    // 헤더 라인은 그대로 둔다.
    if (/^#{2,4}\s+/.test(ln)) break;

    // 문장부호로 끝나면 OK
    if (/[.!?…。]$/.test(ln)) break;

    // 한국어 종결형(다/요)로 끝나면 마침표를 보강
    if (/[다요]$/.test(ln)) {
      lines[i] = ln + ".";
      break;
    }

    // 그 외는 '끊긴 문장' 가능성이 있지만, UI에서 내용이 사라지며 "빠지는" 현상이 생길 수 있어
    // 가능한 한 완결로 보강한다.
    if (ln.length <= 8) {
      lines.splice(i, 1);
      break;
    }
    if (/[가-힣]/.test(ln)) {
      lines[i] = ln + ".";
      break;
    }
    // 한국어가 거의 없는 경우에는 제거(노이즈)
    lines.splice(i, 1);
    break;
  }

  return lines.join("\n").trimEnd();
}

// (안전) 장기기억 요약에 모델이 프롬프트/메타 텍스트를 그대로 섞어 반환하는 경우가 있어
// UI/DB에 저장하기 전에 제거한다.
// - "start_thought" / 영어 지시문 / Dialogue Context 등
// - 유효한 "## 장기 기억 (a-b턴)" 블록만 남긴다.

function sanitizeLongMemorySummary(input: string, summaryEvery: number): string {
  const raw = String(input || "").replace(/\r\n/g, "\n");
  const headerRe = /^##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*(?:턴)?\s*\)\s*$/gm;

  type Hit = { start: number; end: number; idx: number; len: number };
  const hits: Hit[] = [];
  for (const m of raw.matchAll(headerRe)) {
    const idx = m.index ?? 0;
    const st = Number(m[1]);
    const ed = Number(m[2]);
    if (!Number.isFinite(st) || !Number.isFinite(ed) || ed < st) continue;
    hits.push({ start: st, end: ed, idx, len: m[0].length });
  }
  if (hits.length === 0) return "";

  // Sort by appearance order (idx) to slice bodies
  hits.sort((a, b) => a.idx - b.idx);

  const byStart = new Map<number, { start: number; end: number; text: string }>();

  const isMetaLine = (t: string) => {
    return (
      /^start_thought\b/i.test(t) ||
      /Long[- ]term Memory Summary Writer/i.test(t) ||
      /Dialogue Context/i.test(t) ||
      /Correction on Turn Indexing/i.test(t) ||
      /^Korean only\./i.test(t) ||
      /^Markdown\./i.test(t) ||
      /^Summary of the provided/i.test(t)
    );
  };

  const sanitizeBody = (body: string, blockStart: number) => {
    let out = String(body || "").replace(/\r\n/g, "\n");

    // remove meta + dialogue echo lines
    const lines = out.split("\n");
    const kept: string[] = [];
    for (const line of lines) {
      const tr = line.trim();
      if (!tr) {
        kept.push(line);
        continue;
      }
      if (isMetaLine(tr)) continue;
      if (/^###\s*\(대화\s*요약\)/.test(tr)) continue;
      if (/(사용자\s*:|어시스턴트\s*:|User\s*:|Assistant\s*:)/i.test(tr)) continue;
      kept.push(line);
    }
    out = kept.join("\n");

    // repair missing ')' at end-of-line like '(1-2턴'
    out = out.replace(/\((\s*\d+\s*[-–~]\s*\d+\s*(?:턴)?\s*)$/gm, (_m, body) => `(${body})`);
    out = out.replace(/\((\s*\d+\s*(?:턴)?\s*)$/gm, (_m, body) => `(${body})`);

    const offset = blockStart > 1 ? blockStart - 1 : 0;

    const shiftIfRelative = (a: number, b: number) => {
      if (blockStart > 1 && b <= summaryEvery && b < blockStart) return [a + offset, b + offset] as const;
      return [a, b] as const;
    };

    // normalize '(a-b)' / '(a-b턴)' -> '(a-b턴)' and '(a-a)' -> '(a턴)'
    out = out.replace(/\(\s*(\d+)\s*[-–~]\s*(\d+)\s*(?:턴)?\s*\)/g, (m0, aS, bS) => {
      let a = Number(aS);
      let b = Number(bS);
      if (!Number.isFinite(a) || !Number.isFinite(b)) return m0;
      [a, b] = shiftIfRelative(a, b);
      if (a === b) return `(${a}턴)`;
      return `(${a}-${b}턴)`;
    });
    out = out.replace(/\(\s*(\d+)\s*(?:턴)?\s*\)/g, (m0, nS) => {
      let n = Number(nS);
      if (!Number.isFinite(n)) return m0;
      const [nn] = shiftIfRelative(n, n);
      return `(${nn}턴)`;
    });

    // normalize whitespace
    out = out.replace(/\n{3,}/g, "\n\n").trim();

    // ensure ending punctuation for UX
    if (out && !/[\.!?…。…\)\]\"”’》〉]$/.test(out)) out += ".";

    return out;
  };

  for (let i = 0; i < hits.length; i++) {
    const h = hits[i];
    const nextIdx = i + 1 < hits.length ? hits[i + 1].idx : raw.length;
    const bodyStart = h.idx + raw.slice(h.idx).split("\n")[0].length; // end of header line
    const body = raw.slice(bodyStart, nextIdx).replace(/^\n/, "");

    // enforce expected range length
    // - 일반 블록: (end-start+1) == summaryEvery
    // - 롤업 블록: 1부터 시작하며 (end-start+1)이 summaryEvery의 배수(여러 구간을 1개로 압축)
    const size = h.end - h.start + 1;
    const isRollup =
      summaryEvery > 0 && h.start === 1 && size >= summaryEvery && size % summaryEvery === 0 && h.end % summaryEvery === 0;
    if (summaryEvery > 0 && !isRollup && size != summaryEvery) continue;
    if (h.start < 1) continue;
    if (summaryEvery > 0 && !isRollup && (h.start - 1) % summaryEvery != 0) continue;

    const cleanedBody = sanitizeBody(body, h.start);

    // (완화) ### 헤딩이 없다고 요약을 통째로 버리면 빈 요약이 자주 발생한다.
    // - 헤딩은 강제 제거(텍스트만 남김)
    // - 의미 길이(공백 제거 후)가 너무 짧으면 제외
    const bodyNoHeadings = cleanedBody.replace(/^\s*#{1,6}\s+/gm, "");
    const meaningfulLen = bodyNoHeadings.replace(/\s/g, "").length;
    if (meaningfulLen < 20) continue;

    const finalBody = bodyNoHeadings.replace(/\n{3,}/g, "\n\n").trim();
    const fullText = `## 장기 기억 (${h.start}-${h.end}턴)\n\n${finalBody}`.trim();
    const prev = byStart.get(h.start);
    if (!prev || fullText.length >= prev.text.length) {
      byStart.set(h.start, { start: h.start, end: h.end, text: fullText });
    }
  }

  if (byStart.size === 0) return "";

  const blocks = [...byStart.values()].sort((a, b) => a.start - b.start);

  // keep only contiguous blocks from turn 1 onward
  const kept: string[] = [];
  let expectedStart = 1;
  for (const b of blocks) {
    if (b.start != expectedStart) break;
    const size = b.end - b.start + 1;
    const isRollup =
      summaryEvery > 0 && b.start === 1 && size >= summaryEvery && size % summaryEvery === 0 && b.end % summaryEvery === 0;
    if (summaryEvery > 0 && !isRollup && b.end != b.start + summaryEvery - 1) break;
    kept.push(b.text);
    expectedStart = b.end + 1;
  }

  return kept.join("\n\n").trim();
}

function upsertSummaryRangeBlock(prev: string, block: string, st: number, ed: number): string {
  const p = String(prev || "").trim();
  const b = String(block || "").trim();
  if (!b) return p;

  const header = `## 장기 기억 (${st}-${ed}턴)`;
  // block 자체에 header가 없다면 붙여준다(안전).
  const normalized = b.startsWith("##") ? b : `${header}\n\n${b}`;

  if (!p) return normalized;

  // 동일 구간 block이 있으면 교체, 없으면 append
  const re = new RegExp(
    `(^##\\s*장기\\s*기억\\s*\\(\\s*${st}\\s*-\\s*${ed}\\s*턴\\s*\\)[\\s\\S]*?)(?=^##\\s*장기\\s*기억\\s*\\(|\\s*$)`,
    "m"
  );

  if (re.test(p)) {
    return p.replace(re, normalized + "\n\n");
  }
  return `${p}\n\n${normalized}`.trim();
}



function estTokens(text: string) {
  // 아주 러프한 추정(실제 토큰과 다를 수 있음)
  const t = String(text || "").trim();
  if (!t) return 0;
  return Math.ceil(t.length / 4);
}

// 가능한 한 '완결된 문장'에서 잘라 UI에 미완성 문장이 노출되지 않도록 한다.
function trimToComplete(text: string) {
  const t = String(text || "").trim();
  if (!t) return t;

  // 마지막 종결 후보(. ! ? " ' ) ]) 중 가장 뒤를 기준으로 자른다.
  // 주의: '*'는 지문(*...*)에서 매우 자주 등장하므로 종결 후보에서 제외한다.
  // 또한 "너무 앞에서" 자르면 정상 문단까지 잘려서 오히려 답변이 극단적으로 짧아질 수 있으므로,
  // cut 지점 이후 남는 길이가 충분히 크면(=앞에서 잘리는 케이스) 아예 자르지 않는다.
  // 문자열 리터럴 안에서 따옴표는 반드시 이스케이프한다.
  const candidates = [".", "!", "?", "\"", "'", ")", "]"];
  let cut = -1;
  for (const c of candidates) {
    const idx = t.lastIndexOf(c);
    if (idx > cut) cut = idx;
  }
  if (cut <= 0) return t;

  // cut 이후에 남는 텍스트가 너무 많으면(앞부분만 남기게 되면) 자르지 않는다.
  const tailLen = t.length - (cut + 1);
  if (tailLen >= 120) return t;

  return t.slice(0, cut + 1).trim();
}


// --- Prompt/Output sanitizers (Option A: novel-only) ---
// Avoid feeding markdown-y scaffolding into the model; it tends to leak into output during streaming.
function sanitizePromptForModel(text: string): string {
  const s = String(text ?? "");
  if (!s) return s;
  const lines = s.split(/\r?\n/);
  const out: string[] = [];
  for (let line of lines) {
    // Strip leading markdown heading/bullet/quote markers that can "infect" generation.
    line = line.replace(/^\s{0,3}(#{1,6}\s+)+/g, "");
    line = line.replace(/^\s{0,3}[-*+]\s+/g, "");
    line = line.replace(/^\s{0,3}>\s+/g, "");
    // Collapse accidental table pipes
    if (/^\s*\|.*\|\s*$/.test(line)) line = line.replace(/\|/g, " ");
    out.push(line);
  }
  return out.join("\n").trim();
}

// Enforce output rules softly without rewriting story content.
// - Remove markdown headings/bullets/links that break the client streaming parser.
// - Keep *...* and "..." as-is.
function enforceNovelOnlyOutput(text: string): string {
  let s = String(text ?? "");
  if (!s) return s;

  // Remove markdown headings at line starts
  s = s.replace(/^\s{0,3}#{1,6}\s+/gm, "");

  // Remove list bullets at line starts
  s = s.replace(/^\s{0,3}[-*+]\s+/gm, "");

  // Strip markdown link syntax: [text](url) -> text
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1");

  // Strip bold/italic markers that can appear mid-stream
  s = s.replace(/\*\*([^*]+)\*\*/g, "$1");
  s = s.replace(/__([^_]+)__/g, "$1");

  return s;
}

export async function POST(req: Request) {
  const _reqId = `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
  const _url = new URL(req.url);
  console.log(`[chat/send][${_reqId}] -> ${req.method} ${_url.pathname}${_url.search}`);
  // 요청 헤더(ua/referer...) 로그는 너무 시끄러워서 기본 비활성.
  // 필요 시 CHAT_DEBUG_HEADERS=1 로만 켠다.
  if (process.env.CHAT_DEBUG_HEADERS === "1") {
    console.log(
      `[chat/send][${_reqId}] ua=${req.headers.get("user-agent") || ""} referer=${req.headers.get("referer") || ""}`
    );
  }
  // try/catch 경계에서 사용할 최소 로그 컨텍스트(블록 스코프 이슈 방지)
  let _cidForLog = "";
  let _reqIdForLog = "";
  let debugReasons: string[] = [];
  let _tEnd: (label: string) => void = () => {};
  let _tSendTotal = "";
  let _tPost = "";
  try {
    const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });

  const body = await req.json();
    // body.userText 는 프론트에서 보내는 입력 텍스트.
    // 아래에서 동일 변수명을 다시 선언하지 않도록 별칭을 준다.
    const { chatId, message, userText: userTextInput, presetId, personaOverride, regenerate, userMessageId, replaceAssistantId, runtime } = body || {};

    const cid = String(chatId || "").trim();
	    _cidForLog = cid;
    const finalUserText = String((typeof userTextInput === "string" ? userTextInput : message) || "").trim();
    const regen = Boolean(regenerate);
    const replaceAid = String(replaceAssistantId || "").trim();
    const userMid = String(userMessageId || "").trim();

    let effectiveUserText = finalUserText;

    // 재생성 모드면: userMessageId 기준으로 DB에서 읽어와 정확한 원문을 사용
    if (regen && userMid) {
      const row = db.prepare(`SELECT content FROM messages WHERE id=?`).get(userMid) as any;
      const raw = row?.content ? decryptIfPossible(row.content) : "";
      effectiveUserText = String(raw || finalUserText || "").trim();
    }

    const userText = effectiveUserText;
    if (!cid) return bad("채팅이 없습니다. 먼저 '새 채팅 만들기'를 눌러주세요.");
    if (!userText) return bad("메시지를 입력해 주세요.");

	    const reqId = randomUUID();
	    _reqIdForLog = reqId;
    const tSendTotal = `send.total:${cid}:${reqId}`;
    const tPrompt = `send.prompt.build:${cid}:${reqId}`;
    const tGemini = `send.gemini.call:${cid}:${reqId}`;
    const tPost = `send.postprocess:${cid}:${reqId}`;
	    _tSendTotal = tSendTotal;
	    _tPost = tPost;

    // console.time/timeEnd는 dev/서버 환경에서 라벨 중복/예외 미종료로 경고가 자주 뜬다.
    // 대신 Date.now() 기반으로 안정적인 타이밍 로그를 남긴다.
    const _marks = new Map<string, number>();
    const tStart = (label: string) => {
      _marks.set(label, Date.now());
      return label;
    };
    const tEnd = (label: string) => {
      const t0 = _marks.get(label);
      if (typeof t0 !== "number") return;
      const ms = Date.now() - t0;
      const s = ms >= 1000 ? `${(ms / 1000).toFixed(3)}s` : `${ms.toFixed(3)}ms`;
      console.log(`${label}: ${s}`);
      _marks.delete(label);
    };
	    _tEnd = tEnd;

	    tStart(tSendTotal);
	    tStart(tPrompt);
	    debugReasons = [];

    const tDbChat = `step.db.채팅:${cid}:${reqId}`;
    tStart(tDbChat);
    const chat = db.prepare(`SELECT id, presetId FROM chats WHERE id=?`).get(cid) as any;
    tEnd(tDbChat);
    if (!chat) return NextResponse.json({ error: "채팅을 찾지 못했습니다." }, { status: 404 });

    const tDbPreset = `step.db.프리셋:${cid}:${reqId}`;
    tStart(tDbPreset);
    const preset = db
      .prepare(
        `SELECT id, name, background, characterName, characterAge, character, systemPrompt,
                firstMessages, lorebooks
         FROM presets WHERE id=?`
      )
      .get(chat.presetId) as any;
    tEnd(tDbPreset);

    if (!preset) return NextResponse.json({ error: "프리셋을 찾지 못했습니다." }, { status: 404 });

    // chat_settings가 없는 경우(마이그레이션/생성 중 누락 등)에는 여기서 기본값으로 자동 생성한다.
    // 404로 떨어지면 프론트에서는 "라우트가 없다"로 오해하기 쉬워 디버깅이 매우 어려워진다.
    const tDbSettings = `step.db.설정:${cid}:${reqId}`;
    tStart(tDbSettings);
    let settings = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(cid) as any;
    tEnd(tDbSettings);
    if (!settings) {
      try {
        db.prepare(`INSERT OR IGNORE INTO chat_settings (chatId, updatedAt) VALUES (?, ?)`).run(cid, Date.now());
      } catch {
        // ignore
      }
      settings = db.prepare(`SELECT * FROM chat_settings WHERE chatId=?`).get(cid) as any;
    }
    if (!settings) return NextResponse.json({ error: "채팅 설정을 찾지 못했습니다." }, { status: 400 });

    // (중요) 페르소나는 "settings"(DB 저장값) + "personaOverride"(프론트 임시값)을 합쳐서 결정한다.
    // settings에 이름이 비어있으면, override 기반으로 1회 저장해 다음 호출부터 안정적으로 유지한다.
    const persona = resolvePersona(settings, (personaOverride || null) as PersonaOverride);
    persistPersonaIfMissing(cid, settings, persona);


    const renderMode: "chat" | "novel" = settings?.renderMode === "chat" ? "chat" : "novel";

    const now = Date.now();

    // 1) 유저 메시지 저장(재생성 모드면 저장하지 않음)
    const userMsg = {
      id: regen && userMid ? userMid : randomUUID(),
      chatId: cid,
      role: "user" as const,
      content: userText,
      createdAt: now,
    };

    if (!regen) {
      db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
        userMsg.id,
        userMsg.chatId,
        userMsg.role,
        encryptIfPossible(userMsg.content),
        userMsg.createdAt
      );
    }

    // 2) 전체 메시지 로드
    const tDbMsgs = tStart("db.전체메시지 로드");
    const all = db
      .prepare(`SELECT role, content, createdAt FROM messages WHERE chatId=? ORDER BY createdAt ASC`)
      .all(cid)
      .map((m: any) => ({ ...m, content: decryptIfPossible(m.content) })) as any[];
    tEnd(tDbMsgs);
    // 3) 메모리 구성:
    // - 최근 컨텍스트는 "유저 입력 K턴" 기준으로 포함한다 (user 메시지 1개 = 1턴)
    // - 장기기억(요약)은 '유저 입력 턴' 기준으로 [memoryFrom..memoryTo] 범위의 대화를 요약
    // - 요약은 매 요청마다 다시 만들지 않고, summaryEvery(5~10턴)마다 갱신 + 설정 변경 시 강제 갱신

    // 최근 K턴(= user 메시지 K개) 원문을 그대로 프롬프트에 포함한다.
// - UI에서는 최근 K턴 조절을 제거했으므로, 서버 기본값을 사용한다.
// - 런타임 옵션(runtime.keepUserTurns)이 오면 그 값을 우선한다.
// - 기본은 10턴(유저 입력 10개)으로 둔다. (요약 주기 최대값이 10턴이므로, 최소한 한 주기 분량은 원문 맥락을 유지)
const DEFAULT_KEEP_USER_TURNS = 10;
const rtKeep = Number((runtime && typeof runtime === "object") ? (runtime as any).keepUserTurns : NaN);
const keepUserTurnsRaw = Number.isFinite(rtKeep)
  ? rtKeep
  : Number(settings.memoryFrom ?? DEFAULT_KEEP_USER_TURNS);
const keepUserTurns = Math.max(0, Math.min(20, Math.floor(keepUserTurnsRaw)));
    const tTail = tStart("유저프롬프트.최근K턴 선별");
    const tail = selectRecentByUserTurns(all, keepUserTurns);
    tEnd(tTail);

    // 유저 입력만 카운트해서 "입력 턴"을 만든다. (user 메시지 1개 = 1턴)
    let userTurnCount = 0;
    for (const m of all) {
      if (m.role === "user") userTurnCount += 1;
    }

    const rtModel = String((runtime && typeof runtime === "object") ? runtime.model : "").trim();
    const rtOut = Number((runtime && typeof runtime === "object") ? runtime.maxOutputTokens : NaN);
    const rtReason = Number((runtime && typeof runtime === "object") ? runtime.maxReasoningTokens : NaN);

    const opts = {
      model: rtModel || settings.model || "gemini-2.5-pro",
      maxOutputTokens: (() => {
        const v = Number.isFinite(rtOut) ? rtOut : Number(settings.maxOutputTokens ?? 1024);
        return Math.max(800, Math.min(5000, Math.floor(v)));
      })(),
      maxReasoningTokens: (() => {
        const v = Number.isFinite(rtReason) ? rtReason : Number(settings.maxReasoningTokens ?? 1024);
        return Math.max(256, Math.min(8192, Math.floor(v / 256) * 256));
      })(),
    };

    // 요약 대상: tail(최근 원문) 제외한 과거 메시지 전체
    // (디버그 로그에서도 참조하므로 먼저 계산한다)
    const olderMsgs = all.slice(0, Math.max(0, all.length - tail.length));

    dbg({
      tag: "send.context",
      chatId: cid,
      reqId,
      model: opts.model,
      maxOutputTokens: opts.maxOutputTokens,
      maxReasoningTokens: opts.maxReasoningTokens,
      keepUserTurns,
      totalMessages: all.length,
      totalUserTurns: userTurnCount,
      tailMessages: tail.length,
      olderMessages: olderMsgs.length,
    });

    // NOTE: 과거 로깅 추가 중 'summaryEvery' 식별자에서 TDZ(Temporal Dead Zone) ReferenceError가
    // 발생한 케이스가 있어, dev 번들(Turbopack)에서도 안전하도록 다른 변수명으로 분리한다.
    // 요약 주기: UI에서 3~12를 사용하므로 서버도 동일 범위를 적용
    const summaryEveryVal = Math.max(3, Math.min(12, Number(settings.summaryEvery ?? 8)));

    // 턴당 글자수: UI는 100~2000(10단위) 사용.
    // - 기존 summaryLength 컬럼을 "턴당 글자"로 사용한다.
    // - UI/런타임에서 조절하는 값을 우선 적용한다.
    const rtPerTurn = Number((runtime && typeof runtime === "object") ? (runtime as any).perTurnChars : NaN);
    const perTurnCharsVal = (() => {
      const raw = Number.isFinite(rtPerTurn) ? rtPerTurn : Number(settings.summaryLength ?? 420);
      const v = Number.isFinite(raw) ? raw : 420;
      // 10단위로 정규화 (100~2000)
      const stepped = Math.round(v / 10) * 10;
      return Math.max(100, Math.min(2000, stepped));
    })();

    

    // '턴'은 기본적으로 1개의 assistant 응답(=완료된 대화 1턴)으로 계산한다.
    // - UI에서 '요약 주기 N턴'은 사용자 체감 기준(문답 1회 = 1턴)에 맞추기 위해 assistant 기준으로 맞춘다.
    const isAsstRole = (role: any) => {
      const r = String(role || "").toLowerCase();
      return r === "assistant" || r === "model";
    };
    const countAssistantTurns = (msgs: any[]) => msgs.reduce((acc, m) => acc + (isAsstRole(m?.role) ? 1 : 0), 0);
    const countAssistantTurnsUpTo = (msgs: any[], ts: number) => {
      if (!ts) return 0;
      return msgs.reduce((acc, m) => acc + (isAsstRole(m?.role) && Number(m?.createdAt || 0) <= ts ? 1 : 0), 0);
    };

    const completedTurnCount = countAssistantTurns(all);
// 4) 장기기억 요약 캐시 로드 (UI의 "요약 보기" 및 누적 요약 갱신에 사용)
    const cache = (() => {
      try {
        return db
          .prepare(
            `SELECT recentSummary, updatedAt, lastSummarizedAt, rolledUpCount
             FROM chat_memory_cache
             WHERE chatId=?`
          )
          .get(cid) as any;
      } catch {
        return null;
      }
    })();

    let historySummary = cache?.recentSummary ? String(cache.recentSummary) : "";
    // 현재 설정(summaryEvery)에 맞는 블록만 남겨서 prompt/UI 혼란을 방지
    historySummary = normalizeStoredMemorySummary(historySummary, summaryEveryVal);
    let lastSummarizedAt = Number(cache?.lastSummarizedAt || 0);
    let rolledUpCount = Number(cache?.rolledUpCount || 0);
    const cacheUpdatedAt = Number(cache?.updatedAt || 0);

    // 요약 텍스트는 10,000자 기준으로 제한/롤업한다.
    const summaryMaxChars = 10000;
    function strlenSummary(x: any) {
      return String(x || "").length;
    }

    // 저장된 장기기억 요약에 과거 설정/버그로 인한 "혼합 블록(1-5 + 1-3 등)"이 섞이면
    // 프롬프트 품질/UI 가독성이 깨질 수 있어, 현재 summaryEvery에 맞는 블록만 정규화한다.
    function normalizeStoredMemorySummary(summary: string, every: number): string {
      const src = String(summary || "").trim();
      if (!src) return "";

      const re = /^\s*##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*턴\s*\)\s*$/gm;
      const hits: { start: number; end: number; idx: number }[] = [];
      for (const m of src.matchAll(re)) {
        const a = Number(m[1] || 0);
        const b = Number(m[2] || 0);
        if (!Number.isFinite(a) || !Number.isFinite(b) || a <= 0 || b <= 0) continue;
        const start = Math.min(a, b);
        const end = Math.max(a, b);
        // 길이/정렬 체크
        // - 일반 블록: (start-1)%every==0 AND end==start+every-1
        // - 롤업 블록: 1부터 시작하고, (end-start+1)이 every의 배수인 범위(여러 구간을 1개로 압축)
        const size = end - start + 1;
        const isRollup = start === 1 && every > 0 && size >= every && size % every === 0 && end % every === 0;
        if (!isRollup) {
          if (size !== every) continue;
          if ((start - 1) % every !== 0) continue;
          if (end !== start + every - 1) continue;
        }
        hits.push({ start, end, idx: m.index ?? 0 });
      }
      if (!hits.length) return "";

      hits.sort((x, y) => x.idx - y.idx);
      const byKey = new Map<string, { start: number; end: number; body: string }>();

      for (let i = 0; i < hits.length; i++) {
        const h = hits[i];
        const startIdx = h.idx;
        const nextIdx = i + 1 < hits.length ? hits[i + 1].idx : src.length;
        const blockText = src.slice(startIdx, nextIdx).trim();
        const parts = blockText.split(/\r?\n\r?\n/);
        const body = (parts.slice(1).join("\n\n") || "").trim();
        if (body.replace(/\s+/g, "").length < 20) continue;
        byKey.set(`${h.start}-${h.end}`, { start: h.start, end: h.end, body }); // 마지막이 우선
      }

      const blocks = [...byKey.values()].sort((a, b) => a.start - b.start);
      return blocks
        .map((b) => `## 장기 기억 (${b.start}-${b.end}턴)\n\n${b.body}`.trim())
        .join("\n\n");
    }


    async function rollupIfNeeded(summary: string) {
      // 10,000자를 넘기면 기존 요약을 5,000자로 다시 요약(압축)하고 계속 누적
      if (strlenSummary(summary) <= summaryMaxChars) return { summary, rolledUpCount };
      const tLbl = `send.summary.rollup:${cid}:${reqId}`;
      tStart(tLbl);
      dbg({ tag: "send.summary.rollup.start", chatId: cid, reqId, inputChars: strlenSummary(summary) });
	      const endTurn = getSummarizedEndTurn(summary);
      const rollupEnd = endTurn > 0 ? endTurn : summaryEveryVal;
      const compact = await summarizeKorean({
        text: summary,
        targetChars: 5000,
        opts,
        turnRangeLabel: `1-${rollupEnd}턴`,
        perTurnChars: perTurnCharsVal,
        guidance: "롤업(압축) 요약: 기존 요약을 더 짧고 조밀하게 유지",
      });
      tEnd(tLbl);
      dbg({ tag: "send.summary.rollup.end", chatId: cid, reqId, outputChars: strlenSummary(compact) });
      rolledUpCount += 1;
      return { summary: compact, rolledUpCount };
    }

// (보정) summarizeKorean 결과가 구간 턴 번호를 1부터 다시 매기는 경우가 있어,
// 이번에 요약한 assistantTurn 범위(startTurn..endTurn)에 맞게 헤더의 (N턴)/(A-B턴) 표기를 오프셋 보정한다.
// - 대상: '##'/'###' 헤더 라인의 '(..턴)' 표기만
// - '## 장기 기억 (추가 구간)' 같은 비정상 라벨은 '(start-end턴)'으로 강제
function fixSummaryTurnLabels(summaryChunk: string, startTurn: number, endTurn: number): string {
  const raw = String(summaryChunk || "").trim();
  if (!raw) return raw;

  const st = Math.max(1, Math.floor(startTurn));
  const ed = Math.max(st, Math.floor(endTurn));
  // 모델이 (1-2턴)처럼 "상대 턴"을 쓰는 경우가 많아서 기본은 st-1 만큼 shift한다.
// 다만 이미 (6-10턴) 같은 "절대 턴" 라벨이 섞여 있으면 shift하지 않는다.
const detectOffset = () => {
  const s = String(raw || "");
  const nums: number[] = [];
  const re = /\(\s*(\d+)\s*(?:-\s*(\d+)\s*)?턴\s*\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    const a = Number(m[1] || 0);
    const b = m[2] != null ? Number(m[2] || 0) : 0;
    if (Number.isFinite(a) && a > 0) nums.push(a);
    if (Number.isFinite(b) && b > 0) nums.push(b);
  }
  if (!nums.length) return st - 1;
  const min = Math.min(...nums);
  const max = Math.max(...nums);

  // 이미 절대 턴(>=st)이 포함되어 있으면 offset=0
  if (min >= st && max <= ed) return 0;
  if (nums.some((n) => n >= st)) return 0;

  return st - 1;
};
const offset = detectOffset();
const lines = raw.split(/\r?\n/);
  const out: string[] = [];

  const shiftRange = (a: number, b?: number) => {
    const aa = Math.max(1, a + offset);
    const bb = b == null ? undefined : Math.max(1, b + offset);
    return { aa, bb };
  };

  for (let line of lines) {
    const trimmed = line.trimStart();

    // top-level 장기 기억 헤더는 범위를 강제
    if (/^##\s*장기\s*기억\b/.test(trimmed)) {
      // (중요) top-level header는 항상 a-b 형태로 고정한다.
      // - single-turn(4턴) 형태는 다른 parser/validator에서 누락될 수 있어 4-4로 통일
      const forced = `## 장기 기억 (${st}-${ed}턴)`;
      // 기존 헤더의 뒤쪽 텍스트는 유지(있다면)
      const rest = trimmed.replace(/^##\s*장기\s*기억\b\s*(\([^)]*\))?\s*/, "");
      line = forced + (rest ? " " + rest : "");
      out.push(line);
      continue;
    }

    // '##'/'###' 헤더에서만 '(..턴)'을 보정한다.
    if (/^#{2,3}\s+/.test(trimmed) && /\(\s*\d+(?:\s*-\s*\d+)?\s*턴\s*\)/.test(trimmed)) {
      line = line.replace(/\(\s*(\d+)\s*(?:-\s*(\d+)\s*)?턴\s*\)/g, (whole, a, b) => {
        const aa = Number(a || 0);
        const bb = b != null ? Number(b || 0) : undefined;
        if (!Number.isFinite(aa) || aa <= 0) return whole;
        if (bb != null && (!Number.isFinite(bb) || bb <= 0)) return whole;

        const shifted = shiftRange(aa, bb);
        const A = shifted.aa;
        const B = shifted.bb;

        // 범위 밖이 너무 튀면 clamp(안전)
        const clamp = (x: number) => Math.max(st, Math.min(ed, x));
        const Ac = clamp(A);
        const Bc = B == null ? undefined : clamp(B);

        if (Bc == null || Ac === Bc) return `(${Ac}턴)`;
        const lo = Math.min(Ac, Bc);
        const hi = Math.max(Ac, Bc);
        return `(${lo}-${hi}턴)`;
      });
    }

    // '추가 구간' 단어가 남아 있으면 제거(가독성)
    line = line.replace(/\(\s*추가\s*구간\s*\)/g, `(${st}-${ed}턴)`);

    out.push(line);
  }

  return out.join("\n").trim();
}



    // 요약 갱신 조건
    // - 설정 변경(업데이트 시각)
    // - summaryEveryVal(5~10) 턴마다(=assistant 응답 기준) 누적 요약을 생성/갱신
    // - perTurnCharsVal(턴당 글자수) 변경 시 즉시 반영
    //
    // IMPORTANT:
    // keepUserTurns(최근 원문 유지)와 무관하게 "요약 보기"는 요약이 생성되어야 한다.
    // 그래서 요약 생성 트리거는 olderMsgs(tail 제외) 여부에 의존하지 않는다.
    //
    // 누적 요약에서 "마지막으로 요약된 턴"을 안정적으로 추적하기 위해,
    // 요약 텍스트의 라벨(예: '## 장기 기억 (6-10턴)')에서 최대 endTurn을 파싱한다.
    function extractSummaryRangeBlocks(summary: string): { startTurn: number; endTurn: number }[] {
      const text = String(summary || "");
      const re = /^\s*##\s*장기\s*기억\s*\(\s*(\d+)\s*[-–~]\s*(\d+)\s*턴\s*\)\s*$/gm;
      const out: { startTurn: number; endTurn: number }[] = [];
      for (const m of text.matchAll(re)) {
        const a = Number(m[1]);
        const b = Number(m[2]);
        if (!Number.isFinite(a) || !Number.isFinite(b) || a < 1 || b < a) continue;
        out.push({ startTurn: a, endTurn: b });
      }
      return out;
    }

function getSummarizedEndTurn(summary: string): number {
      const cleaned = sanitizeLongMemorySummary(String(summary || ""), summaryEveryVal);
      const blocks = extractSummaryRangeBlocks(cleaned);
      if (!blocks.length) return 0;
      return Math.max(...blocks.map((b) => b.endTurn));
    }

    // assistantTurn 1..N 기준으로 해당 구간의 메시지(유저+어시스턴트)를 뽑는다.
    function selectMessagesForAssistantTurnRange(msgs: any[], startTurn: number, endTurn: number) {
      const st = Math.max(1, Math.floor(startTurn));
      const ed = Math.max(st, Math.floor(endTurn));

      const asstIdx: number[] = [];
      for (let i = 0; i < msgs.length; i++) {
        if (msgs[i]?.role === "assistant" || msgs[i]?.role === "model") asstIdx.push(i);
      }
      if (!asstIdx.length) return [];

      const startAsstPos = asstIdx[st - 1];
      const endAsstPos = asstIdx[ed - 1] ?? asstIdx[asstIdx.length - 1];

      // 시작 구간은 "직전 assistant 다음"부터 잡아서 해당 턴의 user 입력을 포함시킨다.
      let startPos = 0;
      if (st > 1 && asstIdx[st - 2] != null) startPos = asstIdx[st - 2] + 1;

      // endPos는 해당 턴의 assistant까지 포함
      const endPos = Math.min(msgs.length - 1, endAsstPos);

      if (startPos < 0) startPos = 0;
      if (startPos > endPos) startPos = 0;

      return msgs.slice(startPos, endPos + 1);
    }


// 위 함수와 동일하되, 메시지 인덱스 상한(maxExclusive) 이전까지만 포함하도록 캡핑한다.
// - tail(최근 K턴 원문)과 요약 입력이 중복되는 것을 줄이기 위한 용도.
// - maxExclusive는 msgs 배열에서 '포함하지 않을 첫 인덱스'이다. (slice end-exclusive)
function selectMessagesForAssistantTurnRangeCapped(
  msgs: any[],
  startTurn: number,
  endTurn: number,
  maxExclusive: number
) {
  const cap = Math.max(0, Math.floor(Number(maxExclusive) || 0));
  if (cap <= 0) return [];

  const st = Math.max(1, Math.floor(startTurn));
  const ed = Math.max(st, Math.floor(endTurn));

  const asstIdx: number[] = [];
  for (let i = 0; i < msgs.length; i++) {
    if (msgs[i]?.role === "assistant" || msgs[i]?.role === "model") asstIdx.push(i);
  }
  if (!asstIdx.length) return [];

  const endAsstPos = asstIdx[ed - 1] ?? asstIdx[asstIdx.length - 1];

  // 시작 구간은 "직전 assistant 다음"부터 잡아서 해당 턴의 user 입력을 포함시킨다.
  let startPos = 0;
  if (st > 1 && asstIdx[st - 2] != null) startPos = asstIdx[st - 2] + 1;

  // endPos는 해당 턴의 assistant까지 포함하되, cap 이전까지만
  const endPos0 = Math.min(msgs.length - 1, endAsstPos);
  const endPos = Math.min(endPos0, cap - 1);

  if (startPos < 0) startPos = 0;
  if (startPos >= cap) return [];
  if (startPos > endPos) return [];

  return msgs.slice(startPos, endPos + 1);
}
const summarizedEndTurn = getSummarizedEndTurn(historySummary);
const boundaryEndTurn = Math.floor(completedTurnCount / summaryEveryVal) * summaryEveryVal;

// 이번 경계(boundaryEndTurn)에서 요약할 고정 구간: [boundary-summaryEvery+1 .. boundary]
const windowStartTurn = Math.max(1, boundaryEndTurn - summaryEveryVal + 1);
const windowEndTurn = Math.max(windowStartTurn, boundaryEndTurn);

const hasRangeBlock = (() => {
  const s = String(historySummary || "");
  if (!s.trim()) return false;
  const re = new RegExp(
    `^##\\s*장기\\s*기억\\s*\\(\\s*${windowStartTurn}\\s*-\\s*${windowEndTurn}\\s*턴\\s*\\)`,
    "m"
  );
  return re.test(s);
})();

const shouldRefresh = (() => {
  if (completedTurnCount < summaryEveryVal) return false;
  if (boundaryEndTurn <= 0) return false;

  // 캐시가 없거나 비어 있으면 생성
  if (!cache) return true;
  if (!String(historySummary || "").trim()) return true;

  // 설정 변경은 강제 반영
  const settingsUpdatedAt = Number(settings?.updatedAt || 0);
  if (settingsUpdatedAt > cacheUpdatedAt) return true;

  // 런타임 perTurnCharsVal이 DB와 다르면 즉시 반영
  // - 턴당 글자: 100~2000(10단위) 단위로만 운용
  if (Number.isFinite(rtPerTurn)) {
    const snap = (x: number) => {
      const v = Math.round((Number(x) || 420) / 10) * 10;
      return Math.max(100, Math.min(2000, v));
    };
    const normRt = snap(Number(rtPerTurn));
    const normDb = snap(Number(settings.summaryLength ?? 420));
    if (normRt !== normDb) return true;
  }

  // 이번 boundary 구간(예: 6-10)이 없으면 생성
  if (!hasRangeBlock) return true;

  // boundaryEndTurn이 기존 최상위 endTurn보다 크면 갱신(이 경우 hasRangeBlock은 보통 false)
  if (boundaryEndTurn > summarizedEndTurn) return true;

  return false;
})();

if (shouldRefresh) {
  // 이번 갱신에서 요약할 턴 구간(항상 summaryEveryVal 크기의 고정 구간)
  const startTurn = windowStartTurn;
  const endTurn = windowEndTurn;
const tailStartIdx = Math.max(0, all.length - tail.length);
const rangeMsgs = selectMessagesForAssistantTurnRangeCapped(all, startTurn, endTurn, tailStartIdx);
      if (rangeMsgs.length > 0) {
	  const raw = formatTurns(rangeMsgs);
	  // (중요) 요약 입력이 빈 문자열로 들어가던 버그 방지: 실제 대화 원문(raw)을 사용
	  const rawForSummary = stripUrlsAndMediaMarkdown(raw);
        const tLbl = summarizedEndTurn <= 0 ? `send.summary.full:${cid}:${reqId}` : `send.summary.delta:${cid}:${reqId}`;
        tStart(tLbl);

        const turnCountInRange = Math.max(1, endTurn - startTurn + 1);
        const targetChars = Math.min(100000, Math.max(50, perTurnCharsVal * turnCountInRange));
        const rangeLabel = startTurn === endTurn ? `${startTurn}턴` : `${startTurn}-${endTurn}턴`;

        dbg({
          tag: summarizedEndTurn <= 0 ? "send.summary.full.start" : "send.summary.delta.start",
          chatId: cid,
          reqId,
          startTurn,
          endTurn,
          turns: turnCountInRange,
          inputChars: raw.length,
          targetChars,
          rangeMessages: rangeMsgs.length,
          rangeLabel,
        });

        const newChunk = await summarizeKorean({
          text: rawForSummary,
          targetChars,
          perTurnChars: perTurnCharsVal,
          turnRangeLabel: rangeLabel,
          guidance: String(settings.longMemoryGuidance || "").trim(),
          opts,
        });
        const fixedChunk = fixSummaryTurnLabels(newChunk, startTurn, endTurn);
        const cleanedChunk = sanitizeLongMemorySummary(normalizeSummaryTail(fixedChunk), summaryEveryVal);

        tEnd(tLbl);

        dbg({
          tag: summarizedEndTurn <= 0 ? "send.summary.full.end" : "send.summary.delta.end",
          chatId: cid,
          reqId,
          outputChars: strlenSummary(fixedChunk),
          rangeLabel,
        });

        const combined = sanitizeLongMemorySummary(
          upsertSummaryRangeBlock(historySummary || "", cleanedChunk, startTurn, endTurn).trim(),
          summaryEveryVal
        );

        // 10,000자 제한 + 롤업(5,000자 압축)
        let rolled = await rollupIfNeeded(combined);
        historySummary = sanitizeLongMemorySummary(normalizeSummaryTail(rolled.summary), summaryEveryVal);
        rolledUpCount = rolled.rolledUpCount;

        // 롤업 이후에도 여전히 10,000자 넘는다면 한 번 더 압축(안전장치)
        if (strlenSummary(historySummary) > summaryMaxChars) {
          const rolled2 = await rollupIfNeeded(historySummary);
          historySummary = sanitizeLongMemorySummary(normalizeSummaryTail(rolled2.summary), summaryEveryVal);
          rolledUpCount = rolled2.rolledUpCount;
        }

        // lastSummarizedAt은 "마지막으로 요약에 포함된 메시지 createdAt의 최대값"으로 유지한다.
        const newestAt = rangeMsgs.reduce((mx, m) => Math.max(mx, Number(m?.createdAt || 0)), 0);
        lastSummarizedAt = newestAt || Number(lastSummarizedAt || 0) || Date.now();
      } else {
        // 메시지가 없으면 갱신하지 않음
      }

      // 요약 캐시 저장(조회용) - UI에서 "요약 보기"로 확인
      try {
        // (중요) 저장 시 헤더(## 장기 기억 (a-b턴)) 구조를 유지해야 다음 증분 갱신 파싱이 안정적이다.
        // - postprocessLongMemorySummary()는 ##/### 구조를 지워버려 누적 갱신을 깨뜨릴 수 있으므로 제거
        const historySummaryToStore = stripUrlsAndMediaMarkdown(String(historySummary || ""));
        const summaryChars = strlenSummary(historySummaryToStore);
        db.prepare(
          `INSERT INTO chat_memory_cache (chatId, recentSummary, recentSummaryChars, updatedAt, lastSummarizedAt, rolledUpCount)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(chatId) DO UPDATE SET
             recentSummary=excluded.recentSummary,
             recentSummaryChars=excluded.recentSummaryChars,
             updatedAt=excluded.updatedAt,
             lastSummarizedAt=excluded.lastSummarizedAt,
             rolledUpCount=excluded.rolledUpCount`
        ).run(cid, historySummaryToStore, summaryChars, Date.now(), Number(lastSummarizedAt || 0), Number(rolledUpCount || 0));
      } catch {
        // 캐시 실패는 치명적이지 않으므로 무시
      }
    }
    // 5) 시스템 프롬프트 구성
    // (병목 분석 로그용) 구성 요소별 시간 측정: 페르소나설정 / 프리셋 / 로어북 / 유저노트 / 장기기억
    const tPersonaBlock = tStart("페르소나설정");
    // NOTE: personaOverride(프론트 임시값) + settings(DB 저장값)을 이미 resolvePersona로 합쳤다.
    // user 입력 1턴 기준(=user 메시지)으로 프롬프트가 흔들리지 않도록 여기서는 persona만 사용한다.
    const personaNameFinal = persona.name || "주인공";
    const personaAgeFinal = persona.age || 0;
    const personaGenderFinal = persona.gender;
    const personaInfoFinal = persona.info;

    const personaBlock = [
      `# (1) 페르소나(주인공 설정)`,
      `- 이름: ${personaNameFinal || "(미입력)"}`,
      `- 나이: ${personaAgeFinal ? String(personaAgeFinal) : "(미입력)"}`,
      `- 성별: ${personaGenderFinal || "(미입력)"}`,
      `- 상세 정보: ${personaInfoFinal || ""}`,
    ].join("\n");
    tEnd(tPersonaBlock);

    const tPresetBlock = tStart("프리셋");

    const presetBlock = [
      `# 프리셋`,
      `- 배경: ${preset.background}`,
      `- 상대방 캐릭터 이름: ${preset.characterName || ""}`,
      `- 상대방 나이: ${preset.characterAge || 0}`,
      `- 상대방 캐릭터(성격/말투/행동 원칙): ${preset.character}`,
      `- 추가지침(금칙/우선순위/형식): ${preset.systemPrompt || ""}`,
    ].join("\n");
    tEnd(tPresetBlock);

    // (요구사항)
    // 작업실(캐릭터 제작)에서 저장한 로어북을 대화 프롬프트에 반영한다.
    // - 로어는 기본적으로 '활성화 키'가 최근 대화/입력에 등장하면 포함한다.
    // - 키가 비어있거나 매칭되는 항목이 없으면, 활성화된 로어 중 앞부분 일부를 포함한다.
    const pickLorebooks = () => {
      const tLore = tStart("로어북");
      try {
      const raw = String(preset?.lorebooks || "[]");
      let arr: any[] = [];
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) arr = parsed;
      } catch {
        arr = [];
      }

      const enabled = arr
        .filter((x) => x && typeof x === "object")
        .filter((x) => x.enabled !== false);

      const haystack = `${historySummary || ""}\n${settings?.userNote || ""}`;
      // context/userText는 아래에서 만들어지지만, 로어 선택은 시스템 블록 단계에서도 쓸 수 있게
      // 유저 입력만 먼저 참조한다.
      const recentText = `${haystack}\n${userText || ""}`;

      const norm = (s: string) => String(s || "").toLowerCase();
      const h = norm(recentText);

      const scored = enabled.map((lb) => {
        const keyRaw = lb.activationKey ?? lb.key ?? lb.keys ?? "";
        const keys = Array.isArray(keyRaw)
          ? keyRaw.map((k: any) => String(k || "").trim()).filter(Boolean)
          : String(keyRaw || "")
              .split(/[,\n]+/)
              .map((k) => String(k || "").trim())
              .filter(Boolean);

        let score = 0;
        for (const k of keys) {
          const kk = norm(k);
          if (kk && h.includes(kk)) score += 10;
        }
        return { lb, score, keys };
      });

      scored.sort((a, b) => b.score - a.score);

      const matched = scored.filter((x) => x.score > 0).slice(0, 12);
      const picked = (matched.length ? matched : scored.slice(0, 6))
        .map((x) => ({
          name: String(x.lb?.name || "").trim(),
          content: String(x.lb?.content || x.lb?.text || "").trim(),
          keys: x.keys,
        }))
        .filter((x) => x.name || x.content);

      if (!picked.length) return "# 로어북\n(없음)";

      const lines: string[] = ["# 로어북(작업실)"];
      for (const lb of picked) {
        const k = lb.keys && lb.keys.length ? ` (키: ${lb.keys.join(", ")})` : "";
        lines.push(`- ${lb.name || "(무제)"}${k}`);
        if (lb.content) lines.push(`  - ${lb.content}`);
      }
      return lines.join("\n");
      } finally {
        tEnd(tLore);
      }
    };

    const loreBlock = pickLorebooks();

    const tUserNote = tStart("유저노트");
    const noteBlock = settings.userNote
      ? `# (3) 유저노트(답변 생성 시 참고)\n${settings.userNote}`
      : `# (3) 유저노트(답변 생성 시 참고)\n(없음)`;
    tEnd(tUserNote);

    const tLongMemoryBlock = tStart("장기기억");
    const memoryBlock = [
      `# (2) 장기기억 요약(최근 원문 ${keepUserTurns}턴 제외, ${summaryEveryVal}턴마다 갱신)`,
      historySummary || "(없음)",
    ].join("\n");
    tEnd(tLongMemoryBlock);

    // NOTE: 출력길이 슬라이더(런타임)가 즉시 반영되도록 opts(maxOutputTokens)를 우선 사용한다.
    // (DB settings.maxOutputTokens는 '저장'된 값이고, 런타임 슬라이더는 body.runtime으로 넘어옴)
    const maxOut = Number(opts.maxOutputTokens ?? settings.maxOutputTokens ?? 1024);

    // (요구사항)
    // UI 슬라이더의 값(예: 800/1600)을 사용자는 사실상 "글자수"처럼 체감한다.
    // 하지만 모델의 토큰화(언어/모델별)가 달라서 "max_output_tokens"만으로는
    // 글자수(한글 자수)가 크게 흔들릴 수 있다.
    // → 해결: "목표 글자수"를 슬라이더 값에 맞추고, 결과가 너무 짧/길면 1~2회
    //         재작성하며 max_output_tokens를 **동적으로 보정**한다.
    // 슬라이더 값은 UI에 "토큰"으로 표기되어 있지만, 사용자는 사실상 "원하는 글 길이"(글자수 감각)로 사용한다.
    // 모델별/언어별 토큰화 비율이 달라 max_output_tokens만으로는 길이가 크게 흔들린다.
    // 그래서 **결과 텍스트는 글자수 기준으로 고정**하고,
    // 생성 단계에서는 충분히 쓸 수 있도록 max_output_tokens를 더 크게 잡아(후술) 짧게 끊기는 현상을 줄인다.
    const HARD_CAP_CHARS = 200000; // absolute safety cap to prevent runaway DB growth
    const NO_TRUNCATE_OUTPUT = true; // 원칙: 서버 절단 금지(슬라이더는 '권장' 길이)

    const targetChars = Math.max(200, Math.min(20000, Math.floor(maxOut))); // 슬라이더 값 = 권장 글자수

    // 1) 프롬프트 지시용(강제): 목표의 90% 이상 쓰도록 강하게 요구
    const promptMinChars = Math.max(200, Math.floor(targetChars * 0.90));
    const promptMaxChars = Math.max(promptMinChars + 80, Math.floor(targetChars * 1.15));

    // 2) 로직 판단용(안전장치): "너무 짧다" 판단 기준(목표의 60%)
    const logicMinChars = Math.max(120, Math.floor(targetChars * 0.60));

    // 3) 폭주 방지용 상한(완화 절단): 목표의 130%까지만 허용
    //    - NO_TRUNCATE_OUTPUT=true라도, 이어쓰기/토큰 예산 상향 등으로 2배 이상 튀는 케이스를 막기 위한 안전장치.
    const runawayMaxChars = Math.max(promptMaxChars + 120, Math.floor(targetChars * 1.30));

    // 절단 금지 모드에서는 "재작성/길이 보정" 트리거(minChars)를 0으로 두되,
    // '너무 짧다' 판단에는 logicMinChars/promptMinChars를 사용한다.
    const minChars = NO_TRUNCATE_OUTPUT ? 0 : logicMinChars;
    const maxChars = NO_TRUNCATE_OUTPUT ? runawayMaxChars : Math.max(minChars + 40, targetChars);
    const charBudget = Math.min(HARD_CAP_CHARS, maxChars);

    // 생성 단계에서만 사용할 "여유 토큰" 상한.
    // - max_output_tokens가 너무 낮으면(특히 1000 이하) 짧게 끊기거나 형식이 무너지는 케이스가 많다.
    // - 대신 최종 결과는 아래에서 글자수로 강제 절단하므로, 여기서는 넉넉히 준다.
    // Token budget: keep the existing heuristic, but relax the cap for Gemini 3 models.
    // - Gemini 3 Pro can produce larger single responses; too-low caps force auto-continue,
    //   which creates long "silent" gaps and increases ALB/UX risk.
    const modelName = String((opts as any)?.model || "");
    const isGemini3 = modelName.includes("gemini-3");

    // cap(최대치) 자체를 올려도, 현재 로직은 targetChars(=슬라이더) 기반으로
    // floor(targetChars * 2.2)에서 먼저 제한되는 경우가 많다.
    // 특히 Gemini 3 Pro는 "한 덩어리로" 출력하다 MAX_TOKENS로 끊기는 케이스가 있어,
    // 작은 슬라이더 값에서도 최소 토큰 여유를 보장해 준다(서사/메타 블록 완결 목적).
    const cap = isGemini3 ? 8192 : 6000;

    // 생성 단계 토큰 예산(폭주 방지 + 끊김 완화)
    // - 과거: Gemini 3에 minBoost=4096을 강제하면서 작은 target에서도 과출력이 발생(예: 1200 -> 2800+).
    // - 개선: targetChars에 따라 부드럽게 스케일링한다.
    const boostMul = isGemini3
      ? (targetChars <= 1600 ? 1.35 : targetChars <= 2600 ? 1.55 : 2.0)
      : 2.2;

    const rawBoost = Math.floor(targetChars * boostMul);

    // 작은 목표에서는 최소치를 낮추고(폭주 방지), 큰 목표에서는 끊김을 막기 위해 올린다.
    const minBoost = isGemini3 ? (targetChars >= 3200 ? 3072 : 1536) : 512;

    const boostedMaxOutputTokens = Math.max(minBoost, Math.min(cap, rawBoost));

    // "중간 끊김"이 계속 발생해서, 형식을 단순화하고(LLM이 놓치기 쉬운 규칙 제거)
    // 반드시 짧게라도 완결되도록 강제한다.
    const minParagraphs = maxOut >= 3000 ? 8 : maxOut >= 2000 ? 6 : 3;

    // 상태창은 별도 경량 모델(/api/chat/update-status)로 갱신한다.
    // main 생성 모델이 상태창까지 출력하면 토큰을 소모해 본문이 끊기는 문제가 자주 발생하므로,
    // 여기서는 어떤 프리셋이든 main 프롬프트에 상태창/코드펜스 출력을 요구하지 않는다.
    const statusHandledSeparately = true;
    // (legacy) 프리셋이 상태창을 요구했는지 감지하더라도, main 출력에는 반영하지 않는다.
    const authorWantsStatus = !statusHandledSeparately && /상태\s*창|캐릭터\s*상태|\[\s*시간\s*\/\s*장소\s*\]|```\s*STATUS\b/i.test(
      [presetBlock, personaBlock, noteBlock, String(settings.userNote || ""), loreBlock].filter(Boolean).join("\n")
    );

	    const FENCE = "```";
		    const INV = "\u2063";
	    const formatGuide =
	      [
	      `출력 규칙(화자 마커 + 턴 선점 금지, 매우 중요):`,
		      `1) 지문은 *...* 로 감싼다. 대사는 반드시 큰따옴표 "..." 로 감싼다.`,
		      `   (중요) 일반 마크다운(헤딩/목록/강조/링크/표 등)은 절대 출력하지 않는다. 코드블록 밖에서는 *지문* 또는 "대사"만 쓴다.`,
	      `2) (중요) 보이지 않는 화자 마커 규칙(최소 사용):`,
`   - 상대(NPC) 대사에는 화자 마커를 절대 넣지 않는다. (즉, 그냥 "..." 형태로 출력)`,
`   - 주인공(사용자 캐릭터) 대사는 원칙적으로 출력하지 않는다. (사용자가 직접 입력하는 영역)`,
`   - 예외: 사용자의 최신 입력을 주인공 대사로 '그대로 재현/인용'해야 할 때만, 사용자가 입력한 문장을 원문 그대로 "..." 안에 딱 1회 넣는다.`,
`   - AI가 임의로 '주인공의 새 대사'를 창작하여 출력하는 것을 금지한다.`,
`	   - 화자 마커(${INV}U${INV})는 현재 사용하지 않는다. 주인공 대사는 (예외 상황에서) 원문 인용 1회만 허용한다.`,
	      `3) 턴/행동 선점 금지(절대): 사용자가 아직 입력하지 않은 주인공의 발화/생각/의도/결정/행동을`,
	      `   NPC가 미리 알고 말하거나, 서술이 이미 일어난 것처럼 확정 서술하는 것을 금지한다.`,
	      `   - 사용자가 말하지 않은 내용을 "네가 ~라고 했지" 식으로 선제 인용/요약 금지`,
	      `   - 사용자의 의도/생각을 단정(분명/틀림없이/당연히 등) 금지`,
	      `   - 사용자의 행동을 선점(이미 ~했다) 금지`,
	      `   - 필요하면 NPC는 추측형으로만 말한다(대사 안에 추측임을 드러낼 것).`,
	            `3.5) (중요) 사용자가 직접 입력한 문장은 절대 맞춤법/띄어쓰기/문맥으로 교정하거나 바꿔 쓰지 않는다.`,
      `     주인공 대사로 사용자의 입력을 재현/인용해야 한다면, 오타/비속어/띄어쓰기 포함 원문을 그대로 따옴표 안에 넣는다.`,
      `     (예외) 사용자가 명시적으로 '교정/다듬기/맞춤법 수정'을 요청한 경우에만 수정안을 제안하되, 원문도 함께 보여준다.`,
	      `4) (중요) fenced 코드블록(\`\`\`...\`\`\`)은 절대 출력하지 않는다.`,
	      `   - 상태/정보/능력치/시간/장소 등은 본문에 섞거나 코드펜스로 만들지 말고, 오직 서사(지문/대사)만 출력한다.`,
	      `   - 상태창은 시스템이 별도 API로 갱신한다.`,
            `     - 이미지가 필요하면 반드시 한 줄에만 이렇게 출력한다: !!https://... (또는 !!//...)`,
            `       (중요) 이 줄은 따옴표로 감싸지 말고, 앞뒤에 글자/공백/괄호/마침표를 붙이지 않는다.`,
            `     - 따옴표("...") 안에 URL을 넣지 않는다. 문장부호(.,))를 URL 끝에 붙이지 않는다. 반드시 완전한 URL(https:// 포함, 확장자 .webp/.png/.jpg 등 포함)로 한 줄에 끝낸다.`,

	      `5) 반드시 한국어로만 쓴다. 메타설명/지시문/해설을 쓰지 않는다.`,
	      `6) (매우 중요) 이번 답변의 분량 목표는 약 ${targetChars}자이다.`,
              `   - 반드시 최소 ${promptMinChars}자 이상을 채워서 길고 풍성하게 서술하라.`,
              `   - 내용이 짧으면 묘사/심리/배경 서술을 대폭 추가해서라도 분량을 강제로 늘려라.`,
              `   - 분량이 부족하면 답변을 종료하지 말고 장면을 더 구체적으로 파고들어 계속 써라.`,
	              `   - 너무 길어지면 ${promptMaxChars}자 근처에서 자연스럽게 마무리한다.`,
	      `7) 출력은 항상 '서사 본문'만으로 끝낸다. (상태창 출력 금지)`,
	      `   (중요) 가능하면 1단계(서사 본문)는 지문으로 마무리하되, 불필요한 '*...*' 자리표시자를 강제로 붙이지 않는다.`,
	      `   (중요) 서사 본문이 대사로 끝났다면, 다음 사용자 입력을 기다리는 흐름이 되도록 짧은 지문 1~2문장으로 마무리하는 것을 권장한다. (단, '*...*' 자리표시자만 단독으로 붙이는 것은 금지)`,
	      `   (절대) 따옴표 미닫힘/중간 끊김 금지.`,
	      `8) (중요) 사용자의 다음 발화(주인공 대사/행동)를 네가 대신 쓰지 않는다. 장면은 상대의 반응에서 끝내고, 필요하면 상대가 질문하거나 다음 행동을 촉구하는 대사로 마무리하여 사용자의 입력을 기다린다.`,
	    ].join("\n");

    const system = [
      `너는 아래 설정을 따르는 '상대방 캐릭터'로서 반응한다.`,
      ``,
      sanitizePromptForModel(presetBlock),
      ``,
      sanitizePromptForModel(personaBlock),
      ``,
      sanitizePromptForModel(noteBlock),
      ``,
      sanitizePromptForModel(memoryBlock),
      ``,
      sanitizePromptForModel(loreBlock),
      ``,
      sanitizePromptForModel(formatGuide),
    ].join("\n");

    // 6) 모델 호출
    // - 최근 컨텍스트는 "유저 입력 K턴" 기준으로 tail에 포함
    // - 그 이전은 historySummary(요약)로 대체
    const personaName = personaNameFinal;
    const npcName = preset.characterName || "상대";

    const context = formatStoryTurnsForMode(tail, personaName, npcName, renderMode);
    // 사용자 입력을 모드에 맞춰 전달한다.
    const userLine = buildUserLineForMode(userText, personaName, renderMode);

    const user = [      context ? `[최근 대화]\n${context}` : "",
      ``,
      renderMode === "chat"
        ? `다음은 사용자의 최신 입력이다. 이 입력은 이미 화면에 표시되어 있으므로, 이를 다시 대사로 출력하지 말고 그 다음 장면(지문 + 상대의 반응)만 이어서 출력하라. 사용자의 문장을 교정/재작성하지 말고, 상대가 이를 들었다는 전제 하에 자연스럽게 반응만 이어가라.`
        : `다음은 사용자의 최신 입력이다. 이 입력(주인공 발화)은 이미 화면에 표시되어 있으므로, 이를 다시 "..." 대사로 출력하지 말고 그 다음 장면(지문 + 상대의 반응)만 이어서 출력하라. 사용자의 문장을 교정/재작성하지 말고, 상대가 이를 들었다는 전제 하에 반응만 진행하라. (이름 | ... 같은 화자표기는 쓰지 말고 큰따옴표만 사용)`,
      renderMode === "chat"
        ? `사용자 최신 입력(참고용, 재출력 금지): ${userLine}`
        : `사용자 최신 입력(참고용, 재출력 금지): ${userLine}`,
      ``,
      `출력은 곧바로 시작하라.`,
    ]
      .filter(Boolean)
      .join("\n");

    
tEnd(tPrompt);

const wantStream = Boolean((body as any)?.stream);

// ---- Streaming (NDJSON) ----
if (wantStream) {
const encoder = new TextEncoder();

  // Stream debug logging (set STREAM_DEBUG=1 to enable)
  const STREAM_DEBUG = process.env.STREAM_DEBUG === "1";
  const streamDbgId = `${Date.now().toString(16)}-${Math.random().toString(16).slice(2)}`;
  const streamTag = `[api][chat.send][stream][${streamDbgId}][chat:${String(chatId)}]`;

  // (UX/네트워크 안정화)
  // 모델이 델타를 한동안 안 줄 때도 연결이 살아있음을 알리고,
  // 일부 프록시/버퍼가 응답을 뭉쳐 보내는 현상을 완화하기 위해 heartbeat를 흘려보낸다.
  // - 클라이언트는 type:"ping"을 텍스트에 반영하지 않음(무시)
  // - 하지만 수신 시각 갱신에는 사용 가능
  const HEARTBEAT_MS = 700;

  const rs = new ReadableStream({
    start(controller) {
      (async () => {
        let streamClosed = false;
        let lastPingAt = 0;
        let lastDeltaAt = 0;

        const safeEnqueue = (obj: any) => {
          if (streamClosed) return false;
          try {
            const now = Date.now();
            if (obj?.type === "ping") {
              const sincePing = lastPingAt ? now - lastPingAt : -1;
              const sinceDelta = lastDeltaAt ? now - lastDeltaAt : -1;
              lastPingAt = now;
              if (STREAM_DEBUG) {
                console.debug(`${streamTag} ping sent (sincePing=${sincePing}ms sinceDelta=${sinceDelta}ms)`, obj);
              }
            }
            controller.enqueue(encoder.encode(JSON.stringify(obj) + "\n"));
            return true;
          } catch (e: any) {
            streamClosed = true;
            if (STREAM_DEBUG) console.warn(`${streamTag} enqueue ignored (closed)`, e?.message || e);
            return false;
          }
        };

        const safeClose = () => {
          if (streamClosed) return;
          streamClosed = true;
          try {
            controller.close();
          } catch {}
        };

        // First-byte flush (keep-alive before Gemini starts producing)
        safeEnqueue({ type: "ping", phase: "start", t: Date.now() });

        try {
          const tGeminiStream = tStart(`send.gemini.stream`);

          // ===== Generation (append-only) + optional auto-continue (max 2) =====
          // Goal: if the model ends with MAX_TOKENS, automatically request a continuation
          // (append-only) up to 2 times, preserving the user's reasoning/UI settings.

          const mergeUsage = (base: any, add: any) => {
            if (!add) return base;
            if (!base) return { ...add };
            const out: any = { ...base };
            for (const k of ["promptTokens", "outputTokens", "reasoningTokens", "totalTokens", "latencyMs"]) {
              out[k] = Number(out[k] || 0) + Number(add[k] || 0);
            }
            // keep the last model / finishReason for observability
            if (add.model) out.model = add.model;
            if (add.finishReason) out.finishReason = add.finishReason;
            if (add.tokenBreakdown) out.tokenBreakdown = add.tokenBreakdown;
            return out;
          };

          const makeContinueUser = (combined: string) => {
            const tailLen = 800;
            const tail = combined.slice(Math.max(0, combined.length - tailLen));
            return [
              context ? `[최근 대화]\n${context}` : "",
              "",
              "[CONTINUE] 직전 출력이 MAX_TOKENS로 중단되었다.",
              "- 이미 출력한 내용은 절대 반복/요약/재진술하지 말고, 바로 다음 문장부터 그대로 이어서만 써라.",
              "- 형식은 헌법을 그대로 유지한다: 지문=*...*, 대사=\"...\", 메타=```ANY_LABEL fenced 블록만.",
              "- 만약 메타(fenced)가 열려 있었거나 마지막 문장이 미완이면, 이어서 완결/닫힘까지 책임지고 마무리하라.",
              "",
              "[직전 출력의 마지막 부분(참고, 반복 금지)]",
              tail,
              "",
              "출력은 곧바로 이어서 시작하라.",
            ]
              .filter(Boolean)
              .join("\n");
          };

          const awaitFinalFast = async (p: Promise<any>, ms: number) => {
            try {
              return await Promise.race([p, new Promise((res) => setTimeout(() => res(null), Math.max(0, ms)))]);
            } catch {
              return null;
            }
          };

          const runOne = async (userPrompt: string, tag: string) => {
            if (STREAM_DEBUG) console.debug(`${streamTag} gen.start (${tag})`);

            const gen = await generateTextStream({
              system,
              user: userPrompt,
              opts: { ...opts, maxOutputTokens: boostedMaxOutputTokens },
            });

            let raw = "";
            let lastEmitAt = Date.now();
            const hb = setInterval(() => {
              try {
                const now = Date.now();
                if (now - lastEmitAt < HEARTBEAT_MS) return;
                lastEmitAt = now;
                safeEnqueue({ type: "ping", t: now });
              } catch {
                // ignore
              }
            }, Math.max(200, Math.floor(HEARTBEAT_MS / 2)));

            let hadDelta = false;
            let stoppedEarly = false;
            try {
              for await (const delta of gen.stream) {
                hadDelta = true;
                const combined = raw + delta;

                // Normal path: append-only, but still sanitize noisy separators
                raw = stripStandaloneSeparatorLines(combined);
                lastEmitAt = Date.now();
                const nowD = Date.now();
                const gap = lastDeltaAt ? nowD - lastDeltaAt : -1;
                lastDeltaAt = nowD;

                if (STREAM_DEBUG)
                  console.debug(`${streamTag} delta recv (${tag}) (gap=${gap}ms len=${String(delta || "").length})`);
                safeEnqueue({ type: "delta", text: delta });
              }
            } finally {
              // keep hb alive until we emit done (final usage may arrive slightly later)
            }
            try {
            let final: any = null;
            let usage: any = null;

            // gen.final can resolve much later than the last visible delta (esp. gemini-3-pro*).
            // To avoid long 'done' delays, we only wait briefly for usage/final text.
            const isGemini25 = modelName.includes("gemini-2.5");
            const isGemini3Pro = modelName.includes("gemini-3-pro");
            const baseFinalWait = isGemini3Pro ? 5200 : (isGemini3 ? 3200 : (isGemini25 ? 2200 : 1600));
            const FINAL_WAIT_MS = stoppedEarly ? 350 : baseFinalWait;
            final = await awaitFinalFast(gen.final, FINAL_WAIT_MS);
            usage = (final as any)?.usage ?? null;

            // 일부 모델(특히 gemini-3-pro-preview)은 스트림이 끝난 직후 usage가 늦게 붙는 케이스가 있다.
            // - done까지 '계산중…'으로 남는 문제를 막기 위해, usage가 없으면 한 번 더(짧게) 기다린다.
            if (!usage) {
              const extraWaitMs = isGemini3Pro ? 3500 : isGemini3 ? 2200 : isGemini25 ? 1500 : 1000;
              if (STREAM_DEBUG) console.debug(`${streamTag} final.wait.extra (${tag}) ms=${extraWaitMs}`);
              const f2 = await awaitFinalFast(gen.final, extraWaitMs);
              if (f2) final = f2;
              usage = (final as any)?.usage ?? usage;
            }


            // Append any remaining tail only (never rewrite)
            if (hadDelta && final?.text) {
              const ft = String(final.text || "");
              if (ft.startsWith(raw) && ft.length > raw.length) {
                const tail = ft.slice(raw.length);
                raw += tail;
                try {
                  safeEnqueue({ type: "delta", text: tail });
                } catch {
                  // ignore
                }
              }
            }
            if (!hadDelta && final?.text) {
              const ft = String(final.text || "");
              raw += ft;
              try {
                safeEnqueue({ type: "delta", text: ft });
              } catch {
                // ignore
              }
            }

            // Finish reason should be sourced from usage metadata; in this stream handler `final`
            // only includes { text, usage } (no finishReason field).
            const finishReason = String(
              (usage && (usage.finishReason || usage.native_finish_reason || (usage as any).nativeFinishReason)) || ""
            ).toUpperCase();
            if (STREAM_DEBUG) console.debug(`${streamTag} gen.done (${tag}) finishReason=${finishReason}`);
            return { raw, usage, finishReason };
            } finally {
              clearInterval(hb);
            }
          };

          let combinedRaw = "";
          let combinedUsage: any = null;
          let finishReason = "";

          // 1) initial generation
          {
            const r0 = await runOne(user, "main");
            combinedRaw += r0.raw;
            combinedUsage = mergeUsage(combinedUsage, r0.usage);
            finishReason = r0.finishReason;
          }

          // 2) auto-continue up to N times if MAX_TOKENS
          // NOTE: gemini-3-pro-preview can be slow and is more likely to hit ALB/edge idle timeouts.
          // Limit auto-continue to 1 for gemini-3-pro* to reduce long chained requests.
          const isGemini3Pro = typeof opts.model === "string" && opts.model.includes("gemini-3-pro");
          const MAX_CONTINUES = isGemini3Pro ? 1 : 2;
          for (let i = 0; i < MAX_CONTINUES; i++) {
                        if (finishReason !== "MAX_TOKENS") break;
            // If the model already produced a complete fenced meta block at the end, do not auto-continue.
            // Continuing from here often causes "text after status/info fence" artifacts.
            if (endsWithCompleteFence(combinedRaw)) {
              finishReason = "STOP";
              break;
            }
            const contUser = makeContinueUser(combinedRaw);
            const r = await runOne(contUser, `cont${i + 1}`);
            combinedRaw += r.raw;
            combinedUsage = mergeUsage(combinedUsage, r.usage);
            finishReason = r.finishReason;
          }

          // Preserve final finishReason in usage for logging/UI.
          try {
            if (combinedUsage) combinedUsage.finishReason = finishReason || combinedUsage.finishReason;
          } catch {
            // ignore
          }

          const latestUsage: any = combinedUsage;
          const raw = combinedRaw;

          tEnd(tGeminiStream);

          // (기존 후처리 핵심만 적용: 이름/지문 오류 정리 + 완결 보정 + 예산 컷)
          let assistantText = raw;
          assistantText = stripNamePrefixFromNarration(assistantText);
          assistantText = stripDialogueWrappedNarration(assistantText);
          assistantText = stripEndMarker(assistantText);
          // In novel mode, avoid aggressive trimming that can drop early scene setup.
// (chat mode only) keep trimToComplete; in novel mode we keep append-only content.
          if (renderMode === "chat") {
            assistantText = trimToComplete(assistantText);
          }
          // Always enforce novel-only output markers (removes accidental markdown markers, keeps *...* / "..." / fenced).
          assistantText = enforceNovelOnlyOutput(assistantText);

          // Label-agnostic fence stabilization (opening line split + unclosed fence repair + conservative loose-meta wrapping)
          assistantText = normalizeAnyFenceOpen(assistantText);
          assistantText = repairUnclosedAnyFence(assistantText);
          assistantText = wrapLooseMetaAsFence(assistantText).text;
	          // If the model closes a fenced meta/status block and then keeps writing,
	          // treat everything after the final closing fence as garbage.
	          assistantText = stripTrailingTextAfterFinalFence(assistantText);

          // 상태창/메타 코드는 별도 API가 담당한다.
          // main 출력은 서사 텍스트만 남기도록 fenced 블록을 모두 제거한다.
          assistantText = stripAllFencedBlocks(assistantText);

          // Keep trailing meta/status fenced block intact by trimming the body first.
          assistantText = preserveTrailingFenceBlockWithinBudget(assistantText, maxChars);

          // NOTE: do not override maxChars here; use the value computed from UI/output settings above.
          if (!NO_TRUNCATE_OUTPUT) {
            if (!NO_TRUNCATE_OUTPUT) assistantText = truncateToCharBudget(assistantText, maxChars);
          }

          if (renderMode === "chat") {
            assistantText = normalizeNovelOutput(assistantText, personaNameFinal, npcName, userLine);
            assistantText = enforceNoPreDialogueTokenLeakForMode(assistantText, renderMode);
          }

          // messages 저장
          const createdAt = Date.now();
          const assistantId = randomUUID();

          db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
            assistantId,
            String(chatId),
            "assistant",
            assistantText,
            createdAt
          );

          // usage 저장(있을 때만)
          if (latestUsage) {
            const promptTokens = Number(latestUsage.promptTokens || 0) || 0;
            const outputTokens = Number(latestUsage.outputTokens || 0) || 0;
            const reasoningTokens = Number(latestUsage.reasoningTokens || 0) || 0;
            const totalTokens =
              Number(latestUsage.totalTokens || 0) || promptTokens + outputTokens + reasoningTokens;
            const latencyMs = Number(latestUsage.latencyMs || 0) || 0;

            const cost = estimateCost(String(latestUsage.model || opts.model), promptTokens, outputTokens);
            // prompt token breakdown (실측 promptTokens를 구성요소별로 배분; 합계는 항상 promptTokens)
            // - 정확한 토크나이저가 없으므로 각 블록의 "추정 토큰" 비율로 promptTokens를 배분한다.
            // - 단, 값이 존재하는 항목은 최소 1토큰을 보장해(표시 0 방지) 사용자에게 어디서 소비되는지 보이게 한다.
            const w = (s: string) => {
              const t = estTokens(s || "");
              return (s && s.trim().length > 0) ? Math.max(1, t) : 0;
            };

            const presetPromptW = w(presetBlock);
            const lorebookW = w(typeof loreBlock === "string" ? loreBlock : "");
            const personaW = w(personaBlock);
            const userNoteW = w(noteBlock);
            const longMemoryW = w(historySummary);
            const recentTurnsW = w(context);
            const userInputW = w(userLine);

            // system 전체에는 위 블록들이 포함되어 있으므로, 남는 부분을 "시스템/규칙"으로 분리한다.
            const systemW = estTokens(system);
            const systemAndRulesW = Math.max(
              0,
              systemW - (presetPromptW + lorebookW + personaW + userNoteW + longMemoryW)
            );

            const weights = {
              presetPrompt: presetPromptW,
              lorebookPrompt: lorebookW,
              persona: personaW,
              userNote: userNoteW,
              longMemorySummary: longMemoryW,
              recentTurns: recentTurnsW,
              userInput: userInputW,
              systemAndRules: systemAndRulesW,
            };

            const tokenBreakdown = distribute(promptTokens, weights);
            const estPromptTotal = promptTokens;

            // 스트리밍 응답(클라이언트 즉시 표시용)에도 동일 필드를 실어준다.
            try {
              latestUsage.tokenBreakdown = tokenBreakdown;
              latestUsage.estPromptTotal = estPromptTotal;
              latestUsage.estimatedCostUsd = cost.costUsd;
              latestUsage.estimatedCostKrw = cost.costKrw;
              latestUsage.usdToKrw = cost.usdToKrw;
            } catch {
              // ignore
            }


            db.prepare(
              `INSERT OR REPLACE INTO message_usage (messageId, chatId, model, promptTokens, outputTokens, reasoningTokens, totalTokens, latencyMs, estPromptTotal, tokenBreakdown, costUsd, costKrw, usdToKrw, createdAt)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            ).run(
              assistantId,
              String(chatId),
              String(latestUsage.model || opts.model),
              promptTokens,
              outputTokens,
              reasoningTokens,
              totalTokens,
              latencyMs,
              estPromptTotal,
              JSON.stringify(tokenBreakdown),
              cost.costUsd,
              cost.costKrw,
              cost.usdToKrw,
              createdAt
            );
          }

          safeEnqueue({
                type: "done",
                user: userMsg,
                assistant: {
                  id: assistantId,
                  chatId: String(chatId),
                  role: "assistant",
                  content: assistantText,
                  createdAt,
                },
                usage: latestUsage || null,
              });
          if (STREAM_DEBUG) console.debug(`${streamTag} done sent (len=${assistantText.length})`, { usage: latestUsage || null });
          safeClose();
        } catch (e: any) {
          if (STREAM_DEBUG) console.error(`${streamTag} stream error`, e);
          safeEnqueue({ type: "error", error: String(e?.message || e || "error") });
          safeClose();
        }
      })();
    },
  });

  return new Response(rs, {
    headers: {
      "Content-Type": "application/x-ndjson; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

let latestUsage: any = null;

    tStart(tGemini);
    const first = await generateText({
      system,
      user,
      opts: { ...opts, maxOutputTokens: boostedMaxOutputTokens },
    });
    let assistantText = first.text;
    latestUsage = first.usage;
    {
      const fr = String(first?.usage?.finishReason || "").toUpperCase();
      if (fr && fr !== "STOP" && fr !== "FINISH_REASON_UNSPECIFIED") {
        debugReasons.push(`finishReason:${fr}`);
      }
    }


    // 1) 토큰 상한으로 끊긴 경우: 같은 시스템/컨텍스트를 유지한 채 이어쓰기 요청을 몇 번 자동 수행
//    (재작성보다 이어쓰기가 자연스럽고, 사용자가 겪는 "중간 끊김"을 직접 해결)
//
//    ⚠️ 중요한 안정화:
//    - 상태/INFO/STATUS 같은 fenced 메타 블록이 중간에 나오면, 이어쓰기에서 그 뒤에 본문이 붙어 "상태창 뒤에 또 본문"이 생긴다.
//    - 그래서 이어쓰기 전에 마지막 fenced 블록(있다면)을 떼어두고(메타), 본문만 이어쓴 뒤 마지막에 메타를 1회만 붙인다.
const splitTrailingFenceBlock = (text: string) => {
  const t = String(text || "").trim();
  // 마지막 ```...``` 블록을 잡되, 끝에 있어야만 "메타"로 취급한다.
  const re = /```[^\n]*\n[\s\S]*?\n```\s*$/;
  const m = t.match(re);
  if (!m) return { body: t, meta: "" };
  const meta = m[0].trim();
  const body = t.slice(0, t.length - m[0].length).trim();
  return { body, meta };
};
const stripAllFenceBlocks = (text: string) => {
  const t = String(text || "");
  // 모든 fenced 블록을 제거(이어쓰기에서는 절대 메타/코드블록을 만들지 않도록)
  return t.replace(/```[^\n]*\n[\s\S]*?\n```/g, "").trim();
};

let finish = String((first as any)?.usage?.finishReason || "");

// meta를 분리한 본문 기준으로 이어쓰기를 수행한다.
const _split0 = splitTrailingFenceBlock(assistantText);
let metaTail = _split0.meta;
assistantText = _split0.body;

for (let i = 0; i < 2; i++) {
  const cutByMax = /MAX/i.test(finish);
  if (cutByMax) debugReasons.push("continue:MAX_TOKENS");
  if (!cutByMax) break;

  const tail = assistantText.slice(-600);
  const contUser = [
    "너는 방금 출력한 답변의 '서사 본문'을 이어서 계속 써야 한다.",
    "- 절대 앞부분을 반복하지 말고, 바로 이어서 계속한다.",
    "- 형식은 유지한다: 지문은 *...*, 상대(NPC) 대사는 큰따옴표 \"...\".",
    "- (중요) fenced 코드블록(```...```)은 절대 출력하지 마라. 상태/INFO/STATUS 같은 메타 블록 출력 금지.",
    "- (중요) 서사 본문은 따옴표 대사로 끝내지 말고, 반드시 *...* 지문 한 줄로 장면을 닫아라.",
    "",
    "[이전 출력의 끝부분]",
    tail,
    "",
    "이어서 출력하라."
  ].join("\n");

  // 남은 분량만큼만 이어쓰기 예산을 준다(폭주 방지)
  const curLen = Array.from(String((assistantText || "").trim())).length;
  const room = Math.max(0, runawayMaxChars - curLen);
  if (room <= 80) {
    debugReasons.push(`continue:MAX_TOKENS_SKIP(room=${room})`);
    break;
  }
  const extendTokens = Math.max(256, Math.min(2048, Math.floor(room * 2.0)));

  const cont = await generateText({
    system,
    user: contUser,
    opts: { ...opts, maxOutputTokens: extendTokens },
  });

  const moreRaw = stripEndMarker(cont.text);
  const more = stripAllFenceBlocks(moreRaw);

  // 일부 모델은 MAX_TOKENS인데도 빈 문자열을 내는 경우가 있어(특히 3-pro),
  // 이때는 무한 이어쓰기를 피하기 위해 즉시 중단한다.
  if (!more) {
    debugReasons.push("continue:EMPTY_DELTA");
    latestUsage = cont.usage || latestUsage;
    finish = String(cont?.usage?.finishReason || "");
    break;
  }

  assistantText = `${stripEndMarker(assistantText)}\n${more}`.trim();
  latestUsage = cont.usage || latestUsage;
  finish = String(cont?.usage?.finishReason || "");
}

const strlenLocal = (s: string) => Array.from(String(s || "")).length;

// 1-b) 절단 금지 모드에서도 답변이 지나치게 짧게 끝나면(특히 gemini-3-pro* 조기 STOP),
//      재작성 없이 '이어쓰기'를 1회만 수행해 분량을 보강한다.
//      (프롬프트에서 이미 분량을 강하게 요구하지만, 안전망으로 둔다.)
if (NO_TRUNCATE_OUTPUT) {
  const curLen = strlenLocal((assistantText || "").trim());
  const gap = promptMinChars - curLen;

  // - 목표(90%)보다 부족할 때만 보강
  // - 너무 조금(50자 이하) 부족한 건 그냥 넘어감(과잉 생성 방지)
  // - 이미 폭주 상한(runawayMaxChars)에 근접하면 보강하지 않음
  const room = runawayMaxChars - curLen;

  if (curLen > 0 && gap > 50 && room > 80) {
    debugReasons.push(`continue:SHORT(${curLen}<${promptMinChars}, gap=${gap})`);
    const tail = assistantText.slice(-700);

    // 이어쓰기 예산을 "필요한 만큼만" 부여해 폭주를 막는다.
    // (한글 1자 ≈ 0.6~1 토큰 가정, 넉넉히 3배)
    const extendTokens = Math.max(256, Math.min(2048, gap * 3));

    const contUser = [
      "너는 방금 출력한 서사 본문을 **바로 이어서** 조금만 더 보강해야 한다.",
      "- 절대 앞부분을 반복하지 말고, 직전 문장 다음부터 자연스럽게 이어간다.",
      "- 형식 유지: 지문 *...*, 상대 대사 \"...\"",
      "- 메타/상태창/코드블록 절대 금지.",
      "- 이미지/링크/URL/마크다운(![](), []()) 절대 금지.",
      `- (중요) 약 ${Math.min(gap, 900)}자 정도만 묘사를 더 추가해서 자연스럽게 마무리하라.`,
      "- 마지막은 반드시 *...* 지문 한 줄로 장면을 닫아라.",
      "",
      "[이전 출력의 끝부분]",
      tail,
      "",
      "이어서 출력하라.",
    ].join("\n");

    const cont = await generateText({
      system,
      user: contUser,
      opts: { ...opts, maxOutputTokens: extendTokens },
    });

    const moreRaw = stripEndMarker(cont.text);
    const more = stripAllFenceBlocks(moreRaw);

    if (more) {
      assistantText = `${stripEndMarker(assistantText)}\n${more}`.trim();
      latestUsage = cont.usage || latestUsage;
      finish = String(cont?.usage?.finishReason || finish || "");
    } else {
      debugReasons.push("continue:SHORT_EMPTY");
      latestUsage = cont.usage || latestUsage;
    }
  }
}

// (안전장치) 절단 금지 모드라도, 분량이 목표 대비 과도하게 튀면 저장 전에 완화 절단한다.
if (NO_TRUNCATE_OUTPUT) {
  const curLen = strlenLocal((assistantText || "").trim());
  if (curLen > runawayMaxChars) {
    debugReasons.push(`cap:RUNAWAY(${curLen}>${runawayMaxChars})`);
    assistantText = truncateToCharBudget(assistantText, runawayMaxChars);
  }
}

// 이어쓰기 후에는 (있다면) 메타 블록을 1회만 맨 끝에 붙인다.
if (metaTail) {
  assistantText = `${assistantText}\n\n${metaTail}`.trim();
}
// (요구사항) 초반 몇 번 답변이 너무 짧거나 중간에서 끊기는 케이스 보정
    // - "중간 끊김"이면: 같은 내용을 "완결" 형태로 재작성(짧아도 됨)
    // - "너무 짧음"이면: 형식 유지 + 조금 더 길게(하지만 끊기지 않게)
    const trimmed = (assistantText || "").trim();

    // 너무 긴 규칙을 주면 모델이 오히려 '*' 같은 잔해만 내보내는 케이스가 있어,
    // 최소 구조(주인공 대사 + 지문 + NPC 대사)만 만족하는지 강하게 검증한다.
    // 추가로 '길이'를 슬라이더 값(=targetChars)에 최대한 맞추기 위해
    // 너무 짧거나/너무 길면 1~2회 재작성하며 max_output_tokens를 동적으로 보정한다.
    const isTooShort = trimmed.length < minChars;
    const isTooLong = trimmed.length > maxChars + 80;
    const looksCut = trimmed.length > 0 && !/[\.!\?"\'\)\]\*]$/.test(trimmed);

    const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const hasNpcLine = new RegExp(`(^|\\n)${esc(npcName)}\\s*\\|\\s*.+`, "m").test(trimmed);
    const hasNarration = /(^|\n)\*[^\n]*\*/m.test(trimmed) || /(^|\n)\*[^\n]+/m.test(trimmed);
    const hasPersonaLine = new RegExp(`(^|\\n)${esc(personaName)}\\s*\\|\\s*.+`, "m").test(trimmed);

    const badShape = trimmed === "*" || trimmed === "" || !hasNpcLine || !hasPersonaLine || !hasNarration;

    // 길이 보정에 사용할 토큰 상한 계산(출력 길이와 사용 토큰/문자 비율 기반)
    const adjustMaxOutputTokens = (desiredChars: number) => {
      // 목표는 "최종 결과를 desiredChars 근처로" 맞추는 것이고, 실제 길이는 아래에서 문자수로 잘라 고정한다.
      // 문제는 max_output_tokens가 너무 낮으면(특히 1000 이하) 모델이 조기 종료/끊김/형식 누락을 내기 쉽다는 점.
      // 그래서 생성 단계에서는 **충분히 크게** 주고, 최종은 문자수로 잘라낸다.
      // 경험적으로(한글 기준) 1토큰당 1~4자까지 흔들릴 수 있으므로 여유를 두어 2.2배를 기본으로 둔다.
      const boosted = Math.floor(desiredChars * 2.2);
      return Math.max(512, Math.min(5000, boosted));
    };
    function strlen(s: string): number {
      return Array.from(String(s || "")).length;
    }
    function sliceChars(s: string, n: number): string {
      return Array.from(String(s || "")).slice(0, n).join("");
    }
    function truncateToCharBudget(text: string, budget: number): string {
      const t = String(text || "").trim();
      if (strlen(t) <= budget) return t;
      // 문장 단위로 최대한 자연스럽게 자르기
      const head = sliceChars(t, budget);
      // Prefer cutting on paragraph boundaries first, then line breaks, then sentence-ending punctuation.
      const candidates = ["\n\n", "\n", ".", "!", "?", "\"", "'", ")", "]"];
      let cut = -1;
      for (const c of candidates) {
        const idx = head.lastIndexOf(c);
        if (idx > cut) cut = idx;
      }
      const out = (cut >= Math.floor(budget * 0.55)) ? head.slice(0, cut + 1) : head;
      return out.trim();
    }

    if (!NO_TRUNCATE_OUTPUT && (badShape || looksCut || isTooShort || isTooLong)) {
      try {
        const retryUser = [
          user,
          "[추가 지시]",
          badShape
            ? "방금 답변이 형식을 만족하지 못했습니다(대사/지문 누락 또는 '*'만 출력). 아래 규칙대로 전체를 다시 작성하세요."
            : looksCut
              ? "방금 답변이 문장 중간에서 끊겼습니다. 같은 장면을 **짧아도 좋으니 완결**되게 다시 작성하세요."
              : isTooLong
                ? `방금 답변이 너무 깁니다. 같은 장면을 유지하되 군더더기를 줄여 약 ${targetChars}자(±10%) 안으로 더 짧고 밀도 있게 다시 작성하세요.`
                : `방금 답변이 너무 짧습니다. 같은 장면을 유지하되 묘사/상황/심리를 더 추가하여 최소 ${minChars}자 이상으로 충분히 길게 쓰고, 끝까지 완결되게 다시 작성하세요.`,
          "- 반드시 한국어",
          `- 글자수 목표: 약 ${targetChars}자(±10%), 가능하면 ${maxChars}자 이내`,
      `  1) 지문 1~3문장: *...* (행동/표정/상황/심리)`,
      `  2) 주인공 대사 1줄: ${personaNameFinal} | "..." (반드시 큰따옴표로 감싼다)`,
      `  3) 상대 대사 1~3줄: ${preset.characterName || "상대"} | "..." (반드시 큰따옴표로 감싼다)`,
          "- 지문 줄에는 이름 접두를 붙이지 말 것",
          "- 마지막은 마침표/물음표/느낌표/따옴표 중 하나로 문장을 완결하고 종료한다. ([END] 금지)",
          "[주인공 대사(그대로)]",
          userLine,
          "[이전 답변(참고용, 그대로 복붙 금지)]",
          assistantText,
        ].join("\n");

        // 길이/형식 보정 시에는 max_output_tokens를 동적으로 조절한다.
        // - 너무 짧으면 더 쓸 수 있게 상향
        // - 너무 길면 짧게 쓰도록 하향
        const nextMaxOut = adjustMaxOutputTokens(targetChars);
        const rewritten = await generateText({
          system,
          user: retryUser,
          opts: { ...opts, maxOutputTokens: nextMaxOut },
        });
        if (rewritten?.text) {
          assistantText = rewritten.text;
          latestUsage = rewritten.usage;
        }
      } catch {
        // ignore
      }
    }

    // (요구사항 #2)
    // "이어쓰기"는 모델이 그대로 지시문을 섞어 출력하거나(예: '이어지는...') 빈 문자열이 나오는 경우가 있어,
    // 2차 재작성 + 최종 문장 단위 절단으로 안정적으로 '완결'을 보장한다.
    assistantText = stripEndMarker(assistantText || "");

    const t1 = (assistantText || "").trim();
    const stillCut = t1.length > 0 && !/[\.\!\?\"\'\)\]\*]$/.test(t1);
    if (!NO_TRUNCATE_OUTPUT && stillCut) {
      try {
        const retryUser2 = [
          user,
          "[추가 지시]",
          "아래 텍스트는 마지막 문장이 미완성입니다. 같은 내용을 **완결된 형태로 전체를 다시 작성**하세요.",
          "- 출력 형식(대사: 이름 | 내용 / 지문: *...*)은 반드시 유지",
          "- 마지막은 완결된 문장/문단으로 끝내기. ([END] 금지)",
          `- 글자수 목표: 약 ${targetChars}자(±10%), 가능하면 ${maxChars}자 이내`,
          "[미완성 텍스트]",
          assistantText,
        ].join("\n");

        const rewritten2 = await generateText({
          system,
          user: retryUser2,
          opts: { ...opts, maxOutputTokens: adjustMaxOutputTokens(targetChars) },
        });

        if (rewritten2?.text) {
          assistantText = stripEndMarker(rewritten2.text);
          latestUsage = rewritten2.usage;
        }
      } catch {
        // ignore
      }
    }

    if (!NO_TRUNCATE_OUTPUT) {
      assistantText = trimToComplete(stripEndMarker(assistantText || ""));
    }

    // 마크다운(STATUS 코드펜스) 누락 복구
    {
      const n = normalizeStatusFenceOpen(assistantText);
      if (n.normalized) {
        assistantText = n.text;
        console.warn(`[chat/send] normalized STATUS opening fence (non-stream)`, {
          chatId: String(chatId),
        });
      }
      const r = repairUnclosedStatusFence(assistantText);
      assistantText = r.text;
      if (r.repaired) {
        console.warn(`[chat/send] repaired unclosed STATUS fence (non-stream)`, {
          chatId: String(chatId),
          model: String(opts.model || ""),
        });
      }
    }
    // UI/형식 안정화: 지문 접두/주인공 대사 주체 오류를 최소한으로 교정
    if (renderMode === "chat") {
            assistantText = normalizeNovelOutput(assistantText, personaNameFinal, npcName, userLine);
            assistantText = enforceNoPreDialogueTokenLeakForMode(assistantText, renderMode);
          }

    // (핵심) 슬라이더 값(예: 800/1600)에 맞춰 **문자수 기준**으로 최종 길이를 고정한다.
    // - 내부적으로는 max_output_tokens를 넉넉히 줄 수 있지만,
    // - 사용자에게 노출되는 결과는 목표 문자수 범위(±) 안으로 맞춘다.
    const _beforeCharBudget = assistantText;
    if (!NO_TRUNCATE_OUTPUT) assistantText = truncateToCharBudget(assistantText, maxChars);
    if (strlen(_beforeCharBudget) > maxChars) debugReasons.push("trim:CHAR_BUDGET");

    // 여전히 너무 짧으면(특히 1,000 이하 구간) 1회 더 재작성한다.
    if (!NO_TRUNCATE_OUTPUT && (strlen(assistantText) < Math.min(minChars, Math.floor(targetChars * 0.35)) || strlen(assistantText) < 180)) {
      try {
        const retryUser3 = [
          user,
          "[추가 지시]",
          `지금 답변이 너무 짧습니다. 같은 장면을 유지하되 최소 ${minChars}자 이상으로 충분히 서술하고, 끝까지 완결되게 다시 작성하세요.`,
          `- 글자수 목표: 약 ${targetChars}자(±10%), 가능하면 ${maxChars}자 이내`,
          "- 첫 줄은 지문으로 시작(대사로 시작 금지)",
          "- 지문(*...*)에는 이름 접두를 붙이지 말 것",
          "- 마지막은 완결된 문장/문단으로 종료. ([END] 금지)",
          "[주인공 대사(그대로)]",
          userLine,
        ].join("\n");
        const rewritten3 = await generateText({
          system,
          user: retryUser3,
          opts: { ...opts, maxOutputTokens: adjustMaxOutputTokens(targetChars) },
        });
        if (rewritten3?.text) {
          assistantText = renderMode === "chat" ? normalizeNovelOutput(stripEndMarker(rewritten3.text), personaNameFinal, npcName, userLine) : normalizeNovelPlain(rewritten3.text);
          const _beforeCharBudget2 = assistantText;
          if (!NO_TRUNCATE_OUTPUT) {
            if (!NO_TRUNCATE_OUTPUT) assistantText = truncateToCharBudget(assistantText, maxChars);
          }
          if (strlen(_beforeCharBudget2) > maxChars) debugReasons.push("trim:CHAR_BUDGET");
          latestUsage = rewritten3.usage;
        }
      } catch {
        // ignore
      }
    }

    tEnd(tGemini);
    tStart(tPost);

    // ---- Token breakdown (prompt input composition) ----
    // promptTokens(실측)을 구성요소별로 "배분"해서 보여준다.
    // 각 구성요소의 가중치는 문자 기반 추정치(rough)이며, 합계는 promptTokens(실측)과 정확히 일치한다.
    function distribute(total: number, weights: Record<string, number>) {
      const entries = Object.entries(weights)
        .map(([k, w]) => [k, Math.max(0, Number(w) || 0)] as const)
        .filter(([, w]) => w > 0);
      const sumW = entries.reduce((a, [, w]) => a + w, 0);
      if (!Number.isFinite(total) || total <= 0 || sumW <= 0) {
        return Object.fromEntries(Object.keys(weights).map((k) => [k, 0]));
      }
      // floor 배분 후, 나머지를 소수점 큰 순서로 분배
      const raw = entries.map(([k, w]) => ({ k, w, exact: (total * w) / sumW }));
      const base = raw.map((r) => ({ ...r, n: Math.floor(r.exact), frac: r.exact - Math.floor(r.exact) }));
      let used = base.reduce((a, r) => a + r.n, 0);
      let remain = total - used;
      base.sort((a, b) => b.frac - a.frac);
      for (let i = 0; i < base.length && remain > 0; i++) {
        base[i].n += 1;
        remain -= 1;
      }
      const out: Record<string, number> = Object.fromEntries(Object.keys(weights).map((k) => [k, 0]));
      for (const r of base) out[r.k] = r.n;
      // 만약 remain이 남는 특이 케이스(가중치 동일 등)도 안전 처리
      if (remain > 0) {
        const keys = base.map((r) => r.k);
        for (let i = 0; i < remain; i++) out[keys[i % keys.length]] += 1;
      }
      return out;
    }

    const presetPromptW = estTokens(presetBlock);
    const personaW = estTokens(personaBlock);
    const userNoteW = estTokens(noteBlock);
    const longMemoryW = estTokens(historySummary);
    const lorebookW = estTokens(typeof loreBlock === "string" ? loreBlock : "");
    const systemW = estTokens(system);
    const systemAndRulesW = Math.max(0, systemW - (presetPromptW + personaW + userNoteW + longMemoryW + lorebookW));
    const recentTurnsW = estTokens(context);
    const userInputW = estTokens(userLine);

    const weights = {
      presetPrompt: presetPromptW,
      lorebookPrompt: lorebookW,
      persona: personaW,
      userNote: userNoteW,
      longMemorySummary: longMemoryW,
      systemAndRules: systemAndRulesW,
      recentTurns: recentTurnsW,
      userInput: userInputW,
    };

    // 비용 추정
    // - 기본: Gemini usageMetadata 기반(실측 input/output)
    // - UI에 표시하는 "예상 비용(추정)"은 "실측 토큰 + 입력 구성(추정)"을 합산한 값으로 계산(사용자 요청)
    const u0 = latestUsage || {};
    // NOTE: modelName is already used above for token budget caps; avoid redeclaration here.
    const modelNameForCost = String(u0.model || opts.model || "");
    const promptT = Number(u0.promptTokens || 0);
    const outT = Number(u0.outputTokens || 0);
    const cost = estimateCost(modelNameForCost, promptT, outT);

    const tokenBreakdown = distribute(promptT, weights);
    const estPromptTotal = Object.values(tokenBreakdown).reduce((a, b) => a + (Number(b) || 0), 0);

    let assistantMsg: any = {
      id: randomUUID(),
      chatId: cid,
      role: "assistant" as const,
      // (요구사항)
      // 응답 첫 줄이 인물 이름으로 시작하는 서술(예: "서윤아는...")이면
      // 억지로 "상대 |" 접두를 붙이지 않는다.
      content: ensurePrefix(assistantText || "(응답이 비었습니다.)", npcName, [personaName, npcName]),
      createdAt: Date.now(),
      usage: latestUsage
        ? {
            ...latestUsage,
            tokenBreakdown,
            estPromptTotal,
            estimatedCostUsd: cost.costUsd,
            estimatedCostKrw: cost.costKrw,
            usdToKrw: cost.usdToKrw,
            debugReasons,
          }
        : null,
    };

    if (replaceAid) {
      // 기존 assistant 메시지를 교체
      db.prepare(`UPDATE messages SET content=?, createdAt=? WHERE id=?`).run(
        encryptIfPossible(assistantMsg.content),
        assistantMsg.createdAt,
        replaceAid
      );
      assistantMsg.id = replaceAid;
    } else {
      db.prepare(`INSERT INTO messages (id, chatId, role, content, createdAt) VALUES (?, ?, ?, ?, ?)`).run(
        assistantMsg.id,
        assistantMsg.chatId,
        assistantMsg.role,
        encryptIfPossible(assistantMsg.content),
        assistantMsg.createdAt
      );
    }

    // 메시지별 토큰/지연 정보 저장(선택 기능)
    try {
      const u = latestUsage || {};
      const modelName2 = String(u.model || opts.model || "");
      const promptT2 = Number(u.promptTokens || 0);
      const outT2 = Number(u.outputTokens || 0);
	      const reasoningT2 = Number((u as any).reasoningTokens || 0);
	      const c = estimateCost(modelName2, promptT2, outT2);
      db.prepare(
	        `INSERT OR REPLACE INTO message_usage (messageId, chatId, model, promptTokens, outputTokens, reasoningTokens, totalTokens, latencyMs, estPromptTotal, tokenBreakdown, costUsd, costKrw, usdToKrw, createdAt)
	         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(messageId) DO UPDATE SET
           model=excluded.model,
           promptTokens=excluded.promptTokens,
           outputTokens=excluded.outputTokens,
	           reasoningTokens=excluded.reasoningTokens,
           totalTokens=excluded.totalTokens,
           latencyMs=excluded.latencyMs,
           estPromptTotal=excluded.estPromptTotal,
           tokenBreakdown=excluded.tokenBreakdown,
           costUsd=excluded.costUsd,
           costKrw=excluded.costKrw,
           usdToKrw=excluded.usdToKrw,
           createdAt=excluded.createdAt`
      ).run(
        assistantMsg.id,
        cid,
        String(u.model || opts.model || ''),
        Number(u.promptTokens || 0),
	        Number(u.outputTokens || 0),
	        reasoningT2,
        Number(u.totalTokens || 0),
        Number(u.latencyMs || 0),
        Number(u.estPromptTotal || 0),
        JSON.stringify(u.tokenBreakdown || {}),
        Number(c.costUsd || 0),
        Number(c.costKrw || 0),
        Number(c.usdToKrw || DEFAULT_USD_TO_KRW),
        assistantMsg.createdAt
      );
    } catch {
      // ignore
    }

    // (선택지) 사용자가 다음에 말할만한 답변 3개를 제안
    let suggestions: string[] = [];
    try {
      const suggestSystem = [
        "너는 한국어 대화 보조자다.",
        "사용자가 다음에 보낼만한 짧은 답변 후보 3개를 제안한다.",
        "반드시 **주인공(사용자) 시점**의 답변으로만 구성한다.",
        "- 즉, '내/나/저/제가' 등 1인칭을 사용하거나, 주인공이 직접 말하는 문장이어야 한다.",
        "- 상대 캐릭터(서윤아/이춘복 등)의 시점/독백/지문을 쓰지 않는다.",
        "- 이름 접두(예: '서윤아 |')나 지문(*...*)를 포함하지 않는다.",
        "각 항목은 1줄, 4~40자, 존댓말/반말은 현재 톤을 유지한다.",
        "출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\",\"...\"]}",
      ].join("\n");
      const suggestUser = [
        "[최근 대화]",
        context || "",
        "[사용자 방금 입력]",
        userText,
        "[상대 방금 응답]",
        assistantMsg.content,
      ].join("\n");

      const raw = await generateText({
        system: suggestSystem,
        user: suggestUser,
        opts: { ...opts, maxOutputTokens: Math.min(256, Number(settings.maxOutputTokens ?? 1024)) },
      });
      const rawStr = String(raw?.text || "{}").trim();
      // 모델이 코드펜스/설명을 섞어도 JSON만 최대한 추출
      const a = rawStr.indexOf("{");
      const b = rawStr.lastIndexOf("}");
      const jsonStr = a !== -1 && b !== -1 && b > a ? rawStr.slice(a, b + 1) : rawStr;
      const parsed = JSON.parse(jsonStr || "{}");
      if (Array.isArray(parsed.suggestions)) {
        suggestions = parsed.suggestions.map((s: any) => String(s || "").trim()).filter(Boolean).slice(0, 3);
      }
    } catch {
      // ignore
    }

    // usage는 즉시 렌더링을 위해 함께 내려준다.
    try {
      if (debugReasons.length) {
        console.warn(`[send][${cid}][${reqId}] debug`, debugReasons);
      }
    } catch {
      // ignore
    }
    tEnd(tPost);
    tEnd(tSendTotal);
    return NextResponse.json({ chatId: cid, user: userMsg, assistant: assistantMsg, suggestions, usage: latestUsage || null, debugReasons });
  } catch (e: any) {
    // 서버 로그에 남겨서 EC2 콘솔에서 바로 원인 확인 가능
    try {
      console.error("/api/chat/send error:", e?.message || e, e?.stack);
    } catch {
      // ignore
    }

    // 클라이언트에서는 원인 파악이 필요하므로 message를 함께 내려준다(민감정보는 포함하지 않음)
    const msg = String(e?.message || "요청 처리 중 오류가 발생했습니다.");
	    // (주의) 이 함수는 try 블록 내부에서만 타이머 헬퍼가 생성된다.
	    // 에러 상황에서는 타이머 종료를 강제하지 않고 서버 로그를 우선한다.
    // (안전) 가능한 경우 타이머 종료
    try {
      _tEnd(_tPost);
      _tEnd(_tSendTotal);
    } catch {
      // ignore
    }
    if (debugReasons.length) {
      console.warn(`[send][${_cidForLog}][${_reqIdForLog}] debug`, debugReasons);
    }
    return NextResponse.json(
      {
        error: "요청 처리 중 오류가 발생했습니다. 입력값/서버 로그를 확인해 주세요.",
        detail: msg,
      },
      { status: 500 }
    );
  }
}
