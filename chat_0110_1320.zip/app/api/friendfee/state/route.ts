import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, verifySession } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";

function noStore(res: NextResponse) {
  res.headers.set("Cache-Control", "no-store, max-age=0");
  res.headers.set("Pragma", "no-cache");
  res.headers.append("Vary", "Cookie");
  return res;
}

function ensureWallet(email: string) {
  const now = Date.now();
  db.prepare(
    `INSERT INTO friendfee_wallet (userEmail, balance, updatedAt)
     VALUES (?, 0, ?)
     ON CONFLICT(userEmail) DO NOTHING`
  ).run(email, now);
}

export async function GET(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value ?? "";
  const session = token ? await verifySession(token) : null;
  if (!session?.email) {
    return noStore(NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 }));
  }

  ensureWallet(session.email);

  // friendfee_touch_user: update last seen for admin panel
  const nowIso = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (email, created_at, updated_at, last_login_at, last_seen_at)
     VALUES (?, datetime('now'), datetime('now'), ?, ?)
     ON CONFLICT(email) DO UPDATE SET
       updated_at = datetime('now'),
       last_seen_at = excluded.last_seen_at`
  ).run(session.email, nowIso, nowIso);

  const wallet = db
    .prepare(`SELECT balance, updatedAt FROM friendfee_wallet WHERE userEmail = ?`)
    .get(session.email) as any;

  const daysRows = db
    .prepare(`SELECT dayKey FROM friendfee_attendance WHERE userEmail = ? ORDER BY dayKey ASC`)
    .all(session.email) as any[];
  const days = daysRows.map((r) => String(r.dayKey));
  const lastCheck = days.length ? days[days.length - 1] : null;

  return noStore(
    NextResponse.json({
      ok: true,
      balance: Number(wallet?.balance ?? 0),
      updatedAt: Number(wallet?.updatedAt ?? 0),
      attendance: { days, lastCheck },
    })
  );
}
