const Database = require("better-sqlite3");
const path = require("path");

// sqlite 파일 위치 (프로젝트 루트 기준)
const dbPath = path.join(process.cwd(), "data.sqlite3");
const db = new Database(dbPath);

db.exec(`
CREATE TABLE IF NOT EXISTS presets (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  background TEXT NOT NULL,
  character TEXT NOT NULL,
  systemPrompt TEXT NOT NULL,
  createdAt INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS chats (
  id TEXT PRIMARY KEY,
  presetId TEXT NOT NULL,
  title TEXT,
  createdAt INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  chatId TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  createdAt INTEGER NOT NULL
);
`);

console.log("DB init done:", dbPath);
