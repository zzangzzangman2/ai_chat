import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, isAdminEmail } from "@/lib/auth";

function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const isAdmin = isAdminEmail(u.email);
  try {
    const body = (await req.json()) as { id?: string };
    const id = String(body?.id || "").trim();
    if (!id) return bad("삭제할 프리셋 id가 필요합니다.");

    const preset = isAdmin
      ? (db.prepare(`SELECT id FROM presets WHERE id=?`).get(id) as any)
      : (db.prepare(`SELECT id FROM presets WHERE id=? AND userEmail=?`).get(id, u.email) as any);
    if (!preset) {
      return NextResponse.json({ error: "프리셋을 찾지 못했습니다." }, { status: 404 });
    }

    // 연결된 채팅/메시지/설정/요약 캐시까지 함께 삭제
    const tx = db.transaction(() => {
      const chatIds = isAdmin
        ? (db.prepare(`SELECT id FROM chats WHERE presetId=?`).all(id) as any[])
        : (db.prepare(`SELECT id FROM chats WHERE presetId=? AND userEmail=?`).all(id, u.email) as any[]);
      for (const c of chatIds) {
        const cid = c.id as string;
        db.prepare(`DELETE FROM messages WHERE chatId=?`).run(cid);
        db.prepare(`DELETE FROM chat_settings WHERE chatId=?`).run(cid);
        db.prepare(`DELETE FROM chat_memory_cache WHERE chatId=?`).run(cid);
      }
      if (isAdmin) {
        db.prepare(`DELETE FROM chats WHERE presetId=?`).run(id);
        db.prepare(`DELETE FROM presets WHERE id=?`).run(id);
      } else {
        db.prepare(`DELETE FROM chats WHERE presetId=? AND userEmail=?`).run(id, u.email);
        db.prepare(`DELETE FROM presets WHERE id=? AND userEmail=?`).run(id, u.email);
      }
    });

    tx();
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: "프리셋 삭제 중 오류가 발생했습니다." },
      { status: 500 }
    );
  }
}
