import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { decryptIfPossible } from "@/lib/crypto";
import { generateText } from "@/lib/ai";

type Role = "user" | "assistant";

function safeStr(v: any): string {
  return String(v ?? "");
}

function clampStr(s: string, max: number): string {
  const t = safeStr(s);
  if (t.length <= max) return t;
  return t.slice(0, max);
}

function normalizeLine(s: string): string {
  // suggestions must be dialogue only: no leading list markers, no role tags, no quotes wrapping, no markdown
  let t = safeStr(s).trim();
  t = t.replace(/^[-*\d\)\.]+\s+/g, "");
  t = t.replace(/^(주인공|나|당신|상대|NPC|\[.*?\])\s*[:|]\s*/i, "");
  // Strip surrounding quotes (but keep inner quotes)
  // NOTE: Avoid the /s (dotAll) flag for older TS targets by using [\s\S].
  t = t.replace(/^"([\s\S]+)"$/, "$1");
  t = t.replace(/^“([\s\S]+)”$/, "$1");
  // Remove markdown images/links
  t = t.replace(/!\[[^\]]*\]\([^\)]+\)/g, "").trim();
  t = t.replace(/\[[^\]]*\]\([^\)]+\)/g, "").trim();
  // Remove stray code fences
  t = t.replace(/```[\s\S]*?```/g, "").trim();
  // Collapse spaces
  t = t.replace(/\s+/g, " ").trim();
  // Hard clamp
  if (t.length > 120) t = t.slice(0, 120).trim();
  return t;
}

function pickTwoFallback(lastNpcOrAssistant: string): [string, string] {
  // Context-aware-ish but safe, always dialogue.
  const hint = normalizeLine(lastNpcOrAssistant);
  if (hint) {
    return [
      normalizeLine(`좋아. 방금 그 말, 어디까지가 진심이지?`),
      normalizeLine(`한 번만 더 말해봐. 너, 지금 뭘 노리는 거야?`),
    ];
  }
  return [normalizeLine("…지금 그 말, 책임질 수 있어?"), normalizeLine("좋아. 그럼 네가 원하는 걸 똑바로 말해."),];
}

function parseSuggestionsJson(raw: string): string[] {
  const t = safeStr(raw).trim();
  // direct JSON
  try {
    const obj = JSON.parse(t);
    const arr = (obj && (obj.suggestions ?? obj.Suggestions)) as any;
    if (Array.isArray(arr)) return arr.map((x) => safeStr(x));
  } catch {
    // ignore
  }
  // try to extract JSON substring
  const m = t.match(/\{[\s\S]*\}/);
  if (m) {
    try {
      const obj = JSON.parse(m[0]);
      const arr = (obj && (obj.suggestions ?? obj.Suggestions)) as any;
      if (Array.isArray(arr)) return arr.map((x) => safeStr(x));
    } catch {
      // ignore
    }
  }
  // fallback: take first 2 non-empty lines
  const lines = t
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  return lines.slice(0, 2);
}

export async function POST(req: Request) {
  try {
    const u = await getSessionUser();
    if (!u) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    const body = await req.json().catch(() => ({} as any));

    const chatId = safeStr(body?.chatId || "").trim();
    if (!chatId) {
      return NextResponse.json({ ok: false, error: "Missing chatId" }, { status: 400 });
    }

    const personaOverride = safeStr(body?.personaOverride || "");
    const assistantContent = safeStr(body?.assistantContent || "").trim();
    const userContent = safeStr(body?.userContent || "").trim();
    const previousSuggestions: string[] = Array.isArray(body?.previousSuggestions) ? body.previousSuggestions.map((x: any) => safeStr(x)) : [];

    // Prefer client-provided recentMessages to avoid stale DB reads right after streaming.
    const recentMessagesRaw = Array.isArray(body?.recentMessages) ? body.recentMessages : null;
    let recent: { role: Role; content: string }[] = [];

    if (recentMessagesRaw) {
      recent = recentMessagesRaw
        .map((m: any) => {
          const role: Role = m?.role === "user" ? "user" : "assistant";
          return { role, content: safeStr(m?.content || "") };
        })
        .filter((m: any) => (m.role === "user" || m.role === "assistant") && safeStr(m.content).trim().length > 0)
        .slice(-20)
        .map((m: any) => ({ role: m.role as Role, content: clampStr(m.content, 4000) }));
    } else {
      // DB fallback
      const rows = db
        .prepare(`SELECT role, content FROM messages WHERE chatId = ? ORDER BY createdAt DESC LIMIT 24`)
        .all(chatId)
        .reverse() as any[];
      recent = rows
        .map((r) => {
          const role: Role = r.role === "user" ? "user" : "assistant";
          return {
            role,
            content: safeStr(decryptIfPossible(safeStr(r.content || ""))),
          };
        })
        .filter((m) => (m.role === "user" || m.role === "assistant") && safeStr(m.content).trim().length > 0)
        .slice(-20)
        .map((m) => ({ role: m.role as Role, content: clampStr(m.content, 4000) }));
    }

    // Target text to ground on: assistantContent override > last assistant in recent
    let targetAssistant = assistantContent;
    if (!targetAssistant) {
      const lastA = [...recent].reverse().find((m) => m.role === "assistant");
      targetAssistant = safeStr(lastA?.content || "").trim();
    }

    // Some streams include image markdown; keep it for context but it should not dominate.
    const contextLines = recent
      .map((m) => `${m.role === "user" ? "U" : "A"}: ${m.content.replace(/\s+/g, " ").trim()}`)
      .join("\n")
      .slice(-8000);

    const lastLineHint = (userContent || targetAssistant || "").slice(-400);

    const system = [
      "너는 소설형 AI 채팅의 '추천 대사' 생성기다.",
      "반드시 한국어.",
      "반드시 '대사만' 출력한다. 지문(*...*), 해설, 분석, 목록, 번호, 따옴표로 감싼 전체 문장, 역할 태그(주인공|상대|NPC|:) 금지.",
      "반드시 2개를 만든다.",
      "주인공이 상대 NPC에게 바로 던질 말투로, 공격적/도발/협박/유도(선택 강요, 반박, 압박) 느낌을 강하게.",
      "둘은 서로 의미가 다르게(중복 금지).",
      "마크다운(이미지/링크/코드) 금지.",
      "출력은 JSON 한 줄로만: {\"suggestions\":[\"...\",\"...\"]}",
    ].join("\n");

    const user = [
      personaOverride ? `[주인공 설정]\n${clampStr(personaOverride, 1400)}` : "",
      "[최근 대화(가장 중요)]",
      contextLines || "(없음)",
      targetAssistant ? "\n[방금 상대/장면(특히 중요)]\n" + clampStr(targetAssistant, 1600) : "",
      userContent ? "\n[방금 주인공 입력(참고)]\n" + clampStr(userContent, 600) : "",
      previousSuggestions.length ? "\n[이전 추천(중복 금지)]\n" + previousSuggestions.map((s) => `- ${s}`).join("\n") : "",
      "\n[지시]",
      "- 위 맥락을 빠르게 요약해서, 지금 당장 이어질 주인공의 대사를 2개 제시해라.",
      "- 반드시 상대 NPC에게 바로 던질 대사만(한 줄 대사씩).",
      "- 반드시 지금 상황에 붙어 있어야 한다(일반론/뜬금포 금지).",
      "- 마지막에 끊기지 않게 완결된 문장으로 끝내라.",
      lastLineHint ? "\n[마지막 힌트]\n" + clampStr(lastLineHint, 240) : "",
    ].filter(Boolean).join("\n");

    const out = await generateText({
      system,
      user,
      opts: {
        // Fast + cheap, but keep enough quality
        model: "gemini-3-flash-preview",
        maxOutputTokens: 220,
        temperature: 0.9,
      } as any,
    });

    const raw = safeStr(out?.text || "").trim();
    const parsed = parseSuggestionsJson(raw);

    const cleaned = parsed.map(normalizeLine).filter(Boolean);
    let s1 = cleaned[0] || "";
    let s2 = cleaned[1] || "";

    if (!s1 || !s2 || s1 === s2) {
      const [f1, f2] = pickTwoFallback(targetAssistant || userContent);
      if (!s1) s1 = f1;
      if (!s2 || s1 === s2) s2 = f2;
    }

    // Ensure exactly 2
    const suggestions = [normalizeLine(s1), normalizeLine(s2)].filter(Boolean);
    while (suggestions.length < 2) suggestions.push(normalizeLine("…좋아. 계속해."));

    return NextResponse.json({ ok: true, suggestions: suggestions.slice(0, 2) });
  } catch (e: any) {
    // Never 500 the UI: return safe fallbacks
    const [a, b] = pickTwoFallback("");
    return NextResponse.json({ ok: true, suggestions: [a, b], warn: safeStr(e?.message || e) });
  }
}
