import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  throw new Error("GEMINI_API_KEY가 .env.local에 없습니다.");
}

export const genai = new GoogleGenAI({ apiKey });

export type ChatGenOpts = {
  model: string;
  maxOutputTokens: number;
  maxReasoningTokens: number;
};

function normalizeModelName(model: string) {
  const m = String(model || "").trim();
  if (!m) return "";
  // Some routers/providers prefix models like "google/gemini-3-pro-preview".
  const slash = m.lastIndexOf("/");
  return slash >= 0 ? m.slice(slash + 1) : m;
}

function isGemini3Pro(model: string) {
  const m = normalizeModelName(model);
  return m === "gemini-3-pro" || m.startsWith("gemini-3-pro-");
}

type ThinkingConfigAny = { thinkingBudget?: number; thinkingLevel?: string };

function buildThinkingConfig(model: string, maxReasoningTokens: number): ThinkingConfigAny | null {
  // Requirement:
  // - Gemini 2.5 / Gemini 3 Flash: keep numeric (thinkingBudget)
  // - Gemini 3 Pro: map UI low/middle/high preset to thinkingLevel (low/high)
  //   (Gemini 3 Pro supports thinkingLevel: "low" | "high")
  // Ref: https://ai.google.dev/gemini-api/docs/thinking
  if (isGemini3Pro(model)) {
    const t = Math.max(0, Number(maxReasoningTokens) || 0);
    // UI presets (gemini-3*): low=512, middle=1024, high=1536.
    // Map: low -> low, middle/high -> high.
    const level = t <= 768 ? "low" : "high";
    return { thinkingLevel: level };
  }

  const budget = Math.max(0, Number(maxReasoningTokens) || 0);
  if (!budget) return null;
  return { thinkingBudget: budget };
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function extractHttpStatus(err: any): number | null {
  const e = err || {};
  const cand = [
    e?.status,
    e?.code,
    e?.response?.status,
    e?.cause?.status,
    e?.cause?.code,
    e?.cause?.response?.status,
  ];
  for (const v of cand) {
    const n = Number(v);
    if (Number.isFinite(n) && n >= 100 && n <= 599) return Math.floor(n);
  }
  const msg = String(e?.message || e || "");
  const m = msg.match(/\b(429|500|502|503|504)\b/);
  if (m) return Number(m[1]);
  return null;
}

function isRetryableGeminiError(err: any) {
  const s = extractHttpStatus(err);
  // Typical transient classes: quota/rate (429), backend (5xx).
  return s === 429 || s === 500 || s === 502 || s === 503 || s === 504;
}

async function withRetry<T>(fn: () => Promise<T>, opts: { maxRetries: number; baseDelayMs: number; label?: string }) {
  let attempt = 0;
  let lastErr: any = null;
  while (attempt <= opts.maxRetries) {
    try {
      const value = await fn();
      return { value, retries: attempt };
    } catch (e: any) {
      lastErr = e;
      if (!isRetryableGeminiError(e) || attempt >= opts.maxRetries) throw e;
      const backoff = opts.baseDelayMs * Math.pow(2, attempt);
      const jitter = Math.floor(Math.random() * Math.max(50, opts.baseDelayMs));
      await sleep(backoff + jitter);
      attempt += 1;
      continue;
    }
  }
  // unreachable
  throw lastErr;
}

function isChatDebug() {
  // 로깅만 추가: 기존 기능/출력에는 영향 없음
  return String(process.env.CHAT_DEBUG || "").trim() === "1";
}

function safeLen(v: any) {
  return Array.from(String(v ?? "")).length;
}

function safePreview(v: any, max = 180) {
  const s = String(v ?? "");
  if (s.length <= max) return s;
  return s.slice(0, max) + "…";
}

export async function generateText(params: {
  system: string;
  user: string;
  opts: ChatGenOpts;
}) {
  const { system, user, opts } = params;

  const t0 = Date.now();

  // 일부 모델/SDK 조합에서 thinkingConfig가 지원되지 않아 500이 나는 케이스가 있어
  // 1차: thinkingConfig 포함
  // 2차(실패 시): thinkingConfig 제거
  const baseReq: any = {
    model: opts.model,
    contents: [{ role: "user", parts: [{ text: user }] }],
    config: {
      systemInstruction: system,
      maxOutputTokens: opts.maxOutputTokens,
    },
  };

  const thinkingConfig = buildThinkingConfig(opts.model, opts.maxReasoningTokens);
  const withThinking: any = thinkingConfig
    ? {
        ...baseReq,
        config: {
          ...baseReq.config,
          thinkingConfig,
        },
      }
    : null;

  let resp: any;
  let lastErr: any = null;
  const attempts: Array<{ label: string; ok: boolean; ms: number; err?: string }> = [];
  const reqs: Array<{ label: string; req: any }> = withThinking
    ? [
        { label: "withThinking", req: withThinking },
        { label: "base", req: baseReq },
      ]
    : [{ label: "base", req: baseReq }];

  if (isChatDebug()) {
    console.log(
      JSON.stringify({
        tag: "gemini.req",
        model: opts.model,
        maxOutputTokens: opts.maxOutputTokens,
        thinkingBudget: thinkingConfig?.thinkingBudget ?? null,
        thinkingLevel: thinkingConfig?.thinkingLevel ?? null,
        systemChars: safeLen(system),
        userChars: safeLen(user),
        systemPreview: safePreview(system),
        userPreview: safePreview(user),
      })
    );
  }

  for (const it of reqs) {
    const tAttempt = Date.now();
    try {
      const r = await withRetry(() => genai.models.generateContent(it.req), {
        maxRetries: 2,
        baseDelayMs: 650,
        label: it.label,
      });
      resp = r.value as any;
      lastErr = null;
      attempts.push({ label: it.label, ok: true, ms: Date.now() - tAttempt });
      break;
    } catch (e: any) {
      lastErr = e;
      attempts.push({ label: it.label, ok: false, ms: Date.now() - tAttempt, err: String(e?.message || e || "") });
    }
  }
  if (!resp) {
    const msg = String(lastErr?.message || lastErr || "Gemini API error");
    // Next.js route에서 그대로 500으로 던지지 말고, 원인 파악이 가능한 에러로 만든다.
    throw new Error(msg);
  }

  const latencyMs = Date.now() - t0;

  const text =
    resp?.text ??
    resp?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
    "";

  const usage = resp?.usageMetadata || resp?.usage || null;
  const finishReason =
    resp?.candidates?.[0]?.finishReason ??
    resp?.candidates?.[0]?.finish_reason ??
    resp?.finishReason ??
    resp?.finish_reason ??
    null;

  // Google 응답 포맷이 조금씩 달라질 수 있어 폭넓게 매핑
  const promptTokens = Number(usage?.promptTokenCount ?? usage?.prompt_tokens ?? 0) || 0;
  const outputTokens = Number(usage?.candidatesTokenCount ?? usage?.output_tokens ?? usage?.completion_tokens ?? 0) || 0;
  // thinking/reasoning 토큰(모델/SDK별 키가 다를 수 있어 폭넓게 매핑)
  const reasoningTokens =
    Number(
      usage?.thoughtsTokenCount ??
        usage?.reasoningTokenCount ??
        usage?.native_tokens_reasoning ??
        usage?.reasoning_tokens ??
        0
    ) || 0;

  const totalTokens = Number(usage?.totalTokenCount ?? usage?.total_tokens ?? 0) || (promptTokens + outputTokens + reasoningTokens);

  if (isChatDebug()) {
    console.log(
      JSON.stringify({
        tag: "gemini.resp",
        model: opts.model,
        latencyMs,
        attempts,
        finishReason,
        usage: {
          promptTokens,
          outputTokens,
          reasoningTokens,
          totalTokens,
        },
        textPreview: safePreview(text, 240),
      })
    );
  }

  return {
    text: String(text || "").trim(),
    usage: {
      promptTokens,
      outputTokens,
      reasoningTokens,
      totalTokens,
      latencyMs,
      model: opts.model,
      finishReason,
    },
  };
}


export async function generateTextStream(params: {
  system: string;
  user: string;
  opts: ChatGenOpts;
}): Promise<{ stream: AsyncIterable<string>; final: Promise<{ text: string; usage: any }> }> {
  const { system, user, opts } = params;

  const baseReq: any = {
    model: opts.model,
    contents: [{ role: "user", parts: [{ text: user }] }],
    config: {
      systemInstruction: system,
      maxOutputTokens: opts.maxOutputTokens,
    },
  };
  const thinkingConfig = buildThinkingConfig(opts.model, opts.maxReasoningTokens);
  const withThinking: any = thinkingConfig
    ? {
        ...baseReq,
        config: {
          ...baseReq.config,
          thinkingConfig,
        },
      }
    : null;

  const reqs: Array<{ label: string; req: any }> = withThinking
    ? [
        { label: "withThinking", req: withThinking },
        { label: "base", req: baseReq },
      ]
    : [{ label: "base", req: baseReq }];

  const streamFn = (genai.models as any)?.generateContentStream;
  if (typeof streamFn === "function") {
    for (const it of reqs) {
      try {
        // Gemini-3-pro-preview can fail transiently (429/5xx) more often, especially in streaming.
        // Retry ONLY before any token is emitted (i.e., when the stream hasn't started producing output).
        let streamLike: any = null;
        let responsePromiseRef: Promise<any> = Promise.resolve(null);
        let responseVersion = 0;

        const startStream = async () => {
          responseVersion += 1;
          const r = await withRetry(() => streamFn.call(genai.models, it.req), {
            maxRetries: 2,
            baseDelayMs: 650,
            label: it.label,
          });
          const streamResp: any = r.value;
          streamLike = streamResp?.stream ?? streamResp;
          responsePromiseRef = streamResp?.response
            ? Promise.resolve(streamResp.response)
            : streamResp?.getFinalResponse
              ? Promise.resolve(streamResp.getFinalResponse())
              : Promise.resolve(null);
          return r.retries;
        };

        await startStream();

        const getStableFinalResponse = async () => {
          // If responsePromiseRef is replaced due to a retry, make sure we return the latest one.
          while (true) {
            const v = responseVersion;
            const p = responsePromiseRef;
            const r = await p.catch(() => null);
            if (v === responseVersion) return r;
          }
        };

        function extractText(obj: any): string {
          return (
            obj?.text ??
            obj?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
            ""
          );
        }

        function isIgnorableChar(ch: string): boolean {
          // Invisible separator (U+2063) is used for speaker marks; treat as ignorable for prefix matching.
          // Also ignore BOM and CR to reduce false mismatches across SDK chunk boundaries.
          return ch === "\u2063" || ch === "\ufeff" || ch === "\r";
        }

        function matchPrefixIgnore(acc: string, t: string): number {
          // Try to match full `acc` as a prefix of `t` while ignoring certain characters in both strings.
          // Returns the raw index in `t` right after the matched prefix, or -1 if not matched.
          let ia = 0;
          let it = 0;

          const la = acc.length;
          const lt = t.length;

          while (ia < la || it < lt) {
            while (ia < la && isIgnorableChar(acc[ia])) ia++;
            while (it < lt && isIgnorableChar(t[it])) it++;

            if (ia >= la) {
              // Remaining acc are ignorable; prefix matched.
              return it;
            }
            if (it >= lt) return -1;

            if (acc[ia] !== t[it]) return -1;

            ia++;
            it++;
          }

          return ia >= la ? it : -1;
        }

        async function* iter() {
          // SDK/모델 조합에 따라 chunk.text가 "누적 텍스트"로 올 수도 있고 "delta"로 올 수도 있다.
          // - 누적이면: 앞부분(acc)과의 차이만(delta) 내보낸다.
          // - delta이면: 그대로 내보낸다.
          let acc = "";
          let restarts = 0;

          while (true) {
            try {
              for await (const chunk of streamLike as any) {
                const t = String(extractText(chunk) || "");
                if (!t) continue;

                let delta = t;
                if (t.startsWith(acc)) {
                  delta = t.slice(acc.length);
                }
                acc += delta;
                if (delta) yield String(delta);
              }
              break;
            } catch (e: any) {
              // If the stream errors out BEFORE producing any text, treat it as transient and retry a few times.
              if (acc.length === 0 && restarts < 2 && isRetryableGeminiError(e)) {
                restarts += 1;
                const backoff = 650 * Math.pow(2, restarts - 1);
                const jitter = Math.floor(Math.random() * 200);
                await sleep(backoff + jitter);
                await startStream();
                continue;
              }
              throw e;
            }
          }

          // 일부 환경에서는 스트림 종료 후 final response에만 남은 tail이 포함될 수 있다.
          // 이 경우, tail을 추가 delta로 흘려보내 UI에서 "중간 끊김 + 한 번에 나머지" 현상을 줄인다.
          try {
            const finalResp = await getStableFinalResponse();
            const finalText = String(extractText(finalResp) || "");
            if (finalText) {
              let cut = -1;
              if (finalText.startsWith(acc)) cut = acc.length;
              else if (acc) cut = matchPrefixIgnore(acc, finalText);
              if (cut >= 0 && finalText.length > cut) {
                const tail = finalText.slice(cut);
                acc += tail;
                if (tail) yield String(tail);
              }
            }
          } catch {
            // ignore
          }
        }

        const final = (async () => {
          const finalResp = await getStableFinalResponse();
          if (!finalResp) {
            const r = await generateText({ system, user, opts });
            return r;
          }
          const text =
            finalResp?.text ??
            finalResp?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
            "";
          const usage = finalResp?.usageMetadata || finalResp?.usage || null;

          const promptTokens = Number(usage?.promptTokenCount ?? usage?.prompt_tokens ?? 0) || 0;
          const outputTokens =
            Number(usage?.candidatesTokenCount ?? usage?.output_tokens ?? usage?.completion_tokens ?? 0) || 0;
          const reasoningTokens =
            Number(
              usage?.thoughtsTokenCount ??
                usage?.reasoningTokenCount ??
                usage?.native_tokens_reasoning ??
                usage?.reasoning_tokens ??
                0
            ) || 0;
          const totalTokens =
            Number(usage?.totalTokenCount ?? usage?.total_tokens ?? 0) ||
            promptTokens + outputTokens + reasoningTokens;

          return {
            text: String(text || "").trim(),
            usage: {
              promptTokens,
              outputTokens,
              reasoningTokens,
              totalTokens,
              latencyMs: 0,
              model: opts.model,
              finishReason: null,
            },
          };
        })();

        return { stream: iter(), final };
      } catch {
        // try next request variant
      }
    }
  }

  // fallback: non-stream call then chunk
  const r = await generateText({ system, user, opts });
  async function* chunker() {
    const s = String(r.text || "");
    const step = 64;
    for (let i = 0; i < s.length; i += step) {
      yield s.slice(i, i + step);
    }
  }
  return { stream: chunker(), final: Promise.resolve(r) };
}

export async function summarizeKorean(params: {
  text: string;
  targetChars: number;
  opts: ChatGenOpts;
  turnRangeLabel?: string;
  perTurnChars?: number;
  guidance?: string;
}) {
  const { text, targetChars, opts, turnRangeLabel, perTurnChars, guidance } = params;

  const system = `너는 장기기억(롱텀 메모리) 요약 작가다. 한국어로만 답한다. 반드시 마크다운 형식으로 출력한다.`;
  const user = `아래 [대화]를 기반으로 장기 기억 요약을 작성해줘.

요구사항:
- **형식 고정(매우 중요)**:
  - 출력에 '## 장기 기억 (...)' 같은 상위 헤더를 쓰지 마라.
  - 소제목(###)에 '(3-4턴)' 같은 턴 범위 표기를 붙이지 마라. (필요하면 문장으로 풀어쓴다.)
- **대사/인용 금지(매우 중요)**:
  - 요약에 **직접 대사**(따옴표로 감싼 문장), **대화 원문**(누가 뭐라고 말했다 형태의 문장 그대로), **화자 표기**(예: '오지명:', '오지명 |')를 넣지 마라.
  - 필요한 경우 **서술문으로 바꿔** 표현한다. (예: "울지 마" → 오지명이 서원을 압박하며 눈물을 참으라고 요구한다.)
  - 출력에 따옴표( " “ ” ‘ ’ )를 사용하지 마라.
- 문장은 반드시 완결형으로 끝내고, 말줄임표(...) 또는 "…"로 끝내지 마라.
- 전체 길이는 **가능하면** 대략 ${targetChars}자에 가깝게(±15% 내외) 작성하되, **절대** ${targetChars}자를 초과하지 마라.
- 각 소제목 본문은 **(해당 소제목이 커버하는 턴 수 × ${perTurnChars ?? 100}자) 이내**로 최대한 맞춘다(공백 포함). 길면 문장을 줄이거나 핵심만 남겨라.
- 형식은 반드시 아래 템플릿을 따른다:

- **턴 범위 표기/연속성 규칙(중요)**
  - 소제목의 (턴범위)는 반드시 실제 대화 턴 기준으로 표기한다.
  - **턴 누락 금지**: 예) (1-4턴) 다음에 (6-10턴)처럼 건너뛰면 안 된다. 필요한 경우 (1-4), (5-5), (6-10)처럼라도 연속되게 만든다.
  - 경계 턴(예: 5, 10, 15...)이 요약에서 빠지지 않도록, 정보가 적더라도 최소 1문장으로 포함한다.

## 장기 기억 (${turnRangeLabel ?? "이번 구간"})

### (소제목 1) (턴범위)
핵심 사건/관계/결정사항을 1~3문장으로 요약(군더더기 금지).

### (소제목 2) (턴범위)
...

- 소제목은 사건 중심으로 짧게
- 인물 이름/관계/상태 변화/결정/갈등을 빠뜨리지 말 것
- 사실 위주, 예측/미래 진행 금지

[추가 가이던스]
${(guidance || "").trim() || "(없음)"}

[대화]
${text}`;

  const r = await generateText({ system, user, opts });
  return r.text;
}

