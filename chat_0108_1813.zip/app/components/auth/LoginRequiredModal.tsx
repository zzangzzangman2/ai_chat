"use client";

import React, { useEffect } from "react";

export default function LoginRequiredModal(props: {
  open: boolean;
  presetTitle: string;
  presetThumb?: string;
  onClose: () => void;
}) {
  const { open, presetTitle, presetThumb, onClose } = props;

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const title = (presetTitle || "").trim() || "(제목 없음)";
  const thumb = (presetThumb || "").trim();

  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 2000,
        background: "rgba(0,0,0,0.62)",
        backdropFilter: "blur(10px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 18,
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        style={{
          width: "min(980px, 100%)",
          borderRadius: 22,
          overflow: "hidden",
          border: "1px solid rgba(255,255,255,0.12)",
          background: "rgba(10,10,12,0.96)",
          boxShadow: "0 24px 90px rgba(0,0,0,0.65)",
          position: "relative",
          display: "grid",
          gridTemplateColumns: "1.15fr 1fr",
        }}
      >
        <button
          type="button"
          aria-label="닫기"
          onClick={onClose}
          style={{
            position: "absolute",
            top: 12,
            right: 12,
            width: 38,
            height: 38,
            borderRadius: 12,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(255,255,255,0.06)",
            color: "#e9eefc",
            cursor: "pointer",
            fontWeight: 900,
            zIndex: 2,
          }}
        >
          ×
        </button>

        <div
          style={{
            padding: 26,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            background:
              "radial-gradient(900px 500px at 30% 20%, rgba(122,63,255,0.25), rgba(0,0,0,0) 55%)",
          }}
        >
          <div
            style={{
              display: "flex",
              gap: 12,
              alignItems: "center",
              padding: 14,
              borderRadius: 18,
              border: "1px solid rgba(255,255,255,0.10)",
              background: "rgba(255,255,255,0.05)",
            }}
          >
            <div
              style={{
                width: 52,
                height: 52,
                borderRadius: 14,
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.10)",
                overflow: "hidden",
                flex: "0 0 auto",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {thumb ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={thumb} alt={title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              ) : (
                <span style={{ fontWeight: 950, color: "rgba(233,238,252,0.75)" }}>M</span>
              )}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <div style={{ fontWeight: 950, fontSize: 16, lineHeight: 1.2 }}>{title}</div>
              <div style={{ fontSize: 12, opacity: 0.72 }}>계속하려면 로그인이 필요해요.</div>
            </div>
          </div>

          <div style={{ display: "grid", gap: 10, marginTop: 18 }}>
            <div style={{ fontSize: 24, fontWeight: 950, letterSpacing: "-0.3px" }}>메이트</div>
            <div style={{ fontSize: 13, opacity: 0.78, lineHeight: 1.5 }}>
              채팅 시작/작업실/메뉴 기능은 로그인 후 사용할 수 있습니다.
            </div>
          </div>

          <div style={{ fontSize: 12, opacity: 0.55, lineHeight: 1.5, marginTop: 18 }}>
            * 작품 리스트는 로그인 없이도 볼 수 있어요.
          </div>
        </div>

        <div style={{ padding: 26, display: "flex", flexDirection: "column", justifyContent: "center", gap: 12 }}>
          <div style={{ display: "grid", justifyItems: "center", gap: 10, padding: "10px 0 6px" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/mate.png"
              alt="MATE"
              style={{ width: 92, height: 92, borderRadius: 22, objectFit: "cover" }}
            />
            <div style={{ fontSize: 13, opacity: 0.8, textAlign: "center" }}>
              계속하려면 로그인이 필요합니다.
            </div>
          </div>

          <a
            href="/api/auth/google"
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
              width: "100%",
              borderRadius: 16,
              padding: "12px 14px",
              border: "1px solid rgba(255,255,255,0.14)",
              background: "rgba(155,92,255,0.18)",
              color: "#e9eefc",
              textDecoration: "none",
              fontWeight: 900,
            }}
          >
            Google로 계속하기
          </a>

          <div style={{ textAlign: "center", color: "rgba(233,238,252,0.6)", fontSize: 12, lineHeight: 1.5 }}>
            계속 진행하면 서비스 이용을 위한 로그인에 동의하는 것으로 간주합니다.
          </div>
        </div>
      </div>
    </div>
  );
}
