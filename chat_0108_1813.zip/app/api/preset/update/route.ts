// app/api/preset/update/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, isAdminEmail } from "@/lib/auth";

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const isAdmin = isAdminEmail(u.email);
  try {
    const body = await req.json();
    const id = String(body?.id || "");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

    const name = String(body?.name || "");
    const background = String(body?.background || "");
    const characterName = String(body?.characterName || "");
    const characterAge = Number(body?.characterAge || 0);
    const character = String(body?.character || "");
    const systemPrompt = String(body?.systemPrompt || "");

    const image = String(body?.image || "");
    const tags = String(body?.tags || "");
    const target = String(body?.target || "all");
    const isPublic = body?.isPublic === 0 || body?.isPublic === false ? 0 : 1;
    const gallery = String(body?.gallery || "[]");
    const firstMessages = String(body?.firstMessages || "[]");
    const lorebooks = String(body?.lorebooks || "[]");

    if (isAdmin) {
      db.prepare(
        `UPDATE presets
         SET name=?, background=?, characterName=?, characterAge=?, character=?, systemPrompt=?,
             image=?, tags=?, target=?, gallery=?, firstMessages=?, lorebooks=?, isPublic=?
         WHERE id=?`
      ).run(
        name,
        background,
        characterName,
        characterAge,
        character,
        systemPrompt,
        image,
        tags,
        target,
        gallery,
        firstMessages,
        lorebooks,
        isPublic,
        id
      );
    } else {
      db.prepare(
        `UPDATE presets
         SET name=?, background=?, characterName=?, characterAge=?, character=?, systemPrompt=?,
             image=?, tags=?, target=?, gallery=?, firstMessages=?, lorebooks=?, isPublic=?
         WHERE id=? AND userEmail=?`
      ).run(
        name,
        background,
        characterName,
        characterAge,
        character,
        systemPrompt,
        image,
        tags,
        target,
        gallery,
        firstMessages,
        lorebooks,
        isPublic,
        id,
        u.email
      );
    }

    const preset = isAdmin
      ? db.prepare(`SELECT * FROM presets WHERE id=?`).get(id)
      : db.prepare(`SELECT * FROM presets WHERE id=? AND userEmail=?`).get(id, u.email);
    return NextResponse.json({ preset });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}

