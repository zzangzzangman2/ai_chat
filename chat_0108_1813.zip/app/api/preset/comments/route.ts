import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { addPresetComment, listPresetComments } from "@/lib/db";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const presetId = (searchParams.get("presetId") || "").trim();
  const limit = Math.max(1, Math.min(100, Number(searchParams.get("limit") || 50)));

  if (!presetId) return NextResponse.json({ ok: false, error: "presetId required" }, { status: 400 });

  const u = await getSessionUser();
  const comments = listPresetComments(presetId, u?.email || null, limit);

  const res = NextResponse.json({ ok: true, comments });
  res.headers.set("Cache-Control", "no-store, max-age=0");
  return res;
}

export async function POST(req: NextRequest) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const presetId = String(body?.presetId || "").trim();
    const content = String(body?.content || "");
    if (!presetId) return NextResponse.json({ ok: false, error: "presetId required" }, { status: 400 });

    const comment = addPresetComment(presetId, u.email, content);
    return NextResponse.json({ ok: true, comment });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "error" }, { status: 400 });
  }
}
