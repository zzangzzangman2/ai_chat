// Minimal type shim for better-sqlite3 to satisfy TypeScript during Next.js builds.
// We intentionally keep this lightweight to avoid pulling external @types.

declare module "better-sqlite3" {
  const Database: any;
  export default Database;
}
