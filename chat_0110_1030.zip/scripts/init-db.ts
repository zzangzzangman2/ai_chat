import "../lib/db";
console.log("DB init done");
