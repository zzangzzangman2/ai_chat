import "../lib/db";

console.log("DB migration done");

