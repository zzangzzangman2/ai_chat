#!/usr/bin/env node
/**
 * lore_import_to_db.mjs
 * - Input: txt file with sections starting with "#"
 * - Output: writes JSON array into presets.lorebooks (as JSON string)
 *
 * Requirements:
 *   - Node 20+
 *   - better-sqlite3 installed (already in your project)
 *
 * Safe features:
 *   - Creates DB backup copy before update
 *   - Dry-run mode
 *   - Can list presets
 */

import fs from "fs";
import path from "path";
import crypto from "crypto";
import process from "process";

import Database from "better-sqlite3";

function usage() {
  console.log(`
Usage:
  node scripts/lore_import_to_db.mjs --presetId <id> --txt <file> [--db <dbpath>] [--dry-run]
  node scripts/lore_import_to_db.mjs --presetName "<name>" --txt <file> [--db <dbpath>] [--dry-run]
  node scripts/lore_import_to_db.mjs --list-presets [--db <dbpath>]

Options:
  --db         SQLite path (default tries: ai/data/data.sqlite3 then ai/data.sqlite3 then ai/data/data.sqlite3 relative)
  --presetId   Target preset id
  --presetName Target preset name (exact match)
  --txt        Lorebook source txt file
  --dry-run    Parse + show summary, do not write DB
  --list-presets  Print preset list (id, name, characterName)
  --max        Max lore items (default 100)
  --keysMode   activation key rule: "firstToken" | "fullTitle" (default firstToken)
               - firstToken: "아이신기오로 하이샨" -> "아이신기오로"
               - fullTitle : "아이신기오로 하이샨" -> "아이신기오로 하이샨"
`);
}

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) continue;
    const k = a.slice(2);
    const v = (i + 1 < argv.length && !argv[i + 1].startsWith("--")) ? argv[++i] : true;
    args[k] = v;
  }
  return args;
}

const HEADER_RE = /^\s*#\s*(.+?)\s*$/;

function normalizeTitle(raw) {
  let t = (raw ?? "").trim();
  // "남궁세가: ..." -> "남궁세가"
  if (t.includes(":")) t = t.split(":", 1)[0].trim();
  return t;
}

function makeActivationKey(rawTitle, keysMode) {
  const t0 = normalizeTitle(rawTitle);
  let t = t0.replace(/추가설정/g, "").trim();

  if (!t) return "";

  if (keysMode === "fullTitle") {
    return t;
  }

  // default: firstToken
  const parts = t.split(/\s+/).filter(Boolean);
  return parts.length ? parts[0] : t;
}

function cleanBlock(lines) {
  let start = 0;
  let end = lines.length - 1;
  while (start <= end && lines[start].trim() === "") start++;
  while (end >= start && lines[end].trim() === "") end--;
  const sliced = lines.slice(start, end + 1);
  return sliced.join("\n").replace(/\s+$/g, "");
}

function parseSections(text) {
  const sections = [];
  let currentTitle = null;
  let buf = [];

  for (const line of text.split(/\r?\n/)) {
    const m = HEADER_RE.exec(line);
    if (m) {
      // flush previous
      if (currentTitle !== null) {
        const content = cleanBlock(buf);
        if (content) sections.push({ title: currentTitle, content });
      }
      currentTitle = m[1].trim();
      buf = [];
    } else {
      buf.push(line.replace(/\s+$/g, ""));
    }
  }

  if (currentTitle !== null) {
    const content = cleanBlock(buf);
    if (content) sections.push({ title: currentTitle, content });
  }

  return sections;
}

function guessDbPath(cliDb) {
  if (cliDb && fs.existsSync(cliDb)) return cliDb;

  // Try common paths
  const candidates = [
    path.resolve(process.cwd(), "data", "data.sqlite3"),     // ai/data/data.sqlite3 (if cwd=ai)
    path.resolve(process.cwd(), "data.sqlite3"),            // ai/data.sqlite3
    path.resolve(process.cwd(), "ai", "data", "data.sqlite3"),
    path.resolve(process.cwd(), "ai", "data.sqlite3"),
  ];
  for (const c of candidates) {
    if (fs.existsSync(c)) return c;
  }
  // fallback to first candidate (may error later)
  return candidates[0];
}

function backupDb(dbPath) {
  const dir = path.dirname(dbPath);
  const base = path.basename(dbPath);
  const ts = new Date().toISOString().replace(/[:.]/g, "-");
  const backupPath = path.join(dir, `${base}.bak.${ts}`);
  fs.copyFileSync(dbPath, backupPath);
  return backupPath;
}

function detectPresetColumns(db) {
  // columns in presets table
  const cols = db.prepare(`PRAGMA table_info(presets)`).all().map(r => r.name);
  return cols;
}

function getPresetByIdOrName(db, presetId, presetName) {
  if (presetId) {
    const row = db.prepare(`SELECT * FROM presets WHERE id = ?`).get(presetId);
    return row || null;
  }
  if (presetName) {
    // exact match
    const row = db.prepare(`SELECT * FROM presets WHERE name = ?`).get(presetName);
    return row || null;
  }
  return null;
}

function listPresets(db) {
  const cols = detectPresetColumns(db);
  const hasCharacterName = cols.includes("characterName");
  const sel = hasCharacterName ? `id, name, characterName` : `id, name`;
  const rows = db.prepare(`SELECT ${sel} FROM presets ORDER BY name ASC`).all();
  for (const r of rows) {
    if (hasCharacterName) {
      console.log(`${r.id}  |  ${r.name ?? ""}  |  ${r.characterName ?? ""}`);
    } else {
      console.log(`${r.id}  |  ${r.name ?? ""}`);
    }
  }
}

function ensureLorebooksColumn(db) {
  const cols = detectPresetColumns(db);
  if (!cols.includes("lorebooks")) {
    throw new Error(
      `DB presets table has no 'lorebooks' column.\n` +
      `You are likely pointing to the wrong DB file. Expected: ai/data/data.sqlite3`
    );
  }
}

function main() {
  const args = parseArgs(process.argv);

  if (args["help"] || args["h"]) {
    usage();
    process.exit(0);
  }

  const dbPath = guessDbPath(args["db"]);
  const max = Number(args["max"] ?? 100);
  const dryRun = !!args["dry-run"];
  const presetId = typeof args["presetId"] === "string" ? args["presetId"] : null;
  const presetName = typeof args["presetName"] === "string" ? args["presetName"] : null;
  const txtPath = typeof args["txt"] === "string" ? args["txt"] : null;
  const listOnly = !!args["list-presets"];
  const keysMode = (args["keysMode"] === "fullTitle") ? "fullTitle" : "firstToken";

  if (!fs.existsSync(dbPath)) {
    console.error(`DB not found: ${dbPath}`);
    process.exit(1);
  }

  const db = new Database(dbPath);

  try {
    if (listOnly) {
      console.log(`DB: ${dbPath}`);
      listPresets(db);
      return;
    }

    if (!txtPath || !fs.existsSync(txtPath)) {
      console.error(`TXT not found: ${txtPath}`);
      usage();
      process.exit(1);
    }

    if (!presetId && !presetName) {
      console.error(`Need --presetId or --presetName`);
      usage();
      process.exit(1);
    }

    ensureLorebooksColumn(db);

    const preset = getPresetByIdOrName(db, presetId, presetName);
    if (!preset) {
      console.error(`Preset not found. Use --list-presets to find id/name.`);
      process.exit(1);
    }

    const text = fs.readFileSync(txtPath, "utf-8");
    const sections = parseSections(text);

    const items = [];
    let order = 0;
    for (const s of sections) {
      if (order >= max) break;
      const name = normalizeTitle(s.title);
      const key = makeActivationKey(s.title, keysMode);
      const id = crypto.randomUUID();

      items.push({
        id,
        name,
        content: s.content,
        activationKeys: key ? [key] : [],
        order,
        isOpen: false
      });

      order++;
    }

    console.log(`DB: ${dbPath}`);
    console.log(`Target preset: id=${preset.id} name=${preset.name ?? ""}`);
    console.log(`Parsed lore items: ${items.length} (keysMode=${keysMode}, max=${max})`);

    // Quick preview first 3
    for (const it of items.slice(0, 3)) {
      console.log(`- [${it.order}] name="${it.name}" key="${it.activationKeys?.[0] ?? ""}" contentLen=${it.content.length}`);
    }

    if (dryRun) {
      console.log(`DRY RUN: not writing DB.`);
      return;
    }

    const backupPath = backupDb(dbPath);
    console.log(`Backup created: ${backupPath}`);

    const lorebooksJson = JSON.stringify(items);

    const stmt = db.prepare(`UPDATE presets SET lorebooks = ? WHERE id = ?`);
    const info = stmt.run(lorebooksJson, preset.id);

    console.log(`UPDATE done. changes=${info.changes}`);
  } finally {
    db.close();
  }
}

main();

