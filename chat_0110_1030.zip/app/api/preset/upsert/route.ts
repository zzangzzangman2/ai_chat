import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser } from "@/lib/auth";
import { randomUUID } from "crypto";

type Body = {
  isPublic?: number | boolean;
  id?: string;
  name: string;
  background: string;
  characterName: string;
  characterAge: number;
  character: string;
  systemPrompt: string;
};

function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}

export async function POST(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const body = (await req.json()) as Body;

  const name = (body.name || "").trim();
  const background = (body.background || "").trim();
  const characterName = (body.characterName || "").trim();
  const characterAge = Number(body.characterAge || 0);
  const character = (body.character || "").trim();
  const systemPrompt = (body.systemPrompt || "").trim();

  const isPublic = (body as any)?.isPublic === 0 || (body as any)?.isPublic === false ? 0 : 1;

  if (!name) return bad("프리셋 이름을 적어주세요.");
  if (!background) return bad("배경을 적어주세요.");
  if (!characterName) return bad("상대방 캐릭터 이름을 적어주세요.");
  if (!Number.isFinite(characterAge) || characterAge <= 0) return bad("상대방 나이를 올바르게 적어주세요.");
  if (!character) return bad("상대방 캐릭터(성격/말투/행동 원칙)를 적어주세요.");

  const now = Date.now();
  const id = body.id?.trim() || randomUUID();

  const exists = db.prepare(`SELECT 1 FROM presets WHERE id = ?`).get(id, u.email);

  if (exists) {
    db.prepare(
      `UPDATE presets
       SET name=?, background=?, characterName=?, characterAge=?, character=?, systemPrompt=?, isPublic=?
       WHERE id=? AND userEmail=?`
    ).run(name, background, characterName, characterAge, character, systemPrompt, isPublic, id, u.email);
  } else {
    db.prepare(
      `INSERT INTO presets (id, userEmail, name, background, characterName, characterAge, character, systemPrompt, createdAt, isPublic)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, u.email, name, background, characterName, characterAge, character, systemPrompt, now, isPublic);
  }

  const preset = db
    .prepare(
      `SELECT id, name, background, characterName, characterAge, character, systemPrompt, createdAt, COALESCE(isPublic,1) AS isPublic
       FROM presets WHERE id=? AND userEmail=?`
    )
    .get(id, u.email);

  return NextResponse.json({ preset });
}

