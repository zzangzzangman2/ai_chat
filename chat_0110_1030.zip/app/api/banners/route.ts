import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const rows = db
      .prepare(
        `SELECT id, imageUrl, linkUrl
         FROM banners_live
         WHERE isActive = 1
         ORDER BY sortOrder ASC, createdAt DESC`
      )
      .all();
    return NextResponse.json(
      { ok: true, banners: rows },
      { headers: { "Cache-Control": "no-store" } }
    );
  } catch (e: any) {
    // banners 테이블이 아직 없을 수 있으므로 안전하게 처리
    return NextResponse.json(
      { ok: true, banners: [] },
      { headers: { "Cache-Control": "no-store" } }
    );
  }
}
