import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  throw new Error("GEMINI_API_KEY가 .env.local에 없습니다.");
}

export const genai = new GoogleGenAI({ apiKey });

export type ChatGenOpts = {
  model: string;
  maxOutputTokens: number;
  maxReasoningTokens: number;
};

function normalizeModelName(model: string) {
  const m = String(model || "").trim();
  if (!m) return "";
  // Some routers/providers prefix models like "google/gemini-3-pro-preview".
  const slash = m.lastIndexOf("/");
  return slash >= 0 ? m.slice(slash + 1) : m;
}

function isGemini3Pro(model: string) {
  const m = normalizeModelName(model);
  return m === "gemini-3-pro" || m.startsWith("gemini-3-pro-");
}

type ThinkingConfigAny = { thinkingBudget?: number; thinkingLevel?: string };

function buildThinkingConfig(model: string, maxReasoningTokens: number): ThinkingConfigAny | null {
  // Requirement:
  // - Gemini 2.5 / Gemini 3 Flash: keep numeric (thinkingBudget)
  // - Gemini 3 Pro: map UI low/middle/high preset to thinkingLevel (low/high)
  //   (Gemini 3 Pro supports thinkingLevel: "low" | "high")
  // Ref: https://ai.google.dev/gemini-api/docs/thinking
  if (isGemini3Pro(model)) {
    const t = Math.max(0, Number(maxReasoningTokens) || 0);
    // UI presets (gemini-3*): low=512, middle=1024, high=1536.
    // Map: low -> low, middle/high -> high.
    const level = t <= 768 ? "low" : "high";
    return { thinkingLevel: level };
  }

  const budget = Math.max(0, Number(maxReasoningTokens) || 0);
  if (!budget) return null;
  return { thinkingBudget: budget };
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T | null> {
  return await Promise.race([
    p,
    new Promise((res) => setTimeout(() => res(null), Math.max(0, ms))),
  ]) as any;
}

function extractHttpStatus(err: any): number | null {
  const e = err || {};
  const cand = [
    e?.status,
    e?.code,
    e?.response?.status,
    e?.cause?.status,
    e?.cause?.code,
    e?.cause?.response?.status,
  ];
  for (const v of cand) {
    const n = Number(v);
    if (Number.isFinite(n) && n >= 100 && n <= 599) return Math.floor(n);
  }
  const msg = String(e?.message || e || "");
  const m = msg.match(/\b(429|500|502|503|504)\b/);
  if (m) return Number(m[1]);
  return null;
}

function isRetryableGeminiError(err: any) {
  const s = extractHttpStatus(err);
  // Typical transient classes: quota/rate (429), backend (5xx).
  return s === 429 || s === 500 || s === 502 || s === 503 || s === 504;
}

async function withRetry<T>(fn: () => Promise<T>, opts: { maxRetries: number; baseDelayMs: number; label?: string }) {
  let attempt = 0;
  let lastErr: any = null;
  while (attempt <= opts.maxRetries) {
    try {
      const value = await fn();
      return { value, retries: attempt };
    } catch (e: any) {
      lastErr = e;
      if (!isRetryableGeminiError(e) || attempt >= opts.maxRetries) throw e;
      const backoff = opts.baseDelayMs * Math.pow(2, attempt);
      const jitter = Math.floor(Math.random() * Math.max(50, opts.baseDelayMs));
      await sleep(backoff + jitter);
      attempt += 1;
      continue;
    }
  }
  // unreachable
  throw lastErr;
}

function isChatDebug() {
  // 로깅만 추가: 기존 기능/출력에는 영향 없음
  return String(process.env.CHAT_DEBUG || "").trim() === "1";
}

function safeLen(v: any) {
  return Array.from(String(v ?? "")).length;
}

function safePreview(v: any, max = 180) {
  const s = String(v ?? "");
  if (s.length <= max) return s;
  return s.slice(0, max) + "…";
}

export async function generateText(params: {
  system: string;
  user: string;
  opts: ChatGenOpts;
}) {
  const { system, user, opts } = params;

  const t0 = Date.now();

  // 일부 모델/SDK 조합에서 thinkingConfig가 지원되지 않아 500이 나는 케이스가 있어
  // 1차: thinkingConfig 포함
  // 2차(실패 시): thinkingConfig 제거
  const baseReq: any = {
    model: opts.model,
    contents: [{ role: "user", parts: [{ text: user }] }],
    config: {
      systemInstruction: system,
      maxOutputTokens: opts.maxOutputTokens,
    },
  };

  const thinkingConfig = buildThinkingConfig(opts.model, opts.maxReasoningTokens);
  const withThinking: any = thinkingConfig
    ? {
        ...baseReq,
        config: {
          ...baseReq.config,
          thinkingConfig,
        },
      }
    : null;

  let resp: any;
  let lastErr: any = null;
  const attempts: Array<{ label: string; ok: boolean; ms: number; err?: string }> = [];
  const reqs: Array<{ label: string; req: any }> = withThinking
    ? [
        { label: "withThinking", req: withThinking },
        { label: "base", req: baseReq },
      ]
    : [{ label: "base", req: baseReq }];

  if (isChatDebug()) {
    console.log(
      JSON.stringify({
        tag: "gemini.req",
        model: opts.model,
        maxOutputTokens: opts.maxOutputTokens,
        thinkingBudget: thinkingConfig?.thinkingBudget ?? null,
        thinkingLevel: thinkingConfig?.thinkingLevel ?? null,
        systemChars: safeLen(system),
        userChars: safeLen(user),
        systemPreview: safePreview(system),
        userPreview: safePreview(user),
      })
    );
  }

  for (const it of reqs) {
    const tAttempt = Date.now();
    try {
      const r = await withRetry(() => genai.models.generateContent(it.req), {
        maxRetries: 2,
        baseDelayMs: 650,
        label: it.label,
      });
      resp = r.value as any;
      lastErr = null;
      attempts.push({ label: it.label, ok: true, ms: Date.now() - tAttempt });
      break;
    } catch (e: any) {
      lastErr = e;
      attempts.push({ label: it.label, ok: false, ms: Date.now() - tAttempt, err: String(e?.message || e || "") });
    }
  }
  if (!resp) {
    const msg = String(lastErr?.message || lastErr || "Gemini API error");
    // Next.js route에서 그대로 500으로 던지지 말고, 원인 파악이 가능한 에러로 만든다.
    throw new Error(msg);
  }

  const latencyMs = Date.now() - t0;

  const text =
    resp?.text ??
    resp?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
    "";

  const usage = resp?.usageMetadata || resp?.usage || null;
  const finishReason =
    resp?.candidates?.[0]?.finishReason ??
    resp?.candidates?.[0]?.finish_reason ??
    resp?.finishReason ??
    resp?.finish_reason ??
    null;

  // Google 응답 포맷이 조금씩 달라질 수 있어 폭넓게 매핑
  const promptTokens = Number(usage?.promptTokenCount ?? usage?.prompt_tokens ?? 0) || 0;
  const outputTokens = Number(usage?.candidatesTokenCount ?? usage?.output_tokens ?? usage?.completion_tokens ?? 0) || 0;
  // thinking/reasoning 토큰(모델/SDK별 키가 다를 수 있어 폭넓게 매핑)
  const reasoningTokens =
    Number(
      usage?.thoughtsTokenCount ??
        usage?.reasoningTokenCount ??
        usage?.native_tokens_reasoning ??
        usage?.reasoning_tokens ??
        0
    ) || 0;

  const totalTokens = Number(usage?.totalTokenCount ?? usage?.total_tokens ?? 0) || (promptTokens + outputTokens + reasoningTokens);

  if (isChatDebug()) {
    console.log(
      JSON.stringify({
        tag: "gemini.resp",
        model: opts.model,
        latencyMs,
        attempts,
        finishReason,
        usage: {
          promptTokens,
          outputTokens,
          reasoningTokens,
          totalTokens,
        },
        textPreview: safePreview(text, 240),
      })
    );
  }

  return {
    text: String(text || "").trim(),
    usage: {
      promptTokens,
      outputTokens,
      reasoningTokens,
      totalTokens,
      latencyMs,
      model: opts.model,
      finishReason,
    },
  };
}


export async function generateTextStream(params: {
  system: string;
  user: string;
  opts: ChatGenOpts;
}): Promise<{ stream: AsyncIterable<string>; final: Promise<{ text: string; usage: any }> }> {
  const { system, user, opts } = params;

  const baseReq: any = {
    model: opts.model,
    contents: [{ role: "user", parts: [{ text: user }] }],
    config: {
      systemInstruction: system,
      maxOutputTokens: opts.maxOutputTokens,
    },
  };
  const thinkingConfig = buildThinkingConfig(opts.model, opts.maxReasoningTokens);
  const withThinking: any = thinkingConfig
    ? {
        ...baseReq,
        config: {
          ...baseReq.config,
          thinkingConfig,
        },
      }
    : null;

  const reqs: Array<{ label: string; req: any }> = withThinking
    ? [
        { label: "withThinking", req: withThinking },
        { label: "base", req: baseReq },
      ]
    : [{ label: "base", req: baseReq }];

  const streamFn = (genai.models as any)?.generateContentStream;
  if (typeof streamFn === "function") {
    for (const it of reqs) {
      try {
        // Gemini-3-pro-preview can fail transiently (429/5xx) more often, especially in streaming.
        // Retry ONLY before any token is emitted (i.e., when the stream hasn't started producing output).
        let streamLike: any = null;
        let responsePromiseRef: Promise<any> = Promise.resolve(null);
        let responseVersion = 0;

        const startStream = async () => {
          responseVersion += 1;
          const r = await withRetry(() => streamFn.call(genai.models, it.req), {
            maxRetries: 2,
            baseDelayMs: 650,
            label: it.label,
          });
          const streamResp: any = r.value;
          streamLike = streamResp?.stream ?? streamResp;
          responsePromiseRef = streamResp?.response
            ? Promise.resolve(streamResp.response)
            : streamResp?.getFinalResponse
              ? Promise.resolve(streamResp.getFinalResponse())
              : Promise.resolve(null);
          return r.retries;
        };

        await startStream();

        const getStableFinalResponse = async () => {
          // If responsePromiseRef is replaced due to a retry, make sure we return the latest one.
          while (true) {
            const v = responseVersion;
            const p = responsePromiseRef;
            const r = await p.catch(() => null);
            if (v === responseVersion) return r;
          }
        };

        function extractText(obj: any): string {
          return (
            obj?.text ??
            obj?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
            ""
          );
        }

        function isIgnorableChar(ch: string): boolean {
          // Invisible separator (U+2063) is used for speaker marks; treat as ignorable for prefix matching.
          // Also ignore BOM and CR to reduce false mismatches across SDK chunk boundaries.
          return ch === "\u2063" || ch === "\ufeff" || ch === "\r";
        }

        function matchPrefixIgnore(acc: string, t: string): number {
          // Try to match full `acc` as a prefix of `t` while ignoring certain characters in both strings.
          // Returns the raw index in `t` right after the matched prefix, or -1 if not matched.
          let ia = 0;
          let it = 0;

          const la = acc.length;
          const lt = t.length;

          while (ia < la || it < lt) {
            while (ia < la && isIgnorableChar(acc[ia])) ia++;
            while (it < lt && isIgnorableChar(t[it])) it++;

            if (ia >= la) {
              // Remaining acc are ignorable; prefix matched.
              return it;
            }
            if (it >= lt) return -1;

            if (acc[ia] !== t[it]) return -1;

            ia++;
            it++;
          }

          return ia >= la ? it : -1;
        }

        async function* iter() {
          // SDK/모델 조합에 따라 chunk.text가 "누적 텍스트"로 올 수도 있고 "delta"로 올 수도 있다.
          // - 누적이면: 앞부분(acc)과의 차이만(delta) 내보낸다.
          // - delta이면: 그대로 내보낸다.
          let acc = "";
          let restarts = 0;

          while (true) {
            try {
              for await (const chunk of streamLike as any) {
                const t = String(extractText(chunk) || "");
                if (!t) continue;

                let delta = t;
                if (t.startsWith(acc)) {
                  delta = t.slice(acc.length);
                }
                acc += delta;
                if (delta) yield String(delta);
              }
              break;
            } catch (e: any) {
              // If the stream errors out BEFORE producing any text, treat it as transient and retry a few times.
              if (acc.length === 0 && restarts < 2 && isRetryableGeminiError(e)) {
                restarts += 1;
                const backoff = 650 * Math.pow(2, restarts - 1);
                const jitter = Math.floor(Math.random() * 200);
                await sleep(backoff + jitter);
                await startStream();
                continue;
              }
              throw e;
            }
          }

          // 일부 환경에서는 스트림 종료 후 final response에만 남은 tail이 포함될 수 있다.
          // 이 경우, tail을 추가 delta로 흘려보내 UI에서 "중간 끊김 + 한 번에 나머지" 현상을 줄인다.
          try {
            const finalResp = await withTimeout(getStableFinalResponse(), 220);
            const finalText = String(extractText(finalResp) || "");
            if (finalText) {
              let cut = -1;
              if (finalText.startsWith(acc)) cut = acc.length;
              else if (acc) cut = matchPrefixIgnore(acc, finalText);
              if (cut >= 0 && finalText.length > cut) {
                const tail = finalText.slice(cut);
                acc += tail;
                if (tail) yield String(tail);
              }
            }
          } catch {
            // ignore
          }
        }

        const final = (async () => {
          const finalResp = await withTimeout(getStableFinalResponse(), 1200);
          if (!finalResp) {
            const r = await generateText({ system, user, opts });
            return r;
          }
          const text =
            finalResp?.text ??
            finalResp?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
            "";
          const usage = finalResp?.usageMetadata || finalResp?.usage || null;

          const promptTokens = Number(usage?.promptTokenCount ?? usage?.prompt_tokens ?? 0) || 0;
          const outputTokens =
            Number(usage?.candidatesTokenCount ?? usage?.output_tokens ?? usage?.completion_tokens ?? 0) || 0;
          const reasoningTokens =
            Number(
              usage?.thoughtsTokenCount ??
                usage?.reasoningTokenCount ??
                usage?.native_tokens_reasoning ??
                usage?.reasoning_tokens ??
                0
            ) || 0;
          const totalTokens =
            Number(usage?.totalTokenCount ?? usage?.total_tokens ?? 0) ||
            promptTokens + outputTokens + reasoningTokens;

          return {
            text: String(text || "").trim(),
            usage: {
              promptTokens,
              outputTokens,
              reasoningTokens,
              totalTokens,
              latencyMs: 0,
              model: opts.model,
              finishReason: null,
            },
          };
        })();

        return { stream: iter(), final };
      } catch {
        // try next request variant
      }
    }
  }

  // fallback: non-stream call then chunk
  const r = await generateText({ system, user, opts });
  async function* chunker() {
    const s = String(r.text || "");
    const step = 64;
    for (let i = 0; i < s.length; i += step) {
      yield s.slice(i, i + step);
    }
  }
  return { stream: chunker(), final: Promise.resolve(r) };
}

export async function summarizeKorean(params: {
  text: string;
  targetChars: number;
  opts: ChatGenOpts;
  turnRangeLabel?: string;
  perTurnChars?: number;
  guidance?: string;
}) {
  const { text, targetChars, opts, turnRangeLabel, perTurnChars, guidance } = params;

  const rangeLabel = String(turnRangeLabel || "이번 구간");

  // Keep ai.ts self-contained (avoid importing server-only sanitizers).
  // We still remove obvious noise that harms summarization quality.
  let cleanDialogue = String(text || "");
  // Drop fenced blocks (INFO/status/logs)
  cleanDialogue = cleanDialogue.replace(/```[\s\S]*?```/g, "");
  // Drop markdown images/links
  cleanDialogue = cleanDialogue.replace(/!\[[^\]]*\]\([^\)]+\)/g, "");
  cleanDialogue = cleanDialogue.replace(/\[[^\]]*\]\([^\)]+\)/g, "");
  // Drop raw URLs
  cleanDialogue = cleanDialogue.replace(/https?:\/\/\S+/g, "");
  // Drop lines that become just punctuation artifacts (e.g., '!!' / '!')
  cleanDialogue = cleanDialogue
    .split("\n")
    .filter((ln) => {
      const t = ln.trim();
      if (!t) return false;
      if (/^[!\-_=~.]+$/.test(t)) return false;
      return true;
    })
    .join("\n")
    .trim();

  const system = `너는 장기기억(롱텀 메모리) 요약 작가다. 한국어로만 답하고, 아래 출력 형식을 정확히 지킨다.`;
  const user = `아래 [대화]를 기반으로 장기 기억 요약을 작성해줘.

출력 형식(절대 준수):
1) 첫 줄은 정확히 다음 한 줄로 시작한다: ## 장기 기억 (${rangeLabel})
2) 그 다음 줄은 빈 줄 1개
3) 이어서 **2~6문장**의 서술형 요약을 쓴다. 각 문장은 완결형으로 끝내라.
4) (매우 중요) 요약에 **직접 대사**, **인용**, **화자 표기**(예: "주인공 |", "NPC:"), **따옴표**( " “ ” ‘ ’ )를 절대 쓰지 마라.
5) (매우 중요) **추가 헤딩(### 등)**, 불릿/번호 목록, 코드블록(\`\`\`), 링크/URL, 마크다운(![](), []())을 절대 쓰지 마라.
6) 분량은 가능하면 약 ${targetChars}자(±15%)로 맞추되, 너무 짧게 끝내지 말고 최소 ${Math.max(200, Math.floor(targetChars * 0.80))}자 이상을 목표로 하라.

[대화]
${cleanDialogue}`;

  const r = await generateText({ system, user, opts });
  return r.text;
}

